export interface JobRequirement {
  level: string; // e.g. "Idéal", "Acceptable"
  education: string[];
  experience: string[];
}

export interface JobCandidateGroup {
  candidates: string[];
  requirements: JobRequirement[];
}

export interface JobDetails {
  force: string;
  candidateGroups: JobCandidateGroup[];
  notes: string[];
}

export interface MedicalStandard {
  v: number;
  cv: number;
  h: number;
  g: number;
  o: number;
  a: number;
  u: number;
}

export type JobCategory = 'officier' | 'mr';

export interface EntryProgramsDatabase {
  regularForceNCM: string[];
  regularForceOfficer: string[];
  all: string[];
}

export const REGULAR_FORCE_NCM_PROGRAMS: string[] = [
  "EER",
  "Non Qual",
  "PFACA",
  "PFS-MR",
  "Qual",
  "Semi-Qual",
];

export const REGULAR_FORCE_OFFICER_PROGRAMS: string[] = [
  "EDO",
  "EDO(ES-PMNE)",
  "PFACA",
  "PFAM",
  "PFDM",
  "PFOEP",
  "PFOR",
  "PIMM",
];

export const ALL_ENROLLMENT_PROGRAMS: string[] = [
  "EDO",
  "EDO(ES-PMNE)",
  "EER",
  "MGC",
  "Non Qual",
  "PFACA",
  "PFAM",
  "PFDM",
  "PFIR",
  "PFOEP",
  "PFOR",
  "PFS-MR",
  "PIMM",
  "PIRO",
  "Qual",
  "RC",
  "Rés CO-OP",
  "Rés supp",
  "SAIOC",
  "Semi-Qual",
];

export const ENTRY_PROGRAMS_DATABASE: EntryProgramsDatabase = {
  regularForceNCM: REGULAR_FORCE_NCM_PROGRAMS,
  regularForceOfficer: REGULAR_FORCE_OFFICER_PROGRAMS,
  all: ALL_ENROLLMENT_PROGRAMS,
};

export type MilitaryElement = 'Air' | 'Armée' | 'Marine' | 'CMP';

export const JOB_ELEMENTS_MAP: Record<string, MilitaryElement> = {
  // Métiers militaires du rang (MR)
  "00005": "Armée",
  "00010": "Armée",
  "00019": "Air",
  "00099": "CMP",
  "00100": "CMP",
  "00105": "Marine",
  "00109": "Air",
  "00114": "Marine",
  "00115": "Marine",
  "00120": "CMP",
  "00129": "Armée",
  "00130": "Armée",
  "00134": "Armée",
  "00135": "Air",
  "00136": "Air",
  "00137": "CMP",
  "00138": "Air",
  "00149": "Air",
  "00152": "CMP",
  "00153": "CMP",
  "00155": "CMP",
  "00161": "CMP",
  "00164": "CMP",
  "00166": "CMP",
  "00167": "CMP",
  "00168": "CMP",
  "00169": "CMP",
  "00170": "CMP",
  "00171": "CMP",
  "00238": "Armée",
  "00261": "Air",
  "00299": "Marine",
  "00301": "Air",
  "00302": "Air",
  "00303": "Air",
  "00304": "Air",
  "00305": "Air",
  "00306": "Air",
  "00324": "Marine",
  "00327": "Armée",
  "00335": "CMP",
  "00337": "Air",
  "00339": "Armée",
  "00366": "Marine",
  "00368": "Armée",
  "00370": "Air",
  "00372": "CMP",
  "00375": "CMP",
  "00376": "CMP",
  "00378": "CMP",
  "00383": "Armée",
  "00384": "Armée",
  "00385": "Armée",
  "00386": "Air",
  "00387": "Armée",
  "00394": "Air",
  "00402": "Marine",
  "00404": "Marine",
  "00405": "Marine",
  "00406": "CMP",
  "00407": "CMP",

  // Métiers d'officiers
  "00178": "Armée",
  "00179": "Armée",
  "00180": "Armée",
  "00181": "Armée",
  "00182": "Air",
  "00183": "Air",
  "00184": "Air",
  "00185": "Air",
  "00187": "Armée",
  "00189": "Air",
  "00190": "CMP",
  "00191": "CMP",
  "00194": "CMP",
  "00195": "CMP",
  "00197": "CMP",
  "00198": "CMP",
  "00203": "CMP",
  "00204": "CMP",
  "00207": "Marine",
  "00208": "CMP",
  "00211": "CMP",
  "00213": "CMP",
  "00214": "CMP",
  "00328": "CMP",
  "00340": "Air",
  "00341": "Armée",
  "00344": "Marine",
  "00345": "Marine",
  "00349": "CMP",
  "00374": "CMP",
  "00389": "Air",
  "00390": "CMP",
  "00393": "CMP",
  "00398": "CMP",
};

export interface RecruitmentCenter {
  city: string;
  name: string;
  nameEn: string;
  address: string;
  fullFr: string;
  fullEn: string;
}

export const RECRUITMENT_CENTERS: RecruitmentCenter[] = [
  {
    city: "Québec",
    name: "Centre de recrutement des Forces armées canadiennes - détachement Québec",
    nameEn: "Canadian Forces Recruiting Centre - Detachment Quebec",
    address: "2575 boulevard Sainte-Anne, bureau 120, Québec, QC, G1J 0G7",
    fullFr: "Centre de recrutement des Forces armées canadiennes - détachement Québec\n2575 boulevard Sainte-Anne, bureau 120, Québec, QC, G1J 0G7",
    fullEn: "Canadian Forces Recruiting Centre - Detachment Quebec\n2575 boulevard Sainte-Anne, bureau 120, Québec, QC, G1J 0G7",
  },
  {
    city: "Sherbrooke",
    name: "Centre de recrutement des Forces armées canadiennes - détachement Sherbrooke",
    nameEn: "Canadian Forces Recruiting Centre - Detachment Sherbrooke",
    address: "50 Place de la Cité, 315 King Ouest, Sherbrooke, Québec, J1H 4G9",
    fullFr: "Centre de recrutement des Forces armées canadiennes - détachement Sherbrooke\n50 Place de la Cité, 315 King Ouest, Sherbrooke, Québec, J1H 4G9",
    fullEn: "Canadian Forces Recruiting Centre - Detachment Sherbrooke\n50 Place de la Cité, 315 King Ouest, Sherbrooke, Québec, J1H 4G9",
  },
  {
    city: "Montréal",
    name: "Centre de recrutement des Forces armées canadiennes - détachement Montréal",
    nameEn: "Canadian Forces Recruiting Centre - Detachment Montreal",
    address: "1600 Boul Rene-Levesque O, Montreal, QC, H3H1P9",
    fullFr: "Centre de recrutement des Forces armées canadiennes - détachement Montréal\n1600 Boul Rene-Levesque O, Montreal, QC, H3H1P9",
    fullEn: "Canadian Forces Recruiting Centre - Detachment Montreal\n1600 Boul Rene-Levesque O, Montreal, QC, H3H1P9",
  },
  {
    city: "Rimouski",
    name: "Centre de recrutement des Forces armées canadiennes - détachement Rimouski",
    nameEn: "Canadian Forces Recruiting Centre - Detachment Rimouski",
    address: "70 Rue St-Germain Est, Rimouski, QC, G5L 7J9",
    fullFr: "Centre de recrutement des Forces armées canadiennes - détachement Rimouski\n70 Rue St-Germain Est, Rimouski, QC, G5L 7J9",
    fullEn: "Canadian Forces Recruiting Centre - Detachment Rimouski\n70 Rue St-Germain Est, Rimouski, QC, G5L 7J9",
  },
  {
    city: "Chicoutimi",
    name: "Centre de recrutement des Forces armées canadiennes - détachement Chicoutimi",
    nameEn: "Canadian Forces Recruiting Centre - Detachment Chicoutimi",
    address: "345 des Saguenéens, Chicoutimi, QC, G7H 6K9",
    fullFr: "Centre de recrutement des Forces armées canadiennes - détachement Chicoutimi\n345 des Saguenéens, Chicoutimi, QC, G7H 6K9",
    fullEn: "Canadian Forces Recruiting Centre - Detachment Chicoutimi\n345 des Saguenéens, Chicoutimi, QC, G7H 6K9",
  },
];

export const ENROLMENT_HOURS: string[] = [
  "6h00", "6h15", "6h30", "6h45",
  "7h00", "7h15", "7h30", "7h45",
  "8h00", "8h15", "8h30", "8h45",
  "9h00", "9h15", "9h30", "9h40", "9h45",
  "10h00", "10h15", "10h30", "10h45",
  "11h00", "11h15", "11h30", "11h45",
  "12h00", "12h15", "12h30", "12h45",
  "13h00", "13h15", "13h30", "13h45",
  "14h00", "14h15", "14h30", "14h45",
  "15h00", "15h15", "15h30", "15h45",
  "16h00"
];

export interface JobEntry {
  medicalStandard?: MedicalStandard;
  id: string;
  title: string;
  titleEn?: string;
  abbreviation: string;
  category?: JobCategory;
  element?: MilitaryElement;
  isCMP?: boolean;
  entryPrograms?: string[];
  requirements: string;
  htmlContent?: string;
  details?: JobDetails[];
  contracts?: { program: string; duration: string }[];
  urlFr?: string;
  urlEn?: string;
}

export const JOBS_DATA: JobEntry[] = [
  {
    id: "00003",
    title: "SANS MÉTIER",
    titleEn: "NON-COMMISSIONED MEMBER",
    abbreviation: "MIL RANG",
    requirements:
      "Ce code indique qu'aucun métier n'a été sélectionné au dossier.",
    details: [],
    contracts: [],
  },
  {
    id: "00005",
    medicalStandard: { v: 3, cv: 3, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "MILITAIRE DU RANG BLINDÉS",
    abbreviation: "MR BLINDÉS",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme d’études secondaires ou équivalent (Idéal) ou 10e année / Secondaire IV (Acceptable). Permis de conduire valide.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "MÉ 1", "RECL 1"],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou équivalent"],
                experience: [
                  "Permis de conduire d’une province/d’un territoire en règle 2",
                ],
              },
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Permis de conduire d’une province/d’un territoire en règle 2",
                ],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "MÉ 1", "RECL 1 (qualifié)"],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou équivalent"],
                experience: [
                  "Permis de conduire d’une province/d’un territoire en règle 2",
                  "Atteinte du Niveau professionnel de compétence (NPC) dans 00005 MR BLINDÉS",
                ],
              },
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Permis de conduire d’une province/d’un territoire en règle 2",
                  "Atteinte du Niveau professionnel de compétence (NPC) dans 00005 MR BLINDÉS",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le candidat doit détenir ou être en mesure d’obtenir un permis de conduire d’une province ou d’un territoire (de classe G ou 5) en règle, sans condition restrictive et sans infraction en matière de conduite qui limiterait l’entièreté de ses privilèges de conduite. Il est reconnu que certains candidats peuvent ne pas être admissibles à un permis pleinement gradué au moment de la demande en raison des règlements provinciaux/territoriaux relatifs à l’âge et aux délais. Ces candidats qui n’ont pas encore obtenu un permis pleinement gradué doivent le faire dès que la réglementation le permet, pendant ou après leur inscription.",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
        ],
      },
      {
        force: "FORCE DE LA RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "MÉ 1", "RECL 1"],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou équivalent"],
                experience: [
                  "Permis de conduire d’une province/d’un territoire en règle 2",
                ],
              },
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Permis de conduire d’une province/d’un territoire en règle 2",
                ],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "MÉ 1", "RECL 1 (qualifié)"],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou équivalent"],
                experience: [
                  "Permis de conduire d’une province/d’un territoire en règle 2",
                  "Atteinte du Niveau professionnel de compétence (NPC) dans 00005 MR BLINDÉS",
                ],
              },
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Permis de conduire d’une province/d’un territoire en règle 2",
                  "Atteinte du Niveau professionnel de compétence (NPC) dans 00005 MR BLINDÉS",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le candidat doit détenir ou être en mesure d’obtenir un permis de conduire d’une province ou d’un territoire (de classe G ou 5) en règle, sans condition restrictive et sans infraction en matière de conduite qui limiterait l’entièreté de ses privilèges de conduite. Il est reconnu que certains candidats peuvent ne pas être admissibles à un permis pleinement gradué au moment de la demande en raison des règlements provinciaux/territoriaux relatifs à l’âge et aux délais. Ces candidats qui n’ont pas encore obtenu un permis pleinement gradué doivent le faire dès que la réglementation le permet, pendant ou après leur inscription.",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "3 ans",
      },
    ],
  },
  {
    id: "00010",
    medicalStandard: { v: 3, cv: 3, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "FANTASSIN",
    abbreviation: "FANT",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme d’études secondaires, de Secondaires V au Québec ou l’équivalent (Idéal) ou 10e année secondaire, Secondaire IV au Québec ou l’équivalent (Acceptable).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1, 2", "RECL 1, 2", "MÉ 1, 2"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires, de Secondaires V au Québec ou l’équivalent",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année secondaire, Secondaire IV au Québec ou l’équivalent",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: [
              "Candidat civil 1, 2",
              "RECL 1, 2",
              "MÉ 1, 2",
              "(tous en service actif ou avec service antérieur comme 00010 FANT)",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires, de Secondaires V au Québec ou l’équivalent",
                ],
                experience: [
                  "Avoir atteint le niveau opérationnel de compétence (NOC) 3 du GPM 00010 FANT dans la F rég ou la P rés",
                  "QEL (comme fantassin ou l’équivalent)",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année secondaire, Secondaire IV au Québec ou l’équivalent",
                ],
                experience: [
                  "Avoir atteint le niveau opérationnel de compétence (NOC) 3 du GPM 00010 FANT dans la F rég ou la P rés",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces canadiennes (TAFC), s’ils ne l’ont pas déjà fait. Un candidat civil RECL ou MÉ qui n’a pas atteint le niveau opérationnel de compétence (NOC) comme 00010 FANT doit obtenir la note de passage du TAFC pour ce GPM. Se reporter à la Feuille de travail – Affectation (FTA) pour prendre connaissance des notes de passage en vigueur.",
          "2. Conformément aux critères d’enrôlement/RECL/MÉ en vigueur.",
          "3. Le niveau opérationnel de compétence (NOC) du GPM 00010 FANT se trouve dans la Description du GPM à l’adresse suivante: http://cmp-cpm.mil.ca/fr/soutien/personnel-militaire/dbpp-description-de-gpm.page.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: [
              "Candidat civil 1, 2",
              "RECL 1, 2",
              "MÉ 1, 2",
              "MSÉ 1, 2",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires, de Secondaires V au Québec ou l’équivalent",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année secondaire, Secondaire IV au Québec ou l’équivalent",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: [
              "Candidat civil 1, 2",
              "MÉ 1, 2",
              "MSÉ 1, 2",
              "(Tous en service actif ou avec service extérieur comme 00010 FANT)",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires, de Secondaires V au Québec ou l’équivalent",
                ],
                experience: [
                  "Avoir atteint au moin le NOC du GPM 00010 FANT dans la F rég ou la P rés",
                  "QEL (comme fantassin ou l’équivalent)",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année secondaire, Secondaire IV au Québec ou l’équivalent",
                ],
                experience: [
                  "Avoir atteint le niveau opérationnel de compétence (NOC) 3 du GPM 00010 FANT dans la F rég ou la P rés",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces canadiennes (TAFC), s’ils ne l’ont pas déjà fait. Un candidat civil RECL, MÉ ou MSÉ qui n’a pas atteint le niveau opérationnel de compétence (NOC) comme 00010 FANT doit obtenir la note de passage du TAFC pour ce GPM. Se reporter à la Feuille de travail – Affectation (FTA) pour prendre connaissance des notes de passage en vigueur.",
          "2. Conformément aux critères d’enrôlement/RECL/MÉ/MSÉ en vigueur.",
          "3. Le niveau opérationnel de compétence (NOC) du GPM 00010 FANT se trouve dans la Description du GPM à l’adresse suivante : http://cmp-cpm.mil.ca/fr/soutien/personnel-militaire/dbpp-description-de-gpm.page.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "3 ans",
      },
    ],
  },
  {
    id: "00019",
    medicalStandard: { v: 3, cv: 2, h: 2, g: 2, o: 2, a: 2, u: 5 },
    title: "OPÉRATEUR DE DÉTECTEURS ÉLECTRONIQUES AÉROPORTÉS",
    abbreviation: "OP DÉA",
    requirements:
      "FORCE RÉGULIÈRE: 12e année ayant les mathématiques avancées (niveau 10), ou Secondaire V (Québec) avec les mathématiques 426 ou 436 / SN IV/TS IV (Acceptable).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1,2", "RECL 1,2", "MÉ 1,2"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "12e année ayant les mathématiques avancées (niveau 10), ou Secondaire V (Québec) avec les mathématiques 426 ou 436 / SN IV/TS IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces canadiennes (TAFC), s’ils ne l’ont pas déjà fait. Consulter la Feuille de travail – Affectations (FTA) pour connaître les notes de passage en vigueur.",
          "2. Conformément aux critères d'enrôlement/RECL/MÉ en vigueur.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "7 ans",
      },
    ],
  },
  {
    id: "00099",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "SPÉCIALISTE DU RENSEIGNEMENT",
    abbreviation: "S RENS",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme d’études secondaires ou diplôme de Secondaire V au Québec, comportant: Cours d’anglais ou de français de la 12e année ou du Secondaire V au Québec.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: [
              "Candidat civil 1, 2, 3, 4",
              "RECL 1, 2, 3, 4",
              "MÉ 1, 2, 3, 4",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou diplôme de Secondaire V au Québec, comportant :",
                  "o Cours d’anglais ou de français de la 12e année ou du Secondaire V au Québec",
                ],
                experience: [
                  "Au moins un an d’expérience à temps partiel ou à temps plein à un poste ayant trait au renseignement... OU Avoir suivi avec succès le cours Opérations de traitement des sources (AIMC)...",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Tout Baccalauréat, certificat, ou Diplôme d'études postsecondaire",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "11e année du secondaire, diplôme de Secondaire V au Québec ou l’équivalent, comportant :",
                  "o Cours d’anglais ou de français de la 11e année ou du Secondaire V au Québec",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: [
              "Candidat civil 1, 2, 3, 4",
              "RECL 1, 2, 3, 4",
              "MÉ 1, 2, 3, 4",
              "(tous en service ou avec service antérieur comme 00099 S RENS )",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou diplôme de Secondaire V au Québec",
                ],
                experience: [
                  "Doit avoir atteint le niveau opérationnel de compétence (NOC) 6 dans la F rég ou la P rés comme 00099 S RENS",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "11e année du secondaire, diplôme de Secondaire V au Québec ou l’équivalent",
                ],
                experience: [
                  "Doit avoir atteint le niveau opérationnel de compétence (NOC) 6 dans la F rég ou la P rés comme 00099 S RENS",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces canadiennes (TAFC), s’ils ne l’ont pas déjà fait. Les candidats civils, RECL et MÉ qui ont atteint le NOC comme 00099 S RENS ne sont pas tenus d’obtenir la note du passage du TAFC. Consulter la Feuille de travail – Affectations (FTA) pour connaître les notes de passage en vigueur.",
          "2. Conformément aux critères d'enrôlement/RECL/MÉ en vigueur.",
          "3. Tous les candidats doivent être en mesure d’atteindre une cote de sécurité de niveau 3 (Très secret). La demande doit être engagée par l’entremise de l’officier de sécurité de l’unité du candidat avant le début du cours 00099 S RENS .",
          "4. Les Normes d'aptitude physique au travail (NAPT) sont énoncées dans la description des spécifications de travail (DST) S RENS au lien suivant : https://collaboration cmp.forces.mil.ca/sites/MPG/DPGR/dpgr2/SpecMaint/Occupational_Specifications/OFS/INT%20 OP%2000099/OFS_INT%20OP_F_00099_Anx_E.docx",
          "5. Les équivalences acceptables du cours Opérations de traitement des sources (AIMC) sont les suivantes : cours HUMINT, cours Opérations HUMINT en campagne, ou cours Spécialiste de l’exploitation des sources.",
          "6. Le niveau opérationnel de compétence (NOC) est expliqué dans la description de spécifications de travail du GPM 00099 S RENS à l’adresse suivante : http://cmp-cpm.mil.ca/fr/soutien/personnel-militaire/dbpp-description-de-gpm.page",
        ],
      },
      {
        force: "FORCE DE LA RÉSERVE",
        candidateGroups: [
          {
            candidates: [
              "Candidat civil 1, 2, 3, 4",
              "RECL 1, 2, 3, 4",
              "MÉ 1, 2, 3, 4",
              "MSÉ 1, 2, 3, 4",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou diplôme de Secondaire V au Québec, comportant :",
                  "o Cours d’anglais ou de français de la 12e année ou du Secondaire V au Québec",
                ],
                experience: [
                  "Au moins un an d’expérience à temps partiel ou à temps plein à un poste ayant trait au renseignement... OU Avoir suivi avec succès le cours Opérations de traitement des sources (AIMC)...",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Tout Baccalauréat ou Diplôme d'études postsecondaire",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "11e année du secondaire, diplôme de Secondaire V au Québec ou l’équivalent, comportant :",
                  "o Cours d’anglais ou de français de la 11e année ou du Secondaire V au Québec",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: [
              "Candidat civil 1, 2, 3, 4",
              "RECL 1, 2, 3, 4",
              "MÉ 1, 2, 3, 4",
              "MSÉ 1, 2, 3, 4",
              "(tous en service ou avec service antérieur comme 00099 S RENS )",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou diplôme de Secondaire V au Québec",
                ],
                experience: [
                  "Doit avoir atteint le niveau opérationnel de compétence (NOC) 6 dans la F rég ou la P rés comme 00099 S RENS",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "11e année du secondaire, diplôme de Secondaire V au Québec ou l’équivalent",
                ],
                experience: [
                  "Doit avoir atteint le niveau opérationnel de compétence (NOC) 6 dans la F rég ou la P rés comme 00099 S RENS",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces canadiennes (TAFC), s’ils ne l’ont pas déjà fait. Les candidats civils, RECL et MÉ qui ont atteint le NOC comme 00099 S RENS ne sont pas tenus d’obtenir la note du passage du TAFC. Consulter la Feuille de travail – Affectations (FTA) pour connaître les notes de passage en vigueur.",
          "2. Conformément aux critères d'enrôlement/RECL/MÉ/MSÉ en vigueur.",
          "3. Tous les candidats doivent être en mesure d’atteindre une cote de sécurité de niveau 3 (Très secret). La demande doit être engagée par l’entremise de l’officier de sécurité de l’unité du candidat avant le début du cours 00099 S RENS .",
          "4. Les Normes d'aptitude physique au travail (NAPT) sont énoncées dans la description des spécifications de travail (DST) S RENS au lien suivant : https://collaboration cmp.forces.mil.ca/sites/MPG/DPGR/dpgr2/SpecMaint/Occupational_Specifications/OFS/INT%20 OP%2000099/OFS_INT%20OP_F_00099_Anx_E.docx",
          "5. Les équivalences acceptables du cours Opérations de traitement des sources (AIMC) sont les suivantes : cours HUMINT, cours Opérations HUMINT en campagne et cours Spécialiste de l’exploitation des sources.",
          "6. Le niveau opérationnel de compétence (NOC) est expliqué dans la description de spécifications de travail du GPM 00099 S RENS à l’adresse suivante : http://cmp-cpm.mil.ca/fr/soutien/personnel-militaire/dbpp-description-de-gpm.page",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "5 ans",
      },
    ],
  },
  {
    id: "00100",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN EN MÉTÉOROLOGIE",
    abbreviation: "TECH MÉT",
    requirements:
      "FORCE RÉGULIÈRE: 11e année / Secondaire V ou l'équivalent, comportant: mathématiques appliquées de 11e année / Sec V, et tout cours de chimie ou de physique de 11e année / Sec V.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant :",
                  "o mathématiques appliquées de 11e année / Sec V",
                  "o Tout cours de chimie ou de physique de 11e année / Sec V",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "11e année / Secondaire V ou l’équivalent, comportant :",
                  "o mathématiques appliquées de 11e année / Sec V",
                  "o Tout cours de chimie ou de physique de 11e année / Sec V",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "(qualifié)"],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou l’équivalent"],
                experience: [
                  "Doit avoir obtenu la qualification de grade Cplc pour le GPM 00100 TECH MÉT dans la F rég",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "11e année / Secondaire V ou l’équivalent, comportant :",
                  "o mathématiques appliquées de 11e année / Sec V",
                  "o Tout cours de chimie ou de physique de 11e année / Sec V",
                ],
                experience: [
                  "Doit avoir atteint le niveau opérationnel de compétence (NPC) 2 dans la F rég comme 00100 TECH MÉT",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "5 ans",
      },
    ],
  },
  {
    id: "00105",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "MANŒUVRIER",
    abbreviation: "MAN",
    requirements:
      "FORCE RÉGULIÈRE & FORCE DE RÉSERVE: 10e année / Secondaire IV (Acceptable).",
    details: [
      {
        force: "FORCE RÉGULIÈRE & FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent comportant :",
                  "o mathématiques appliquées de 11e année / Sec V",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "(qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC) 2 du GPM MAN 00105",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
    ],
  },
  {
    id: "00109",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 3, o: 3, a: 5, u: 5 },
    title:
      "TECHNICIEN DES SYSTÈMES D’INFORMATION STRATÉGIQUES ET DE TÉLÉCOMMUNICATIONS AÉROSPATIALES",
    abbreviation: "TECH SITA",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: 10e année / Secondaire IV, comportant mathématiques appliquées, 10e année / Sec IV (Acceptable).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant :",
                  "o Mathématiques académiques de 11e année / Sec V",
                  "o Physique de 11e année / Sec V",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV, comportant :",
                  "o Mathématiques appliquées, 10e année / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PESMR 1", "Candidat civil", "RECL", "MÉ"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans conditions ou être présentement inscrit comme étudiant à temps plein dans un programme d’études à un établissement d’enseignement postsecondaire sélectionné par les FAC 2",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. La liste des établissements postsecondaires et des programmes approuvés par le CAF, ainsi que les exigences individuelles associées (y compris la durée et les crédits), sera mise à jour dans le Liste des groupes professionnels militaires (LGPM) sur le portail des Forces armées canadiennes Accréditations, Certifications et Équivalences (FAC ACE)",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant :",
                  "o Mathématiques académiques de 11e année / Sec V",
                  "o Physique de 11e année / Sec V",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV, comportant :",
                  "o Mathématiques appliquées, 10e année / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. La liste des établissements postsecondaires et des programmes approuvés par le CAF, ainsi que les exigences individuelles associées (y compris la durée et les crédits), sera mise à jour dans le Liste des groupes professionnels militaires (LGPM) sur le portail des Forces armées canadiennes Accréditations, Certifications et Équivalences (FAC ACE)",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "5 ans",
      },
      {
        program: "PFS-MR",
        duration: "7 ans",
      },
    ],
  },
  {
    id: "00114",
    medicalStandard: { v: 4, cv: 2, h: 2, g: 2, o: 2, a: 5, u: 5 },
    title: "OPÉRATEUR D’ÉQUIPMENT D’INFORMATION DE COMBAT (MARINE)",
    abbreviation: "OP ÉICM",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Études secondaires de 10e année, Secondaire IV au Québec ou l’équivalent.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1, 2", "MÉ 2", "MSÉ"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaire ou de Secondaire V au Québec, comportant :",
                  "o Mathématiques théoriques de 11e année ou mathématique 536 / SN V/TS V au Québec;",
                  "o Cours de physiques de 11e année ou de physique 534 au Québec",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "Études secondaires de 10e année, Secondaire IV au Québec ou l’équivalent",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: [
              "Candidat avec service antérieur 1, 2",
              "MÉ 1, 2",
              "MSÉ 1, 2",
              "(tous en service actif ou avec service antérieur en tant qu’ 00114 OP ÉICM)",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaire ou de Secondaire V au Québec",
                ],
                experience: [
                  "Atteinte du Niveau opérationnel de compétence (NOC) du GPM 00114 OP ÉICM dans la F rég ou la P rés",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Études secondaires de 10e année, Secondaire IV au Québec ou l’équivalent",
                ],
                experience: [
                  "Atteinte du Niveau opérationnel de compétence (NOC) du GPM 00114 OP ÉICM dans la F rég ou la P rés",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces Canadiennes (TAFC), si ne l’ont pas déjà fait. Un candidat civil, RECL ou MÉ qui n’a pas atteint le NOC comme 00114 OP ÉICM doit obtenir la note de passage du TAFC. Consulter la Feuille de travail - Affectations (FTA) pour connaître les notes de passages en vigueur.",
          "2. Conformément aux critères d’enrôlement/RECL/MÉ en vigueur.",
          "3. Le Niveau opérationnel de compétence (NOC) du GPM 00114 OP ÉICM est défini dans la description du GPM à l’adresse suivante : http://cmp-cpm.mil.ca/fr/soutien/personnel-militaire/dbpp-description-de-gpm.page.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: [
              "Candidat civil 1, 2",
              "RECL 1, 2",
              "MÉ 1, 2",
              "MSÉ 1, 2",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Secondary school graduation certificate or a Diplôme d’études secondaire ou de Secondaire V au Québec, comportant :",
                  "o Mathématiques théoriques de 11e année ou mathématique 536 / SN V/TS V au Québec;",
                  "o Cours de physiques de 11e année ou de physique 534 au Québec",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire, Secondaire IV au Québec ou l’équivalent",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: [
              "Applicant with Former Service 1, 2",
              "OT 1, 2",
              "CT 1, 2",
              "SCT 1, 2",
              "(tous en service actif ou avec service antérieur en tant qu’ 00114 OP ÉICM)",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou de Secondaire V au Québec",
                ],
                experience: [
                  "Atteinte du Niveau opérationnel de compétence (NOC) du GPM 00114 OP ÉICM dans la F rég ou la P rés",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire ou Secondaire IV au Québec ou l’équivalent",
                ],
                experience: [
                  "Atteinte du Niveau opérationnel de compétence (NOC) du GPM 00114 OP ÉICM dans la F rég ou la P rés",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent passer le Test d’aptitude des Forces canadiennes (TAFC) s’ils ne l’ont pas déjà fait. Un candidat civil, RECL, MÉ ou MSÉ qui n’a pas atteint le NOC du GPM 00114 OP ÉICM doit obtenir la note de passage du TAFC pour ce GPM. Consulter la Feuille de travail - Affectations (FTA) pour connaître les notes de passages en vigueur.",
          "2. Conformément aux critères d’enrôlement/RECL/MÉ/MSÉ en vigueur.",
          "3. Le Niveau opérationnel de compétence (NOC) du GPM 00114 OP ÉICM est défini dans la description du GPM à l’adresse suivante : http://cmp-cpm.mil.ca/fr/soutien/personnel-militaire/dbpp-description-de-gpm.page.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
    ],
  },
  {
    id: "00115",
    medicalStandard: { v: 4, cv: 2, h: 2, g: 2, o: 2, a: 5, u: 5 },
    title: "OPÉRATEURS DE DÉTECTEURS ÉLECTRONIQUE MARITIMES",
    abbreviation: "OP DEM",
    requirements: "FORCE RÉGULIÈRE: 10e année / Secondaire IV.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant :",
                  "o Mathématiques appliquées de 11e / Sec V",
                  "o Cours de physique de 11e / Sec V",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: [
              "Candidat avec service antérieur 1",
              "RECL 1",
              "MÉ 1",
              "(qualifié)",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du niveau opérationnel de compétence (NPC) 2 ent tant qu’ 00115 OP DEM dans la F rég.",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
    ],
  },
  {
    id: "00120",
    medicalStandard: { v: 4, cv: 3, h: 2, g: 3, o: 3, a: 5, u: 5 },
    title: "SPÉCIALISTE DU RENSEIGNEMENT D’ORIGINE ÉLECTROMAGNÉTIQUE",
    abbreviation: "SPÉC ROEM",
    requirements:
      "FORCE RÉGULIÈRE: 10e année / Secondaire IV, comportant mathématiques appliquées de 10e année / Sec IV (Acceptable) OU Baccalauréat / Diplôme postsecondaire.",
    details: [
      {
        force: "FORCE RÉGULIÈRE & FORCE DE LA RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1, 2", "RECL 1, 2", "MÉ 1, 2"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent comportant :",
                  "o mathématiques appliquées de 11e année / Sec V",
                ],
                experience: [
                  "Expérience dans tous les programmes informatiques suivants dans le cadre des exigences de travail durant six mois au cours des trois dernières années :",
                  "o Excel de Microsoft",
                  "o PowerPoint de Microsoft",
                  "o Word de Microsoft",
                  "o Windows de Microsoft",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Tout Baccalauréat ou Diplôme d'études postsecondaire",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV, comportant :",
                  "o mathématiques appliquées de 10e année / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: [
              "Candidat civil 1, 2",
              "RECL 1, 2",
              "MÉ 1, 2",
              "(qualifié)",
            ],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou l’équivalent"],
                experience: [
                  "Doit avoir atteint le niveau opérationnel de compétence (NPC) 3 dans la F rég ou la P rés comme 00120 SPÉC ROEM",
                ],
              },
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Doit avoir atteint le niveau opérationnel de compétence (NPC) 3 dans la F rég ou la P rés comme 00120 SPÉC ROEM",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Tous les candidats doivent être en mesure d’obtenir une cote de sécurité de niveau III (Très Secret). L’Officier de sécurité de l’unité (OSU) du candidat doit faire la demande avant le début de l’instruction dans le GPM 00120 SPÉC ROEM (candidats par RECL ou MÉ); dans le cas d’un candidat civil, le même officier doit faire la demande d’obtention de la cote avant ou pendant l’instruction de la QMB.",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "6 ans",
      },
    ],
  },
  {
    id: "00129",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN DES VÉHICULES",
    abbreviation: "TECH V",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: 10e année / Secondaire IV, comportant mathématiques appliquées de 10e année / Sec IV et Cours de sciences de10e / Sec IV.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant :",
                  "o mathématiques appliquées de 11e année / Sec V",
                  "o Cours de physique 11e / Sec V",
                ],
                experience: ["Permis de conduire provincial valide2"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV, comportant :",
                  "o mathématiques appliquées de 10e année / Sec IV",
                  "o Cours de sciences de10e / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "(qualifié)"],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou l’équivalent"],
                experience: [
                  "Atteinte du NPC3 comme 00129 TECH V dans la F rég ou la P rés",
                ],
              },
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du NPC3 comme 00129 TECH V dans la F rég ou la P rés",
                ],
              },
            ],
          },
          {
            candidates: ["PIESMR 1", "Candidat civil", "RECL", "MÉ"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans conditions et être présentement inscrit comme étudiant à temps plein dans un programme d’études à un établissement d’enseignement postsecondaire sélectionné par les FAC4",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Par « permis de conduire provincial valide », on entend un permis permettant de conduire un véhicule automobile, frappé d’aucune condition et conférant tous les privilèges de conduite.",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP).",
          "4. La liste des établissements postsecondaires et des programmes approuvés par le CAF, ainsi que les exigences individuelles associées (y compris la durée et les crédits), sera mise à jour dans le Liste des groupes professionnels militaires (LGPM) sur le portail des Forces armées canadiennes Accréditations, Certifications et Équivalences (FAC ACE)",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant :",
                  "o mathématiques appliquées de 11e année / Sec V",
                  "o Cours de physique de 11e / Sec V",
                ],
                experience: ["Permis de conduire provincial valide2"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV, comportant :",
                  "o mathématiques appliquées de 10e année / Sec IV",
                  "o Cours de sciences de 10e / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "(qualifié)"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou du Secondaire V au Québec",
                ],
                experience: [
                  "Atteinte du NPC3 comme 00129 TECH V dans la F rég ou la P rés",
                ],
              },
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du NPC3 comme 00129 TECH V dans la F rég ou la P rés",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Par « permis de conduire provincial valide », on entend un permis permettant de conduire un véhicule automobile, frappé d’aucune condition et conférant tous les privilèges de conduite.",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP).",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "5 ans",
      },
      {
        program: "PFS-MR",
        duration: "7 ans",
      },
    ],
  },
  {
    id: "00130",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN D’ARMEMENT (TERRE)",
    abbreviation: "TECH A (T)",
    requirements:
      "FORCE RÉGULIÈRE: 10e année / Secondaire IV, comportant mathématiques appliquées de 10e année / Sec IV et Cours de sciences de 10e / Sec IV.",
    details: [
      {
        force: "FORCE RÉGULIÈRE & FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant :",
                  "o mathématiques appliquées de 11e année / Sec V",
                  "o Cours de physique 11e / Sec V",
                ],
                experience: ["Permis de conduire provincial valide 2"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV, comportant :",
                  "o mathématiques appliquées de 10e année / Sec IV",
                  "o Cours de sciences de 10e / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "(qualifié)"],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou l’équivalent"],
                experience: [
                  "Atteinte du NPC3,4 comme 00130 TECH A(T) dans la F rég ou la P rés",
                ],
              },
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du NPC3,4 comme 00130 TECH A(T) dans la F rég ou la P rés",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Par « permis de conduire provincial valide », on entend un permis permettant de conduire un véhicule automobile, frappé d’aucune condition et conférant tous les privilèges de conduite.",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP).",
          "4. Dans le cas d’un candidat de la P rés pour la F Reg, une ÉFA sera exigée.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "5 ans",
      },
    ],
  },
  {
    id: "00134",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN DES MATÉRIAUX",
    abbreviation: "TECH MAT",
    requirements:
      "FORCE RÉGULIÈRE: 10e année / Secondaire IV, comportant mathématiques appliquées de 10e année / Sec IV et Cours de sciences de 10e / Sec IV.",
    details: [
      {
        force: "FORCE RÉGULIÈRE & FORCE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant :",
                  "o mathématiques appliquées de 11e année / Sec V",
                  "o Cours de physique de 11e / Sec V",
                ],
                experience: ["Permis de conduire provincial valide2"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV, comportant :",
                  "o mathématiques appliquées de 10e année / Sec IV",
                  "o Cours de sciences de 10e / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "(qualifié)"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou du Secondaire V au Québec",
                ],
                experience: [
                  "Atteinte du NPC3 comme 00129 TECH V dans la F rég ou la P rés",
                ],
              },
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du NPC3 comme 00129 TECH V dans la F rég ou la P rés",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Par « permis de conduire provincial valide », on entend un permis permettant de conduire un véhicule automobile, frappé d’aucune condition et conférant tous les privilèges de conduite.",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP).",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "5 ans",
      },
    ],
  },
  {
    id: "00135",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN EN SYSTÈMES AÉRONAUTIQUES",
    abbreviation: "TECH AÉRO",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Certificat d’école secondaire ou l’équivalent comportant Anglais 12e an/Sec V ou Physique Sec V et cours de mathématiques spécifiés (SN/TS/536/526/CEGEP 201).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Un diplôme d’un programme TEA‑M (technicien d’entretien d’aéronefs - maintenance) accrédité par Transports Canada 4",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable 5 (Option de formation en anglais)",
                education: [
                  "Certificat d’école secondaire ou l’équivalent, comportant :",
                  "o Anglais de 12e an / Sec V",
                  "ET",
                  "o Un des cours de mathématiques suivants :",
                  "  a. 12e annee / CEGEP 201 Appliquée ou Théoriques",
                  "  b. Séquence sciences naturelles (SN) Sec V",
                  "  c. Séquence technico-sciences (TS) Sec V",
                  "  d. Mathématiques 536",
                  "  e. Mathématiques 526",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable 5 (Option de formation en français)",
                education: [
                  "Certificat d’école secondaire ou l’équivalent, comportant :",
                  "o Physique Sec V",
                  "ET",
                  "o Un des cours de mathématiques suivants :",
                  "  a. Séquence sciences naturelles (SN) Sec V",
                  "  b. Séquence technico-sciences (TS) Sec V",
                  "  c. Mathématiques 536",
                  "  d. Mathématiques 526",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIES-MR 1", "Candidat civil", "RECL", "MÉ"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans conditions ou être présentement inscrit comme étudiant à temps plein dans un programme d’études à un établissement d’enseignement postsecondaire sélectionné par les FAC 2",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "(qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC)3 du GPM TECH AÉRO 00135",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. La liste des établissements offrant des programmes d’études postsecondaires acceptables auprès des FAC pour les candidats PIES-MR se trouve à l’adresse suivante : Forces armées canadiennes Accréditations, Certifications et Équivalences (FAC ACE). Les candidats qui ont déjà terminé des études postsecondaires collégiales ou universitaires peuvent être admissibles au statut «semi-spécialisé», en contournant une partie de la formation professionnelle requise. Les recruteurs sont encouragés à discuter de cette option avec leurs candidats.",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
          "4. Les programmes accrédités par Transports Canada se trouvent à : Formation de base – Cours de formation approuvés/acceptables (actuellement actifs)",
          "5. Les exigences académiques en mathématiques, sciences et langues sont établies conformément aux normes de formation professionnelle définies par les établissements partenaires offrant le programme de formation tech aéro (PFTA). Cette norme d'admission fera l'objet d'un examen périodique au fur et à mesure de l'évolution du programme.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Un diplôme d’un programme TEA‑M (technicien d’entretien d’aéronefs - maintenance) accrédité par Transports Canada 3",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable 4 (Option de formation en anglais)",
                education: [
                  "Certificat d’école secondaire ou l’équivalent, comportant :",
                  "o Anglais de 12e an / Sec V",
                  "ET",
                  "o Un des cours de mathématiques suivants :",
                  "  a. 12e an / CEGEP 201 Appliquée ou Théoriques",
                  "  b. Séquence sciences naturelles (SN) Sec V",
                  "  c. Séquence technico-sciences (TS) Sec V",
                  "  d. Mathématiques 536",
                  "  e. Mathématiques 526",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable 4 (Option de formation en français)",
                education: [
                  "Certificat d’école secondaire ou l’équivalent, comportant :",
                  "o Physique Sec V",
                  "ET",
                  "o Un des cours de mathématiques suivants :",
                  "  a. Séquence sciences naturelles (SN) Sec V",
                  "  b. Séquence technico-sciences (TS) Sec V",
                  "  c. Mathématiques 536",
                  "  d. Mathématiques 526",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "(qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC) 2 du GPM TECH AÉRO 00135",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
          "3. Les programmes accrédités par Transports Canada se trouvent à : Formation de base – Cours de formation approuvés/acceptables (actuellement actifs)",
          "4. Les exigences académiques en mathématiques, sciences et langues sont établies conformément aux normes de formation professionnelle définies par les établissements partenaires offrant le programme de formation tech aéro (PFTA). Cette norme d'admission fera l'objet d'un examen périodique au fur et à mesure de l'évolution du programme.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "5 ans",
      },
      {
        program: "PIES-MR",
        duration: "7 ans",
      },
    ],
  },
  {
    id: "00136",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN EN SYSTÈMES AVIONIQUES",
    abbreviation: "TECH AVIO",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Certificat d’école secondaire ou l’équivalent comportant Anglais 12e an/Sec V ou Physique Sec V et cours de mathématiques spécifiés (SN/TS/536/526/CEGEP 201).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Un diplôme d’un programme TEA‑E (technicien d’entretien d’aéronefs - avionique) accrédité par Transports Canada 4",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable 5 (Option de formation en anglais)",
                education: [
                  "Certificat d’école secondaire ou l’équivalent, comportant :",
                  "o Anglais de 12e an / Sec V",
                  "ET",
                  "o Un des cours de mathématiques suivants :",
                  "  a. 12e an / CEGEP 201 Appliquée ou Théoriques",
                  "  b. Séquence sciences naturelles (SN) Sec V",
                  "  c. Séquence technico-sciences (TS) Sec V",
                  "  d. Mathématiques 536",
                  "  e. Mathématiques 526",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable 5 (Option de formation en français)",
                education: [
                  "Certificat d’école secondaire ou l’équivalent, comportant :",
                  "o Physique Sec V",
                  "ET",
                  "o Un des cours de mathématiques suivants :",
                  "  a. Séquence sciences naturelles (SN) Sec V",
                  "  b. Séquence technico-sciences (TS) Sec V",
                  "  c. Mathématiques 536",
                  "  d. Mathématiques 526",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIES-MR 1", "Candidat civil", "RECL", "MÉ"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans conditions ou être présentement inscrit comme étudiant à temps plein dans un programme d’études à un établissement d’enseignement postsecondaire sélectionné par les FAC 2",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "(qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC)3 du GPM TECH AVIO 00136",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. La liste des établissements offrant des programmes d’études postsecondaires acceptables auprès des FAC pour les candidats PIES-MR se trouve à l’adresse suivante : Forces armées canadiennes Accréditations, Certifications et Équivalences (FAC ACE). Les candidats qui ont déjà terminé des études postsecondaires collégiales ou universitaires peuvent être admissibles au statut «semi-spécialisé», en contournant une partie de la formation professionnelle requise. Les recruteurs sont encouragés à discuter de cette option avec leurs candidats.",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
          "4. Les programmes accrédités par Transports Canada se trouvent à : Formation de base – Cours de formation approuvés/acceptables (actuellement actifs)",
          "5. Les exigences académiques en mathématiques, sciences et langues sont établies conformément aux normes de formation professionnelle définies par les établissements partenaires offrant le programme de formation tech aéro (PFTA). Cette norme d'admission fera l'objet d'un examen périodique au fur et à mesure de l'évolution du programme.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Un diplôme d’un programme TEA‑E (technicien d’entretien d’aéronefs - avionique) accrédité par Transports Canada 4",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable 4 (Option de formation en anglais)",
                education: [
                  "Certificat d’école secondaire ou l’équivalent, comportant :",
                  "o Anglais de 12e an / Sec V",
                  "ET",
                  "o Un des cours de mathématiques suivants :",
                  "  a. 12e an / CEGEP 201 Appliquée ou Théoriques",
                  "  b. Séquence sciences naturelles (SN) Sec V",
                  "  c. Séquence technico-sciences (TS) Sec V",
                  "  d. Mathématiques 536",
                  "  e. Mathématiques 526",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable 4 (Option de formation en français)",
                education: [
                  "Certificat d’école secondaire ou l’équivalent, comportant :",
                  "o Physique Sec V",
                  "ET",
                  "o Un des cours de mathématiques suivants :",
                  "  a. Séquence sciences naturelles (SN) Sec V",
                  "  b. Séquence technico-sciences (TS) Sec V",
                  "  c. Mathématiques 536",
                  "  d. Mathématiques 526",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "(qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC) 2 du GPM TECH AVIO 00136",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
          "3. Les programmes accrédités par Transports Canada se trouvent à : Formation de base – Cours de formation approuvés/acceptables (actuellement actifs)",
          "4. Les exigences académiques en mathématiques, sciences et langues sont établies conformément aux normes de formation professionnelle définies par les établissements partenaires offrant le programme de formation tech aéro (PFTA). Cette norme d'admission fera l'objet d'un examen périodique au fur et à mesure de l'évolution du programme.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "5 ans",
      },
      {
        program: "PIES-MR",
        duration: "7 ans",
      },
    ],
  },
  {
    id: "00137",
    medicalStandard: { v: 4, cv: 1, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN D’IMAGERIE",
    abbreviation: "TECH IMAG",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme d’études secondaires ou diplôme de Secondaire V au Québec ou l’équivalent.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1, 2", "RECL 1, 2", "MÉ 1, 2"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études collégiales en photographie, en photojournalisme, multimédia ou conception graphique dans un collège reconnu",
                  "OU",
                  "Baccalauréat en étude de communication ou en communications visuelle",
                ],
                experience: [
                  "Expérience dans un ou plusieurs des domaines suivants sera prise en considération : photographie, photojournalisme, conception graphique ou multimédia.",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou diplôme de Secondaire V au Québec ou l’équivalent",
                ],
                experience: [
                  "Expérience dans un ou plusieurs des domaines suivants sera prise en considération : photographie, photojournalisme, conception graphique ou multimédia.",
                ],
              },
            ],
          },
          {
            candidates: [
              "Candidat civil 1, 2",
              "MÉ 1, 2",
              "(tous avec service antérieur comme TECH IMAG 00137)",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou diplôme de Secondaire V au Québec ou l’équivalent",
                ],
                experience: [
                  "Avoir suivi le cours de qualification professionnelle élémentaire (NOC)3 de TECH IMAG 00137",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire, Secondaire IV au Québec ou l’équivalent",
                ],
                experience: [
                  "Avoir suivi le cours de qualification professionnelle élémentaire (NOC)3 de TECH IMAG 00137",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent passer le test d’aptitude des Forces canadiennes (TAFC) s’ils ne l’ont pas déjà passé. Les EDO, RECL, MÉ qui ont atteint le point fonctionnel professionnel ne sont pas tenus d’obtenir la note de passage du TAFC. Reportez-vous vous à la fiche d'affectation (OAW) pour connaître les seuils actuels.",
          "2. Conformément aux critères d’enrôlement/RECL/MÉ en vigueur.",
          "3. Le Niveau opérationnel de compétence (NOC) est expliqué dans la description du GPM à l’adresse suivante : http://cmp-cpm.mil.ca/fr/soutien/personnel-militaire/dbpp-description-de-gpm.page",
        ],
      },
      {
        force: "FORCE DE LA RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1, 2", "RECL 1, 2", "MÉ 1, 2"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études collégiales en photographie, en photojournalisme, multimédia ou conception graphique dans un collège reconnu",
                  "OU",
                  "Baccalauréat en étude de communicationou en communications visuelle",
                ],
                experience: [
                  "Expérience dans un ou plusieurs des domaines suivants sera prise en considération : photographie, photojournalisme, conception graphique ou multimédia.",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou diplôme de Secondaire V au Québec ou l’équivalent",
                ],
                experience: [
                  "Expérience dans un ou plusieurs des domaines suivants sera prise en considération : photographie, photojournalisme, conception graphique ou multimédia.",
                ],
              },
            ],
          },
          {
            candidates: [
              "Candidat civil 1, 2",
              "MÉ 1, 2",
              "(tous avec service antérieur comme TECH IMAG 00137)",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou diplôme de Secondaire V au Québec ou l’équivalent",
                ],
                experience: [
                  "Avoir suivi le cours de qualification professionnelle élémentaire (NOC)3 de TECH IMAG 00137",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire, Secondaire IV au Québec ou l’équivalent",
                ],
                experience: [
                  "Avoir suivi le cours de qualification professionnelle élémentaire (NOC)3 de TECH IMAG 00137",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent passer le test d’aptitude des Forces canadiennes (TAFC) s’ils ne l’ont pas déjà passé. Les EDO, RECL, MÉ qui ont atteint le point fonctionnel professionnel ne sont pas tenus d’obtenir la note de passage du TAFC. Reportez-vous vous à la fiche d'affectation (OAW) pour connaître les seuils actuels.",
          "2. Conformément aux critères d’enrôlement/RECL/MÉ/MSÉ en vigueur.",
          "3. Le Niveau opérationnel de compétence (NOC) est expliqué dans la description du GPM à l’adresse suivante : http://cmp-cpm.mil.ca/fr/soutien/personnel-militaire/dbpp-description-de-gpm.page",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "5 ans",
      },
    ],
  },
  {
    id: "00138",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN EN STRUCTURES D’AÉRONEF",
    abbreviation: "TECH SA",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Certificat d’école secondaire ou l’équivalent comportant Anglais 12e an/Sec V ou cours de mathématiques spécifiés (SN/TS/536/526/CEGEP 201).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Un diplôme d’un programme TEA‑S (technicien d’entretien d’aéronefs - structures) accrédité par Transports Canada 4",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable 5 (Option de formation en anglais)",
                education: [
                  "Certificat d’école secondaire ou l’équivalent, comportant :",
                  "o Anglais de 12e an / Sec V",
                  "ET",
                  "o Un des cours de mathématiques suivants :",
                  "  a. 12e année / CEGEP 201 Appliquée ou Théoriques",
                  "  b. Séquence sciences naturelles (SN) Sec V",
                  "  c. Séquence technico-sciences (TS) Sec V",
                  "  d. Mathématiques 536",
                  "  e. Mathématiques 526",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable 5 (Option de formation en français)",
                education: [
                  "Certificat d’école secondaire ou l’équivalent, comportant un des cours de mathématiques suivants :",
                  "  a. Séquence sciences naturelles (SN) Sec V",
                  "  b. Séquence technico-sciences (TS) Sec V",
                  "  c. Mathématiques 536",
                  "  d. Mathématiques 526",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIES-MR 1", "Candidat civil", "RECL", "MÉ"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans conditions ou être présentement inscrit comme étudiant à temps plein dans un programme d’études à un établissement d’enseignement postsecondaire sélectionné par les FAC 2",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "(qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC)3 du GPM TECH SA 00138",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. La liste des établissements offrant des programmes d’études postsecondaires acceptables auprès des FAC pour les candidats PIES-MR se trouve à l’adresse suivante : Forces armées canadiennes Accréditations, Certifications et Équivalences (FAC ACE). Les candidats qui ont déjà terminé des études postsecondaires collégiales ou universitaires peuvent être admissibles au statut «semi-spécialisé», en contournant une partie de la formation professionnelle requise. Les recruteurs sont encouragés à discuter de cette option avec leurs candidats.",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
          "4. Les programmes accrédités par Transports Canada se trouvent à : Formation de base – Cours de formation approuvés/acceptables (actuellement actifs)",
          "5. Les exigences académiques en mathématiques, sciences et langues sont établies conformément aux normes de formation professionnelle définies par les établissements partenaires offrant le programme de formation tech aéro (PFTA). Cette norme d'admission fera l'objet d'un examen périodique au fur et à mesure de l'évolution du programme.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Un diplôme d’un programme TEA‑S (technicien d’entretien d’aéronefs - structures) accrédité par Transports Canada 3",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable 4 (Option de formation en anglais)",
                education: [
                  "Certificat d’école secondaire ou l’équivalent, comportant :",
                  "o Anglais de 12e an / Sec V",
                  "ET",
                  "o Un des cours de mathématiques suivants :",
                  "  a. 12e an / CEGEP 201 Appliquée ou Théoriques",
                  "  b. Séquence sciences naturelles (SN) Sec V",
                  "  c. Séquence technico-sciences (TS) Sec V",
                  "  d. Mathématiques 536",
                  "  e. Mathématiques 526",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable 4 (Option de formation en français)",
                education: [
                  "Certificat d’école secondaire ou l’équivalent, comportant un des cours de mathématiques suivants :",
                  "  a. Séquence sciences naturelles (SN) Sec V",
                  "  b. Séquence technico-sciences (TS) Sec V",
                  "  c. Mathématiques 536",
                  "  d. Mathématiques 526",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "(qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC) 2 du GPM TECH SA 00138",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
          "3. Les programmes accrédités par Transports Canada se trouvent à : Formation de base – Cours de formation approuvés/acceptables (actuellement actifs)",
          "4. Les exigences académiques en mathématiques, sciences et langues sont établies conformément aux normes de formation professionnelle définies par les établissements partenaires offrant le programme de formation tech aéro (PFTA). Cette norme d'admission fera l'objet d'un examen périodique au fur et à mesure de l'évolution du programme.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "5 ans",
      },
      {
        program: "PIES-MR",
        duration: "7 ans",
      },
    ],
  },
  {
    id: "00149",
    medicalStandard: { v: 3, cv: 2, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "POMPIER",
    abbreviation: "POMPIER",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme / certificat d'études secondaires ou équivalent, comportant : Mathématiques appliquées, 10e année / Sec IV. Permis de conduire provincial/territorial en règle.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1, 2", "RECL 1, 2", "MÉ 1, 2"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Obtention d’un diplôme d’un programme de service d’incendie agréé 3",
                  "Formation/qualification de pompier conforme à la norme 1001, niveaux I et II << Firefighter Level I and II >> de la << National Fire Protection Association (NFPA) >> 4",
                  "Formation/qualification conforme à la norme 472 sur les matières dangereuses de la <<NFPA (472 HAZMAT) >> 4",
                ],
                experience: [
                  "Expérience d’au moins un an comme pompier à temps plein ou à temps partiel dans un service d’incendie municipal ou privé reconnu",
                  "ET",
                  "Détenir un permis de conduire provincial/territorial en règle 5",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Obtention d’un diplôme d’un programme de service d’incendie agréé 3",
                  "OU",
                  "Diplôme / certificat d'études secondaires ou équivalent, comportant :",
                  "o Mathématiques appliquées, 10e année / Sec IV",
                ],
                experience: [
                  "Détenir un permis de conduire provincial/territorial en règle 5",
                ],
              },
            ],
          },
          {
            candidates: [
              "Candidat civil 1, 2",
              "RECL 1, 2",
              "MÉ 1, 2",
              "(qualifié)",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme / certificat d'études secondaires ou équivalent",
                ],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC)6 en tant que 00149 POMPIER",
                  "ET",
                  "Détenir un permis de conduire provincial/territorial en règle 5",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Pour pouvoir recevoir une formation professionnelle de 00149 POMPIER , un candidat doit obtenir la note de passage de l’évaluation de la condition physique de préadmission (ECPP)",
          "a. Un candidat faisant l'objet d'un reclassement ou d'une mutation entre éléments doit obtenir la note de passage de l'ECPP avant son RECL/sa MÉ;",
          "b. Un candidat civil enrôlé directement doit obtenir la note de passage de l’ECPP après avoir obtenu sa QMB.",
          "3. On trouve toutes les institutions d’études avant l’entrée en service qui sont agréées par le <<International Fire Service Accreditation Congress (IFSAC) >> ou <<ProBoard International Accreditation for Fire Service Organizations >>, de même que les programmes agréés de formation des pompiers qui sont admissibles aux primes de recrutement est est disponible sur la Liste des groupes professionnels militaires (LGPM) sur le portail des Forces armées canadiennes Accréditations, Certifications et Équivalences (FAC ACE).",
          "4. L’affiliation à la NFPA doit être accréditée par l’ <<International Fire Service Accreditation Congress (IFSAC)>> ou par le ProBoard. Toute autre équivalence non accréditée sera évaluée au cas par cas par l'OSSG du GISFC et par le Directeur du service des incendies des Forces canadiennes (par l’entremise du DBPP 4).",
          "5. Le candidat doit détenir un permis de conduire d’une province/territoire (de classe G ou 5) en règle, sans restrictions et ne doit pas avoir fait l’objet d’aucune infraction courante qui limiterait ses privilèges de conduite.",
          "6. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: [
              "Candidat civil 1, 2",
              "RECL 1, 2",
              "MÉ 1, 2",
              "SMÉ 1, 2",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Obtention d’un diplôme d’un programme de service d’incendie agréé 3",
                  "Formation/qualification de pompier conforme à la norme 1001, niveaux I et II << Firefighter Level I and II >> de la << National Fire Protection Association (NFPA)>> 4",
                  "Formation/qualification conforme à la norme 472 sur les matières dangereuses de la <<NFPA 472 HAZMAT>> 4",
                ],
                experience: [
                  "Expérience d’au moins un an comme pompier à temps plein ou à temps partiel dans un service d’incendie municipal ou privé reconnu",
                  "ET",
                  "Détenir un permis de conduire provincial/territorial en règle 5",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Obtention d’un diplôme d’un programme de service d’incendie agréé 3",
                  "OU",
                  "Diplôme / certificat d'études secondaires ou équivalent, comportant :",
                  "o Mathématiques appliquées, 10e année / Sec IV",
                ],
                experience: [
                  "Détenir un permis de conduire provincial/territorial en règle 5",
                ],
              },
            ],
          },
          {
            candidates: [
              "Candidat civil 1, 2, 6",
              "RECL 1, 2",
              "MÉ 1, 2",
              "SMÉ 1, 2",
              "(qualifié)",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme / certificat d'études secondaires ou équivalent",
                ],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC)6 en tant que 00149 POMPIER",
                  "ET",
                  "Détenir un permis de conduire provincial/territorial en règle 5",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Pour pouvoir recevoir une formation professionnelle de 00149 POMPIER , un candidat doit obtenir la note de passage de l’évaluation de la condition physique de préadmission (ECPP)",
          "a. Un candidat faisant l'objet d'un reclassement ou d'une mutation entre éléments doit obtenir la note de passage de l'ECPP avant son RECL/sa MÉ;",
          "b. Un candidat civil enrôlé directement doit obtenir la note de passage de l’ECPP après avoir obtenu sa QMB.",
          '3. On trouve toutes les institutions d’études avant l’entrée en service qui sont agréées par le "International Fire Service Accreditation Congress (IFSAC)" ou "ProBoard International Accreditation for Fire Service Organizations", de même que les programmes agréés de formation des pompiers qui sont admissibles aux primes de recrutement est est disponible sur la Liste des groupes professionnels militaires (LGPM) sur le portail des Forces armées canadiennes Accréditations, Certifications et Équivalences (FAC ACE).',
          "4. L’affiliation à la NFPA doit être accréditée par le <<International Fire Service Accreditation Congress (IFSAC)>> ou par le ProBoard. Toute autre équivalence non accréditée sera évaluée au cas par cas par l'OSSG du GISFC et par le Directeur du service des incendies des Forces canadiennes (par l’entremise du DBPP 4).",
          "5. Le candidat doit détenir un permis de conduire d’une province/d’un territoire (de classe G ou 5) en règle, sans restrictions et ne doit pas avoir fait l’objet d’aucune infraction courante qui limiterait ses privilèges de conduite.",
          "6. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "9 ans",
      },
    ],
  },
  {
    id: "00152",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "TECHNOLOGUE DE LABORATOIRE MÉDICAL",
    abbreviation: "TECH LAB M",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme ou baccalauréat dans un programme agréé de Technologie de laboratoire médical. Attestation de la SCSLM ou de l'ACORPLM. Aucune expérience requise si diplôme récent.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: [
              "Candidat civil 1, 2, 3",
              "RECL 1, 2, 3",
              "MÉ 1, 2, 3",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme ou baccalauréat dans un programme agréé de Technologie de laboratoire médical 4",
                  "ET",
                  "Certification de l'un des organismes suivants:",
                  "o La Société canadienne de science de laboratoire médical (SCSLM) 5, OU",
                  "o L'Alliance canadienne des organismes de réglementation des professionnels de laboratoire médical (ACORPLM) 6, incluant la réussite des examens du « TLM généraliste » pour les technologistes de laboratoire médical (TLM) 7",
                  "ET",
                  "Et l'un des éléments suivants :",
                  "o Permis ou inscription sans restriction (statut actif) délivré par l'autorité de réglementation provinciale ou territoriale 8",
                  "o Lettre de conformité (« Good Standing ») émise par l'autorité de réglementation du candidat 8",
                ],
                experience: [
                  "Au moins douze mois d'expérience clinique, à temps plein ou à temps partiel, comme technologiste de laboratoire médical au cours des deux dernières années",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Diplôme ou baccalauréat dans un programme agréé de Technologie de laboratoire médical 4",
                  "ET",
                  "Certification de l'un des organismes suivants:",
                  "o La Société canadienne de science de laboratoire médical (SCSLM) 5, OU",
                  "o L'Alliance canadienne des organismes de réglementation des professionnels de laboratoire médical (ACORPLM) 6, incluant la réussite des examens du « TLM généraliste » pour les technologistes de laboratoire médical (TLM) 7",
                  "ET",
                  "Et l'un des éléments suivants :",
                  "o Permis ou inscription sans restriction (statut actif) délivré par l'autorité de réglementation provinciale ou territoriale 8",
                  "o Lettre de conformité (« Good Standing ») émise par l'autorité de réglementation du candidat 8",
                ],
                experience: [
                  "Obtention d'un diplôme au cours des 18 derniers mois – Aucune expérience minimale requise",
                  "Obtention d'un diplôme au-delà des 18 derniers mois – Au moins six mois d'expérience à temps plein ou à temps partiel dans un laboratoire médical clinique au cours des deux dernières années",
                ],
              },
            ],
          },
          {
            candidates: ["PIES-MR 1, 2", "Candidat civil", "RECL", "MÉ"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition ou être présentement enrôlé comme étudiant à temps plein dans un programme d'étude à un établissement d'enseignement postsecondaire choisi par les FAC 9",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Afin de s’assurer que tous les candidats répondent aux exigences de permis et de certification...",
          "3. Certains candidats peuvent avoir suivi un parcours de formation non traditionnel...",
        ],
      },
      {
        force: "FORCE DE LA RÉSERVE",
        candidateGroups: [
          {
            candidates: [
              "Candidat civil 1, 2, 3",
              "RECL 1, 2, 3",
              "MÉ 1, 2, 3",
              "MSÉ 1, 2, 3",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme ou baccalauréat dans un programme agréé de Technologie de laboratoire médical 4",
                  "ET",
                  "Certification de l'un des organismes suivants:",
                  "o La Société canadienne de science de laboratoire médical (SCSLM) 5, OU",
                  "o L'Alliance canadienne des organismes de réglementation des professionnels de laboratoire médical (ACORPLM) 6, incluant la réussite des examens du « TLM généraliste » pour les technologistes de laboratoire médical (TLM) 7",
                  "ET",
                  "Et l'un des éléments suivants :",
                  "o Permis ou inscription sans restriction (statut actif) délivré par l'autorité de réglementation provinciale ou territoriale 8",
                  "o Lettre de conformité (« Good Standing ») émise par l'autorité de réglementation du candidat",
                ],
                experience: [
                  "Être actuellement employé à temps plein comme technologiste de laboratoire médical dans un laboratoire clinique et posséder au moins deux ans d’expérience.",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Afin de s’assurer que tous les candidats répondent aux exigences de permis et de certification, tous les dossiers seront examinés par le conseiller en occupation MLAB TECH, par l’entremise de l’agent ERPT du personnel des Services de santé, à: ++Prior Learning Assessment and Recognition / Évaluation et reconnaissance des acquis@CMP D H Svcs Pers@Ottawa-Hull",
          "3. Certains candidats peuvent avoir suivi un parcours de formation non traditionnel ou une voie de formation internationale pour obtenir leur certification. Des renseignements sur les programmes de formation non traditionnels ou internationaux jugés acceptables pour les TLM sont disponibles à : Devenir technologiste de laboratoire médical (TLM)",
          "4. La liste des établissements d'enseignement agréés offrant un programme en technologie de laboratoire médical se trouve au lieu suivant : Programmes de formation – Agrément Canada",
          "5. Pour en savoir plus sur la certification de la SCSLM, consultez : https://csmls.org/",
          "6. Pour en savoir plus sur la certification de l’ACORPLM, consultez : https://camlpr.org/camlpr/",
          "7. Renseignements sur les examens des domaines de pratique : Types d’examens, contenu et format – ACORPLM",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "5 ans",
      },
      {
        program: "PFS-MR",
        duration: "9 ans",
      },
    ],
  },
  {
    id: "00153",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "TECHNOLOGUE EN RADIATION MÉDICALE",
    abbreviation: "TECH RAD M",
    requirements:
      "FORCES RÉGULIÈRE & RÉSERVE: Diplôme ou baccalauréat dans un programme agréé de technologie radiologique médicale, permis/certification sans restriction, et lettre de l'organisme de réglementation en règle.",
    details: [
      {
        force: "FORCES RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: [
              "Candidat civil 1, 2, 3",
              "RECL 1, 2, 3",
              "MÉ 1, 2, 3",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme ou baccalauréat dans un programme agréé de technologie radiologique médicale 4, 5",
                  "Détenir un permis, une certification ou autorisation sans restriction d’exercer comme technologue en radiation médicale (en règle et en vigueur) provenant d’un organisme de réglementation provincial/territorial reconnu 6",
                  "Lettre de l'organisme de réglementation de la profession du candidat attestant que ce dernier est « en règle » 6",
                  "OU",
                  "Diplôme ou baccalauréat dans un programme agréé de technologie radiologique médicale 4, 5",
                  "Certification provenant d’un association professionnel ayant conclu une entente récproque avec l’Association canadienne des technologues en radiation médicale (ACTRM) 6",
                  "Lettre de l'organisme de réglementation de la profession du candidat attestant que ce dernier est « en règle » 6",
                ],
                experience: [
                  "Obtention d’un diplôme au cours des 12 mois précédents : Aucune expérience requise",
                  "OU",
                  "Obtention d’un diplôme au delà des 12 mois précédents : Le technoloque doit avoir travaillé pendant au moins 700 heures au cours des 5 années précédant leur demande de renouvellement de permis. Aucun stage pretique à l’interne ou cours de recyclage n’est exigé.",
                ],
              },
            ],
          },
          {
            candidates: [
              "Candidat civil 1,2,3",
              "RECL 1,2,3",
              "MÉ1,2,3",
              "(tous avec des antécédents de sercice comme TECH RAD M 00153)",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme ou baccalauréat dans un programme agréé de technologie radiologique médicale 4, 5",
                  "Détenir un permis, une certification ou autorisation sans restriction d’exercer comme technologue en radiation médicale (en règle et en vigueur) provenant d’un organisme de réglementation provincial/territorial reconnu 6",
                  "Lettre de l'organisme de réglementation de la profession du candidat attestant que ce dernier est « en règle » 6",
                  "OU",
                  "Diplôme ou baccalauréat dans un programme agréé de technologie radiologique médicale 4, 5",
                  "Certification provenant d’un association professionnel ayant conclu une entente récproque avec l’Association canadienne des technologues en radiation médicale (ACTRM) 6",
                  "Lettre de l'organisme de réglementation de la profession du candidat attestant que ce dernier est « en règle » 6",
                ],
                experience: [
                  "Atteinte du Niveau opérationnel de competence (NOC) comme TECH RAD M 00153 au cours des cinq (5) dernières années8",
                ],
              },
            ],
          },
          {
            candidates: ["PFS-MR 1, 2, 9", "Candidat civil", "RECL", "MÉ"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition ou être présentement inscrit comme étudiant à temps plein à un programme d'études dans un établissement d'enseignement postsecondaire choisi par les FAC 7",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces canadiennes (TAFC), s’ils ne l’ont pas déjà fait. Seul un candidat PFS-MR est tenu d’obtenir la note de passage du TAFC. Consulter la Feuille de travail ˗ Affectations (FTA) pour connaître les notes de passage en vigueur.",
          "2. Conformément aux exigences d’enrôlement/RECL/MÉ/PFS-MR.",
          "3. Afin d’assurer la conformité de tous les candidats aux exigences relatives aux permis d’exercice et de certification, les dossiers font l’objet d’un examen par le conseiller du GPM TECH RAD M, par l’entremise de l’officier ÉFA du personnel des Services de santé à l’adresse suivante : DND.CFHSvcsGp_PLAR-ERA_GpSvcFC.MDN@forces.gc.ca",
          "4. Les seuls programmes acceptables doivent sont ceux dans le domains en technologie de radiation médicale (ce qui exclut ceux en imagerie par résonnance magnétique, en médecine nucléaire, en radiothérapie et thérapie ultrasonique).",
          "5. On trouve la liste des établissements d’études agréés qui offrent le programme de technologie radiologique médicale au lien suivant : https://accreditation.ca/educational-programs/.",
          "6. On trouve les organismes de réglementation et les partenaires provinciaux/territoriaux au site suivant : https://www.camrt.ca/fr/a-propos-de-actrm/partenariats/organismes-provinciaux/.",
          "7. La liste des établissements d’études postsecondaires, les programmes et les exigences personnelles connexes (entre autres la durée et les crédits des cours) est tenue èa jour dans la base de données des Accréditations, Certifications et Équivalences (FAC-ACE) au lien https://caface-rfacace.forces.gc.ca/fr/index. Le lien Current NCMSTEP - PIRA MOLs contient une liste des programmes agrees, notamment des renseignements concernant le programme PESMR, les incitatifs de solde et au recrutement (ISR) ainsi que le liste des groupes professionnels militaires (LGPM).",
          "8. Le Niveau opérationnel de compétence est énoncé dans la description du GPM TECH RAD M 00153 au lien suivant : http://cmp-cpm.mil.ca/fr/soutien/personnel-militaire/dbpp-description-de-gpm.page.",
          "9. La promotion à Cpl Spec 1 n’aura lieu qu’à l’achèvement de l’examen national de certification.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: [
              "Candidat civil 1, 2, 3",
              "RECL 1, 2, 3",
              "MÉ 1, 2, 3",
              "MSÉ 1, 2, 3",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme ou baccalauréat dans un programme agréé de technologie radiologique médicale 4, 5",
                  "Certification provenant d’un association professionnel ayant conclu une entente récproque avec l’Association canadienne des technologues en radiation médicale (ACTRM) 6",
                  "Lettre de l'organisme de réglementation de la profession du candidat attestant que ce dernier est « en règle » 6",
                  "OR",
                  "Diplôme ou baccalauréat dans un programme agréé de technologie radiologique médicale 4, 5",
                  "Certification provenant d’un association professionnel ayant conclu une entente récproque avec l’Association canadienne des technologues en radiation médicale (ACTRM) 6",
                  "Lettre de l'organisme de réglementation de la profession du candidat attestant que ce dernier est « en règle » 6",
                ],
                experience: [
                  "Occuper présentement un employ à templs plein ou à temps partiel dans un sercice radiologique en clinique",
                  "Le candidat doit avoir travaillé pendant au moins 700 heures au cours des 5 années précédent leur demande de renouvellement de précédant leur demande de renouvellement de permis. Aucun stage pretique à l’interne ou cours de recyclage n’est exigé.",
                ],
              },
            ],
          },
          {
            candidates: [
              "Candidat civil 1, 2, 3",
              "RECL 1, 2, 3",
              "MÉ 1, 2, 3",
              "MSÉ 1, 2, 3",
              "(tous avec des antécédents de sercice comme TECH RAD M 00153)",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme ou baccalauréat dans un programme agréé de technologie radiologique médicale 4, 5",
                  "Certification provenant d’un association professionnel ayant conclu une entente récproque avec l’Association canadienne des technologues en radiation médicale (ACTRM) 6",
                  "Lettre de l'organisme de réglementation de la profession du candidat attestant que ce dernier est « en règle » 6",
                  "OU",
                  "Diplôme ou baccalauréat dans un programme agréé de technologie radiologique médicale 4, 5",
                  "Certification provenant d’un association professionnel ayant conclu une entente récproque avec l’Association canadienne des technologues en radiation médicale (ACTRM) 6",
                  "Lettre de l'organisme de réglementation de la profession du candidat attestant que ce dernier est « en règle » 6",
                ],
                experience: [
                  "Atteinte du Niveau opérationnel de competence (NOC) comme TECH RAD M 00153 au cours des cinq (5) dernières années8",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces canadiennes (TAFC), s’ils ne l’ont pas déjà fait. Ils ne sont pas tenus d’obtenir la note de passage du TAFC.",
          "2. Conformément aux exigences d’enrôlement/RECL/MÉ/MSÉ.",
          "3. Afin d’assurer la conformité de tous les candidats aux exigences relatives aux permis d’exercice et de certification, les dossiers font l’objet d’un examen par le conseiller du GPM TECH RAD M, par l’entremise de l’officier ÉFA du personnel des Services de santé à l’adresse suivante : DND.CFHSvcsGp_PLAR-ERA_GpSvcFC.MDN@forces.gc.ca.",
          "4. Les seuls programmes acceptables doivent sont ceux dans le domains en technologie de radiation médicale (ce qui exclut ceux en imagerie par résonnance magnétique, en médecine nucléaire, en radiothérapie et thérapie ultrasonique).",
          "5. On trouve la liste des établissements d’études agréés qui offrent le programme de technologie radiologique médicale au lien suivant : https://accreditation.ca/educational-programs/.",
          "6. On trouve les organismes de réglementation et les partenaires provinciaux/territoriaux au site suivant : https://www.camrt.ca/fr/a-propos-de-actrm/partenariats/organismes-provinciaux/.",
          "7. Le Niveau opérationnel de compétence est énoncé dans la description du GPM TECH RAD M 00153 au lien suivant : http://cmp-cpm.mil.ca/fr/soutien/personnel-militaire/dbpp-description-de-gpm.page",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
      {
        program: "PFS-MR",
        duration: "9 ans",
      },
    ],
  },
  {
    id: "00155",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "TECHNOLOGUE EN ÉLECTRONIQUE BIOMÉDICAL",
    abbreviation: "TEC ÉB",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme de technologie accrédité en ingénierie biomédicale délivré par un établissement canadien.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme de technologie accrédité en ingénierie biomédicale délivré par un établissement canadien 2",
                ],
                experience: [
                  "A travaillé en tant que technologue en électronique biomédicale pendant une période totale d’au moins six (6) mois au cours des deux (2) dernières années",
                  "OU",
                  "Aucun minimum d’expérience requis pour les nouveaux gradués (dans les 12 mois d'obtenir un diplôme)",
                ],
              },
            ],
          },
          {
            candidates: ["PFS-MR 1 :", "Candidat civil", "RECL", "TCS"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires (Sec V Québec)",
                  "(Voir le lien afin d'obtenir les exigences d’admission pour chacun des établissements post-secondaires choisis par les FC) 2",
                  "ET",
                  "Être accepté sans condition ou être actuellement inscrit à un programme accrédité de technologie d'ingénierie biomédicale dans un établissement d'enseignement postsecondaire au Canada 2",
                ],
                experience: ["Critères actuels du PFS-MR"],
              },
            ],
          },
          {
            candidates: ["TCS 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme de technologie accrédité en ingénierie biomédicale délivré par un établissement canadien 2",
                ],
                experience: [
                  "Actuellement employé en tant que technologue en électronique biomédicale",
                  "OU",
                  "Aucun minimum d’expérience requis pour les nouveaux gradués (dans les 12 mois d'obtenir un diplôme)",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. La liste des établissements postsecondaires et des programmes approuvés par le CAF, ainsi que les exigences individuelles associées (y compris la durée et les crédits), sera mise à jour dans le Liste des groupes professionnels militaires (LGPM) sur le portail des Forces armées canadiennes Accréditations, Certifications et Équivalences (FAC ACE)",
        ],
      },
      {
        force: "FORCE DE LA RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme de technologie accrédité en ingénierie biomédicale délivré par un établissement canadien 2",
                ],
                experience: [
                  "Actuellement employé en tant que technologue en électronique biomédicale",
                ],
              },
            ],
          },
          {
            candidates: ["TCS 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme de technologie accrédité en ingénierie biomédicale délivré par un établissement canadien 2",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. La liste des établissements postsecondaires et des programmes approuvés par le CAF, ainsi que les exigences individuelles associées (y compris la durée et les crédits), sera mise à jour dans le Liste des groupes professionnels militaires (LGPM) sur le portail des Forces armées canadiennes Accréditations, Certifications et Équivalences (FAC ACE)",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
      {
        program: "PFS-MR",
        duration: "8 ans",
      },
    ],
  },
  {
    id: "00161",
    medicalStandard: { v: 3, cv: 2, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "POLICE MILITAIRE",
    abbreviation: "PM",
    requirements:
      "FORCE REGULIÈRE & RÉSERVE: Diplôme d’études secondaires ou équivalent, ou diplôme de Secondaire V au Québec. Permis de conduire d’une province/d’un territoire en règle.",
    details: [
      {
        force: "FORCE REGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1, 2, 3"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme dans un programme approuvé à un établissement d’enseignement postsecondaire 4",
                ],
                experience: [
                  "Au moins un an d’expérience à temps plein comme agent des forces de l’ordre (p. ex., agent de police au Canada, shérif, agent des services frontaliers du Canada [ASFC], agent de maintien de l’ordre public ou garde de sécurité) au cours des cinq années précédentes",
                  "Permis de conduire d’une province/d’un territoire en règle 5",
                  "Aucun casier judiciaire",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Diplôme dans un programme approuvé à un établissement d’enseignement postsecondaire 4",
                ],
                experience: [
                  "Permis de conduire d’une province/d’un territoire en règle 5",
                  "Aucun casier judiciaire",
                ],
              },
            ],
          },
          {
            candidates: ["RECL 1, 2, 3"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme dans un programme approuvé à un établissement d’enseignement postsecondaire 4",
                ],
                experience: [
                  "Au moins six mois cumulatifs d’expérience de déploiement opérationnel (au pays ou à l’étranger)",
                  "Permis de conduire d’une province/d’un territoire en règle 5",
                  "Aucun casier judiciaire",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou équivalent, ou diplôme de Secondaire V au Québec",
                ],
                experience: [
                  "Permis de conduire d’une province/d’un territoire en règle 5",
                  "Aucun casier judiciaire",
                ],
              },
            ],
          },
          {
            candidates: ["RECL(U) 1, 2, 3"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme dans un programme approuvé à un établissement d’enseignement postsecondaire 4",
                ],
                experience: [
                  "Permis de conduire d’une province/d’un territoire en règle 5",
                  "Aucun casier judiciaire",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou équivalent, ou diplôme de Secondaire V au Québec",
                ],
                experience: [
                  "Avoir atteint le Niveau opérationnel de compétence (NOC) ) 6 dans un GPM précédent dans la F rég ou la P rés",
                  "OU",
                  "Au moins un an d’expérience à temps plein comme agent des forces de l’ordre (p. ex., agent de police au Canada, shérif, agent des services frontaliers du Canada [ASFC], agent de maintien de l’ordre public ou garde de sécurité) au cours des cinq années précédentes",
                  "ET (DANS LES DEUX CAS)",
                  "Permis de conduire d’une province/d’un territoire en règle 5",
                  "Aucun casier judiciaire",
                ],
              },
            ],
          },
          {
            candidates: ["MÉ1, 2, 3"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme dans un programme approuvé à un établissement d’enseignement postsecondaire 4",
                ],
                experience: [
                  "Au moins six mois cumulatifs d’expérience de déploiement opérationnel (au pays ou à l’étranger)",
                  "OU",
                  "Au moins un an d’expérience à temps plein comme agent des forces de l’ordre (p. ex., agent de police au Canada, shérif, agent des services frontaliers du Canada [ASFC], agent de maintien de l’ordre public ou garde de sécurité) au cours des cinq années précédentes",
                  "ET (DANS LES DEUX CAS)",
                  "Permis de conduire d’une province/d’un territoire en règle 5",
                  "Aucun casier judiciaire",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou équivalent, ou diplôme de Secondaire V au Québec",
                ],
                experience: [
                  "24 mois de service sans interruption depuis l’atteinte du NOC",
                  "OU",
                  "Au moins un an d’expérience à temps plein comme agent des forces de l’ordre (p. ex., agent de police au Canada, shérif, agent des services frontaliers du Canada [ASFC], agent de maintien de l’ordre public ou garde de sécurité) au cours des cinq années précédentes",
                  "ET (DANS LES DEUX CAS)",
                  "Permis de conduire d’une province/d’un territoire en règle 5",
                  "Aucun casier judiciaire",
                ],
              },
            ],
          },
          {
            candidates: [
              "Candidat civil 1, 2, 3",
              "RECL 1, 2, 3",
              "MÉ 1, 2, 3",
              "(tous avec service antérieur comme 00161 PM dans la F rég)8",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou équivalent, ou diplôme de Secondaire V au Québec",
                ],
                experience: [
                  "Permis de conduire d’une province/d’un territoire en règle 5",
                  "Aucun casier judiciaire",
                  "Avoir atteint le Niveau opérationnel de compétence (NOC) 6 comme 00161 PM dans la F rég",
                  "Au moment de la libération7 ou de la mutation, avoir reçu des titres de compétences comme PM sans aucun problème lié au code de conduite8",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces canadiennes (TAFC), s’ils ne l’ont pas déjà fait précédemment. Les candidats civils et RECL/MÉ avec service antérieur et ayant atteint le NOC dans la F rég ou qui ont obtenu un diplôme dans un programme accrédité à un établissement postsecondaire approuvé4 doivent subir le TAFC si leur dossier ne contient aucune note, mais ne sont pas tenus d’obtenir la note de passage. Tous les autres candidats doivent obtenir la note de passage du TAFC. Consulter la feuille de travail – Affectations (FTA) pour prendre connaissance des notes de passages en vigueur.",
          "2. Un comité de sélection doit examiner le dossier d’un candidat pour le GPM 00161 PM. Selon son classement par ordre de mérite, le candidat peut être invité à se présenter à un Centre d’évaluation de la Police militaire (PM) afin qu’on détermine son aptitude à être sélectionné pour ce GPM. Les résultats du CEPM indiquant qu’un candidat a été retenu restent valides pendant deux ans à partir de la date de son évaluation. Seul le Grand prévôt des Forces canadiennes (GPFC) peut octroyer une dérogation au processus de sélection des policiers militaires. Tout militaire actuellement en service (P rés) ou avec service antérieur comme PM doit prendre part au processus de sélection en vue d’une évaluation individuelle par le GPFC. Toute demande de la part d’un candidat doit être adressée à un officier de sélection de la CGPM PM des FAC.",
          "3. La liste des établissements postsecondaires approuvés par les FAC, des programmes et des exigences individuelles associées (entre autres leur durée et les crédits octroyés) figurera dans la base de données des Accréditations, Certifications et Équivalences (FAC-ACE) au lien https://caface-rfacace.forces.gc.ca/fr/index. Le lien en question contiendra et tiendra à jour la liste des programmes accrédités, entre autres des renseignements sur le programme PESMR et les primes au rendement/indemnités de recrutement (PRIR) de la Liste des groupes professionnels militaires (LGPM)).",
          "4. Le candidat doit détenir un permis de conduire d’une province ou d’un territoire (de classe G ou 5) en règle et qui n’est frappé d’aucune condition restrictive et sans aucune infraction en matière de conduite qui limiterait l’entièreté de ses privilèges de conduite. Il doit donc remettre une copie de son dossier de conducteur de la province/du territoire en question.",
          "5. Le Niveau opérationnel de compétence (NOC) est expliqué dans la description du GPM à l’adresse suivante : http://cmp-cpm.mil.ca/fr/soutien/personnel-militaire/dbpp-description-de-gpm.page",
          "6. La période écoulée depuis la date de la libération de la F rég ne doit pas dépasser cinq ans.",
          "7. La demande de verification du code de conduit doit être envoyée au GP PM FC//CEM – Disponibilité opérationnelle.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: [
              "Candidat civil 1, 2, 3",
              "RECL 1, 2, 3",
              "MÉ 1, 2, 3",
              "MSÉ 1, 2, 3",
              "(PM de la P rés, ID SGPM 00161.14, 00161.15 et 00161.16)",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "11e année du secondaire ou Secondaire V au Québec",
                ],
                experience: [
                  "Aucun casier judiciaire",
                  "Permis de conduire d’une province/d’un territoire en règle 6 (ID SGPM 00161.14 et 00161.16 uniquement)",
                ],
              },
            ],
          },
          {
            candidates: [
              "Candidat civil 1, 2",
              "RECL 1, 2",
              "MÉ 1, 2",
              "MSÉ 1, 2",
              "(Tous en service actif ou avec service antérieur comme PM 00161 dans la F rég ou la P rés)",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplômes d’études secondaires ou équivalent, ou de Secondaire V au Québec",
                ],
                experience: [
                  "Atteinte du Niveau opérationnel de compétence (NOC)5 dans la F rég",
                  "Aucun casier judiciaire",
                  "Permis de conduire d’une province/d’un territoire en règle 6 (ID SGPM 00161.14 et 00161.16 uniquement)",
                  "Au moment de la libération ou de la mutation, avoir reçu des titres de compétences comme PM sans aucun problème lié au code de conduite 6",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces canadiennes (TAFC), s’ils ne l’ont pas déjà fait précédemment. Les candidats civils et les candidats RECL ou MÉ avec service antérieur et ayant atteint le NOC dans la F rég ou qui ont obtenu un diplôme dans un programme accrédité à un établissement postsecondaire approuvé4 doivent passer le TAFC si leur dossier ne contient aucune note, mais ne sont pas tenus d’obtenir la note de passage. Tous les autres candidats doivent obtenir la note de passage du TAFC. Consulter la feuille de travail – Affectations (FTA) pour prendre connaissance des notes de passages en vigueur.",
          "2. Conformément aux critères d’enrôlement/RECL/MÉ/MSÉ en vigueur.",
          "3. Un comité de sélection doit examiner le dossier d’un candidat des sous-divisions 00161.14 ou 00161.16 PM de l’élément constitutif de la P rés (PM accrédité de la P rés). Selon son classement par ordre de mérite, le candidat peut être invité à se présenter à un Centre d’évaluation de la police militaire (CEPM) afin qu'on détermine son aptitude à être sélectionné pour ce GPM. Les résultats du CEPM indiquant qu’un candidat a été retenu restent valides pendant deux ans à partir de la date de son évaluation. Seul le Grand Prévôt des Forces armées canadiennes (GPFAC) peut octroyer une dérogation au processus de sélection des policiers militaires. Tout militaire actuellement en service (P rés) ou avec service antérieur comme PM doit passer ce processus de sélection en vue d’une évaluation individuelle par le GPFC. Toute demande de la part d’un candidat doit être adressée à un officier de sélection de la CGPM PM des FAC.",
          "4. Un candidat des sous-divisions 00161.14 ou 00161.16 PM de l’élément constitutif de la P rés (PM accrédité de la P rés) doit détenir un permis de conduire d’une province ou d’un territoire (de classe G ou 5) en règle et qui n’est frappé d’aucune condition restrictive et sans aucune infraction en matière de conduite qui limiterait l’entièreté de ses privilèges de conduite. Il doit donc remettre une copie de son dossier de conducteur de la province/du territoire en question.",
          "5. Le Niveau opérationnel de compétence (NOC) est expliqué dans la description du GPM à l’adresse suivante : http://cmp-cpm.mil.ca/fr/soutien/personnel-militaire/dbpp-description-de-gpm.page.",
          "6. La demande de verification du code de conduit doit être envoyée au GP PM FC//CEM – Disponibilité opérationnelle",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "5 ans",
      },
    ],
  },
  {
    id: "00164",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "CUISINIER",
    abbreviation: "CUIS",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: 10e année du secondaire / Secondaire IV, comportant mathématiques générales de 10e année / Sec IV.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme collégial ou certifiat d’un collège agréé en :",
                  "o Compétences/art culinaires 2",
                  "Diplôme d’études secondaires ou l’équivalent comportant :",
                  "o mathématiques générales de 11e année / Sec V",
                ],
                experience: [
                  "Certificat des normes interprovinciales Sceau rouge 4",
                  "Expérience de neuf cent soixante heures (960) ou plus au cours des deux (2) années précédentes dans l’un ou plusieurs des domaines/GPM suivants : o Boulanger o Cuisinier/Chef-cuisinier o Boucher",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire / Secondaire IV, comportant :",
                  "o mathématiques générales de 10e année / Sec IV",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "(qualifié)"],
            requirements: [
              {
                level: "Ideal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent comportant :",
                  "o mathématiques générales de 11e année / Sec V",
                ],
                experience: [
                  "Atteinte du NPC3 comme 00164 CUISINIER dans la F rég ou la P rés",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire / Secondaire IV, comportant :",
                  "o mathématiques générales de 10e année / Sec IV",
                ],
                experience: [
                  "Atteinte du NPC3 comme 00164 CUISINIER dans la F rég ou la P rés",
                ],
              },
            ],
          },
          {
            candidates: ["PIESMR 1", "Candidat civil", "RECL", "MÉ"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Admissibilité inconditionnelle comme étudiant à temps plein dans un programme à un établissement postsecondaire autorisé par les FAC 2",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. La liste des établissements postsecondaires et des programmes approuvés par le CAF, ainsi que les exigences individuelles associées (y compris la durée et les crédits), sera mise à jour dans le Liste des groupes professionnels militaires (LGPM) sur le portail des Forces armées canadiennes Accréditations, Certifications et Équivalences (FAC ACE)",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP).",
          "4. On peut se renseigner sur la certification du Programme des normes interprovinciales Sceau rouge concernant un CUISINIER au site suivant : http://www.red-seal.ca/w.2lc.4m.2-fra.html.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme collégial ou certifiat d’un collège agréé en :",
                  "o Compétences/art culinaires 2",
                  "Diplôme d’études secondaires ou l’équivalent comportant :",
                  "o mathématiques générales de 11e année / Sec V",
                ],
                experience: [
                  "Certificat des normes interprovinciales Sceau rouge 4",
                  "Expérience de neuf cent soixante heures (960) ou plus au cours des deux (2) années précédentes dans l’un ou plusieurs des domaines/GPM suivants : o Boulanger o Cuisinier/Chef-cuisinier o Boucher",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire / Secondaire IV, comportant :",
                  "o mathématiques générales de 10e année / Sec IV",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "(qualifié)"],
            requirements: [
              {
                level: "Ideal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent comportant :",
                  "o mathématiques générales de 11e année / Sec V",
                ],
                experience: [
                  "Atteinte du NPC3 comme 00164 CUISINIER dans la F rég ou la P rés",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire / Secondaire IV, comportant :",
                  "o mathématiques générales de 10e année / Sec IV",
                ],
                experience: [
                  "Atteinte du NPC3 comme 00164 CUISINIER dans la F rég ou la P rés",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. La liste des établissements postsecondaires et des programmes approuvés par le CAF, ainsi que les exigences individuelles associées (y compris la durée et les crédits), sera mise à jour dans le Liste des groupes professionnels militaires (LGPM) sur le portail des Forces armées canadiennes Accréditations, Certifications et Équivalences (FAC ACE)",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP).",
          "4. On peut se renseigner sur la certification du Programme des normes interprovinciales Sceau rouge concernant un CUISINIER au site suivant : http://www.red-seal.ca/w.2lc.4m.2-fra.html.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "3 ans",
      },
      {
        program: "PFS-MR",
        duration: "5 ans",
      },
    ],
  },
  {
    id: "00166",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 3, a: 5, u: 5 },
    title: "MUSICIEN",
    abbreviation: "MUS",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme d’études secondaires ou de Secondaire V au Québec.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: [
              "Candidat civil 1, 2, 3, 5",
              "RECL 1, 2, 3, 5",
              "MÉ 1, 2, 3, 5",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme ou Baccalauréat en interprétation musicale décerné par un collège, conservatoire de musique, ou une université reconnus6",
                ],
                experience: [
                  "Expérience comme musicien professionnel dans une variété d’ensembles et dans divers styles de musique, p. ex. à titre de musicien travaillant à son propre compte, ou à temps plein avec une orchestre, un ensemble ou un groupe de musique local 4",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou de Secondaire V au Québec",
                ],
                experience: [
                  "Expérience comme musicien dans une variété d’ensembles et dans divers styles de musique, p. ex. à titre de musicien travaillant à son propre compte, ou à temps plein avec une orchestre, un ensemble ou un groupe de musique local 4",
                  "OU",
                  "Étudiant en voie d’obtenir un diplôme ou un Baccalauréat en interprétation musicale dans un collège, un conservatoire de musique ou une université reconnus 4",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces canadiennes (TAFC), s’ils ne l’ont pas déjà fait précédemment. Les candidats doivent atteindre le seuil minimum d’admissibilité pour MR (10e percentile de la note totale) au TAFC.",
          "2. Les candidats avec service antérieur et ayant atteint le NOC comme 00166 MUS ne sont pas tenus d’obtenir la note de passage du TAFC. Consulter la feuille de travail – Affectations (FTA) pour prendre connaissance des notes de passages en vigueur.",
          "3. Conformément aux critères de RECL/MÉ en vigueur.",
          "4. Tous les candidats doivent passer par un processus d’évaluation, qui inclut notamment une audition sous l’autorité du superviseur musicale, tel que prévue dans la DOAD 5041-1, Services de musique des Forces canadiennes. Le processus d’audition pour la Force régulière comporte trois étapes, décrites au site Web suivant : https://www.canada.ca/fr/services/defense/fac/envedette/musique/demande-emploi-musicien-forces-canadiennes.html",
          "5. L’expérience relative à ces critères d’entrée fera l’objet d’une vérification lors du processus d’audition. Pour obtenir plus de renseignements, communiquer par courriel à l’adresse : Music-Musique@forces.gc.ca",
          "6. Les Normes d'aptitude physique au travail (NAPT) sont énoncées dans la description des spécifications de travail (DST) MUS au lien suivant : https://collaboration-cmp.forces.mil.ca/sites/MPG/DPGR/dpgr2/SpecMaint/Occupational_Specifications/OFS/MUSCN%2000166/OFS_MUSCN_F_00166_Anx_E.docx",
          "7. Les candidats titulaires d’un diplôme en musique sont dispensés de passer l’examen théorique et auditif pendant la phase d’audition.",
        ],
      },
      {
        force: "FORCE DE LA RÉSERVE",
        candidateGroups: [
          {
            candidates: [
              "Candidat civil 1, 2, 3, 5",
              "RECL 1, 2, 3, 5",
              "MÉ 1, 2, 3. 5 (divers ID SGPM)",
              "MSÉ 1, 2, 3, 5",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "A obtenu ou est en voie er d’obtenir un diplôme de 1er cycle en musique ou en interprétation musicale, d’une université ou d’un collège reconnus",
                ],
                experience: [
                  "Expérience comme musicien dans une variété d’ensembles et dans divers styles de musique, p. ex. à titre de musicien travaillant à son propre compte, ou à temps plein dans une orchestre, un ensemble ou un groupe de musique local 4",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année secondaire, Secondaire IV au Québec, ou l’équivalent",
                ],
                experience: [
                  "Expérience limitée comme musicien dans une variété d’ensembles et dans divers styles de musique (p. ex., jouer dans un orchestre à 4 l’école secondaire)",
                ],
              },
            ],
          },
          {
            candidates: ["MÉ 1, 2, 3, 5 (même ID SGPM – MUS 00166)"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme de 1er cycle universitaire ou autre diplôme en musique ou en interprétation musicale d’une université ou d’un collège reconnus",
                ],
                experience: [
                  "Doit atteindre le niveau opérationnel de compétence comme MUS 00166 dans la F rég.",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année secondaire, Secondaire IV au Québec, ou l’équivalent",
                ],
                experience: [
                  "Doit atteindre le niveau opérationnel de compétence comme MUS 00166 dans la F rég.",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces canadiennes (TAFC), s’ils ne l’ont pas déjà fait précédemment. Les candidats doivent atteindre le seuil minimum d’admissibilité pour MR (10e percentile de la note totale) au TAFC.",
          "2. Les candidats avec service antérieur et ayant atteint le NOC comme 00166 MUS ne sont pas tenus d’obtenir la note de passage du TAFC. Consulter la feuille de travail – Affectations (FTA) pour prendre connaissance des notes de passages en vigueur.",
          "3. Conformément aux critères de RECL/MÉ/MSÉ en vigueur.",
          "4. Tous les candidats doivent passer par un processus d’évaluation, qui inclut notamment une audition sous l’autorité du superviseur musicale, tel que prévue dans la DOAD 5041-1, Services de musique des Forces canadiennes. Le processus d’audition pour la Force régulière comporte trois étapes, décrites au site Web suivant : https://www.canada.ca/fr/services/defense/fac/envedette/musique/demande-emploi-musicien-forces-canadiennes/audition-musiques-reserve.html",
          "5. L’expérience relative à ces critères d’entrée fera l’objet d’une vérification lors du processus d’audition. Pour obtenir plus de renseignements, communiquer par courriel à l’adresse : MusicMusique@forces.gc.ca",
          "6. Les Normes d'aptitude physique au travail (NAPT) sont énoncées dans la description des spécifications de travail (DST) MUS au lien suivant : https://collaboration-cmp.forces.mil.ca/sites/MPG/DPGR/dpgr2/SpecMaint/Occupational_Specifications/OFS/MUSCN%2000166/OFS_MUSCN_F_00166_Anx_E.docx",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
    ],
  },
  {
    id: "00167",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "COMMIS DES POSTES",
    abbreviation: "COMMIS P",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: 10e année du secondaire ou Secondaire IV au Québec.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou diplôme de Secondaire V au Québec",
                ],
                experience: [
                  "Avoir une expérience à temps plein ou partiel pour un minimum de six (6) mois dans l’un ou plusieurs des domaines suivants :",
                  "o Service à la clientèle",
                  "o Ventes",
                  "o Utilisation de la suite Microsoft Office",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire ou Secondaire IV au Québec",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "(qualifié)"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou diplôme de Secondaire V au Québec",
                ],
                experience: [
                  "Avoir atteint le niveau opérationnel de compétence (NOC) 2 comme 00167 COMMIS P dans la F rég",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire ou Secondaire IV au Québec",
                ],
                experience: [
                  "Avoir atteint le niveau opérationnel de compétence (NOC) 2 comme 00167 COMMIS P dans la F rég",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
        ],
      },
      {
        force: "FORCE DE LA RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou diplôme de Secondaire V au Québec",
                ],
                experience: [
                  "Avoir une expérience à temps plein ou partiel pour un minimum de six (6) mois dans l’un ou plusieurs des domaines suivants :",
                  "o Service à la clientèle",
                  "o Ventes",
                  "o Utilisation de la suite Microsoft Office",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire ou Secondaire IV au Québec",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "(qualifié)"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou diplôme de Secondaire V au Québec",
                ],
                experience: [
                  "Avoir atteint le niveau opérationnel de compétence (NOC) 2 comme COMMIS P 00167 dans la F rég ou la P rés",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire ou Secondaire IV au Québec",
                ],
                experience: [
                  "Avoir atteint le niveau opérationnel de compétence (NOC) 2 comme COMMIS P 00167 dans la F rég ou la P rés",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "3 ans",
      },
    ],
  },
  {
    id: "00168",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN GESTION DU MATÉRIEL",
    abbreviation: "TECH GEST MAT",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: 10e année d’études secondaire ou Secondaire IV au Québec.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: [
              "Candidat civil 1, 2, 3",
              "RECL 1, 2, 3",
              "MÉ 1, 2, 3",
            ],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou l’équivalent"],
                experience: [
                  "Six mois d’expérience cumulative ou détention de qualifications dans l’un des domaines suivants :",
                  "o Contrôle du matériel",
                  "o Entreposage",
                  "o Approvisionnement",
                  "o Gestion budgétaire",
                  "o Expérience antérieure en gestion de magasin",
                  "o Contrôle de matières dangereuses",
                  "o Emballage de matières dangereuses",
                  "Six mois d’expérience dans l’un des logiciels suivants :",
                  "o Microsoft Office, notamment Excel",
                  "o Produits d’application de systèmes (PAS) en fonctions de gestion du matériel",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année d’études secondaire ou Secondaire IV au Québec",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: [
              "Candidat avec service antérieur 1, 2, 3",
              "RECL 1, 2, 3",
              "MÉ 1, 2, 3",
              "(Tous avec service antérieur ou actif en tant que 00168 TECH GEST MAT)",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "10e année d’études secondaire ou Secondaire IV au Québec",
                ],
                experience: [
                  "Atteinte du niveau opérationnel de compétence (NOC) 4 du GPM 00168 TECH GEST MAT dans la F rég ou la F rés",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces canadiennes (TAFC), s’il ce n’est pas déjà le cas. Les candidats civils, RECL ou MÉ qui n’ont pas atteint le NOC en tant que TECH GEST MAT 00168 doivent obtenir la note de passage du TAFC.",
          "2. Conformément aux critères d’enrôlement/RECL/MÉ en vigueur.",
          "3. Les Normes d'aptitude physique au travail (NAPT) sont énoncées dans la description des spécifications de travail (DST) TECH GEST MAT.",
          "4. Le niveau opérationnel de compétence (NOC) est expliqué dans la description du GPM.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: [
              "Candidat civil 1, 2, 3",
              "RECL 1, 2, 3",
              "MÉ1, 2, 3",
              "MSÉ 1, 2, 3",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "10e année d’études secondaire ou Secondaire IV au Québec",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: [
              "Candidat avec service antérieur 1, 2, 3",
              "RECL 1, 2, 3",
              "MÉ 1, 2, 3",
              "MSÉ 1, 2, 3",
              "(Tous avec service antérieur ou actif en tant que 00168 TECH GEST MAT)",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "10e année d’études secondaire ou Secondaire IV au Québec",
                ],
                experience: [
                  "Atteinte du niveau opérationnel de compétence (NOC) 4 du GPM 00168 TECH GEST MAT dans la F rég ou la P rés",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces canadiennes (TAFC), s’il ce n’est pas déjà le cas. Les candidats civils, RECL, MÉ ou MSÉ qui n’ont pas atteint le NOC en tant que TECH GEST MAT 00168 doivent obtenir la note de passage du TAFC.",
          "2. Conformément aux critères d’enrôlement/RECL/MÉ/MSÉ en vigueur.",
          "3. Les Normes d'aptitude physique au travail (NAPT) sont énoncées dans la description des spécifications de travail (DST) TECH GEST MAT.",
          "4. Le niveau opérationnel de compétence (NOC) est expliqué dans la description du GPM.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "3 ans",
      },
    ],
  },
  {
    id: "00169",
    medicalStandard: { v: 4, cv: 1, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "TECHNICHIEN DE MUNITIONS",
    abbreviation: "TECH MUN",
    requirements:
      "FORCE RÉGULIÈRE: 10e année du secondaire, Secondaire IV au Québec ou l’équivalent.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: [
              "Candidat civil 1, 2, 4, 5",
              "RECL 1, 2, 4, 5",
              "MÉ 1, 2, 4, 5",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou de Secondaire V au Québec",
                ],
                experience: [
                  "Détenir un permis de conduire valide d’une province 3",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire, Secondaire IV au Québec ou l’équivalent",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: [
              "Candidat civil 1, 2, 4, 5",
              "RECL 1, 2, 4, 5",
              "MÉ 1, 2, 4, 5",
              "(tous avec service antérieur comme TECH MUN 00169)",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou de Secondaire V au Québec",
                ],
                experience: [
                  "Doit avoir atteint le NQ5A ou suivi le cours de qualification du grade de Cpl pour le GPM 00169 TECH MUN dans la F rég",
                  "Détenir un permis de conduire valide d’une province 3",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire, Secondaire IV au Québec ou l’équivalent",
                ],
                experience: [
                  "Doit avoir atteint le NQ5A ou suivi le cours de qualification du grade de Cpl pour le GPM 00169 TECH MUN dans la F rég",
                  "Détenir un permis de conduire valide d’une province 3",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces canadiennes (TAFC), s’ils ne l’ont pas déjà fait.",
          "2. Conformément aux critères d’enrôlement/RECL/de mutation entre éléments en vigueur.",
          "3. Par « permis de conduire valide d’une province », il faut entendre un permis...",
          "4. Afin de suivre la formation professionnelle propre au GPM 00169 TECH MUN, tous les candidats doivent obtenir la cote de sécurité du niveau II (Secret).",
          "5. Les Normes d'aptitude physique au travail (NAPT) sont énoncées dans la description des spécifications de travail.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
    ],
  },
  {
    id: "00170",
    medicalStandard: { v: 3, cv: 2, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN DES MOUVEMENTS",
    abbreviation: "TECH MOUV",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: 10e année d’études secondaires / Secondaire IV.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou l’équivalent"],
                experience: [
                  "Au moins six mois d'expérience cumulée dans un ou plusieurs des domaines suivants : o Courtier en douane, maritime, etc. o Expéditeur et réceptionnaire; o Responsable des opérations des installations; o Agent de billets et de fret ou autre commis associé; o Utilisation de systèmes de freins à air; o Conducteur de camion; o Préposé à la rampe de transport aérien; o Manutentionnaire.",
                  "Permis de conduire d’une province / d’un territoire en règle 2",
                ],
              },
              {
                level: "Acceptable",
                education: ["10e année d’études secondaires / Secondaire IV"],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "(qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année d’études secondaires / Secondaire IV"],
                experience: [
                  "Atteinte du niveau professionnel de compétence (NPC)3 dans 00170 TECH MOUV",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le candidat doit détenir un permis de conduire d'une province/territoire (de classe G ou 5) en règle ne comprenant aucune condition ni limite en lien avec les privilèges de conduite.",
          "3. Le niveau Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
        ],
      },
      {
        force: "FORCE DE LA RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Tous les Programmes d’enrôlement 1"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année d’études secondaires / Secondaire IV"],
                experience: ["Aucune expérience requis"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
    ],
  },
  {
    id: "00171",
    medicalStandard: { v: 3, cv: 2, h: 3, g: 3, o: 3, a: 5, u: 5 },
    title: "CONDUCTEUR DE MATÉRIEL MOBILE DE SOUTIEN",
    abbreviation: "COND MMS",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: 10e année (Ontario) ou l’équivalent.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: [
              "Postulant civil 1 (aucun service précédent)",
              "Postulant civil 1 (avec service précédent autre que COND MMS)",
              "RECL et Mutation entre éléments des FC 1 (non qualifié)",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires d’Ontario ou l’équivalent",
                ],
                experience: [
                  "Aucune infraction comme le démontre le résumé des conducteurs civils",
                  "Âgé au moins de 18 ans afin de pouvoir travailler au transport de marchandises dangereuses",
                  "Produire le dossier de conducteur civil",
                  "Une expérience, des compétences ou une formation dans l’un ou plusieurs des domaines suivants constitue un atout (cette liste n’est pas complète) : o répartiteur et opérateur radio o conducteur d’ambulance o contremaître en construction générale et en équipement lourd o contremaître en transport routier o conducteur de grue o conducteur de camion léger et de poids lourds o conducteur d’autobus o chauffeur, conducteur de taxi et de limousine o conducteur de matériel lourd o Logiciels Microsoft Windows",
                ],
              },
              {
                level: "Acceptable",
                education: ["10e année (Ontario) ou l’équivalent"],
                experience: ["Aucune experience minimale requise"],
              },
            ],
          },
          {
            candidates: [
              "Postulant civil 1 (avec service précédent en qualité de 00171 COND MMS)",
              "Mutation entre éléments des FC 1 (qualifié)",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires d’Ontario ou l’équivalent",
                ],
                experience: [
                  "Posséder au moins le NQ 5 pour les 00171 COND MMS dans le dernier cinq ans",
                  "Une expérience, des compétences ou une formation dans Logiciels Microsoft Windows",
                ],
              },
              {
                level: "Acceptable",
                education: ["10e année (Ontario) ou l’équivalent"],
                experience: [
                  "Posséder au moins le NQ 3 pour les 00171 COND MMS dans le dernier cinq ans",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces canadiennes (TAFC), s’ils ne l’ont pas déjà fait. Un candidat civil RECL, MÉ ou MSÉ qui n’a pas atteint le niveau opérationnel de compétence (NOC) comme 00171 COND MMS doit obtenir la note de passage du TAFC pour ce GPM. Se reporter à la Feuille de travail – Affectation (FTA) pour prendre connaissance des notes de passage en vigueur.",
          "2. Conformément aux critères d’enrôlement/RECL/MÉ/MSÉ en vigueur.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Tous les programmes d’entrée 1,2"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année d’étude en Ontario ou l’équivalent"],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces canadiennes (TAFC), s’ils ne l’ont pas déjà fait. Un candidat civil RECL, MÉ ou MSÉ qui n’a pas atteint le niveau opérationnel de compétence (NOC) comme 00171 COND MMS doit obtenir la note de passage du TAFC pour ce GPM. Se reporter à la Feuille de travail – Affectation (FTA) pour prendre connaissance des notes de passage en vigueur.",
          "2. Conformément aux critères d’enrôlement/RECL/MÉ/MSÉ en vigueur.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "3 ans",
      },
    ],
  },
  {
    id: "00178",
    medicalStandard: { v: 3, cv: 3, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "BLINDÉS",
    abbreviation: "BLINDÉS",
    requirements: "FORCE RÉGULIÈRE & RÉSERVE: Baccalauréat : toute discipline.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "PSAC1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: ["Maîtrise académique en : toute discipline"],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: ["Baccalauréat : toute discipline"],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PFOR 1", "PFUMR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition à un programme de baccalauréat dans l’un des domaines suivants : toute discipline",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PFOEP 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent",
                  "ET",
                  "Compléter un programme de baccalauréat dans l’un des domaines suivants : toute discipline",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Conformément au DOAD 5002-10, Programme d’intégration des officiers sortis du rang, exigences académiques",
                ],
                experience: [
                  "Détenir au minimum le grade effectif de sgt dans l’un des occupations suivantes : o 00005 MR BLINDES o Conformément à la directive 00178 BLINDES PNSCO",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Les candidats doivent détenir le grade effectif de 00381 Adjuc et détenir le grade d'Adjum comme 00005 MR BLINDES",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "PSAC 1", "RECL 1", "MÉ1"],
            requirements: [
              {
                level: "Idéal",
                education: ["Maîtrise académique en : toute discipline"],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: ["Baccalauréat : toute discipline"],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIRO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Inscrit comme étudiant à temps partiel, à temps plein ou à distance dans un établissement postsecondaire canadien dans un programme menant à un baccalauréat 2 : toute discipline",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Conformément au DOAD 5002-10, Programme d’intégration des officiers sortis du rang, exigences académiques",
                ],
                experience: [
                  "Les candidats doivent détenir le grade effectif de sgt ou plus dans le GPM 00005 MR BLINDÉS",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Les candidats doivent détenir le grade effectif de 00381 Adjuc et détenir le grade d'Adjum comme 00005 MR BLINDES",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Pour les candidats du Québec, cela comprend l'inscription à un programme CÉGEP préuniversitaire approprié conformément au DOAD 5002-8, Programme d intégration à la Réserve – Officiers (PIRO).",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "9 ans",
      },
      {
        program: "PFOR",
        duration: "13 ans",
      },
    ],
  },
  {
    id: "00179",
    medicalStandard: { v: 3, cv: 3, h: 2, g: 2, o: 2, a: 5, u: 5 },
    title: "ARTILLERIE",
    abbreviation: "ARTIL",
    requirements: "FORCE RÉGULIÈRE & RÉSERVE: Baccalauréat : toute discipline.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "PSAC1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: ["Maîtrise académique en : toute discipline"],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: ["Baccalauréat : toute discipline"],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PFOR 1", "PFUMR1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition à un programme de baccalauréat dans l’un des domaines suivants : toute discipline",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PFOEP 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent",
                  "ET",
                  "Compléter un programme de baccalauréat dans l’un des domaines suivants : toute discipline",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Conformément au DOAD 5002-10, Programme d’intégration des officiers sortis du rang, exigences académiques",
                ],
                experience: [
                  "Détenir au minimum le grade effectif de sgt dans l’un des occupations suivantes : o 00368 ARTIL o Conformément à la directive 00179 ARTIL PNSCO",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Les candidats doivent détenir le grade effectif de 00381 Adjuc et détenir le grade d'Adjum comme 00368 ARTIL",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "PSAC 1", "RECL 1", "MÉ1"],
            requirements: [
              {
                level: "Idéal",
                education: ["Maîtrise académique en : toute discipline"],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: ["Baccalauréat : toute discipline"],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIRO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Inscrit comme étudiant à temps partiel, à temps plein ou à distance dans un établissement postsecondaire canadien dans un programme menant à un baccalauréat 2 : toute discipline",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Conformément au DOAD 5002-10, Programme d’intégration des officiers sortis du rang, exigences académiques",
                ],
                experience: [
                  "Détenir au minimum le grade effectif de sgt dans l’un des occupations suivantes : o 00368 ARTIL o Conformément à la directive 00179 ARTIL PNSCO",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Les candidats doivent détenir le grade effectif de 00381 Adjuc et détenir le grade d'Adjum comme 00368 ARTIL",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Pour les candidats du Québec, cela comprend l’enrôlement dans un programme pré-universitaire approprié du CÉGEP conforme à la DOAD 5002-8 PIRO.",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "9 ans",
      },
      {
        program: "PFOR",
        duration: "13 ans",
      },
    ],
  },
  {
    id: "00180",
    medicalStandard: { v: 3, cv: 3, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "OFFICIER D’INFANTERIE",
    abbreviation: "O INF",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Baccalauréat : Tout baccalauréat ès arts (général) ou en sciences (général) de trois ans / 90 heures de crédit.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "PSAC 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Tout baccalauréat ès sciences, génie, ou arts de quatre ans / 120 heures de crédit avec une majeure déclarée en : o ingénierie (BIng) o sciences appliquées (BScA) o sciences domaine o arts domaine",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "Baccalauréat : o Tout baccalauréat ès arts (général) ou en sciences (général) de trois ans / 90 heures de crédit",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PFOR 1", "PFUMR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être admis sans condition à un programme d'études de premier cycle dans l’une des disciplines suivantes : o ingénierie (BIng) o sciences appliquées (BScA) o sciences domaine o arts domaine",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PFOEP 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent",
                  "ET",
                  "Compléter un programme de baccalauréat dans l’un des domaines selon la liste Idéal/Acceptable pour les candidats EDO",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Conformément au DOAD 5002-10, Programme d’intégration des officiers sortis du rang, exigences académiques",
                ],
                experience: [
                  "Les candidats doivent détenir le grade effectif de Sgt ou supérieur dans l’une des occupations suivantes : o 00010 FANT o 00357 OP CBRN o 00369 SF OP o 00382 CBT FIS o Conformément à la directive 00180 O INF PNSCO",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Les candidats doivent détenir le grade effectif d'Adjuc (00381) et avoir déjà détenu le grade d'Adjum en tant que GPM 00010 FANT",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "PSAC 1", "RECL 1", "MÉ 1", "MSÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Tout baccalauréat ès sciences, génie, ou arts de quatre ans / 120 heures de crédit avec une majeure déclarée en : o ingénierie (BIng) o sciences appliquées (BScA) o sciences domaine o arts domaine",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "Baccalauréat : o Tout baccalauréat ès arts (général) ou en sciences (général) de trois ans / 90 heures de crédit",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIRO 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Inscrit comme étudiant à temps partiel, à temps plein ou à distance dans un établissement postsecondaire canadien dans un programme menant à un baccalauréat 2 : o ingénierie (BIng) o sciences appliquées (BScA) o sciences domaine o arts domaine",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "Inscrit comme étudiant à temps partiel, à temps plein ou à distance dans un établissement postsecondaire canadien dans un programme menant à un baccalauréat 2 : Baccalauréat : o Toute discipline",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Conformément au DOAD 5002-10, Programme d’intégration des officiers sortis du rang, exigences académiques",
                ],
                experience: [
                  "Les candidats doivent détenir le grade effectif de Sgt ou supérieur dans l’une des occupations suivantes : o 00010 FANT o 00357 OP CBRN o 00369 SF OP o 00382 CBT FIS",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Pour les candidats du Québec, cela comprend l'inscription à un programme CÉGEP préuniversitaire approprié conformément au DOAD 5002-8, Programme d intégration à la Réserve – Officiers (PIRO).",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "9 ans",
      },
      {
        program: "PFOR",
        duration: "13 ans",
      },
    ],
  },
  {
    id: "00181",
    medicalStandard: { v: 3, cv: 2, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "GÉNIE",
    abbreviation: "GÉNIE",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Baccalauréat ès sciences : Mathématiques appliquées, Sciences appliquées / générales, Chimie, Science Informatique, Sciences environnementales, Mathématiques, Mathématiques et physique, Physique, Sciences spatiales, Sciences de la terre.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "PSAC 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Baccalauréat en ingénierie (BIng) ou baccalauréat en sciences appliquées (BScA) dans l’un des domaines suivants : o civil o environnemental o géomatique",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "Baccalauréat en ingénierie (BIng) ou baccalauréat en sciences appliquées (BScA) en ingénierie dans l’un des domaines suivants : o Aérospatiale / Aéronautique o Chimie o Informatique / Systèmes Informatique o Électricité o Énergie o Physique o Géologie o Industriel o Matériaux o Mécanique o Minier o Bâtiment",
                  "OU",
                  "Baccalauréat ès sciences : o Mathématiques appliquées o Sciences appliquées / générales 2 o Chimie o Science Informatique o Sciences environnementales o Mathématiques o Mathématiques et physique o Physique o Sciences spatiales o Sciences de la terre",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PFOR 1", "PFUMR1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  'Obtenir une admission inconditionnelle dans un programme de baccalauréat qui répond aux normes d’entrées académiques "idéales" ou "acceptables" pour les candidats d’ÉDO',
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PFOEP 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent",
                  "ET",
                  "Diplôme en technologie du domaine du génie à un collège communautaire ou d’un institut de technologie reconnu",
                  "OU",
                  "Au moins deux ans de crédits d’études dans un programme de baccalauréat dans premier cycle de la liste Idéal/Acceptable pour les candidats EDO",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Conformément au DOAD 5002-10, Programme d’intégration des officiers sortis du rang, exigences académiques",
                ],
                experience: [
                  "Détenir au minimum le grade effectif de sgt dans l’un des occupations suivantes : o 00339 SAP CBT o Conformément à la directive 00339 SAP CBT PNSCO",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Les candidats doivent détenir le grade effectif de 00381 Adjuc et détenir le grade d'Adjum comme 00339 SAP CBT",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Les diplômes en sciences générales et appliquées doivent comporter un curriculum d’environ 75% de physique et de mathématiques, le reste (25 %) étant axé dans n’importe quel autre domaine.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "RECL 1", "MÉ 1", "MSÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Baccalauréat en ingénierie (BIng) ou baccalauréat en sciences appliquées (BScA) en ingénierie: o Toute discipline",
                  "Baccalaureate ès sciences4 : o Toute discipline",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: ["Baccalauréat : o Toute discipline"],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIRO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Inscrit comme étudiant à temps partiel, à temps plein ou à distance dans un établissement postsecondaire canadien dans un programme menant à un baccalauréat3 :",
                  "Baccalauréat en ingénierie (BIng) ou baccalauréat en sciences appliquées (BScA) en ingénierie : o Civil o Environnement o Géomatique o Aérospatiale / Aéronautique o Chimie o Informatique / Systèmes Informatiques o Électricité o Énergie o Physique o Géologie o Industriel o Matériaux o Mécanique o Minier o Bâtiment",
                  "OU",
                  "Baccalauréat ès sciences: o Mathématiques appliquées o Sciences appliquées / générales 2 o Chimie o Science Informatique o Sciences environnementales o Math o Math et physique o Physique o Sciences spatiales o Sciences de la terre",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIRO 1 (Exigence Critique 4)"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Enrôlé à titre d’étudiant à temps plein, à temps partiel dans un établissement d’enseignement postsecondaire canadien à un programme menant à l’un des diplômes suivants 3 : Baccalauréat : o Toute discipline",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Conformément au DOAD 5002-10, Programme d’intégration des officiers sortis du rang, exigences académiques",
                ],
                experience: [
                  "Détenir au minimum le grade effectif de sgt dans l’un des occupations suivantes : o 00339 SAP CBT",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Les diplômes en sciences générales...",
          "3. Pour les candidats du Québec, cela comprend l'inscription à un programme CÉGEP...",
          "4. Une unité de la P rés qui éprouve un besoin urgent en personnel doit fournir une justification...",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "9 ans",
      },
      {
        program: "PFOR",
        duration: "13 ans",
      },
    ],
  },
  {
    id: "00182",
    medicalStandard: { v: 3, cv: 2, h: 2, g: 2, o: 2, a: 2, u: 5 },
    title: "OFFICIER – SYSTÈMES DE COMBAT",
    abbreviation: "OSCA",
    requirements: "FORCE RÉGULIÈRE & RÉSERVE: Baccalauréat : toute discipline.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: [
              "EDO 1, 2, 3",
              "PSAC 1, 2, 3",
              "RECL 1, 2, 3",
              "MÉ 1, 2, 3",
            ],
            requirements: [
              {
                level: "Idéal",
                education: ["Maîtrise universitaire en : toute discipline"],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: ["Baccalauréat : toute discipline"],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["EDO 1, 2", "RECL 1, 2", "MÉ 1, 2", "(qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Baccalauréat : toute discipline"],
                experience: [
                  "Avoir atteint le niveau professionnel de compétence (NPC) en tant que OSCA 00182 dans la F rég 4",
                ],
              },
            ],
          },
          {
            candidates: ["PFOR 1, 2, 3, 6"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition à un programme de baccalauréat dans l’un des domaines suivants : toute discipline",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PFUMR 1, 2, 3, 6"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Avoir terminé au moins deux cours d’un an au niveau universitaire ou l’équivalent (p. ex. quatre cours d’un semestre)",
                  "ET",
                  "Être accepté sans condition à un programme d’étude menant à l’obtention d’un baccalauréat dans l’un des domaines suivants: toute discipline",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PFOEP 1, 2, 3, 6"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent",
                  "ET",
                  "Compléter un programme de baccalauréat dans l’un des domaines suivants : toute discipline",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1, 2, 3"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent",
                  "OU",
                  "Diplôme ou baccalauréat représentant au moins deux ans d’études universitaires à plein temps 5",
                ],
                experience: [
                  "Les candidats doivent détenir le grade effectif de Sgt ou supérieur dans le GPM 00019 OP DÉA",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO1, 2, 3"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Les candidats doivent détenir le grade effectif d'Adjuc et avoir déjà détenu le grade d'Adjum en tant que GPM 00019 OP DÉA",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Tous les candidats doivent conformément aux prescriptions de l'annexe E de la PFC 154",
          "3. Tous les candidats doivent réussir le processus de sélection pour 00182 OSCA au CFACSC 8 Escadre Trenton.",
          "4. Le niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM.",
          "5. Consulter la DOAD 5002-10, paragr. 3.5 (a, b) pour connaître les exigences relatives à la scolarité.",
          "6. Tout programme qui comprend des éléments non académiques qui ne sont pas directement liés au programme d’études ou qui sont requis pour obtenir un permis ou une certification professionnelle pour atteindre le NPC n’est pas autorisé.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["EDO 1, 2", "RECL 1, 2", "MÉ 1, 2", "(qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Baccalauréat : toute discipline"],
                experience: [
                  "Avoir atteint le niveau professionnel de compétence (NPC) en tant que OSCA 00182 dans la F rég 4",
                ],
              },
            ],
          },
          {
            candidates: ["PIRO1, 2 (qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Inscrit comme étudiant à temps partiel, à temps plein ou à distance dans un établissement postsecondaire canadien dans un programme menant à un baccalauréat 3 : toute discipline",
                ],
                experience: [
                  "Avoir atteint le niveau professionnel de compétence (NPC) en tant que OSCA 00182 dans la F rég 4",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Tous les candidats doivent conformément aux prescriptions de l'annexe E de la PFC 154",
          "3. Pour les candidats du Québec, cela comprend l'inscription à un programme CÉGEP préuniversitaire approprié conformément au DOAD 5002-8, Programme d intégration à la Réserve – Officiers (PIRO).",
          "4. Le niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM.",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "9 ans",
      },
      {
        program: "PFOR",
        duration: "12 ans",
      },
    ],
  },
  {
    id: "00183",
    medicalStandard: { v: 2, cv: 2, h: 2, g: 2, o: 2, a: 1, u: 5 },
    title: "PILOTE",
    abbreviation: "PIL",
    requirements: "FORCE RÉGULIÈRE & RÉSERVE: Baccalauréat : toute discipline.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: [
              "EDO 1, 2, 3",
              "PSAC 1, 2, 3",
              "RECL 1, 2, 3",
              "MÉ 1, 2, 3",
            ],
            requirements: [
              {
                level: "Idéal",
                education: ["Maîtrise universitaire en : toute discipline"],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: ["Baccalauréat : toute discipline"],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: [
              "EDO 1, 2, 3",
              "RECL 1, 2, 3",
              "MÉ 1, 2, 3",
              "(qualifié)",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: ["Baccalauréat : toute discipline"],
                experience: [
                  "Avoir atteint le niveau opérationnel de compétence (NPC) 4 en tant que Pilote 00183 dans la F rég",
                ],
              },
            ],
          },
          {
            candidates: ["PFOR 1, 2, 3, 5"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition à un programme de baccalauréat dans l’un des domaines suivants : toute discipline",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PFUMR 1, 2, 3, 5"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Avoir terminé au moins deux cours d’un an au niveau universitaire ou l’équivalent (p. ex. quatre cours)",
                  "ET",
                  "Être accepté sans condition à un programme d’étude menant à l’obtention d’un baccalauréat 4 dans l’un des domaines suivants: toute discipline",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PFOEP 1, 2, 3, 5"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent",
                  "ET",
                  "Compléter un programme de baccalauréat dans l’un des domaines suivants : toute discipline",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Tous les candidats doivent conformément aux prescriptions de l'annexe E de la PFC 154",
          "3. Le candidat doit réussir au processus de sélection du CSPNFC du 8e Escadre Trenton.",
          "4. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM.",
          "5. Tout programme qui comprend des éléments non académiques qui ne sont pas directement liés au programme d’études ou qui sont requis pour obtenir un permis ou une certification professionnelle pour atteindre le NPC n’est pas autorisé.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: [
              "EDO 1, 2, 3",
              "RECL 1, 2, 3",
              "MÉ 1, 2, 3",
              "(qualifié)",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: ["Baccalauréat : Toute discipline"],
                experience: [
                  "Avoir atteint le niveau opérationnel de compétence (NPC) 4 en tant que Pilote 00183 dans la F rég",
                ],
              },
            ],
          },
          {
            candidates: ["PIRO1, 2, 3", "(qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Inscrit comme étudiant à temps partiel, à temps plein ou à distance dans un établissement postsecondaire canadien dans un programme menant à un baccalauréat: Toute discipline",
                ],
                experience: [
                  "Avoir atteint le niveau opérationnel de compétence (NPC) 4 en tant que Pilote 00183 dans la F rég",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Tous les candidats doivent conformément aux prescriptions de l'annexe E de la PFC 154",
          "3. Pour les candidats du Québec, cela comprend l'inscription à un programme CÉGEP préuniversitaire approprié conformément au DOAD 5002-8, Programme d intégration à la Réserve – Officiers (PIRO).",
          "4. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM.",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "13 ans",
      },
      {
        program: "PFOR",
        duration: "17 ans",
      },
    ],
  },
  {
    id: "00184",
    medicalStandard: { v: 3, cv: 2, h: 2, g: 3, o: 3, a: 4, u: 5 },
    title: "CONTRÔLE AÉROSPATIAL",
    abbreviation: "C AÉRO",
    requirements: "FORCE RÉGULIÈRE & RÉSERVE: Baccalauréat : toute discipline.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: [
              "EDO 1, 2, 3",
              "PSAC 1, 2, 3",
              "RECL 1, 2, 3",
              "MÉ 1, 2, 3",
            ],
            requirements: [
              {
                level: "Idéal",
                education: ["Maîtrise universitaire en : toute discipline"],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: ["Baccalauréat : toute discipline"],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["EDO 1, 2", "RECL 1, 2", "MÉ 1, 2", "(qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Baccalauréat : toute discipline"],
                experience: [
                  "Avoir atteint le niveau de compétence (NPC) en tant que C AÉRO 00184 dans la F rég 4",
                ],
              },
            ],
          },
          {
            candidates: ["PFOR 1, 2, 3, 6"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition à un programme de baccalauréat dans l’un des domaines suivants : toute discipline",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PFUMR 1, 2, 3, 6"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Avoir terminé au moins deux cours d’un an au niveau universitaire ou l’équivalent (p. ex. quatre cours d’un semestre)",
                  "ET",
                  "Être accepté sans condition à un programme d’étude menant à l’obtention d’un baccalauréat dans l’un des domaines suivants: toute discipline",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PFOEP 1, 2, 3, 6"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent",
                  "ET",
                  "Compléter un programme de baccalauréat dans l’un des domaines suivants : toute discipline",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1, 2, 3"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent",
                  "OU",
                  "Diplôme ou baccalauréat représentant au moins deux ans d’études universitaires à plein temps 5",
                ],
                experience: [
                  "Les candidats doivent détenir le grade effectif de Sgt ou supérieur dans le 00337 OP CA",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO1, 2, 3"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Les candidats doivent détenir le grade effectif de 00381 Adjuc et avoir déjà détenu le grade d'Adjum en tant que 00337 OP CA",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Tous les candidats doivent conformément aux prescriptions de l'annexe E de la PFC 154",
          "3. Tous les candidats doivent réussir le processus de sélection pour 00182 OSCA au CFACSC 8 Escadre Trenton.",
          "4. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM.",
          "5. Consulter la DOAD 5002-10, paragr. 3.5 (a, b) pour connaître les exigences relatives à la scolarité.",
          "6. Tout programme qui comprend des éléments non académiques qui ne sont pas directement liés au programme d’études ou qui sont requis pour obtenir un permis ou une certification professionnelle pour atteindre le NPC n’est pas autorisé.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["EDO 1, 2", "RECL 1, 2", "MÉ 1, 2", "(qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Baccalauréat : toute discipline"],
                experience: [
                  "Avoir atteint le niveau de compétence (NPC) en tant que C AÉRO 00184 dans la F rég 4",
                ],
              },
            ],
          },
          {
            candidates: ["PIRO1, 2", "(qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Inscrit comme étudiant à temps partiel, à temps plein ou à distance dans un établissement postsecondaire canadien dans un programme menant à un baccalauréat 3: toute discipline",
                ],
                experience: [
                  "Avoir atteint le niveau de compétence (NPC) en tant que C AÉRO 00184 dans la F rég 4",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Tous les candidats doivent conformément aux prescriptions de l'annexe E de la PFC 154",
          "3. Pour les candidats du Québec, cela comprend l'inscription à un programme CÉGEP préuniversitaire approprié conformément au DOAD 5002-8, Programme d intégration à la Réserve – Officiers (PIRO).",
          "4. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM.",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "6 ans",
      },
      {
        program: "PFOR",
        duration: "10 ans",
      },
    ],
  },
  {
    id: "00185",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 3, o: 3, a: 5, u: 5 },
    title: "GÉNIE AÉROSPATIAL",
    abbreviation: "G AÉRO",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Baccalauréat en ingénierie (BIng), baccalauréat ès sciences appliquées (BScA) ou baccalauréat ès sciences (BSc).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "PSAC 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Baccalauréat en ingénierie (BIng) ou baccalauréat ès sciences appliquées (BScA) en ingénierie, reconnus par Ingénieurs Canada (CCI) dans l’un des domaines suivants : o Aérospatiale/Aéronautique o Informatique o Systèmes Informatique o Électricité o Systèmes Électricité o Mécanique o Systèmes Mécanique o Systèmes Mécatronique o Mécatronique o Physique o Logiciel o Systèmes Logiciel o Conception de Systèmes",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "Baccalauréat en ingénierie (BIng) ou baccalauréat ès sciences appliquées (BScA) en ingénierie, reconnus par Ingénieurs Canada (CCI) dans l’un des domaines suivants : o Chimie o Gestion o Matériaux o Spatiale",
                  "Baccalauréat ès sciences (BSc) : o Sciences Appliquées 2 o Science Informatique o Sciences Spatiales o Sciences de terre o Physique o Chimie",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["EDO 1", "RECL 1", "MÉ 1", "(qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Baccalauréat: o n'importe lequel"],
                experience: [
                  "Doit avoir atteint le niveau opérationnel de compétence (NPC)3 en 00185 G AÉRO de la F rég",
                ],
              },
            ],
          },
          {
            candidates: ["PFOR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être admis sans condition à un : Baccalauréat en ingénierie (BIng) ou baccalauréat ès sciences appliquées (BScA) en ingénierie, reconnus par Ingénieurs Canada (CCI) dans l’un des domaines suivants : o Aérospatiale/Aéronautique o Chimie o Informatique o Systèmes Informatique o Électricité o Systèmes Électricité o Gestion o Matériaux o Mécanique o Systèmes Mécanique o Systèmes Mécatronique o Mécatronique o Physique o Logiciel o Systèmes Logiciel o Spatiale o Conception de Systèmes",
                  "Baccalauréat ès sciences (BSc) : o Sciences Appliquées 2 o Science Informatique o Sciences Spatiales o Sciences de terre o Physique o Chimie",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PFUMR 1, 2"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Avoir terminé au moins deux cours d’un an au niveau universitaire ou l’équivalent (p. ex. quatre cours)",
                  "AND",
                  "Être admis sans condition à un programme d’études de premier cycle dans l’un des domaines suivants : Baccalauréat en ingénierie (BIng) ou baccalauréat ès sciences appliquées (BScA) en ingénierie, reconnus par Ingénieurs Canada (CCI) dans l’un des domaines suivants: o Aérospatiale/Aéronautique o Chimie o Informatique o Systèmes Informatique o Électricité o Systèmes Électricité o Gestion o Matériaux o Mécanique o Systèmes Mécanique o Systèmes Mécatronique o Mécatronique o Physique o Logiciel o Systèmes Logiciel o Spatiale o Conception de Systèmes",
                  "Baccalauréat ès sciences (BSc) : o Sciences Appliquées o Science Informatique o Sciences Spatiales o Sciences de terre o Physique o Chimie",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Diplôme d’études secondaires ou l’équivalent"],
                experience: [
                  "Détenir au minimum le grade effectif de sgt dans l’un des occupations suivantes : o 00021 MÉC B o 00135 TECH AÉRO o 00136 TECH AVIO o 00138 TECH SA o 00261 TECH SA (A) o 00343 TECH END o 00363 SUR MA",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Les candidats doivent avoir le grade effectif de 00381 Adjuc et détenir le grade d'Adjum dans l’un des occupations suivantes : o 00021 FLT ENGR o 00363 AM SUPT",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Les diplômes de sciences appliquées acceptables sont ceux dont au moins 75 % du programme d'études est lié à un ou plusieurs des programmes de diplômes d'ingénieur AERE « idéaux » ou « acceptables ». Les cours de mathématiques, de physique et de chimie peuvent également être pris en compte dans cette exigence de 75 %.",
          "3. Le niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM.",
        ],
      },
      {
        force: "FORCE DE LA RÉSERVE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "RECL 1", "MÉ 1", "MSÉ 1", "(qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Baccalauréat : o n'importe lequel"],
                experience: [
                  "Doit avoir atteint le niveau opérationnel de compétence (NPC)2 en 00185 G AÉRO de la F rég",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Les candidats doivent avoir le grade effectif de 00381 Adjuc et détenir le grade d'Adjum dans l’un des occupations suivantes : o 00021 MÉC B o 00363 SUR MA",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM.",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "6 ans",
      },
      {
        program: "PFOR",
        duration: "10 ans",
      },
    ],
  },
  {
    id: "00187",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "GÉNIE ÉLECTRIQUE ET MÉCANIQUE",
    abbreviation: "GEM",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Baccalauréat en ingénierie (BIng), baccalauréat en sciences appliquées (BScA) ou Baccalauréat ès sciences (BSc).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "PSAC 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Baccalauréat en ingénierie (BIng) ou baccalauréat en sciences appliquées (BScA) dans l’un des domaines suivants : o Production automatisée o Véhicules automoteurs o Électricité o Électromécanique o Systèmes électromécaniques o Systèmes électroniques o Systèmes d’ingénierie et informatique o Génie industriel o Systèmes industriels o Intégration o Gestion o Fabrication o Matériaux o Mécanique o Systèmes mécaniques o Mécatronique o Systèmes mécatroniques o Microélectronique o Nanotechnologie o Opérations et logistique o Physique o Processus o Conception de systèmes",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "Baccalauréat en ingénierie (BIng) ou baccalauréat en sciences appliquées (BScA) en ingénierie: o Toute discipline",
                  "OU",
                  "Baccalauréat ès sciences (BSc) dans l’un des domaines suivants : o Sciences appliquées 2 o Chimie o Sciences informatiques o Général 2 o Systèmes informatiques o Mathématiques/mathématiques appliquées o Physique o Sciences spatiales o Sciences de la Terre",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PFOR 1", "PFUMR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être admis sans condition à un Baccalauréat en ingénierie (BIng) ou baccalauréat en sciences appliquées (BScA) en ingénierie : o Toute discipline",
                  "OU",
                  "Baccalauréat en sciences (BSc) dans l’un des domaines suivants : o Sciences appliquées2 o Chimie o Sciences informatiques o Général2 o Systèmes informatiques o Mathématiques/mathématiques appliquées o Physique o Sciences spatiales o Sciences de la terre",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PFOEP 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent",
                  "ET",
                  "Diplôme en technologie d’ingénierie d’un collège communautaire ou d’un institut de technologie reconnu2",
                  "OU",
                  "Au moins deux ans d’études supérieures à unités dans un programme de baccalauréat en ingénierie",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Conformément au DOAD 5002-10, Programme d’intégration des officiers sortis du rang, exigences académiques",
                ],
                experience: [
                  "Le candidat doit détenir au moins le grade effectif de sgt dans l’un des GPM suivants : o 00129 TECH V o 00130 TECH A[T] o 00134 TECH MAT o 00327 TECH ÉLEC-OPTO [T] o 00388 TECH+ G MT o Conformément à la directive 00187 GEM",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Les candidats doivent occuper le rang effectif de 00381 Adjuc et avoir détenu le rang de Adjum dans l'une des occupations suivantes : o 00129 TECH V o 00130 TECH A[T] o 00134 TECH MAT o 00327 TECH ÉLEC-OPTO [T] o 00388 TECH+ G MT",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Un diplôme en sciences générales ou appliquées doit sanctionner environ 75 % d’études en physique, en chimie et en mathématiques, les 25 % restants devant porter sur n’importe quel autre domaine.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "RECL 1", "MÉ 1", "MSÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Baccalauréat en ingénierie (BIng) ou baccalauréat en sciences appliquées (BScA) dans l’un des domaines suivants : o Production automatisée o Véhicules automoteurs o Électricité o Électromécanique o Systèmes électromécaniques o Systèmes électroniques o Systèmes d’ingénierie et informatique o Génie industriel o Systèmes industriels o Intégration o Gestion o Fabrication o Matériaux o Mécanique o Systèmes mécaniques o Mécatronique o Systèmes mécatroniques o Microélectronique o Nanotechnologie o Opérations et logistique o Physique o Processus o Conception de systèmes",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "Baccalauréat en ingénierie (BIng) ou baccalauréat en sciences appliquées (BScA) en ingénierie, dans l’un des domaines suivants : o Toute discipline",
                  "OU",
                  "Baccalauréat ès sciences (BSc) dans l’un des domaines suivants : o Sciences appliquées3 o Chimie o Sciences informatiques o Général3 o Systèmes informatiques o Mathématiques/mathématiques appliquées o Physique o Sciences spatiales o Sciences de la terre",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Exigence Critique 4",
                education: ["Baccalauréat : o toute discipline"],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIRO 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Inscrit comme étudiant à temps partiel, à temps plein ou à distance dans un établissement postsecondaire canadien dans un programme menant à un Baccalauréat en ingénierie (BIng)2 ou baccalauréat en sciences appliquées (BScA)2 dans l’un des domaines suivants : o Production automatisée o Véhicules automoteurs o Électricité o Électromécanique o Systèmes électromécaniques o Systèmes électroniques o Systèmes d’ingénierie et informatique o Génie industriel o Systèmes industriels o Intégration o Gestion o Fabrication o Matériaux o Mécanique o Systèmes mécaniques o Mécatronique o Systèmes mécatroniques o Microélectronique o Nanotechnologie o Opérations et logistique o Physique o Processus o Conception de systèmes",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "Inscrit comme étudiant à temps partiel, à temps plein ou à distance dans un établissement postsecondaire canadien dans un programme menant à un : Baccalauréat en ingénierie (BIng)2 ou baccalauréat en sciences appliquées (BScA)2 en ingénierie : o Toute discipline",
                  "OU",
                  "Baccalauréat ès sciences (BSc)2 dans l’un des domaines suivants : o Sciences appliquées3 o Chimie o Sciences informatiques o Général3 o Systèmes informatiques o Mathématiques/mathématiques appliquées o Physique o Sciences spatiales o Sciences de la terre",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Exigence Critique 4",
                education: [
                  "Inscrit comme étudiant à temps partiel, à temps plein ou à distance dans un établissement postsecondaire canadien dans un programme menant à un baccalauréat 2 : o Toute disciple",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Conformément au DOAD 5002-10, Programme d’intégration des officiers sortis du rang, exigences académiques",
                ],
                experience: [
                  "Le candidat doit détenir au moins le grade effectif de sgt dans l’un des GPM suivants : o 00129 TECH V o 00130 TECH A[T] o 00134 TECH MAT o 00327 TECH ÉLEC-OPTO [T] o 00388 TECH+ G MT",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Dans le cas des candidats du Québec, ces exigences comprennent un enrôlement dans un programme CEGEP préuniversitaire, conformément au message CANFORGEN 023/13, Programme d’intégration à la Réserve – Officiers (PIRO).",
          "3. Un diplôme en sciences générales ou appliquées doit sanctionner environ 75 % d’études en physique, en chimie et en mathématiques, les 25 % restants devant porter sur n’importe quel autre domaine.",
          "4. Une justification à l’effet que la P rés éprouve un besoin urgent en personnel doit être envoyé au responsable de l’enrôlement, tel qu’exposé à la DOAD 5002-1 (c.-à-d un officier commandant de commandement ou de formation).",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "9 ans",
      },
      {
        program: "PFOR",
        duration: "13 ans",
      },
    ],
  },
  {
    id: "00189",
    medicalStandard: { v: 3, cv: 3, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "GÉNIE CONSTRUCTION",
    abbreviation: "GÉNIE CONST",
    requirements:
      "FORCE RÉGULIÈRE: Baccalauréat en ingénierie ou Baccalauréat en Sciences.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 3"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Baccalauréat en ingénierie o Civil o Mécanique o Électrique o Environnement",
                  "Baccalauréat en Sciences o BSc Génie en protection incendie",
                ],
                experience: [
                  "Aucune expérience de travail minimale requise",
                  "Leadership démontré/ posséder des qualités d'officier",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Baccalauréat en ingénierie o Chimique o Gestion o Ingénie et gestion o Géologie",
                  "Baccalauréat en Sciences o Environnement o Géologie o Technologie de sûreté et protection incendie o Géomatique/arpentage o BScA (dans un domaine connexe susmentionné)",
                ],
                experience: [
                  "Au moins trois mois d’expérience pertinente dans un ou plusieurs des domaines suivants : o industrie de la construction o gestion des installations o services d’incendies o services de l’environnement o géomatique o gestion de projet o service militaire",
                  "Leadership démontré/ posséder des qualités d'officier",
                ],
              },
              {
                level: "Exigence Critique 1",
                education: [
                  "Baccalauréat en ingénierie o Général o Aéronautique o Aérospatial o Physique o Génie informatique o Logiciel o Système d’information o Architecture maritime/navale o Nucléaire o Pétrolier",
                  "Baccalauréat en Sciences o Mathématiques o Chimie o Physique o Science spatiale o Astronomie o Informatique",
                ],
                experience: [
                  "Au moins trois mois d’expérience pertinente dans un ou plusieurs des domaines suivants : o industrie de la construction o gestion des installations o services d’incendies o services de l’environnement o géomatique o gestion de projet o service militaire",
                  "Leadership démontré/ posséder des qualités d'officier",
                ],
              },
            ],
          },
          {
            candidates: ["Recl Vol 2, 3", "Recl Oblig 2, 3"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Conformément aux normes de scolarité « Acceptable » susmentionnées de l’EDO",
                ],
                experience: [
                  "Au moins trois mois d’expérience pertinente dans un ou plusieurs des domaines suivants : o industrie de la construction o gestion des installations o services d’incendies o services de l’environnement o géomatique o gestion de projet o service militaire",
                  "Leadership démontré/ posséder des qualités d'officier",
                ],
              },
            ],
          },
          {
            candidates: ["Réaffectations 3"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Conformément aux normes de scolarité susmentionnées de l’EDO",
                ],
                experience: [
                  "Conformément aux normes de scolarité susmentionnées de l’EDO",
                  "Leadership démontré/ posséder des qualités d'officier",
                ],
              },
            ],
          },
          {
            candidates: ["PSAC 2, 3"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Conformément aux normes de scolarité susmentionnées de l’EDO",
                ],
                experience: [
                  "Au moins trois mois d’expérience pertinente dans un ou plusieurs des domaines suivants : o industrie de la construction o gestion des installations o services d’incendies o services de l’environnement o géomatique o gestion de projet o service militaire",
                  "Leadership démontré/ posséder des qualités d'officier",
                ],
              },
            ],
          },
          {
            candidates: ["PFUMR – GÉNIE CONST (Général) 3"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Deux cours crédités de niveau universitaire terminés avec succès, et acceptation inconditionnelle à un programme de premier cycle selon les critères « Idéal » de l’EDO susmentionnés",
                ],
                experience: [
                  "Satisfaire aux normes du PFUMR actuelles",
                  "Leadership démontré/ posséder des qualités d'officier",
                ],
              },
            ],
          },
          {
            candidates: [
              "PFUMR – GÉNIE CONST – Spécialiste en protection incendie 3",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Deux cours crédités de niveau universitaire terminés avec succès, et acceptation inconditionnelle à l’Université de Maryland pour le BSc Génie en protection incendie 4",
                ],
                experience: [
                  "Satisfaire aux normes du PFUMR actuelles et être Pompier 00149",
                  "Leadership démontré/ posséder des qualités d'officier",
                ],
              },
            ],
          },
          {
            candidates: ["PIOSR 3"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "12e année en Ontario, Secondaire V au Québec ou DESPA",
                ],
                experience: [
                  "Conformément aux exigences actuelles pour être CDR : 10 ans de service",
                  "ET les candidats doivent au moins avoir atteint le NQ 5 dans les SGPM suivants : o 00149 Pompier o 00238 TEC géomatique o 00301 TEC REFR o 00302 TEC DE o 00303 TEC GE o 00304 TEC PC o 00305 TEC EPPE o 00306 TEC Const o 00307 SUR GC o 00339 Génie de combat",
                  "Leadership démontré/ posséder des qualités d'officier",
                ],
              },
            ],
          },
          {
            candidates: ["PFOR 2, 3"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Conformément aux normes de recrutement du PFOR Les candidats poursuivront des études selon les normes de scolarité susmentionnées de l’EDO",
                ],
                experience: [
                  "Conformément aux exigences actuelles du PFOR",
                  "Leadership démontré/ posséder des qualités d'officier",
                ],
              },
            ],
          },
          {
            candidates: ["PFOEP 3", "Réaffectations PFOEP 3"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme de technologie d’un programme reconnu par le CCTT; ou certification de TSAI (technologue) dans l’un des programmes suivants : o Civil o Construction o Environnemental o Géomatique/arpentage o Électrique o Mécanique o Géologique/minier/pétrolier o Hydrogéologique/ hydro économique o Chimique o Informatique",
                  "OU Technique en Protection incendie",
                  "Doit poursuivre un diplôme conformément à les normes de l’EDO",
                ],
                experience: [
                  "Conformément aux exigences du PFOEP",
                  "Au moins trois mois d’expérience pertinente dans un ou plusieurs des domaines suivants : o industrie de la construction o gestion des installations o services d’incendies o services de l’environnement o géomatique o gestion de projet o service militaire",
                  "Leadership démontré/ posséder des qualités d'officier",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Les critères d’exception sont définis comme une situation où le SGPM éprouve des besoins personnels urgents et celle-ci ne peut se produire jusqu’à ce que le SGPM soit classé SGPM ROUGE dans la matrice de l’état des groupes professionnels du DBPP.",
          "2. Les dérogations pour les programmes académiques qui ne sont pas susmentionnés doivent être approuvés par le Gestionnaire du groupe professionnel GC, via l’OSPB (Air) par l’entremise de DBPP 4-2.",
          "3. Le candidat doit atteindre le seuil d’admissibilité Officiers (30e percentile de la note totale) au Test d’aptitude des Forces canadiennes (TAFC).",
          "4. Le baccalauréat de génie en protection incendie de l’Université de Maryland est un programme reconnu par le Bureau canadien d’agrément des programmes de génie, qui rencontre les exigences en matière de qualification pour la certification d’ingénieur professionnel. Ce dernier est le seul diplôme de génie en protection incendie disponible en Amérique du nord. Le programme du Collège Seneca/Université de Cincinnati ne rencontre pas toutes les exigences pour un diplôme en génie, donc il ne rencontre pas les critères d’entrée idéaux pour le groupe professionnel du Génie Construction. Essentiellement, il combine un diplôme technique et un an de Gestion de sécurité incendie fait par correspondance, résultant en l’obtention d’un baccalauréat en technologie de sûreté et protection incendie. Cette qualification est acceptable pour accéder au groupe professionnel, mais n’est pas le diplôme préféré afin de pourvoir à toutes les exigences requises par le métier Génie Construction en matière d’emploi.",
          "5. Les postulants PFOEP qui ont obtenus la Technique en protection incendie du Collège Seneca devront compléter un an d’étude par correspondance via l’Université de Cincinnati pour obtenir un baccalauréat en technologie de sûreté et protection incendie.",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "9 ans",
      },
      {
        program: "PFOR",
        duration: "13 ans",
      },
    ],
  },
  {
    id: "00190",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "PHYSIOTHÉRAPIE",
    abbreviation: "PHYSIO",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Maîtrise en physiothérapie ou Baccalauréat en physiothérapie. Permis/licence d’exercice en règle.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO1,2,3", "RECL1,2,3", "MÉ1,2,3", "PSAC1,2,3"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Maîtrise en physiothérapie ou Baccalauréat en physiothérapie",
                  "ET",
                  "Permis/licence d’exercice en règle (à titre actif) en tant que physiothérapeute émis par un organisme de réglementation provincial ou territorial4,5",
                  "Lettre de l’organisme de réglementation du candidat attestant que ce dernier est « En règle »",
                ],
                experience: [
                  "Obtention du diplôme au cours des 12 mois précédents : o Aucune expérience requise",
                  "OU",
                  "Obtention du diplôme depuis plus de 12 mois : o Au moins 1,200 heures d’expérience en tant que physiothérapeute en orthopédie, en clinique externe, ou en physiothérapie sportive au cours des 2,5 années précédentes6",
                ],
              },
            ],
          },
          {
            candidates: [
              "ES-PMNE1,8,9 (o En service F reg)",
              "PFOS1,8,9 (o Civil, o MÉ)",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Acceptation sans condition dans un programme d'un établissement postsecondaire agréé7,8 menant à une maîtrise en physiothérapie",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le candidat doit exercer la profession de physiothérapeute s’il a obtenu son diplôme de maîtrise depuis plus de 12 mois. Tous les candidats détenir un permis d’exercice complet, sans restriction et illimité émis dans une province ou un territoire du Canada.",
          "3. Candidat EDO/RECL/MÉ/ES-PMNE : pour émettre une demande d’évaluation de la formation antérieure (ÉFA), le candidat peut obtenir une liste des documents exigés en communiquant avec le groupe des Services de santé des Forces canadiennes à l’adresse suivant: DND.CFHSVCsGP_PLAR-ERA_GpSvcFC.MDN@forces.gc.ca; la demande doit être transmise au même destinataire et à la même adresse afin de pouvoir déterminer si le candidat, en plus de répondre aux exigences énoncées au tableau précédent, n’a pas fait l’objet des sanctions suivantes : a. S’être fait révoquer son permis d’exercer par ordre d’une autorité compétente; b. Faire l’objet d’une enquête de la part d’une autorité compétente. Le dossier d’un candidat ayant fait l’objet d’une enquête ayant abouti à l’imposition de sanctions fera l’objet d’un examen individuel par le Médecin général.",
          "4. Par « permis en règle sans restriction », on entend un permis complet, sans restriction et illimité d’agir de manière indépendante comme physiothérapeute dans une province ou un territoire du Canada.",
          "5. On trouve les organismes de réglementation provinciaux et territoriaux compétents au lien suivant : https://alliancept.org/fr/",
          "6. L’exercice en physiothérapie orthopédique en clinique externe ou en physiothérapie sportive doit se situer dans une un zone de traitement d’une population active et ayant recours à des pratiques factuelles.",
          "7. On trouve une liste des programmes accrédités de maîtrise en physiothérapie du conseil canadien des programmes universitaires de physiothérapie au site Web suivant : LE CONSEIL CANADIEN DES PROGRAMMES UNIVERSITAIRES DE PHYSIOTHÉRAPIE - Programmes canadiens",
          "8. Les écoles qui ne figurent pas sur la liste au lien de la note 8 ci-dissus seront examinées au cas par cas. Les candidats souhaitant postuler à un programme non répertorié doivent en discuter avec les recruteurs spécialistes du Svc S FC bien avant la date limite du concours ESNEM en envoyant un courrier électronique à HSRecruiting-RecrutementSS@forces.gc.ca",
          "9. L’admissibilité s’applique uniquement aux candidats ayant complété le programme de baccalauréat préalable et ayant été acceptés dans un programme canadien reconnu de maîtrise en physiothérapie.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: [
              "EDO 1,2,3",
              "PSAC 1,2,3",
              "RECL1,2,3",
              "MÉ 1,2,3",
              "MSÉ 1,2,3",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Maîtrise en physiothérapie ou Baccalauréat en physiothérapie",
                  "ET",
                  "Permis/licence d’exercice en règle (à titre actif) en tant que physiothérapeute émis par un organisme de réglementation provincial ou territorial4,5",
                  "Lettre de l’organisme de réglementation du candidat attestant que ce dernier est « En règle »",
                ],
                experience: [
                  "Obtention du diplôme au cours des douze (12) mois précédents : o Aucune expérience requise",
                  "OU",
                  "Obtention du diplôme depuis plus de douze (12) mois : o Au moins mille deux cents (1 200) heures d’expérience en tant que physiothérapeute en orthopédie en clinique externe ou en physiothérapie sportive au cours des 2,5 années précédentes7",
                ],
              },
            ],
          },
          {
            candidates: ["MÉ 1,2,3", "MSÉ1,2,3", "(qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Maîtrise en physiothérapie ou Baccalauréat en physiothérapie",
                  "ET",
                  "Permis/licence d’exercice en règle (à titre actif) en tant que physiothérapeute émis par un organisme de réglementation provincial ou territorial4,5",
                  "Lettre de l’organisme de réglementation du candidat attestant que ce dernier est « En règle »",
                ],
                experience: [
                  "Atteinte du niveau professionnel de compétence (NPC)6 pour 00190 PHYSIO",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le candidat doit exercer la profession de physiothérapeute et détenir un permis d’exercice complet, sans restriction et illimité émis dans une province ou un territoire du Canada.",
          "3. Candidat EDO/RECL/PSAC/MÉ/MSÉ : pour émettre une demande d’évaluation de la formation antérieure (ÉFA), le candidat peut obtenir une liste des documents exigés en communiquant avec le groupe des Services de santé des Forces canadiennes...",
          "4. Par « permis en règle sans restriction », on entend un permis complet, sans restriction et illimité d’agir de manière indépendante comme physiothérapeute dans une province ou un territoire du Canada.",
          "5. On trouve les organismes de réglementation provinciaux et territoriaux compétents au lien suivant : https://www.alliancept.org/fr/accueil/.",
          "6. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM.",
          "7. L’exercice en physiothérapie orthopédique en clinique externe ou en physiothérapie sportive doit se situer dans une un zone de traitement d’une population active et ayant recours à des pratiques factuelles.",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "6 ans",
      },
      {
        program: "SEELM/PFOS",
        duration: "9 ans",
      },
    ],
  },
  {
    id: "00191",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "DENTISTE MILITAIRE",
    abbreviation: "DENT M",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Certificat du Bureau national d'examen dentaire du Canada (BNED) et autorisation d'exercer OU acceptation à un programme universitaire en médecine dentaire.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO1", "MÉ 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Avoir obtenu le certificat du Bureau national d'examen dentaire du Canada (BNED)",
                  "ET",
                  "Détenir une Autorisation en règle2,3 et sans restriction d’exercer la Médecine dentaire de la part d’une autorité réglementaire d’une province/d’un territoire du Canada 4",
                  "ET",
                  "Lettre de l’autorité réglementaire professionnelle4 attestant que le candidat est en règle",
                ],
                experience: [
                  "Obtention d’un diplôme d’un programme agréé5 au cours des 18 derniers mois: o Aucune expérience requise",
                  "OU",
                  "Obtention d’un diplôme d’un programme agréé5 il y a plus de 18 mois : o Pratique active de la Médecine dentaire au Canada durant un total d’au 1800 heures au cours des 36 derniers mois",
                  "ET",
                  "Curriculum vitae6 remontant jusqu’à cinq ans quant à l’expérience en tant que dentiste",
                ],
              },
            ],
          },
          {
            candidates: ["PMED1", "PFOS1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Acceptation sans condition à un programme agréé d’une université canadienne menant au Diplôme en médecine dentaire (D.M.D.) ou au Doctorat en médecine dentaire (D.M.D.)5",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Par ailleurs, les candidats ne doivent pas : a) Avoir perdu leur autorisation d’exercer dans quelque juridiction que ce soit; b) Faire l’objet d’une enquête par quelque autorité réglementaire que ce soit. Le dossier d’un candidat ayant fait l’objet d’une enquête ou d’une sanction mineure sera examiné par le Directeur - Services dentaires.",
          "3. Par « Autorisation en règle et sans restriction d’exercer », on entend l’autorisation intégrale et sans restriction d’exercer la Médecine dentaire dans une province ou un territoire du Canada.",
          "4. On peut consulter la liste des autorités réglementaires des provinces/territoires au site suivant : http://cda-adc.ca/fr/about/reg_authorities/.",
          "5. Un programme agréé de dentisterie générale (DDS/DMD) comprend tous les programmes de 4 ou 5 ans offerts dans une université canadienne, ainsi que les programmes de qualification de 2 à 3 ans destinés aux personnes déjà titulaires d’un diplôme en dentisterie obtenu dans un établissement situé à l’extérieur du Canada. Les programmes agréés peuvent être consultés à l’adresse suivante : https://www.cdac-cadc.ca/find-a-program/",
          "6. Le candidat doit remettre un curriculum vitae à jour et les coordonnées de tous les employeurs actuels ou précédents au cours des cinq dernières années. Le Directeur – Services dentaires vérifiera toutes les références mentionnées.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["EDO1", "MÉ 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Avoir obtenu le certificat du Bureau national d'examen dentaire du Canada (BNED)",
                  "ET",
                  "Détenir une Autorisation en règle2,3 et sans restriction d’exercer la Médecine dentaire de la part d’une autorité réglementaire d’une province/d’un territoire du Canada 4",
                  "ET",
                  "Lettre de l’autorité réglementaire professionnelle attestant que le candidat est en règle",
                ],
                experience: [
                  "Obtention d’un diplôme d’un programme agréé7 au cours des 18 derniers mois: o Aucune expérience requise",
                  "OU",
                  "Obtention d’un diplôme d’un programme agréé7 il y a plus de 18 mois : o Pratique active de la Médecine dentaire au Canada durant un total d’au 1800 heures au cours des 36 derniers mois",
                  "ET",
                  "Curriculum vitae6 remontant jusqu’à cinq ans quant à l’expérience en tant que dentiste",
                ],
              },
            ],
          },
          {
            candidates: ["MÉ 1", "MSÉ 1", "(qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Avoir obtenu le certificat du Bureau national d'examen dentaire du Canada",
                  "ET",
                  "Détenir une Autorisation2, 3 en règle et sans restriction d’exercer la Médecine dentaire de la part d’une autorité réglementaire d’une province/d’un territoire du Canada 4",
                  "ET",
                  "Lettre de l’autorité réglementaire professionnelle attestant que le candidat est en règle4",
                ],
                experience: [
                  "Atteinte du niveau professionnel de compétence (NPC)5 du GPM 00191 DENT M dans la F rég F",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Par ailleurs, les candidats ne doivent pas : a) Avoir perdu leur autorisation d’exercer dans quelque juridiction que ce soit; b) Faire l’objet d’une enquête par quelque autorité réglementaire que ce soit. Le dossier d’un candidat ayant fait l’objet d’une enquête ou d’une sanction mineure sera examiné par le Directeur - Services dentaires.",
          "3. Par « Autorisation en règle et sans restriction d’exercer », on entend l’autorisation intégrale et sans restriction d’exercer la Médecine dentaire dans une province ou un territoire du Canada.",
          "4. On peut consulter la liste des autorités réglementaires des provinces/territoires au site suivant : http://cda-adc.ca/fr/about/reg_authorities/.",
          "5. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM.",
          "6. Le candidat doit remettre un curriculum vitae à jour et les coordonnées de tous les employeurs actuels ou précédents au cours des cinq dernières années. Le Directeur – Services dentaires vérifiera toutes les références mentionnées.",
          "7. Un programme agréé de dentisterie générale (DDS/DMD) comprend tous les programmes de 4 ou 5 ans offerts dans une université canadienne, ainsi que les programmes de qualification de 2 à 3 ans destinés aux personnes déjà titulaires d’un diplôme en dentisterie obtenu dans un établissement situé à l’extérieur du Canada. Les programmes agréés peuvent être consultés à l’adresse suivante : https://www.cda-adc.ca/fr/becoming/dat/information/schools/.",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO",
        duration: "6 ans",
      },
      {
        program: "PME-Dent/PFOS",
        duration: "10 ans",
      },
    ],
  },
  {
    id: "00194",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "PHARMACIE",
    abbreviation: "PHARM",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme d’études de premier cycle acrédité en pharmacie. Permis d'exercice en règle.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO1,2", "MÉ1,2", "RECL1,2", "PSAC1,2"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études de premier cycle acrédité dans :3,4 o Pharmacie o Doctorat en pharmacie (niveau d’entrée)",
                  "ET",
                  "Permis d’exercice de la pharmacie sans restriction en règle5",
                  "Lettre de l’autorité de réglementation professionnelle attestant que le candidat est « en règle »6",
                ],
                experience: [
                  "Si diplômé au cours des douze (12) mois précédents3,4: o Aucune expérience requise",
                  "Si diplômé depuis plus des douze (12) mois précédents: o Au moins 1800 heures (c.-à-d. 48 semaines à temps plein) de dispensation de soins en pharmacie directement à des patients au Canada au cours des deux (2) années précédentes.",
                  "ET",
                  "o 450 heures (c.-à-d 12 semaines à temps plein) de dispensations de soins en pharmacie à des patients hospitalisés dans un hôpital de soins tertiaires7 au cours des cinq (5) années précédentes",
                ],
              },
            ],
          },
          {
            candidates: ["MÉ1,2", "(qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Mêmes que pour EDO"],
                experience: [
                  "Atteinte du NPC8 comme PHARM 00194 dans la P rés ou la F rég",
                ],
              },
            ],
          },
          {
            candidates: ["PFOS1", "PMEP1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition dans un programme d’études3 à une université du Canada dans l’un des domaines suivants: o Doctorat en pharmacie (premier cycle)",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le conseiller de GPM doit être avisé et se réserve le droit de rejeter tout candidat pour les raisons suivantes : a) Le candidat fait présentement l’objet d’une enquête par une autorité de réglementation; b) Le candidat a fait l’objet d’une enquête ayant abouti à l’imposition de sanctions; et c) Le candidat s’est vu révoquer son permis par une autorité de réglementation.",
          "3. On peut consulter les programmes d’études de premier cycle acréditésen pharmacie à l’adresse suivante: https://ccapp.ca/fr/programmes-internationaux/",
          "4. Tous les diplômes internationaux doivent comporter une évaluation du diplôme rempli; cette évaluation figure au lien suivant : https://www.wes.org/fr/",
          "5. Un permis en règle sans restriction est un permis d’exercice de la profession comme pharmacien clinicien indépendant sans condition dans une province ou un territoire du Canada.",
          "6. Une lettre de l’autorité réglementaire professionnelle attestant que le candidat est en « en règle » est exigée. On trouve les autorités de réglementation provinciale et territoriale à l’adresse suivante : https://napra.ca/fr/organismes-de-reglementation-de-la-pharmacie.",
          "7. On définit un hôpital de soins tertiaires comme étant un hôpital principal disposant de toute la gamme de soins aux patients. Ces services comprennent, entre autres, une unité de soins intensifs, une unité d’infectiologie et la chirurgie. Une expérience en soins tertiaires est acquise en travaillant dans un hôpital de soins tertiaires après avoir reçu un diplôme. Un candidat doit fournir des références en règle du centre de soins tertiaires où il travaille, notamment son secteur d’intervention particulier.",
          "8. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["EDO1,2", "RECL1,2", "PSAC1,2", "MSÉ1,2"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études de premier cycle acrédité dans l’un des domaines suivants: Pharmacie3,4 ou Doctorat en pharmacie (niveau d’entrée)3,4",
                  "ET",
                  "Permis d’exercice de la pharmacie sans restriction en règle5",
                  "Lettre de l’autorité de réglementation professionnelle attestant que le candidat est « en règle »6",
                ],
                experience: [
                  "Si diplômé au cours des douze (12) mois précédents4: o Aucune expérience requise",
                  "Si diplômé depuis plus des douze (12) mois précédents : o Au moins 1 800 heures (c.-à-d. 48 semaines à temps plein) de dispensation de soins en pharmacie directement à des patients au Canada au cours des deux (2) années précédentes.",
                  "ET",
                  "o Le candidat doit se soumettre à un examen de son profil de pratique par le conseiller du GPM afin de déterminer la pertinence globale de son expérience8",
                ],
              },
            ],
          },
          {
            candidates: ["CT 1,2", "(qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Même qualifications de scolarité que EDO"],
                experience: [
                  "Atteinte du NPC7 comme 00194 PHARM dans la P rés ou la F rég",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le conseiller de GPM doit être avisé et se réserve le droit de rejeter tout candidat pour les raisons suivantes: d) Le candidat fait présentement l’objet d’une enquête par une autorité de réglementation; e) Le candidat a fait l’objet d’une enquête ayant abouti à l’imposition de sanctions; ou f) Le candidat s’est vu révoquer son permis par une autorité de réglementation.",
          "3. On peut consulter les programmes d’études de premier cycle agréés en pharmacie à l’adresse suivante: https://ccapp.ca/fr/programmes-internationaux/",
          "4. Tous les diplômes internationaux doivent comporter une évaluation du diplôme rempli; cette évaluation figure au lien suivant: https://www.wes.org/fr/",
          "5. Un permis en règle sans restriction est un permis d’exercice de la profession comme pharmacien clinicien indépendant sans condition dans une province ou un territoire du Canada.",
          "6. Une lettre de l’autorité réglementaire professionnelle attestant que le candidat est en « en règle » est exigée. On trouve les autorités de réglementation provinciale et territoriale à l’adresse suivante: https://napra.ca/fr/organismes-de-reglementation-de-la-pharmacie.",
          "7. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM.",
          "8. L'expérience doit être validée par le conseiller du GPM Pharmacie par le biais d'un processus officiel d’évaluation et reconnaissance des acquis (ÉRA). Pour lancer une demande d’ÉRA, une liste des documents requis peut être obtenue en contactant le Groupe des Services de santé des Forces canadiennes...",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "4 ans",
      },
      {
        program: "PMEP/PFOS",
        duration: "9 ans",
      },
    ],
  },
  {
    id: "00195",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "SOINS INFIRMIERS",
    abbreviation: "S INFIRM",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Programme de baccalauréat en sciences infirmières et permis d'exercice en règle.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 1,4,8", "RECL 1,4,8", "MÉ 1,4,8", "PSAC 1,4,8"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Programme de baccalauréat6,7: o Baccalauréat en sciences infirmières o Baccalauréat ès sciences infirmières; ou o Baccalauréat en sciences des soins infirmiers",
                  "ET",
                  "Permis d’exercice en règle (état actif) en soins infirmiers3 en tant qu’infirmier autorisé octroyé par un organisme de réglementation provincial ou territorial du Canada5",
                  "ET",
                  "Certificat post-baccalauréat ou cours équivalent9 dans l’une des spécialités suivantes : o Soins intensifs o Soins d’urgence o Soins périopératoire o Santé mentale o Soins médicaux-chirurgicaux",
                ],
                experience: [
                  "Au moins 1,700 heures d’expérience comme infirmier autorisé3 au cours des deux années précédentes dans l’un ou plusieurs des domaines d’exercice suivants: o Soins critiques (soins intensifs et d’urgence) o Santé mentale / Psychiatrie o Soins médicaux-chirurgicaux o Soins péri-opératoires / Salle d’opération",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Programme de baccalauréat6,7: o Baccalauréat en sciences infirmières o Baccalauréat ès sciences infirmières o Baccalauréat en sciences des soins infirmiers",
                  "ET",
                  "Permis d’exercice en règle (état actif) en soins infirmiers en tant qu’infirmier autorisé ou infirmier en pratique3 octroyé par un organisme de réglementation provincial ou territorial du Canada5",
                ],
                experience: [
                  "Diplômé au cours des 18 derniers mois, aucune expérience minimale requise (Candidats en soins infirmiers médico-chirurgicaux seulement)",
                  "OU",
                  "Diplômé depuis plus de 18 mois et ayant cumulé au moins 900 heures, au cours des 3 dernières années, d’expérience en tant qu’infirmier(ère) autorisé(e) au Canada dans n’importe quel domaine de pratique infirmière (voir la note 8)",
                ],
              },
            ],
          },
          {
            candidates: ["EDO 1, 4", "MÉ 1, 4", "RECL 1, 4", "(Qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme en sciences infirmières6, 7 en: o Maîtrise en sciences infirmières – Infirmier(ère) praticien(ne) o Maîtrise en sciences infirmières – Pratique avancée o Baccalauréat en sciences infirmières o Baccalauréat ès sciences en soins infirmiers o Baccalauréat en sciences infirmières",
                  "ET",
                  "Permis d’exercice en règle (état actif) en soins infirmiers en tant qu’infirmier autorisé ou infirmier en pratique 3 octroyé par un organisme de réglementation provincial ou territorial du Canada 5",
                ],
                experience: [
                  "Atteinte du NPC comme S Infirm 001952 dans la F rég ou F rés",
                ],
              },
            ],
          },
          {
            candidates: ["PFOR 1, 10", "PFUMR 1, 10"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Acceptation sans condition dans un programme de baccalauréat6 dans l’un des domaines suivants: o Baccalauréat en sciences infirmières o Baccalauréat ès sciences infirmières o Baccalauréat en sciences des soins infirmiers",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PFOEP 1, 4, 10"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme en soins infirmiers d’un collège agréé au Canada",
                  "ET",
                  "Permis d’exercice en règle (état actif) en soins infirmiers en tant qu’infirmier autorisé ou infirmier en pratique3 octroyé par un organisme de réglementation provincial ou territorial du Canada 5",
                  "ET",
                  "Acceptation sans condition dans un programme de baccalauréat 6 dans l’un des domaines suivants : o Baccalauréat en sciences infirmières o Baccalauréat ès sciences infirmières o Baccalauréat en sciences des soins infirmiers",
                ],
                experience: [
                  "Diplômé au cours des 18 derniers mois, aucune expérience minimale requise (officier infirmier en soins médico-chirurgicaux seulement)",
                  "OU",
                  "Diplômé depuis plus de 18 mois et ayant cumulé au moins 900 heures, au cours des 3 dernières années, d’expérience en tant qu’infirmier(ère) autorisé(e)3 au Canada dans n’importe quel domaine de pratique infirmière",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM.",
          "3. Le candidat doit exercer ses fonctions en tant qu’« Infirmier autorisé » ou « Infirmier praticien » et doit détenir un permis d’exercice complet et sans restriction dans la catégorie d’infirmier autorisé, d’infirmier autorisé (classe étendue), d’infirmier autorisé (infirmier praticien) ou d’infirmier praticien dans une province ou un territoire du Canada, sans antécédent de suspension de permis dans quelque juridiction que ce soit. Cela exclut l’infirmier auxiliaire autorisé, l’infirmier immatriculé, l’infirmier psychiatrique autorisé ainsi que l’infirmier diplômé travaillant avec un permis temporaire.",
          "4. Pour lancer une EFA, le candidat peut obtenir une liste des documents requis en communiquant avec le Groupe des Services de santé des Forces armées canadiennes, à qui ces documents doivent être transmis à l’adresse suivante : DND.CFHSVCsGP_PLAR-ERA_GpSvcFC.MDN@forces.gc.ca...",
          "5. Par « permis en règle sans restriction », on entend un permis complet, sans restriction et illimité d’exercice en tant qu’infirmier autorisé ou d’infirmier autorisé (classe étendue), permettant l’exercice en tant qu’infirmier autorisé dans une province ou un territoire du Canada, sans aucune condition.",
          "6. Les programmes admissibles de baccalauréat ou de maîtrise en sciences infirmières pour le groupe professionnel S INFIRM 00195 doivent être accrédités par l’Association canadienne des écoles de sciences infirmières (ACÉSI/CASN) et sont répertoriés au lien suivant : https://accred.casn.ca/fr/our-programs/programmes-inf-aut/agrement-et-programmes-agrees/.",
          "7. Le diplôme de baccalauréat en sciences infirmières des infirmiers(ères) formé(e)s à l’étranger doit avoir été évalué comme étant une équivalence comparable à un diplôme de baccalauréat canadien par le Service national d’évaluation infirmière (National Nursing Assessment Service) https://www.nnas.ca/fr/.",
          "8. EDO/RECL/MÉ/PSAC les candidats peuvent être enrôlés directement dans l’occupation principale d’officier infirmier médico-chirurgical ou dans l’une des sous-occupations suivantes: officier infirmier en santé mentale, officier infirmier de salle d’opération ou officier infirmier en soins intensifs.",
          "9. Les candidats qui ne possèdent pas le certificat canadien post-baccalauréat ou un cours équivalent, mais qui détiennent une certification de l’Association des infirmières et infirmiers du Canada (AIIC) en soins intensifs – CNCC(C), en soins d’urgence – ENC(C), en soins péri-opératoires – CPN(C), en psychiatrie et santé mentale – CPMHN(C), ou en soins médico-chirurgicaux – CMSN(C) doivent soumettre une EFA.",
          "10. Les programmes canadiens de diplôme condensés, accélérés ou passerelles, même s’ils sont accrédités, ne sont normalement pas autorisés pour les plans subventionnés de production d’officiers (PFOR/PFUMR/PFOEP S INFIRM). Toutefois, ils peuvent être approuvés au cas par cas au moyen d’une demande de dérogation au DPGR.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: [
              "EDO 1,4",
              "PSAC 1,4",
              "RECL 1,4",
              "MSÉ 1,4",
              "MÉ 1,4",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Programme de baccalauréat6,7: o Baccalauréat en sciences infirmières o Baccalauréat ès sciences infirmières o Baccalauréat en sciences des soins infirmiers",
                  "ET",
                  "Permis d’exercice en règle (état actif)3 en soins infirmiers en tant qu’infirmier autorisé ou infirmier en pratique octroyé par un organisme de réglementation provincial ou territorial du Canada5",
                  "ET",
                  "Certificat post-baccalauréat8,9 ou équivalent dans l'une des spécialités suivantes: o Soins intensifs o Soins d’urgence o Soins périopératoires o Santé mentale o Soins médicaux chirurgicaux",
                ],
                experience: [
                  "Infirmiers autorisés:3 occuper présentement un emploi comme infirmier autorisé avec 2,600 heures d’expérience au Canada au cours des deux dernières années dans un ou plusieurs des domaines de pratique suivants: o Soins critiques (soins intensifs et d’urgence) o Santé mentale / Psychiatrie o Médico-chirurgicaux o Soins péri-opératoires / Salle d’opération",
                ],
              },
            ],
          },
          {
            candidates: [
              "EDO 1,4,11",
              "PSAC 1,4,11",
              "RECL 1,4,11",
              "MSÉ 1,4,11",
              "MÉ 1,4,11",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Programme de baccalauréat6,7: o Baccalauréat en sciences infirmières o Baccalauréat ès sciences infirmières o Baccalauréat en sciences des soins infirmiers",
                  "ET",
                  "Permis d’exercice en règle (état actif)3 en soins infirmiers en tant qu’infirmier autorisé ou infirmier en pratique octroyé par un organisme de réglementation provincial ou territorial du Canada5",
                ],
                experience: [
                  "Diplômé au cours des 18 derniers mois, aucune expérience minimale requise (officier infirmier en soins médico-chirurgicaux seulement)",
                  "OU",
                  "Diplômé depuis plus de 18 mois avoir cumulé un minimum de 900 heures, au cours des 3 dernières années, d’expérience au Canada en soins infirmiers médico-chirurgicaux.",
                  "OU",
                  "Au moins 1,700 heures d’expérience comme infirmier autorisé3 au cours des 3 dernières années dans l’un ou plusieurs des domaines d’exercice suivants: o Soins critiques (soins intensifs et d’urgence) o Santé mentale / psychiatrie o Soins péri-opératoires / salle d’opération",
                ],
              },
              {
                level: "Idéal",
                education: [
                  "Diplôme en sciences infirmières6,7 dans l’un des programmes suivants: o Maîtrise en sciences infirmières – Infirmier(ère) praticien(ne) o Maîtrise en sciences infirmières – Pratique avancée",
                  "ET",
                  "Permis d’exercice en règle (statut actif)³ en soins infirmiers à titre d’infirmier(ère) praticien(ne), octroyé par un organisme de réglementation provincial ou territorial du Canada5",
                ],
                experience: [
                  "Infirmier(ère) praticien(ne) comptant 2 600 heures d’expérience au Canada au cours des deux dernières années. La priorité sera accordée aux personnes ayant de l’expérience10 dans un ou plusieurs des domaines suivants: o Soins de santé primaires o Soins aux adultes o Soins aigus",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Diplôme en sciences infirmières6,7 dans l’un des programmes suivants: o Maîtrise en sciences infirmières – Infirmier(ère) praticien(ne) o Maîtrise en sciences infirmières – Pratique avancée",
                  "ET",
                  "Permis d’exercice en règle (statut actif)³ en soins infirmiers à titre d’infirmier(ère) praticien(ne), octroyé par un organisme de réglementation provincial ou territorial du Canada5",
                ],
                experience: [
                  "Infirmier(ère) praticien(ne) comptant 1 700 heures d’expérience au Canada au cours des 3 dernières années. La priorité sera accordée aux personnes ayant de l’expérience10 dans un ou plusieurs des domaines suivants : o Soins de santé primaires o Soins aux adultes o Soins aigus",
                ],
              },
            ],
          },
          {
            candidates: ["MÉ 1,4", "RECL 1,4", "MSÉ 1,4", "(Qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme en sciences infirmières6,7 dans l’un des programmes suivants: o Maîtrise en sciences infirmières – Infirmier(ère) praticien(ne) o Maîtrise en sciences infirmières – Pratique avancée o Baccalauréat en sciences infirmières o Baccalauréat ès sciences en sciences infirmières o Baccalauréat en sciences infirmières",
                  "ET",
                  "Permis d’exercice en règle (état actif) en soins infirmiers en tant qu’infirmier autorisé3 ou infirmier en pratique octroyé par un organisme de réglementation provincial ou territorial du Canada5",
                ],
                experience: [
                  "Atteinte du NPC2 comme S INFIRM 00195 dans la F rég ou F rés",
                ],
              },
            ],
          },
          {
            candidates: ["PIRO 1,11"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Admis et inscrit à un programme de baccalauréat et à moins d’un an de l’obtention de son diplôme de premier cycle en : o Baccalauréat ès sciences infirmières; ou o Baccalauréat en sciences des soins infirmiers",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM.",
          "3. Le candidat doit exercer ses fonctions en tant qu’« Infirmier autorisé » ou « Infirmier praticien » et doit détenir un permis d’exercice complet et sans restriction... Cela exclut l’infirmier auxiliaire autorisé, l’infirmier immatriculé, l’infirmier psychiatrique autorisé ainsi que l’infirmier diplômé travaillant avec un permis temporaire.",
          "4. Candidat EDO/RECL/PSAC/MÉ/MSÉ: pour lancer une EFA, le candidat peut obtenir une liste des documents requis en communiquant avec le Groupe des Services de santé des Forces armées canadiennes... afin de déterminer si le candidat satisfait aux exigences suivantes en plus de celles énoncées dans le tableau précédent : a. N’avoir aucun antécédent de révocation du permis d’exercice par une autorité compétente; b. Ne pas faire présentement l’objet d’une enquête de la part d’un organisme de réglementation... c. Expérience clinique pertinente. d. Confirmer le statut 00195 S INFIRM NPC (le cas échéant).",
          "5. Par permis en règle (statut actif), on entend un permis complet, sans restriction, dans l’une des catégories suivantes : infirmier(ère) autorisé(e), infirmier(ère) autorisé(e) (classe étendue), infirmier(ère) autorisé(e) (infirmier(ère) praticien(ne)) ou infirmier(ère) praticien(ne), permettant l’exercice à titre d’infirmier(ère) autorisé(e) ou d’infirmier(ère) praticien(ne) dans une province ou un territoire du Canada, sans conditions.",
          "6. Le diplôme de baccalauréat en sciences infirmières des infirmier(ère)s formé(e)s à l’étranger doit avoir été évalué comme étant équivalent à un baccalauréat canadien par le Service national d’évaluation infirmière (SNEI): https://www.nnas.ca/fr/",
          "7. Les candidats ayant de l’expérience dans d’autres spécialités peuvent être considérés pour l’enrôlement par le conseiller du GPM 00195 S INFIRM au moyen d’une EFA, en fonction de leur expérience clinique.",
          "8. Les candidats qui ne possèdent pas le certificat canadien post-baccalauréat ou un cours équivalent, mais qui détiennent une certification de l’Association des infirmières et infirmiers du Canada (AIIC)... doivent soumettre une EFA.",
          "9. L’expérience devrait inclure, ou avoir pour principal objectif, la prise en charge de la population adulte (âges 18 à 64 ans).",
          "10. EDO/RECL/MÉ/PSAC: les candidats peuvent être enrôlés directement dans l’occupation principale d’officier infirmier médico-chirurgical ou dans l’une des sous-occupations suivantes : infirmier(ère) praticien(ne), officier infirmier en santé mentale, officier infirmier de salle d’opération, officier infirmier en soins intensifs.",
          "11. Pour les candidats du Québec, cela comprend l’inscription à un programme de CÉGEP préuniversitaire approprié conformément à la DOAD 5002-8, Programme d’admission de la Réserve – Officiers.",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "6 ans",
      },
      {
        program: "PFOR",
        duration: "11 ans",
      },
    ],
  },
  {
    id: "00197",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 3, a: 4, u: 5 },
    title: "OFFICIER DES SCIENCES BIOLOGIQUES",
    abbreviation: "BIO",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Maîtrise ou baccalauréat spécialisé en sciences de la vie (biologie, kinésiologie, etc.).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "RECL1", "MÉ 1", "PSAC 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Maîtrise 2 dans: o Intégration des systèmes humains (facteurs humains) o Santé environnementale et professionnelle (hygiène du travail) o Santé publique o Kinésiologie",
                  "OU",
                  "Maîtrise 2 correspondant à l’un des diplômes idéaux ou acceptables",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "Baccalauréat spécialisé (ou équivalent): 3 o Biologie humaine o Physiologie humaine o Kinésiologie o Biologie o Biochimie o Microbiologie o Génie biomédical o Diplôme dans une discipline des sciences de la vie 4",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["EDO 1", "RECL 1", "MÉ 1", "(qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Baccalauréat : o toute discipline"],
                experience: [
                  "Doit avoir atteint le niveau professionnel de compétence (NPC) 6 en tant que 00197 BIO",
                ],
              },
            ],
          },
          {
            candidates: ["PFOR 1", "PFUMR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Obtenir une acceptation inconditionnelle à: Baccalauréat spécialisé (ou équivalent): o Biologie humaine o Physiologie humaine o Kinésiologie o Biologie o Biochimie o Microbiologie o Génie biomédical o Diplôme dans une discipline des sciences de la vie 4",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Conformément à la DOAD 5002-10, Exigences scolaires pour la commission à partir des rangs",
                ],
                experience: [
                  "Au minimum, les candidats doivent détenir le grade substantif de sergent (sgt) ou supérieur en tant que technicien en physiologie aéronautique (00373 TECH PHYS AÉRO).",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Toutes les maîtrises doivent être examinées par le conseiller du ID SGPM des officiers en biosciences afin de déterminer l’admissibilité au niveau idéal. Les candidats qui ne satisfont pas à la norme d’entrée idéale peuvent néanmoins être jugés admissibles au niveau acceptable, à condition de détenir le baccalauréat approprié, par l’entremise de CFHSAttractionCell- CelluledattractionSSFC@forces.gc.ca.",
          "3. Les candidats qui ne détiennent pas la maîtrise idéale doivent être titulaires d’un baccalauréat spécialisé acceptable ou un équivalent.",
          "4. Un baccalauréat spécialisé en sciences de la vie doit être évalué pour vérifier l’admissibilité à la profession d’officier des biosciences. Pour lancer une évaluation, les relevés de notes doivent être fournis au Groupe des Services de santé des Forces canadiennes à l’adresse suivante: CFHSAttractionCell-CelluledattractionSSFC@forces.gc.ca.",
          "5. Les candidats PFOR/PFUMR sont tenus (lorsqu’ils sont admissibles) de s’inscrire à un programme de baccalauréat spécialisé (ou équivalent) comportant la réalisation d’un mémoire. Les programmes de baccalauréat peuvent exiger que les étudiants présentent une demande d’admission au programme spécialisé seulement après avoir complété un certain nombre d’années d’études. L’expression « lorsqu’ils sont admissibles » signifie que les étudiants doivent présenter leur demande au programme spécialisé dès qu’ils satisfont aux critères d’admissibilité. Le fait de ne pas intégrer ou de ne pas demeurer dans le programme spécialisé entraînera un reclassement obligatoire.",
          "6. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "RECL 1", "MÉ 1", "PSAC 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Maîtrise 2 dans: o Intégration des systèmes humains (facteurs humains) o Santé environnementale et professionnelle (hygiène du travail) o Santé publique o Kinésiologie",
                  "OU",
                  "Maîtrise 2 correspondant à l’un des diplômes idéaux ou acceptables",
                ],
                experience: [
                  "Atteinte du niveau professionnel de compétence (NPC) 3 au sein d’une occupation de la F rég ou F rés",
                  "24 mois d’expérience de travail cumulative dans un domaine pertinent 5",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Baccalauréat spécialisé (ou équivalent): o Biologie humaine o Physiologie humaine o Kinésiologie o Biologie o Biochimie o Microbiologie o Génie biomedical o Diplôme dans une discipline des sciences de la vie 4",
                ],
                experience: [
                  "24 mois d’expérience de travail cumulative dans un domaine pertinent 5",
                ],
              },
            ],
          },
          {
            candidates: ["EDO 1", "RECL 1", "MÉ 1", "(qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Baccalauréat : o toute discipline"],
                experience: [
                  "Doit avoir atteint le niveau professionnel de compétence (NPC) 3 en tant que 00197 BIO",
                  "24 mois d’expérience de travail cumulative dans un domaine pertinent 5",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Toutes les maîtrises doivent être examinées par le conseiller du ID SGPM des officiers en biosciences afin de déterminer l’admissibilité au niveau idéal. Les candidats qui ne satisfont pas à la norme d’entrée idéale peuvent néanmoins être jugés admissibles au niveau acceptable, à condition de détenir le baccalauréat approprié, par l’entremise de CFHSAttractionCell- CelluledattractionSSFC@forces.gc.ca.",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM.",
          "4. Un baccalauréat spécialisé en sciences de la vie doit être évalué pour vérifier l’admissibilité à la profession d’officier des biosciences. Pour lancer une évaluation, les relevés de notes doivent être fournis au Groupe des Services de santé des Forces canadiennes à l’adresse suivante: CFHSAttractionCell-CelluledattractionSSFC@forces.gc.ca.",
          "5. Expérience acquise dans toute combinaison des domaines suivants: intégration des systèmes humains / facteurs humains, santé au travail / hygiène industrielle, renseignement médical, NRBC, physiologie aérospatiale, sécurité laser, science et technologie, recherche ou gestion de projets doit être examinée et approuvée par le conseiller de la structure des groupes professionnels militaires (SGPM) de l’occupation BIO, par l’entremise de CFHSAttractionCell- CelluledattractionSSFC@forces.gc.ca.",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "9 ans",
      },
    ],
  },
  {
    id: "00198",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "TRAVAIL SOCIAL",
    abbreviation: "T SOC",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Baccalauréat en service social (BSS) ou maîtrise en service social (M.S.S.). Permis en règle d'exercer comme travailleur social.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "RECL 1", "MÉ 1", "PSAC 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Maîtrise en service social (M.S.S.) dans un programme agréé, axé ou spécialisé sur le service social en pratique clinique",
                  "Permis en règle et sans restriction (état actif) d’exercer comme travailleur social",
                  "Lettre de l’autorité réglementaire professionnelle attestant que le candidat est « en règle »",
                ],
                experience: [
                  "Minimum de 3 400 heures (2 ans) d’expérience pertinente, au cours des cinq dernières années (à l'exclusion des stages)",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Maîtrise en service social (M.S.S.) dans un programme agréé, axé ou spécialisé sur le service social en pratique clinique",
                  "Permis en règle et sans restriction (état actif) d’exercer comme travailleur social",
                  "Lettre de l’autorité réglementaire professionnelle attestant que le candidat est « en règle »",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["ES-PMNE 1 (En service F reg)"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Baccalauréat en service social (BSS)",
                  "Permis en règle et sans restriction (état actif) d’exercer comme travailleur social",
                  "Lettre de l’autorité réglementaire professionnelle attestant que le candidat est « en règle »",
                  "Admission sans condition à un programme agréé de Maîtrise en service social (M.S.S.) dans une université canadienne et axé sur la pratique clinique",
                ],
                experience: [
                  "Minimum de 3 400 heures (2 ans) d’expérience pertinente, au cours des cinq dernières années (à l'exclusion des stages)",
                  "ET Atteinte du niveau professionnel de compétence (NPC) dans le métier actuel",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "N’importe quel baccalauréat",
                  "Admission sans condition à un programme agréé de Maîtrise en service social (M.S.S.) dans une université canadienne et axé sur la pratique clinique",
                ],
                experience: [
                  "Atteinte du niveau professionnel de compétence (NPC) dans le métier actuel",
                ],
              },
            ],
          },
          {
            candidates: ["PFOS 1 (Candidat civil, MÉ)"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Baccalauréat en service social (BSS)",
                  "Permis en règle et sans restriction (état actif) d’exercer comme travailleur social",
                  "Lettre de l’autorité réglementaire professionnelle attestant que le candidat est « en règle »",
                  "Admission sans condition à un programme agréé de Maîtrise en service social (M.S.S.) dans une université canadienne et axé sur la pratique clinique",
                ],
                experience: [
                  "Minimum de 3 400 heures (2 ans) d’expérience pertinente, au cours des cinq dernières années (à l'exclusion des stages)",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Baccalauréat en service social (BSS)",
                  "Permis en règle et sans restriction (état actif) d’exercer comme travailleur social",
                  "Lettre de l’autorité réglementaire professionnelle attestant que le candidat est « en règle »",
                  "Admission sans condition à un programme agréé de Maîtrise en service social (M.S.S.) dans une université canadienne et axé sur la pratique clinique",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent démontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. On peut consulter les programmes agréés canadiens menant à la Maîtrise en service social (M.S.S.) axé sur la pratique clinique, acceptables en vue d’Études subventionnées pour la maîtrise au niveau d’entrée (ESNEM).",
          "5. Par « permis en règle sans restriction », on entend un permis complet, sans restriction et illimité d’agir comme travailleur social dans une province ou un territoire du Canada.",
          "6. L'expérience pertinente est définie comme un nombre cumulé de 3 400 heures de travail à temps plein ou à temps partiel au cours des cinq dernières années.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "RECL 1", "MÉ 1", "MSÉ 1", "PSAC 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Maîtrise en service social (M.S.S.) dans un programme agréé, axé ou spécialisé sur le service social en pratique clinique",
                  "Permis en règle et sans restriction (état actif) d’exercer comme travailleur social",
                  "Lettre de l’autorité réglementaire professionnelle attestant que le candidat est « en règle »",
                ],
                experience: [
                  "Minimum de 3 400 heures (2 ans) d’expérience pertinente, au cours des cinq dernières années (à l'exclusion des stages)",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Maîtrise en service social (M.S.S.) dans un programme agréé, axé ou spécialisé sur le service social en pratique clinique",
                  "Permis en règle et sans restriction (état actif) d’exercer comme travailleur social",
                  "Lettre de l’autorité réglementaire professionnelle attestant que le candidat est « en règle »",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["RECL 1", "MÉ 1", "MSÉ 1 (Qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Maîtrise en service social (M.S.S.) d’un programme agréé, axé ou spécialisé sur le service social en pratique clinique",
                  "Permis en règle sans restriction (en cours de validité) d’agir comme travailleur social",
                  "Lettre de l’autorité réglementaire professionnelle attestant que le candidat est « en règle »",
                ],
                experience: [
                  "Atteinte du niveau professionnel de compétence (NPC) comme 00198 T SOC dans la F rég",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent démontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "6 ans",
      },
      {
        program: "ES_PMNE/PFOS",
        duration: "9 ans",
      },
    ],
  },
  {
    id: "00203",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 3, a: 5, u: 5 },
    title: "OFFICIER DES AFFAIRES PUBLIQUES",
    abbreviation: "OAP",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Baccalauréat ou Maîtrise dans les communications, relations publiques, journalisme ou domaines connexes.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: [
              "EDO 1, 2, 3",
              "RECL 1, 2, 3",
              "MÉ 1, 2, 3",
              "PSAC 1, 2, 3",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Maîtrise: Communications, Relations internationales, Journalisme, Relations publiques, Anglais/français, Science politique, Commercialisation, Médias numériques, Études militaires et stratégiques, Anthropologie, Psychologie, Philosophie, Sociologie, Linguistique",
                ],
                experience: [
                  "Au moins une (1) année d’expérience cumulative dans deux ou plusieurs des domaines",
                  "OU Expérience opérationnelle en déploiement (au moins 6 mois)",
                ],
              },
              {
                level: "Acceptable",
                education: ["Baccalauréat dans un des domaines mentionnés"],
                experience: [
                  "Au moins une (1) année d’expérience cumulative dans deux ou plusieurs des domaines",
                  "OU Expérience opérationnelle en déploiement (au moins 6 mois)",
                ],
              },
            ],
          },
          {
            candidates: ["MÉ 1, 2", "RECL 1, 2", "EDO 1, 2 (qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Baccalauréat : N'importe lequel"],
                experience: [
                  "Atteinte du Niveau opérationnel de compétence (NOC) comme Officier des affaires publiques (OAP) à la F rég ou à la P rés",
                ],
              },
            ],
          },
          {
            candidates: ["PFUMR 1, 2, 3", "PFOR 1, 2, 3"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Admission sans condition à un programme de Baccalauréat dans les domaines mentionnés",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1, 2, 3"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Certificat d’école secondaire ou l’équivalent OU Diplôme ou baccalauréat d’un établissement post-secondaire (équivalent à au moins deux années d'études)",
                ],
                experience: [
                  "Qualification au grade effectif de sgt/m 2 dans le GPM 00137 TECH IMAG",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO 1, 2"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Certificat d’école secondaire ou l’équivalent"],
                experience: [
                  "Qualification au grade effectif de Adjuc/pm1 et ont occupé le grade de adjum/pm2 dans le GPM 00137 TECH IMAG",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
          "2. Les candidats doivent obtenir la note de passage à l'examen de communication écrite (ECE).",
          "3. Les candidats doivent se soumettre à un canevas réaliste de l’emploi, organisé par la Branche des affaires publiques.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: [
              "EDO 1, 2",
              "RECL 1, 2, 3",
              "MÉ 1, 2, 3",
              "PSAC 1, 2, 3",
            ],
            requirements: [
              {
                level: "Idéal",
                education: ["Maîtrise dans les domaines mentionnés"],
                experience: [
                  "Au moins une (1) année d’expérience cumulative dans deux ou plusieurs des domaines",
                  "OU Expérience opérationnelle en déploiement (au moins 6 mois)",
                ],
              },
              {
                level: "Acceptable",
                education: ["Baccalauréat dans un des domaines mentionnés"],
                experience: [
                  "Au moins une (1) année d’expérience cumulative dans deux ou plusieurs des domaines",
                  "OU Expérience opérationnelle en déploiement (au moins 6 mois)",
                ],
              },
            ],
          },
          {
            candidates: ["MÉ 1, 2", "RECL 1, 2", "MSÉ 1, 2 (qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Baccalauréat : N'importe lequel"],
                experience: [
                  "Atteinte du Niveau opérationnel de compétence (NOC) comme Officier des affaires publiques (OAP) à la F rég ou à la P rés",
                ],
              },
            ],
          },
          {
            candidates: ["PIRO 1, 2, 3"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Enrôlé comme étudiant à temps partiel, à plein temps ou en apprentissage à distance dans un établissement post-secondaire menant à un Baccalauréat dans les domaines mentionnés",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1, 2, 3"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Certificat d’école secondaire ou l’équivalent OU Diplôme ou baccalauréat d’un établissement post-secondaire",
                ],
                experience: [
                  "Qualification au grade effectif de Sgt/m 2 dans le GPM 00137 TECH IMAG",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO 1, 2"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Certificat d’école secondaire ou l’équivalent"],
                experience: [
                  "Qualification au grade effectif de Adjuc/pm1 et ont occupé le grade de adjum/pm2 dans le GPM 00137 TECH IMAG",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du TAFC.",
          "2. Les candidats doivent obtenir la note de passage à l'examen de communication écrite (ECE).",
          "5. Consulter la DOAD 5002-10 pour connaître les exigences relatives à la scolarité.",
          "6. Pour les candidats du Québec, cela comprend l’enrôlement dans un programme pré-universitaire approprié du CÉGEP.",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "6 ans",
      },
      {
        program: "PFOR",
        duration: "10 ans",
      },
    ],
  },
  {
    id: "00204",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 3, a: 5, u: 5 },
    title: "AVOCAT MILITAIRE",
    abbreviation: "AVOCAT MIL",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme en droit décerné par une faculté de droit canadienne et autorisation à pratiquer le droit.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: [
              "EDO 1, 5, 7",
              "RECL 1, 5, 7",
              "MÉ 1, 5, 7",
              "PSAC 1, 5, 7",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "1. Détenir un diplôme en droit décerné par une faculté de droit canadienne reconnue",
                  "2. Être autorisé à pratiquer le droit dans au moins une province ou un territoire canadien",
                  "3. Être « membre en règle » d'un barreau provincial ou territorial",
                ],
                experience: [
                  "Si diplôme obtenu dans les deux (2) dernières années : aucune expérience minimale",
                  "Si diplôme obtenu il y a plus de deux (2) ans : Pratique du droit à temps plein requise",
                ],
              },
            ],
          },
          {
            candidates: ["PFOS 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme en droit (par exemple, LL. B., B.C.L., ou J.D.)",
                  "Avoir réussi la formation professionnelle exigée par son barreau",
                  "Doit être admis au Barreau dans un délai déterminé",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: [
              "EDO 1, 5, 7",
              "RECL 1, 5, 7",
              "MÉ 1, 5, 7",
              "MSÉ 1, 5, 7",
              "PSAC 1, 5, 7",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "1. Détenir un diplôme en droit décerné par une faculté de droit",
                  "2. Être autorisé à pratiquer le droit dans une province canadienne",
                  "3. Être « membre en règle » d'un barreau provincial ou territorial",
                ],
                experience: [
                  "Si diplôme obtenu dans les deux (2) dernières années : aucune expérience minimale",
                  "Si diplôme obtenu il y a plus de deux (2) ans : Pratique du droit à temps plein requise",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent démontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO",
        duration: "7 ans",
      },
      {
        program: "PMED",
        duration: "12 ans",
      },
    ],
  },
  {
    id: "00207",
    medicalStandard: { v: 4, cv: 2, h: 2, g: 2, o: 2, a: 5, u: 5 },
    title: "OFFICIER DE GUERRE NAVALE",
    abbreviation: "OGN",
    requirements: "FORCE RÉGULIÈRE & RÉSERVE: Baccalauréat (toute discipline).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: [
              "EDO 1, 2, 3",
              "PSAC 1, 2, 3",
              "RECL 1, 2, 3",
              "MÉ 1, 2, 3",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Baccalauréat : Ingénierie, Sciences, Administration des affaires, Économie, Commerce, Mathématiques, Systèmes d’information géographique, Technologies de l’information",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: ["Baccalauréat : Toute discipline"],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PFOS 1"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Baccalauréat : N'importe lequel"],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PFUMR 1, 2, 3", "PFOR 1, 2, 3"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Admission sans condition à un programme menant à un Baccalauréat : Toute discipline",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PNSCO 1, 2"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Certificat d'école secondaire ou l'équivalent"],
                experience: [
                  "Qualification au grade de PM 1 et ont déjà occupé le grade de PM 2 (tous les GPM de la RCN)",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
          "2. Les candidats doivent satisfaire au besoin applicable pour l’acuité visuelle.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: [
              "EDO 1, 2",
              "PSAC 1, 2, 3",
              "RECL 1, 2, 3",
              "MÉ 1, 2, 3",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Baccalauréat : Ingénierie, Sciences, Administration des affaires, Économie, Commerce, Mathématiques, Systèmes d’information géographique, Technologies de l’information",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: ["Baccalauréat : Toute discipline"],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIRO 1, 2, 3"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition ou être présentement enrôlé comme étudiant à temps partiel ou plein, dans un programme de baccalauréat",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PNSCO 1, 2"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Certificat d’école secondaire ou l’équivalent"],
                experience: [
                  "Qualification au grade de pm 1 et ont déjà occupé le grade de pm 2 (tous les GPM de la RCN)",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "8 ans",
      },
      {
        program: "PFOR",
        duration: "12 ans",
      },
    ],
  },
  {
    id: "00208",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 3, a: 5, u: 5 },
    title: "SÉLECTION DU PERSONNEL",
    abbreviation: "S PERS",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Baccalauréat spécialisé (4 ans) en psychologie ou sociologie.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["PEDO 1", "RECL 1, 2", "MÉ 1, 2", "PSAC 1, 2"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Maîtrise : Psychologie industrielle organisationnelle, Psychologie sociale, Sociologie, etc.",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "Baccalauréat spécialisé – 4 ans (ou l’équivalent au Québec) : Psychologie, Sociologie, Gérontologie, Sciences sociales",
                  "OU Baccalauréat avec spécialisation (120 crédits) : Relations et ressources humaines, Psychologie organisationnelle",
                  "OU Baccalauréat (ou l’équivalent au Québec) dans tout programme connexe comprenant un nombre précis de cours en méthodes de recherche et/ou statistiques",
                ],
                experience: [
                  "Au moins une ou plusieurs années de travail à temps plein, payé, et connexe au domaine après l'obtention du diplôme de baccalauréat",
                ],
              },
            ],
          },
          {
            candidates: ["PFUMR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté ou présentement inscrit dans un programme menant à un Baccalauréat spécialisé – 4 ans (ou équivalent au Québec) dans les domaines mentionnés ci-dessus",
                ],
                experience: ["Aucun requis"],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le test d’aptitude des Forces canadiennes (TAFC).",
          "4. Les candidats de la FORCE RÉGULIÈRE doivent avoir travaillé à temps plein après l'obtention de leur baccalauréat.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["EDO 1, 2", "RECL 1, 2", "MÉ 1, 2", "PSAC 1, 2"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Maîtrise : Psychologie industrielle organisationnelle, Psychologie sociale, Sociologie, etc.",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "Baccalauréat spécialisé – 4 ans (ou l’équivalent au Québec) : Psychologie, Sociologie, Gérontologie, Sciences sociales",
                  "OU Baccalauréat avec spécialisation (120 crédits) : Relations et ressources humaines, Psychologie organisationnelle",
                  "OU Baccalauréat (ou l’équivalent au Québec) dans tout programme connexe",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIRO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition à l'université ou enrôlé comme étudiant (complet ou temps partiel) dans un baccalauréat visé",
                ],
                experience: ["Aucun requis"],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "6 ans",
      },
      {
        program: "PFOR",
        duration: "10 ans",
      },
    ],
  },
  {
    id: "00211",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 3, a: 5, u: 5 },
    title: "DÉVELOPPEMENT DE L’INSTRUCTION",
    abbreviation: "DÉV INSTR",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Maîtrise ou Baccalauréat en éducation ou un domaine connexe.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 1, 2", "RECL 1, 2", "MÉ 1, 2"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Maîtrise en éducation (technologie éducative, conception de systèmes et de l'instruction, développement du curriculum ou évaluation de l'apprentissage avec ou sans thèse)",
                ],
                experience: [
                  "Au moins trois ans cumulatifs d’expérience à temps plein dans un ou plusieurs de ces domaines",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Baccalauréat : Éducation professionnelle, Éducation aux adultes, Éducation (technologie, conception et développement)",
                ],
                experience: [
                  "Au moins une année cumulative d'expérience à temps plein après le baccalauréat dans un des domaines visés",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
          "5. Un Baccalauréat en enseignement au niveau primaire, secondaire général, Éducation de l'enfance en difficulté ou administration de l'éducation n'est pas pertinent ou adéquat.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["EDO 1, 2", "RECL 1, 2", "MÉ 1, 2"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Maîtrise en éducation (technologie éducative, conception de systèmes et de l'instruction, etc.)",
                ],
                experience: [
                  "Au moins trois ans cumulatifs d’expérience à temps plein",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Baccalauréat : Éducation professionnelle, Éducation aux adultes, etc.",
                ],
                experience: [
                  "Au moins une année cumulative d'expérience à temps plein après le baccalauréat dans un des domaines visés",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "6 ans",
      },
      {
        program: "PFOR",
        duration: "10 ans",
      },
    ],
  },
  {
    id: "00213",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "RENSEIGNEMENT",
    abbreviation: "RENS",
    requirements: "FORCE RÉGULIÈRE & RÉSERVE: Baccalauréat (toute discipline).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 1, 2", "PSAC 1, 2", "RECL 1, 2", "MÉ 1, 2"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Baccalauréat : Ingénierie, Informatique, Études de conflits, Histoire, Sciences politiques, Géographie, Mathématiques, Systèmes d’information géographique, Technologies de l’information",
                ],
                experience: [
                  "Expérience cumulative d'au moins six mois dans des domaines reliés",
                  "OU Au moins un an d'expérience progressive",
                  "OU Cours d'Opérateur/Communicateur",
                ],
              },
              {
                level: "Acceptable",
                education: ["Baccalauréat : toute discipline"],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PFOS 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "N'importe quel cours universitaire de premier cycle (Baccalauréat)",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PFUMR 1, 2", "PFOR 1, 2"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Admission sans condition à un programme menant à un Baccalauréat : Toute discipline",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PNSCO 1, 2"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Certificat d'école secondaire ou l'équivalent"],
                experience: [
                  "Qualification au grade de sgt / m 2 dans n'importe quel GPM",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: [
              "EDO 1",
              "PSAC 1, 2",
              "RECL 1, 2",
              "MÉ 1, 2",
              "MSÉ 1, 2",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Baccalauréat : Ingénierie, Informatique, Études de conflits, Histoire, Sciences politiques, Géographie, etc.",
                ],
                experience: [
                  "Expérience cumulative d'au moins six mois dans des emplois qui ont demandé beaucoup d'analyse",
                  "OU Au moins un an d'expérience",
                  "OU Cours d'Opérateur (F RÉS)",
                ],
              },
              {
                level: "Acceptable",
                education: ["Baccalauréat : toute discipline"],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIRO 1, 2"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition à l'université ou enrôlé comme étudiant à temps partiel ou régulier dans un programme menant à un baccalauréat, n'importe quelle discipline",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PNSCO 1, 2"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Certificat d’école secondaire ou l’équivalent"],
                experience: [
                  "Qualification au grade effectif de sgt / m 2 dans n'importe quel GPM",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "6 ans",
      },
      {
        program: "PFOR",
        duration: "10 ans",
      },
    ],
  },
  {
    id: "00214",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 3, o: 3, a: 5, u: 5 },
    title: "OFFICIER DE LA POLICE MILITAIRE",
    abbreviation: "OPM",
    requirements: "FORCE RÉGULIÈRE & RÉSERVE: Baccalauréat (toute discipline).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 1, 2", "PSAC 1, 2", "RECL 1, 2", "MÉ 1, 2"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Baccalauréat : Justice criminelle, Criminologie, Psychologie, Sociologie, ou Administration publique",
                ],
                experience: [
                  "Au moins un an d’expérience à temps partiel ou à temps plein à une poste d’application de la loi",
                ],
              },
              {
                level: "Acceptable",
                education: ["Baccalauréat : Tout diplôme"],
                experience: [
                  "Aucun casier judiciaire",
                  "Permis de conduire d’une province / d’un territoire en règle",
                ],
              },
            ],
          },
          {
            candidates: ["PFOS 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "N'importe quel cours universitaire de premier cycle (Baccalauréat)",
                ],
                experience: [
                  "Permis de conduire en règle",
                  "Aucun casier judiciaire",
                ],
              },
            ],
          },
          {
            candidates: ["PFUMR 1, 2", "PFOR 1, 2"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Admission sans condition à un programme universitaire ou en cours de baccalauréat",
                ],
                experience: [
                  "Permis de conduire en règle",
                  "Aucun casier judiciaire",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO 1, 2"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Certificat d'école secondaire ou l'équivalent"],
                experience: [
                  "Qualification au grade effectif de sgt/m 2 de la F rég dans n'importe quel GPM",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
          "3. Chaque candidat doit réussir le Centre d'évaluation de la Police militaire (CEPM).",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: [
              "EDO 1",
              "PSAC 1, 2",
              "RECL 1, 2",
              "MÉ 1, 2",
              "MSÉ 1, 2",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Baccalauréat : Justice criminelle, Criminologie, Psychologie, Sociologie, etc.",
                ],
                experience: [
                  "Au moins un an d’expérience à temps partiel ou à temps plein à une poste d’application de la loi",
                ],
              },
              {
                level: "Acceptable",
                education: ["Baccalauréat : Tout diplôme"],
                experience: [
                  "Aucun casier judiciaire",
                  "Permis de conduire complet",
                ],
              },
            ],
          },
          {
            candidates: ["PIRO 1, 2"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition à l'université ou enrôlé comme étudiant",
                ],
                experience: [
                  "Aucun casier judiciaire",
                  "Permis de conduire en règle",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO 1, 2"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Certificat d’école secondaire ou l’équivalent"],
                experience: [
                  "Qualification au grade effectif de sgt/m 2 de la F rés dans n'importe quel GPM",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "6 ans",
      },
      {
        program: "PFOR",
        duration: "13 ans",
      },
    ],
  },
  {
    id: "00238",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN EN GÉOMATIQUE",
    abbreviation: "TECH GÉO",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme d’études secondaires avec Mathématiques appliquées de 11e année / Sec V.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "1. Diplôme de collège / cégep de deux (2) ans en technologie de géomatique ou en application de géomatique",
                  "OU Diplôme d’études secondaires ou l’équivalent : Mathématiques appliquées de 11e année / Sec V",
                ],
                experience: [
                  "Expérience cumulative à temps plein de six mois en analyse en utilisant un système d’information géographique (SIG)",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "11e année d’études secondaires / secondaires V comportant : Mathématiques appliquées de 11e année ou Sec V",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIESMR 1 (Candidat civil, RECL, MÉ)"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition ou être présentement inscrit comme étudiant à temps complet...",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "MSÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "1. Diplôme de collège / cégep de deux (2) ans en technologie de géomatique ou en application de géomatique",
                ],
                experience: [
                  "Expérience cumulative à temps plein de six mois en analyse en SIG",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "11e année d’études secondaires / secondaires V comportant : Mathématiques appliquées de 11e année ou Sec V",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent démontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "6 ans",
      },
      {
        program: "PFS-MR",
        duration: "7 ans",
      },
    ],
  },
  {
    id: "00261",
    medicalStandard: { v: 4, cv: 1, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN EN SYSTÈMES D’ARMEMENT (AIR)",
    abbreviation: "TECH SAA",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: 10e année / Secondaire IV avec mathématiques générales.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "1. Diplôme de collège/cégep de deux ans en tant que technicien ou technologue en génie électrique, en génie électronique, en électromécanique avec des connaissances pratiques en mécanique et dans les domaines de l'électronique de base",
                  "OU Diplôme d’études secondaires ou l’équivalent, comportant : mathématiques appliquées 11e année / Sec V, un cours de physique peu importe le niveau",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV, comportant : mathématiques générales de 10e année / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIESMR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition à un programme de collège/cégep acceptable",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "MSÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "1. Diplôme de collège/cégep en génie électrique, etc.",
                  "OU Diplôme d’études secondaires ou l’équivalent, comportant : mathématiques appliquées 11e année / Sec V, un cours de physique",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV, comportant : mathématiques générales de 10e année / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent démontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "5 ans",
      },
    ],
  },
  {
    id: "00299",
    medicalStandard: { v: 4, cv: 2, h: 2, g: 2, o: 2, a: 5, u: 5 },
    title: "SPÉCIALISTE EN COMMUNICATIONS NAVALES",
    abbreviation: "COMM N",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: 10e année du secondaire / Secondaire IV.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant : Mathématiques appliquées de 11e / Sec V",
                  "Cours de physique de 11e année / Sec V",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: ["10e année du secondaire / Secondaire IV"],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1 (Qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année du secondaire / Secondaire IV"],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC) du GPM COMM N 00299 dans la F rég ou la P rés",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant : Mathématiques appliquées de 11e année ou Sec V",
                  "Cours de physique de 11e année / Sec V",
                ],
                experience: ["Aucune experience requise"],
              },
              {
                level: "Acceptable",
                education: ["10e année du secondaire / Secondaire IV"],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1 (Qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année du secondaire / Secondaire IV"],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC) du GPM COMM N 00299 dans la F rég ou la P rés",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d'aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
    ],
  },
  {
    id: "00301",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN EN RÉFRIGÉRATION ET MÉCANIQUE",
    abbreviation: "TECH RÉFR MÉC",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: 10e année du secondaire / Secondaire IV comportant Mathématiques appliquées de 10e / Sec IV.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant : Mathématiques théoriques de 11e / Sec V",
                  "Un cours en sciences de 11e / Sec V",
                  "Désignation de technicien diplômé (T. D.)",
                ],
                experience: [
                  "Détenir un diplôme provincial ou interprovincial (p. ex. Sceau rouge ou carte de qualification) dans l’un des groupes professionnels",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire / Secondaire IV comportant : Mathématiques appliquées de 10e / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "MSÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant : Mathématiques théoriques de 11e / Sec V",
                  "Un cours en sciences de 11e / Sec V",
                  "Désignation de technicien diplômé (T. D.)",
                ],
                experience: [
                  "Détenir un diplôme provincial ou interprovincial (p. ex. Sceau rouge)",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire / Secondaire IV comportant : Mathématiques appliquées de 10e / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
      {
        program: "PFS-MR",
        duration: "6 ans",
      },
    ],
  },
  {
    id: "00302",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN / DISTRIBUTION ÉLECTRIQUE",
    abbreviation: "TECH DÉ",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: 10e année du secondaire / Secondaire IV comportant Mathématiques appliquées de 10e / Sec IV.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant : Mathématiques théoriques de 11e année / Sec V",
                  "Un cours en physique de 11e année / Sec V",
                ],
                experience: [
                  "Détenir un diplôme provincial ou interprovincial dans l’un des groupes professionnels suivants : Électricien en construction, Électricien industriel, Technicien de lignes électriques",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire / Secondaire IV comportant : Mathématiques appliquées de 10e / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "MSÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant : Mathématiques théoriques de 11e année / Sec V",
                  "Un cours en physique de 11e année / Sec V",
                ],
                experience: [
                  "Détenir un diplôme provincial ou interprovincial",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire / Secondaire IV comportant : Mathématiques appliquées de 10e / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
      {
        program: "PFS-MR",
        duration: "6 ans",
      },
    ],
  },
  {
    id: "00303",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN / GROUPES ÉLECTROGÈNES",
    abbreviation: "TECH GE",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: 10e année du secondaire / Secondaire IV comportant Mathématiques appliquées de 10e / Sec IV.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant : Mathématiques théoriques de 11e année / Sec V",
                  "Un cours en physique de 11e année / Sec V",
                ],
                experience: [
                  "Détenir un diplôme provincial ou interprovincial dans l’un des groupes professionnels",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire / Secondaire IV comportant : Mathématiques appliquées de 10e / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "MSÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant : Mathématiques théoriques de 11e année / Sec V",
                  "Un cours en physique de 11e année / Sec V",
                ],
                experience: [
                  "Détenir un diplôme provincial ou interprovincial",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire / Secondaire IV comportant : Mathématiques appliquées de 10e / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
    ],
  },
  {
    id: "00304",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN / PLOMBERIE ET CHAUFFAGE",
    abbreviation: "TECH PC",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: 10e année du secondaire / Secondaire IV comportant Mathématiques appliquées de 10e / Sec IV.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant : Mathématiques théoriques de 11e année / Sec V",
                  "Un cours en sciences de 11e / Sec V",
                ],
                experience: [
                  "Détenir un diplôme provincial ou interprovincial ou une qualification",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire / Secondaire IV comportant : Mathématiques appliquées de 10e / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "MSÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant : Mathématiques théoriques de 11e année / Sec V",
                  "Un cours en sciences de 11e / Sec V",
                ],
                experience: [
                  "Détenir un diplôme provincial ou interprovincial ou une qualification",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire / Secondaire IV comportant : Mathématiques appliquées de 10e / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
      {
        program: "PFS-MR",
        duration: "6 ans",
      },
    ],
  },
  {
    id: "00305",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN / EAU, PRODUITS PÉTROLIERS ET ENVIRONNEMENT",
    titleEn: "WATER, FUELS AND ENVIRONMENT TECHNICIAN",
    abbreviation: "TECH EPPE",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme d’études secondaires ou 10e année / Secondaire IV comportant Mathématiques appliquées de 10e / Sec IV.",
    details: [
      {
        force: "FORCE RÉGULIÈRE & FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant :",
                  "• Mathématiques théoriques de 11e année / Sec V",
                  "• Un cours en chimie de 11e année / Sec V",
                ],
                experience: [
                  "Détenir une qualification dans l’un des domaines/groupes professionnels civils suivants :",
                  "• Eau et eaux usées",
                  "• Évaluateur de sites environnementaux",
                  "• Opérateur de procédés de traitement du pétrole, des gaz et des produits chimiques",
                  "• Entretien des canalisations d’eau et de gaz",
                  "• Industrie du pétrole et du gaz",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire / Secondaire IV comportant :",
                  "• Mathématiques appliquées de 10e / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable (T. D.)",
                education: ["Désignation de technicien diplômé (T. D.) 2"],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1 (qualifié)"],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou l’équivalent"],
                experience: [
                  "• Atteinte du NPC 3 comme TECH EPPE 00305 dans la F rég ou la P rés, ou",
                  "• Emploi civil continu avec certification provinciale ou interprovinciale valide dans l’un des groupes professionnels suivants : Eau et eaux usées, Évaluateur de sites environnementaux, Opérateur de procédés de traitement du pétrole, des gaz et des produits chimiques, Entretien des canalisations d’eau et de gaz, Industrie du pétrole et du gaz",
                ],
              },
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du NPC 3 comme TECH EPPE 00305 dans la F rég ou la P rés",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. On trouve plus d’informations sur la désignation de technicien diplômé au site Web du Conseil canadien des techniciens et technologues : Conseil canadien des techniciens et technologues (cctt.ca).",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
    ],
  },
  {
    id: "00306",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN EN CONSTRUCTION",
    titleEn: "CONSTRUCTION TECHNICIAN",
    abbreviation: "TECH CONST",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme d’études secondaires ou 10e année / Secondaire IV avec mathématiques.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant :",
                  "• Mathématiques théoriques de 11e / Sec V",
                  "• Un cours en sciences de 11e / Sec V",
                ],
                experience: [
                  "Détenir un diplôme provincial ou interprovincial (p. ex. Sceau rouge ou carte de qualification) dans l’un des groupes professionnels suivants :",
                  "• Briqueteur-maçon / briqueteuse-maçonne (Maçonnerie)",
                  "• Charpenterie",
                  "• Pose de panneaux muraux secs",
                  "• Peinture",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV comportant :",
                  "• Mathématiques appliquées de 10e / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable (T. D.)",
                education: ["Désignation de technicien diplômé (T. D.) 2"],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1 (qualifié)"],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou l’équivalent"],
                experience: [
                  "• Atteinte du Niveau professionnel de compétence (NPC) 3 dans TECH RÉFR MÉC 00301 dans la F rég ou la P rés, ou",
                  "• Emploi civil continu avec certification provinciale ou interprovinciale valide dans l’un des groupes professionnels suivants : Briqueteur-maçon / briqueteuse-maçonne (Maçonnerie), Charpenterie, Pose de panneaux muraux secs, Peinture",
                ],
              },
              {
                level: "Acceptable",
                education: ["10e année du secondaire / Secondaire IV"],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC) 3 dans TECH RÉFR MÉC 00301 dans la F rég ou la P rés",
                ],
              },
            ],
          },
          {
            candidates: ["PIESMR 1", "Candidat civil", "RECL", "MÉ"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition ou être présentement enrôlé comme étudiant à temps plein, dans un programme d’études à un établissement postsecondaire sélectionné par les FAC 4",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. On trouve plus d’informations sur la désignation de technicien diplômé au site Web du Conseil canadien des techniciens et technologues : Conseil canadien des techniciens et technologues (cctt.ca).",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
          "4. La liste des établissements postsecondaires et des programmes approuvés par le CAF, ainsi que les exigences individuelles associées (y compris la durée et les crédits), sera mise à jour dans le Liste des groupes professionnels militaires (LGPM) sur le portail des Forces armées canadiennes Accréditations, Certifications et Équivalences (FAC ACE)",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "MSÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant :",
                  "• Mathématiques théoriques de 11e / Sec V",
                  "• Un cours en sciences de 11e / Sec V",
                ],
                experience: [
                  "Détenir un diplôme provincial ou interprovincial (p. ex. Sceau rouge ou carte de qualification) dans l’un des groupes professionnels suivants :",
                  "• Briqueteur-maçon / briqueteuse-maçonne (Maçonnerie)",
                  "• Charpenterie",
                  "• Pose de panneaux muraux secs",
                  "• Peinture",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire / Secondaire IV comportant :",
                  "• Mathématiques appliquées de 10e / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable (T. D.)",
                education: ["Désignation de technicien diplômé (T. D.) 2"],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: [
              "Candidat civil 1",
              "RECL 1",
              "MÉ 1, MSÉ 1 (qualifié)",
            ],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou l’équivalent"],
                experience: [
                  "• Atteinte du Niveau professionnel de compétence (NPC) 3 dans TECH RÉFR MÉC 00301 dans la F rég ou la P rés, ou",
                  "• Emploi civil continu avec certification provinciale ou interprovinciale valide dans l’un des groupes professionnels suivants : Briqueteur-maçon / briqueteuse-maçonne (Maçonnerie), Charpenterie, Pose de panneaux muraux secs, Peinture",
                ],
              },
              {
                level: "Acceptable",
                education: ["10e année du secondaire / Secondaire IV"],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC) 3 dans TECH RÉFR MÉC 00301 dans la F rég ou la P rés",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. On trouve plus d’informations sur la désignation de technicien diplômé au site Web du Conseil canadien des techniciens et technologues : Conseil canadien des techniciens et technologues (cctt.ca).",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
      {
        program: "PFS-MR",
        duration: "6 ans",
      },
    ],
  },
  {
    id: "00324",
    medicalStandard: { v: 4, cv: 2, h: 2, g: 2, o: 2, a: 5, u: 5 },
    title: "OPÉRATEUR SONAR",
    titleEn: "SONAR OPERATOR",
    abbreviation: "OP SONAR",
    requirements:
      "FORCE RÉGULIÈRE: Diplôme d’études secondaires ou Secondaire V au Québec (Idéal) ou 10e année / Secondaire IV (Acceptable).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1, 2", "RECL 1, 2", "MÉ 1, 2"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou certificat de Secondaire V au Québec, comportant :",
                  "• Mathématiques appliquées de 11e année ou Mathématiques 526 / SN V/TS V au Québec",
                  "• Cours de physique de 11e année ou de physique 534 au Québec",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année d’études, Secondaire IV au Québec ou l’équivalent",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: [
              "Candidat avec service antérieur 1, 2",
              "RECL 1, 2",
              "MÉ 1, 2 (tous avec service antérieur ou actif en tant qu'00324 OP SONAR)",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou certificat de Secondaire V au Québec",
                ],
                experience: [
                  "Obtention de la qualification de grade de matelot de 3e classe (NOC) 3 – 00324 OP SONAR dans la F rég",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année d’études, Secondaire IV au Québec ou l’équivalent",
                ],
                experience: [
                  "Obtention de la qualification de grade de matelot de 3e classe (NOC) 3 – 00324 OP SONAR dans la F rég",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces canadiennes (TAFC), s’il ce n’est pas déjà le cas. Les candidats civils, RECL ou MÉ qui n’ont pas atteint le NOC en tant que 00168 TECH APPR doivent obtenir la note de passage du TAFC. Se reporter à la Feuille de travail - Affectations (FTA) pour connaître les notes de passages actuelles.",
          "2. Conformément aux critères d’enrôlement/RECL/MÉ en vigueur.",
          "3. Le niveau opérationnel de compétence (NOC) est expliqué dans la description du GPM 00324 OP SONAR à l’adresse suivante: http://cmp-cpm.mil.ca/fr/soutien/personnel-militaire/dbpp.page.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
    ],
  },
  {
    id: "00327",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN EN ÉLECTRONIQUE ET OPTRONIQUE (TERRE)",
    titleEn: "ELECTRONIC AND OPTRONIC TECHNICIAN (LAND)",
    abbreviation: "TECH ÉLEC – OPTO [T]",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme d’études secondaires (Idéal) ou 10e année / Secondaire IV comprenant mathématiques et sciences (Acceptable).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant :",
                  "• Math appliquées de 11e / Sec V",
                  "• Cours de physique 11e / Sec V",
                ],
                experience: ["Permis de conduire provincial valide 2"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année d’études secondaires / Secondaire IV comprenant :",
                  "• Math appliquées de 10e / Sec IV",
                  "• Cours de sciences de 10e / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1 (qualifié)"],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou l’équivalent"],
                experience: [
                  "Atteinte du NPC 3 comme 00327 Tech Élec-Opto (T) dans la F rég ou la P rés",
                ],
              },
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du NPC 3 comme 00327 Tech Élec-Opto (T) dans la F rég ou la P rés",
                ],
              },
            ],
          },
          {
            candidates: ["PIESMR 1", "Candidat civil", "RECL", "MÉ"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans conditions ou être présentement enrôlé comme étudiant à temps plein dans un programme d’études à un établissement postsecondaire sélectionné par les FAC 4",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le candidat doit détenir ou être en mesure d’obtenir un permis de conduire d’une province ou d’un territoire (de classe G ou 5) en règle, sans condition restrictive et sans infraction en matière de conduite qui limiterait l’entièreté de ses privilèges de conduite.",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
          "4. La liste des établissements offrant des programmes d’études postsecondaires acceptables auprès des FAC pour les candidats PIES-MR se trouve à l’adresse suivante : Forces armées canadiennes Accréditations, Certifications et Équivalences (FAC ACE).",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant :",
                  "• Math appliquées de 11e / Sec V",
                  "• Cours de physique 11e / Sec V",
                ],
                experience: ["Permis de conduire provincial valide 2"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année d’études secondaires / Secondaire IV comprenant :",
                  "• Math appliquées de 10e / Sec IV",
                  "• Cours de sciences de 10e / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1 (qualifié)"],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou l’équivalent"],
                experience: [
                  "Atteinte du NPC 3 comme 00327 Tech Élec-Opto (T) dans la F rég ou la P rés",
                ],
              },
              {
                level: "Acceptable",
                education: ["10e année du secondaire / Secondaire IV"],
                experience: [
                  "Atteinte du NPC 3 comme 00327 Tech Élec-Opto (T) dans la F rég ou la P rés",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le candidat doit détenir ou être en mesure d’obtenir un permis de conduire d’une province ou d’un territoire (de classe G ou 5) en règle, sans condition restrictive et sans infraction en matière de conduite qui limiterait l’entièreté de ses privilèges de conduite.",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "5 ans",
      },
      {
        program: "PFS-MR",
        duration: "7 ans",
      },
    ],
  },
  {
    id: "00328",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 3, a: 5, u: 5 },
    title: "LOGISTIQUE",
    titleEn: "LOGISTICS",
    abbreviation: "LOG",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Baccalauréat requis (Idéal: commerce/administration, Acceptable: toute discipline).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "MÉ 1", "RECL 1", "PSAC 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Baccalauréat et/ou maîtrise :",
                  "• Comptabilité, Administration des affaires, Commerce, Finance, Économie, Logistique, Gestion de ressources humaines, Administration publique, Gestion de chaîne d’approvisionnement, études internationales, Relations industrielles, Gestion d’entreprise alimentaire, Alimentation, Nutrition/diététique, Chimie, Physique",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: ["Baccalauréat et/ou maîtrise : Toute discipline"],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PFOR 1", "PFUMR 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Être accepté sans condition à un programme de baccalauréat qui répond aux normes d’entrées académiques 'idéales' pour les candidats d’ÉDO",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition à un programme de baccalauréat dans l’un des domaines suivants :",
                  "• Baccalauréat : Anglais, Français, Histoire, Études militaires et stratégiques, Psychologie, Sciences politiques",
                  "• Baccalauréat ès sciences : Informatique, Mathématiques, Sciences spatiales, Sciences de la terre",
                  "• Baccalauréat en ingénierie (BIng) ou baccalauréat en sciences appliquées (BScA) en ingénierie : Génie aéronautique, Génie chimique, Génie civil, Génie informatique, Génie électrique, Génie mécanique",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PFOEP 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent ET Compléter un programme de baccalauréat qui répond aux normes d’entrées académiques 'idéales' pour les candidats d’ÉDO",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent ET Compléter un programme de baccalauréat dans l’un des domaines suivants :",
                  "• Baccalauréat : Anglais, Français, Histoire, Études militaires et stratégiques, Psychologie, Sciences politiques",
                  "• Baccalauréat ès sciences : Informatique, Mathématiques, Sciences spatiales, Sciences de la terre",
                  "• Baccalauréat en ingénierie (BIng) ou baccalauréat en sciences appliquées (BScA) en ingénierie : Génie aéronautique, Génie chimique, Génie civil, Génie informatique, Génie électrique, Génie mécanique",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Conformément au DOAD 5002-10, Programme d’intégration des officiers sortis du rang, exigences académiques",
                ],
                experience: [
                  "Les candidats doivent avoir le rang effectif de m2/sgt dans l'une des professions suivantes : 00164 CUIS, 00167 COMMIS P, 00168 TECH GEST MAT, 00169 TECH MUN, 00170 TECH MOUV, 00171 COND MMS, 00375 ADM RH, 00376 ADM SERV FIN, Conformément à la directive 00328 LOG PNSCO",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Les candidats doivent avoir le rang effectif de pm1/adjuc et ont occupé le rang de pm2 / adjum dans l'une des professions suivantes : 00164 CUIS, 00167 COMMIS P, 00168 TECH GEST MAT, 00169 TECH MUN, 00170 TECH MOUV, 00171 COND MMS, 00375 ADM RH, 00376 ADM SERV FIN",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["PEDO 1", "RECL 1", "MÉ 1", "MSÉ 1", "PSAC 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Baccalauréat et/ou maîtrise :",
                  "• Comptabilité, Administration des affaires, Commerce, Finance, Économie, Logistique, Gestion de ressources humaines, Administration publique, Gestion de chaîne d’approvisionnement, études internationales, Relations industrielles, Gestion d’entreprise alimentaire, Alimentation, Nutrition/diététique, Chimie, Physique",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: ["Baccalauréat et/ou maîtrise : toute discipline"],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIRO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Inscription à temps plein, à temps partiel ou par apprentissage à distance dans un programme de baccalauréat dans un établissement d’enseignement postsecondaire en vue de l’obtention d’un baccalauréat 2 dans le domaine suivant :",
                  "• Comptabilité, Administration des affaires, Commerce, Finance, Économie, Logistique, Gestion de ressources humaines, Administration publique, Gestion de chaîne d’approvisionnement, Relations industrielles, Gestion d’entreprise alimentaire, Alimentation, Nutrition/diététique, Chimie, Physique, Anglais, Français, Histoire, Études militaires et stratégiques, Psychologie, Sciences politiques, Informatique, Mathématiques, Sciences spatiales",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Conformément au DOAD 5002-10, Programme d’intégration des officiers sortis du rang, exigences académiques",
                ],
                experience: [
                  "Les candidats doivent avoir le rang effectif de m2/sgt dans l'une des professions suivantes : 00164 CUIS, 00167 COMMIS P, 00168 TECH GEST MAT, 00169 TECH MUN, 00170 TECH MOUV, 00171 COND MMS, 00375 ADM RH, 00376 ADM SERV FIN, Conformément à la directive 00328 LOG PNSCO",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Les candidats doivent avoir le rang effectif de pm1/ adjuc et ont occupé le rang de pm2/ adjum dans l'une des professions suivantes : 00164 CUIS, 00167 COMMIS P, 00168 TECH GEST MAT, 00169 TECH MUN, 00170 TECH MOUV, 00171 COND MMS, 00375 ADM RH, 00376 ADM SERV FIN",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Pour les candidats du Québec, cela comprend l'inscription à un programme CÉGEP préuniversitaire approprié conformément au DOAD 5002-8, Programme d intégration à la Réserve – Officiers (PIRO).",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "6 ans",
      },
      {
        program: "PFOR",
        duration: "10 ans",
      },
    ],
  },
  {
    id: "00335",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN DENTAIRE",
    titleEn: "DENTAL TECHNICIAN",
    abbreviation: "TECH DENT",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Certificat NDAEB et permis en règle provincial requis, ou bien être inscrit aux études à temps plein (PESMR).",
    details: [
      {
        force: "FORCE RÉGULIÈRE & FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1, 2", "RECL 1, 2", "MÉ 1, 2"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Certificat du Bureau national d’examen d’assistance dentaire (NDAEB) 3, 4, 5",
                  "ET Permis en règle 6 pour agir en tant qu’assistant dentaire délivré par une autorité de réglementation canadienne provinciale ou territoriale 7",
                  "ET Lettre de l’autorité de réglementation professionnelle attestant que le candidat est 'en règle' (le cas échéant) 7",
                ],
                experience: [
                  "• Obtention du diplôme au cours des 12 derniers mois: Aucune expérience requise",
                  "OU",
                  "• Obtention du diplôme au-delà des 12 derniers mois: Au moins 900 heures d'expérience en clinique en tant qu'assistant dentaire ou hygiéniste dentaire au cours des deux dernières années 8, 9",
                ],
              },
            ],
          },
          {
            candidates: [
              "RECL 1, 2",
              "MÉ 1, 2 (avec antécédents de service comme GPM 00335 TECH DENT)",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Certificat du Bureau national d’examen d’assistance dentaire (NDAEB) 3, 4, 5",
                  "ET Permis en règle 6 pour agir en tant qu’assistant dentaire délivré par une autorité de réglementation canadienne provinciale ou territoriale 7",
                  "ET Lettre de l’autorité de réglementation professionnelle attestant que le candidat est 'en règle' (le cas échéant) 7",
                ],
                experience: [
                  "• Au moins 900 heures d’expérience en clinique en tant qu’assistant dentaire ou hygiéniste dentaire au cours des deux dernières années 8, 9",
                  "ET Atteinte du Niveau opérationnel de compétence (NOC) en tant que 00335 TECH DENT dans la F rég ou la P rés 10",
                ],
              },
            ],
          },
          {
            candidates: ["PESMR / PESMR Réserve 1, 2"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition ou être présentement inscrit comme étudiant à temps plein dans un programme d’études à un établissement d’enseignement postsecondaire choisi par les FAC 11",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le test d’aptitude des Forces canadiennes (TAFC) s’ils ne l’ont pas déjà fait. Seuls les candidats PESMR sont tenus d’obtenir la note de passage du TAFC. Consulter la Feuille de travail – Affectations (FTA) pour connaître les notes de passages en vigueur. (Pour la Réserve, ils ne sont pas tenus d'obtenir la note de passage du CFAT/TAFC si déjà enrôlés).",
          "2. Conformément aux critères d’enrôlement/RECL/MÉ/PESMR en vigueur.",
          "3. Un candidat qui n’est qualifié/homologué qu’en tant qu’hygiéniste dentaire peut être admissible à une mutation/un enrôlement au GPM TECH DENT. Dans un tel cas, il est tenu de passer avec succès l’examen du BNEAD (NDAEB) et d’obtenir une homologation de niveau II comme assistant dentaire.",
          "4. Un candidat ayant fait ses études au Québec et qui n’a obtenu qu’une qualification comme assistant dentaire de niveau I du ministère de l’Éducation du Québec doit réussir des études ultérieures dans un programme d’études pour assistant dentaire de niveau II pour être admissible à l’examen du BNEAD.",
          "5. Consulter le site Web https://www.ndaeb.ca/index_F.php pour obtenir plus de renseignements sur les exigences en question.",
          "6. Par 'permis en règle sans restriction', on entend un permis complet, sans restriction et illimité d’agir comme assistant dentaire de niveau II dans une province ou un territoire du Canada.",
          "7. On trouve les autorités de réglementation provinciales/territoriales à l'adresse suivante: http://www.cdaa.ca/da-promotion/dental-assisting-regulatory-authorities/?lang=fr (Ne s'applique pas en Ontario, au Québec, aux T.N.-O. et au Nunavut).",
          "8. Le candidat doit détenir une lettre rédigée par ses employeurs précédents opérant son expérience clinique détaillée ainsi que le nombre d'heures travaillées.",
          "9. Si le candidat ne peut répondre aux critères d'expérience clinique en raison de service antérieur, son dossier doit être transmis pour ÉFA.",
          "10. Le niveau opérationnel de compétence (NOC) est défini dans la description du GPM TECH DENT.",
          "11. La liste des établissements postsecondaires participants au programme PESMR se trouve à l'adresse https://caface-rfacace.forces.gc.ca/.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "5 ans",
      },
      {
        program: "PFS-MR",
        duration: "8 ans",
      },
    ],
  },
  {
    id: "00337",
    medicalStandard: { v: 3, cv: 2, h: 2, g: 3, o: 3, a: 4, u: 5 },
    title: "OPÉRATEUR – CONTRÔLE AÉROSPATIAL",
    titleEn: "AEROSPACE CONTROL OPERATOR",
    abbreviation: "OP CA",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme d’études secondaires avec mathématiques théoriques de 11e / Sec V (Idéal) ou 10e année / Secondaire IV avec mathématiques de niveau Sec IV (Acceptable).",
    details: [
      {
        force: "FORCE RÉGULIÈRE & FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant :",
                  "• Math théoriques de 11e année / Sec V",
                  "• Tout cours de science de n'importe quel niveau",
                ],
                experience: [
                  "Détenir un permis de conduire provincial valide 3",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV comprenant :",
                  "• Math appliquées de 10e / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1 (qualifié)"],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou l’équivalent"],
                experience: [
                  "Atteinte du Niveau opérationnel de compétence (NPC) comme 00337 OP CA dans la F rég 3",
                ],
              },
              {
                level: "Acceptable",
                education: ["10e année du secondaire / Secondaire IV"],
                experience: [
                  "Atteinte du Niveau opérationnel de compétence (NPC) comme 00337 OP CA dans la F rég 3",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le candidat doit détenir ou être en mesure d’obtenir un permis de conduire d’une province ou d’un territoire (de classe G ou 5) en règle, sans condition restrictive.",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "5 ans",
      },
    ],
  },
  {
    id: "00339",
    medicalStandard: { v: 3, cv: 2, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "SAPEUR DE COMBAT",
    titleEn: "COMBAT ENGINEER",
    abbreviation: "SPR CBT",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme d’études secondaires ou équivalent (Idéal) ou 10e année / Secondaire IV (Acceptable).",
    details: [
      {
        force: "FORCE RÉGULIÈRE & FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "MÉ 1", "RECL 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou équivalent.",
                  "• Note : La réussite d'un cours de math académiques de 12e année (math 536 : SN V/TS V au Québec) et d'un cours de physique peu importe le niveau est un atout.",
                ],
                experience: [
                  "Aucune expérience requise.",
                  "• Atout : Expérience/qualification civile en génie civil, menuiserie, forage, opération lourde, ou permis de conduire valide 2.",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année secondaire, Secondaire IV au Québec, ou équivalent.",
                  "• Note : La réussite d'un cours de math académiques de 10e année (math 436 : SN IV/TS IV) ou appliquées (math 426) et d'un cours de physique est un atout.",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["MÉ 1 (qualifié)"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou équivalent.",
                  "• Atout : Math 12e (536) / Physique.",
                ],
                experience: [
                  "Atteinte du niveau professionnel de compétence (NPC) 3 dans 00339 SPR CBT dans la F rég ou la P rés des FAC, ou atout de QEL.",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année secondaire, Secondaire IV au Québec, ou équivalent.",
                  "• Atout : Math 10e / Physique.",
                ],
                experience: [
                  "Atteinte du niveau professionnel de compétence (NPC) 3 dans 00339 SPR CBT dans la F rég ou la P rés des FAC.",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le candidat doit détenir un permis de conduire d'une province/territoire (de classe G ou 5) en règle ne comprenant aucune condition ni limite.",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "3 ans",
      },
    ],
  },
  {
    id: "00340",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 3, a: 5, u: 5 },
    title: "GÉNIE ÉLECTRONIQUE ET DES COMMUNICATIONS",
    titleEn: "ELECTRONICS AND COMMUNICATIONS ENGINEERING",
    abbreviation: "GE COMM",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Baccalauréat requis (Idéal: ingénierie/informatique/physique, Acceptable: sciences de la terre/mathématiques/chimie).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "PSAC 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Baccalauréat en ingénierie (BIng) ou baccalauréat en sciences appliquées (BScA) en ingénierie : Communications, Informatique, Systèmes informatiques, Électrique, Logiciel, Systèmes logiciels, Physique.",
                  "• Baccalauréat en science (BSc) : Science de l’information en informatique, Systèmes d’information en informatique, Science informatique, Gestion de l’information, Science de l’information, Systèmes d’information, Technologie de l’information",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "Baccalauréat en ingénierie (BIng) ou baccalauréat en sciences appliquées (BScA) en ingénierie : toute discipline.",
                  "• Baccalauréat en science (BSc) : Mathématiques appliquées, Mathématiques, Mathématiques et Physique, Physique, Chimie, Sciences spatiales, Sciences de la terre",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PFOR 1", "UTPNCM 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition à un programme de baccalauréat dans l'un des domaines admissibles spécifiés pour GE COMM.",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PFOEP 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent ET (Diplôme de technologie dans un domaine du génie décerné par un collège communautaire ou un institut technique agréé OR Au moins deux années complètes d’un baccalauréat en ingénierie ou baccalauréat en sciences appliquées (BScA) en ingénierie / Baccalauréat en science (BSc) dans les domaines admissibles pour GE COMM)",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Conformément au DOAD 5002-10, Programme d’intégration des officiers sortis du rang, exigences académiques",
                ],
                experience: [
                  "Être qualifié au grade effectif de m2/sgt dans l’un des GPM suivants : 00120 CH COMM, 00109 TECH SITA, 00362 SSCIAT, 00378 CYBEROPERATEUR, 00394 TECH SI, 00385 TECH TRANS, 00383 OP TRANS, 00384 SL. Conformément à la directive 00340 GE COMM PNSCO",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Les candidats doivent occuper le rang effectif de 00381 pm1/Adjuc et avoir détenu le rang de pm2/Adjum dans l'une des occupations suivantes : 00394 TECH SI, 00385 TECH TRANS, 00362 SSCIAT, 00120 CH COMM, 00378 CYBER OPERATEUR, 00109 TECH SITA, 00383 OP TRANS, 00384 SL.",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. When applicable, applicants are required to meet the minimum cut-off score on the Canadian Forces Aptitude Test (CFAT) for the related programme.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "RECL 1", "MÉ 1", "PSAC 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Baccalauréat en ingénierie (BIng) ou baccalauréat en sciences appliquées (BScA) en ingénierie : Communications, Informatique, Systèmes informatiques, Électricité, Logiciel, Systèmes logiciels.",
                  "• Baccalauréat en science (BSc) : Science de l’information en informatique, Systèmes d’information en informatique, Science informatique, Gestion de l’information, Science de l’information, Systèmes d’information, Technologie de l’information, Physique",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "Baccalauréat en ingénierie (BIng) ou baccalauréat en sciences appliquées (BScA) en ingénierie : toute discipline.",
                  "• Baccalauréat en science (BSc) : Mathématiques appliquées, Mathématiques, Mathématiques et Physique, Physique, Chimie, Sciences spatiales, Sciences de la terre",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Exigence Critique 2",
                education: ["Baccalauréat : toute discipline"],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIRO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Inscription à temps plein, à temps partiel ou par apprentissage à distance dans un programme de baccalauréat dans un établissement d’enseignement postsecondaire en vue de l’obtention d’un baccalauréat 3 dans l’un des domaines d'études admissibles spécifiés pour GE COMM / Baccalauréat en ingénierie (BIng), baccalauréat en sciences appliquées (BScA) ou Baccalauréat en science (BSc)",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Exigence Critique 2",
                education: [
                  "Enrôlement comme étudiant à temps plein au premier cycle dans le programme d'un établissement postsecondaire canadien menant à un Baccalauréat 3 : toute discipline",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Conformément au DOAD 5002-10, Programme d’intégration des officiers sortis du rang, exigences académiques",
                ],
                experience: [
                  "Être qualifié au grade effectif de m2/sgt dans l’un des GPM suivants : 00120 CH COMM, 00109 TECH SITA, 00362 SSCIAT, 00378 CYBEROPERATEUR, 00394 TECH SI, 00385 TECH TRANS, 00383 OP TRANS, 00384 SL",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Les candidats doivent occuper le rang effectif de 00381 pm1/Adjuc et avoir détenu le rang de pm2/Adjum dans l'une des occupations suivantes : 00394 TECH SI, 00385 TECH TRANS, 00362 SSCIAT, 00120 CH COMM, 00378 CYBER OPERATEUR, 00109 TECH SITA, 00383 OP TRANS, 00384 SL.",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Une unité éprouvant un besoin critique en personnel doit envoyer une justification à l’autorité chargée de l’enrôlement, tel que stipulé dans la DOAD 5002-1 (p. ex., un officier exerçant les pouvoirs de cmdt de commandement ou de formation).",
          "3. Dans le cas des candidats du Québec, ces exigences comprennent un enrôlement dans un programme CEGEP préuniversitaire, conformément au message CANFORGEN 023/13, Programme d’intégration à la Réserve – Officiers (PIRO).",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "9 ans",
      },
      {
        program: "PFOR",
        duration: "13 ans",
      },
    ],
  },
  {
    id: "00341",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 3, a: 5, u: 5 },
    title: "TRANSMISSIONS",
    titleEn: "SIGNALS",
    abbreviation: "TRANS",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Baccalauréat requis (Idéal: ingénierie/informatique, Acceptable: sciences/général).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "PSAC 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Baccalauréat en ingénierie (BIng) ou baccalauréat ès sciences appliquées (BScA) : Communications, Informatique, Ordinateurs, Électrique, Systèmes logiciels.",
                  "• Baccalauréat : Sciences de l'informatique, Systèmes informatiques, Science informatique, Gestion de l'information, Science de l'information, Technologie de l'information",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "Baccalauréat en ingénierie (BIng) ou baccalauréat ès sciences appliquées (BScA) : toute discipline.",
                  "• Baccalauréat : Mathématiques appliquées, Chimie, Imagerie, Mathématiques, Mathématiques et physique, Physique, Sciences de l'espace, Sciences de la Terre, Baccalauréat général 2",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PFOR 1", "PFUMR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition à un programme de baccalauréat dans l'un des domaines admissibles spécifiés pour TRANS.",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PFOEP 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent ET (Diplôme de technologie dans un domaine du génie à un collège ou une institution technique accréditée OR Au moins deux ans de crédits d’études dans un baccalauréat dans l’un des génies suivants : Communications, Informatique, Électricité, Systèmes de logiciels)",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Conformément au DOAD 5002-10, Programme d’intégration des officiers sortis du rang, exigences académiques",
                ],
                experience: [
                  "Détenir au minimum le grade effectif de sgt dans l’un des occupations suivantes : 00394 TECH SI, 00385 TECH TRANS, 00362 SSCIAT, 00120 CH COMM, 00378 CYBEROPERATEUR, 00109 TECH SITA, 00383 OP TRANS, 00384 SL. Conformément à la directive 00341 TRANS PNSCO",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Les candidats doivent occuper le rang effectif de 00381 Adjuc et avoir détenu le rang de Adjum dans l'une des occupations suivantes : 00394 TECH SI, 00385 TECH TRANS, 00362 SSCIAT, 00120 CH COMM, 00378 CYBEROPERATEUR, 00109 TECH SITA, 00383 OP TRANS, 00384 SL.",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Un baccalauréat général en sciences doit comporter au moins 75 % de cours en physique, chimie et/ou en mathématiques, le 25 % restant étant axé dans n’importe quel autre domaine.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "RECL 1", "PSAC 1", "MÉ 1", "MSÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Baccalauréat en ingénierie (BIng) ou baccalauréat ès sciences appliquées (BScA) : Communications, Informatique, Ordinateurs, Électrique, Systèmes logiciels.",
                  "• Baccalauréat : Sciences de l'informatique, Systèmes informatiques, Science informatique, Gestion de l'information, Science de l'information, Technologie de l'information",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "Baccalauréat en ingénierie (BIng) ou baccalauréat ès sciences appliquées (BScA) : toute discipline.",
                  "• Baccalauréat : Mathématiques appliquées, Chimie, Imagerie, Mathématiques, Mathématiques et physique, Physique, Sciences de l'espace, Sciences de la Terre, Baccalauréat général 2",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Exigence Critique 3",
                education: ["Baccalauréat : toute discipline"],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIRO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Inscription à temps plein, à temps partiel ou par apprentissage à distance dans un programme de baccalauréat dans un établissement d’enseignement postsecondaire en vue de l’obtention d’un baccalauréat 4 dans l’un des domaines d'études admissibles spécifiés pour TRANS",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Exigence Critique 3",
                education: [
                  "Inscription à temps plein, à temps partiel ou par apprentissage à distance dans un programme de baccalauréat dans un établissement d’enseignement postsecondaire en vue de l’obtention d’un baccalauréat 4 dans n'importe quelle discipline",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Conformément au DOAD 5002-10, Programme d’intégration des officiels sortis du rang, exigences académiques",
                ],
                experience: [
                  "Détenir au minimum le grade effectif de sgt dans l’un des occupations suivantes : 00120 CH COMM, 00378 CYBER OPERATEUR, 00362 SSCIAT, 00109 TECH SITA, 00394 TECH SI, 00385 TECH TRANS, 00383 OP TRANS, 00384 PL",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Un baccalauréat général en sciences doit comporter au moins 75 % de cours en physique, chimie et/ou en mathématiques, le 25 % restant étant axé dans n’importe quel autre domaine.",
          "3. Une unité éprouvant un besoin critique en personnel doit envoyer une justification à l’autorité chargée de l’enrôlement, tel que stipulé dans la DOAD 5002-1 (p. ex., un officier exerçant les pouvoirs de cmdt de commandement ou de formation).",
          "4. Dans le cas des candidats du Québec, ces exigences comprennent un enrôlement dans un programme CEGEP préuniversitaire, conformément au message CANFORGEN 023/13, Programme d’intégration à la Réserve – Officiers (PIRO).",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "9 ans",
      },
      {
        program: "PFOR",
        duration: "13 ans",
      },
    ],
  },
  {
    id: "00344",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "GÉNIE DES SYSTÈMES DE COMBAT NAVAL",
    titleEn: "NAVAL COMBAT SYSTEMS ENGINEERING",
    abbreviation: "GSCN",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Baccalauréat requis (Idéal: génie électrique/informatique/logiciel, Acceptable: sciences/toute autre discipline).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["ÉDO 1", "RECL 1", "MÉ 1", "PSAC 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "• Diplôme de maîtrise en génie ou en sciences appliquées dans l'une des disciplines admissibles spécifiées,",
                  "• Baccalauréat en génie (B.Ing) ou baccalauréat en sciences appliquées (B.Sc.A) : Électrique, Informatique, Logiciel, Cyber systèmes",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "• Baccalauréat en génie (B.Ing) ou baccalauréat en sciences appliquées (B.Sc.A) : Aéronautique, Aérospatial, Architecture navale, Chimique, Civil, Communications, Industriel, Physique technique, Systèmes électroniques, Matériaux, Maritime, Mécanique, Métallurgique, Nucléaire.",
                  "• Baccalauréat ès sciences : Données, Espace, Informatique, Mathématiques, Physiques.",
                  "• Baccalauréat en technologies de l'information.",
                  "• Baccalauréat de technologie (Technique du génie et sciences appliquées) par la <<Fisheries and Marine Institute of Memorial University>> de Terre-Neuve 2 (avec NPC3 atteint)",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable (qualifié)",
                education: ["Baccalauréat : toute discipline"],
                experience: [
                  "Atteinte du niveau professionnel de compétence (NPC) 3 pour GSCN 00344, ou dans un GPM de la F rég ou la P rés des FAC",
                ],
              },
            ],
          },
          {
            candidates: ["PFUMR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "• Avoir terminé au moins deux cours d’un an au niveau universitaire ou l’équivalent,",
                  "• Obtenir une admission inconditionnelle dans un programme de baccalauréat qui répond aux normes d’entrées académiques 'idéales' ou 'acceptables' pour les candidats d’ÉDO non-qualifiés",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PFOR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Obtenir une admission inconditionnelle dans un programme de baccalauréat 2 qui répond aux normes d’entrées académiques 'idéales' ou 'acceptables' pour les candidats d’ÉDO non-qualifiés",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Certificat d’études secondaires ou l’équivalent, OU Diplôme ou baccalauréat équivalent à au moins deux ans d’études supérieures à temps plein, Conformément au DOAD 5002-10, exigences académiques",
                ],
                experience: [
                  "Les candidats doivent occuper un rang effectif de m2 ou supérieur dans l'une des occupations suivantes : 00366 TECH GA, 00379 TECH MAR",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV ou équivalent"],
                experience: [
                  "Les candidats doivent occuper le rang effectif de pm1 et avoir détenu le rang de pm2 dans l'une des occupations suivantes : 00366 TECH GA, 00379 TECH MAR",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Baccalauréat de technologie (Technique du génie et sciences appliquées) par la <<Fisheries and Marine Institute of Memorial University>> de Terre-Neuve n’est pas admissible sous le PFOR.",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP).",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["ÉDO 1", "RECL 1", "MÉ 1", "MSÉ 1 (qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Baccalauréat : toute discipline"],
                experience: [
                  "Atteinte du niveau professionnel de compétence (NPC) 2 pour GSCN 00344",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "8 ans",
      },
      {
        program: "PFOR",
        duration: "12 ans",
      },
    ],
  },
  {
    id: "00345",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "OFFICIER DU GÉNIE DES SYSTÈMES DE MARINE",
    titleEn: "MARINE SYSTEMS ENGINEERING OFFICER",
    abbreviation: "OGSM",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Baccalauréat requis (Idéal: génie marine/mécanique, Acceptable: sciences/autres génies).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "RECL 1", "MÉ 1", "MSÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "• Maîtrise académique en ingénierie ou en sciences appliquées dans la même discipline,",
                  "• Baccalauréat en technologie – Sciences nautiques de l'Université du Cap-Breton,",
                  "• Baccalauréat en génie ou baccalauréat en sciences appliquées (B.Sc.A) : Marine, Mécanique, Architecture navale",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "• Baccalauréat en génie ou baccalauréat en sciences appliquées (B.Sc.A) dans l’un des domaines suivants : Aéronautique, Aérospatial, Chimique, Génie civil, Génie de l'environnement, Génie des systèmes électriques, Génie des systèmes électroniques, Génie Électrique, Génie Physique, Génie Informatique, Industriel, Logiciel, Matériels, Métallurgique, Nucléaire.",
                  "• Baccalauréat ès sciences : Informatiques, Mathématiques, Physiques, Espace.",
                  "• Baccalaureate of Technology (Engineering Technology and Applied Science) par la <<Fisheries and Marine Institute of Memorial University>> de Terre-Neuve (avec NPC3 atteint)",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable (qualifié)",
                education: ["Baccalauréat : toute discipline"],
                experience: [
                  "Atteint le niveau professionnel de compétence (NPC) 3 pour OGSM 00345, ou dans un GPM de la F rég ou la P rés des FAC",
                ],
              },
            ],
          },
          {
            candidates: ["PFUMR 1, 4"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "• Avoir terminé au moins deux cours d’un an au niveau universitaire ou l’équivalent,",
                  "• Obtenir une admission inconditionnelle dans un programme de baccalauréat qui répond aux normes d’entrées académiques 'idéales' ou 'acceptables' pour les candidats d’EDO non-qualifiés",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PFOR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Obtenir une admission inconditionnelle dans un programme de baccalauréat 2 qui répond aux normes d’entrées académiques 'idéales' ou 'acceptables' pour les candidats d’EDO non-qualifiés",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1, 4"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Certificat d’études secondaires ou l’équivalent, OU Diplôme ou baccalauréat équivalent à au moins deux ans d’études supérieures à temps plein, Conformément au DOAD 5002-10, exigences académiques",
                ],
                experience: [
                  "Les candidats doivent occuper un rang effectif de m2 ou supérieur dans l'une des occupations suivantes : 00326 TECH EPPE, 00379 TECH MAR",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV ou équivalent"],
                experience: [
                  "Les candidats doivent occuper le rang effectif de pm1 et avoir détenu le rang de pm2 dans l'une des occupations suivantes : 00366 TECH GA, 00379 TECH MAR",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Lorsque l'occupation est projetée comme étant « rouge/exigence » en raison du rapport prévisionnel d'un an (EQA à EQR) basé sur le modèle de planification à long terme (MPLT) de DBPP 5.",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP).",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "RECL 1", "MÉ 1", "MSÉ 1 (qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["Baccalauréat : toute discipline"],
                experience: [
                  "Atteint le niveau professionnel de compétence (NPC) 2 pour OGSM 00345",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "8 ans",
      },
      {
        program: "PFOR",
        duration: "12 ans",
      },
    ],
  },
  {
    id: "00349",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 3, a: 5, u: 5 },
    title: "AUMÔNIER",
    titleEn: "CHAPLAIN",
    abbreviation: "AUM",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Maîtrise en théologie/soins spirituels, baccalauréat de base et accréditation/endossement d'une tradition de foi requis.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 1, 2, 3", "RECL 1, 2, 3", "MÉ 1, 2, 3"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "• Baccalauréat 4 dans n'importe quel domaine d'études,",
                  "• Diplôme de maîtrise qui a pour but d’équiper et de développer un leader au sein d’une tradition de foi 5 en matière de soin et soutien spirituels (au moins de deux ans d’équivalence à temps plein) dans un établissement d’enseignement postsecondaire agréé 6.",
                  "• Pour le Québec : Diplôme d’études collégiales ou l'équivalent + Baccalauréat d'un établissement approuvé du Québec en théologie (B Th ou l'équivalent) ou n'importe quel baccalauréat + une maîtrise.",
                ],
                experience: [
                  "• Accrédité et reconnu comme un leader au sein d’une tradition de foi par l’autorité de gouvernance de cette même tradition qui exerce une supervision au Canada,",
                  "• Endossé comme aumônier par le CIAMC, entrevue et jugé apte par un comité présidé par le D Svc Aum,",
                  "• L’équivalent de minimum de deux années d’expérience à temps plein rémunérées à titre de leader accrédité au sein d’une tradition de foi.",
                ],
              },
            ],
          },
          {
            candidates: ["Études subventionnées (ES-PMNE) 1, 2, 12"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "• Baccalauréat dans l'un des domaines admissibles,",
                  "• Acceptation sans condition à un programme de maîtrise qui a pour but d'équiper et de développer un leader au sein d'une tradition de foi.",
                ],
                experience: [
                  "• Preuve d’être un candidat officiel en tant que leader au sein d’une tradition de foi,",
                  "• Endossement conditionnel par le CIAMC, entrevue et lettre d'assurance d'occuper un poste de travail supervisé.",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces canadiennes (TAFC). Un candidat du GPM 00349 AUM n’est pas tenu d’obtenir la note de passage des officiers du TAFC.",
          "2. Conformément aux critères d’enrôlement/RECL/MÉ/ES-PMNE en vigueur.",
          "3. Tous les candidats doivent d’abord communiquer avec le Directeur – Services d’aumônerie (D Svc Aum) afin de commencer le processus d’attestation par le comité interconfessionnel (CIAMC).",
          "4. Si maîtrise obtenue sans baccalauréat, évaluation spécifique.",
          "5. Un leader inclut les intervenants en matière de soin et soutien spirituels dans divers lieux (hôpital, prison, école, etc.).",
          "6. Accréditation par l'ATS ou équivalent.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: [
              "EDO 1, 2, 3",
              "RECL 1, 2, 3",
              "MÉ 1, 2, 3",
              "MSÉ 1, 2, 3",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "• Baccalauréat 4 dans n'importe quel domaine d'études,",
                  "• Diplôme de maîtrise qui a pour but d’équiper et de développer un leader au sein d’une tradition de foi 5 en matière de soin et soutien spirituels (au moins de deux ans d’équivalence à temps plein) dans un établissement d’enseignement postsecondaire agréé 6.",
                  "• Pour le Québec : Diplôme d’études collégiales ou l'équivalent + Baccalauréat d'un établissement approuvé du Québec en théologie (B Th ou l'équivalent) ou n'importe quel baccalauréat + une maîtrise.",
                ],
                experience: [
                  "• Accrédité et reconnu comme un leader au sein d’une tradition de foi par l’autorité de gouvernance de cette même tradition qui exerce une supervision au Canada,",
                  "• Endossé comme aumônier par le CIAMC, entrevue et jugé apte par un comité présidé par le D Svc Aum,",
                  "• L’équivalent de minimum de deux années d’expérience à temps plein rémunérées à titre de leader accrédité au sein d’une tradition de foi.",
                ],
              },
            ],
          },
          {
            candidates: ["PIRO 1, 2"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "• Baccalauréat dans n’importe quel domaine,",
                  "• Acceptation sans condition à un programme de maîtrise qui a pour but d'équiper et de développer un leader.",
                ],
                experience: [
                  "• Attestation de reconnaissance comme candidat en tant qu’animateur de traditions confessionnelles.",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces canadiennes (TAFC). Un candidat du GPM 00349 AUM n’est pas tenu d’obtenir la note de passage des officiers du TAFC.",
          "2. Conformément aux critères d’enrôlement/RECL/MÉ/PIRO en vigueur.",
          "3. Tous les candidats doivent d’abord communiquer avec le Directeur – Services d’aumônerie (D Svc Aum) afin de commencer le processus d’attestation par le comité interconfessionnel (CIAMC).",
          "4. Si maîtrise sans baccalauréat, étude de cas.",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "6 ans",
      },
      {
        program: "ES_PMNE/PFOS",
        duration: "12 ans",
      },
    ],
  },
  {
    id: "00366",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN EN GENIE DES ARMES",
    titleEn: "WEAPONS ENGINEERING TECHNICIAN",
    abbreviation: "TECH GA",
    requirements:
      "FORCE RÉGULIÈRE: Diplôme d’études secondaires avec mathématiques théoriques de 11e / Sec V et physique (Idéal) ou 10e année / Secondaire IV avec math théoriques Sec IV (Acceptable).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant :",
                  "• Mathématiques théoriques de 11e année / Sec V",
                  "• Un cours de physique de n'importe quel niveau",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année du secondaire / Secondaire IV, comportant :",
                  "• Mathématiques théoriques de 10e année / Sec IV (CST 4, SN 4 ou TS 4)",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIES-MR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Doit être admis sans conditions, ou être actuellement inscrit comme étudiant à temps plein dans un programme de formation en génie électronique, dans un des établissements postsecondaires choisis par les FAC 2",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. La liste des établissements postsecondaires et des programmes approuvés par le CAF, ainsi que les exigences individuelles associées, se trouve sur le portail FAC ACE.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
      {
        program: "PFS-MR",
        duration: "6 ans",
      },
    ],
  },
  {
    id: "00368",
    medicalStandard: { v: 3, cv: 2, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "ARTILLEUR",
    titleEn: "ARTILLERYMAN",
    abbreviation: "ARTIL",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme d’études secondaires (Idéal) ou 10e année / Secondaire IV (Acceptable).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou équivalent"],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: ["10e année d’études secondaires / Secondaire IV"],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1 (qualifié)"],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou équivalent"],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC) 2 dans 00368 ARTIL, 00008 ARTIL-DS, ou 00009 ARTIL-DA de la P rés ou de la F rég",
                ],
              },
              {
                level: "Acceptable",
                education: ["10e année d’études secondaires / Secondaire IV"],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC) 2 dans 00368 ARTIL, 00008 ARTIL-DS, ou 00009 ARTIL-DA de la P rés ou de la F rég",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent compléter le Test d’aptitude des Forces canadiennes (TAFC) si ce n’est déjà fait et répondre aux exigences actuelles du programme applicable.",
          "2. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou équivalent"],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: ["10e année d’études secondaires / Secondaire IV"],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1 (qualifié)"],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou équivalent"],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC) 2 dans 00368 ARTIL, 00008 ARTIL-DS, ou 00009 ARTIL-DA de la P rés ou de la F rég",
                ],
              },
              {
                level: "Acceptable",
                education: ["10e année d’études secondaires / Secondaire IV"],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC) 2 dans 00368 ARTIL, 00008 ARTIL-DS, ou 00009 ARTIL-DA de la P rés ou de la F rég",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent compléter le Test d’aptitude des Forces canadiennes (TAFC) si ce n’est déjà fait et répondre aux exigences actuelles du programme applicable.",
          "2. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "3 ans",
      },
    ],
  },
  {
    id: "00370",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN EN DESSIN ET EN ARPENTAGE",
    titleEn: "DRAFTING AND SURVEYING TECHNICIAN",
    abbreviation: "TECH DA",
    requirements:
      "FORCE RÉGULIÈRE & FORCE DE LA RÉSERVE: Diplôme d’études secondaires ou cert. technicien agréé en technologie civile (Idéal) ou 11e année / Secondaire V avec mathématiques de 11e (Acceptable).",
    details: [
      {
        force: "FORCE RÉGULIÈRE & FORCE DE LA RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant :",
                  "• Math appliquées de 11e / Sec V",
                ],
                experience: [
                  "Détenir une qualification dans au moins un des domaines/groupes professionnels civils suivants :",
                  "• Technicien en dessin assisté par ordinateur (CAD)",
                  "• Dessinateur, Technicien en dessin, Technologue de dessin",
                  "• Technologue en arpentage, Technicien en levés topographiques",
                  "• Technologue en levés géographiques, Arpenteur-géomètre, Technicien en arpentage",
                  "OU avoir atteint du niveau professionnel de compétence (NPC) 3 dans l’un des groupes professionnels militaires (GPM) suivants :",
                  "• 00238 TECH GÉO dans la F rég ou la P rés",
                  "• 00306 TECH CONST dans la F rég ou la P rés",
                  "• 00368 GNR dans la F rég ou la P rés",
                ],
              },
              {
                level: "Idéal (Technicien agréé)",
                education: [
                  "Détenir un certificat de Technicien agréé en tant que technologue civil 3",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "11e année / Secondaire V, comportant :",
                  "• Mathématiques appliquées de 11e / Sec V",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1 (qualifié)"],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou l’équivalent"],
                experience: [
                  "Avoir atteint le NPC3 de 00370 TECH DA dans la F rég ou la P rés",
                ],
              },
              {
                level: "Acceptable",
                education: ["11e année / Secondaire V"],
                experience: [
                  "Avoir atteint le NPC3 de 00370 TECH DA dans la F rég ou la P rés",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. On trouve plus d’informations sur la désignation de technicien diplômé au site Web du Conseil canadien des techniciens et technologues : Conseil canadien des techniciens et technologues (cctt.ca).",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP).",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
    ],
  },
  {
    id: "00372",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN DE BLOC OPÉRATOIRE",
    titleEn: "OPERATING ROOM TECHNICIAN",
    abbreviation: "TECH BO",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme d'un programme d'infirmier auxiliaire, autorisation provinciale en règle, cert. en soins peropératoires. Idéal: exp. peropératoire (>1500h).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1, 2", "RECL 1, 2", "MÉ 1, 2"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "• Diplôme d’un programme d’infirmier auxiliaire",
                  "• Détention d’une autorisation en règle de travailler comme infirmier auxiliaire autorisé/immatriculé émise par un organisme de réglementation provincial ou territorial 3, 4, 5",
                  "• Lettre de l’organisme de réglementation de la profession du candidat attestant que ce dernier est « en règle » 5",
                  "• Certification comme infirmier auxiliaire autorisé/immatriculé en soins peropératoires",
                ],
                experience: [
                  "• Expérience actuelle comme infirmier auxiliaire autorisé/immatriculé en soins peropératoires",
                  "• Au moins 1 500 heures de pratique clinique au cours des deux dernières années",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "• Diplôme d’un programme d’infirmier auxiliaire",
                  "• Détention d’une autorisation en règle de travailler comme infirmier auxiliaire autorisé/immatriculé émise par un organisme de réglementation provincial ou territorial 3, 4, 5",
                  "• Lettre de l’organisme de réglementation de la profession du candidat attestant que ce dernier est « en règle » 5",
                  "• Certification comme infirmier auxiliaire autorisé/immatriculé en soins peropératoires",
                ],
                experience: [
                  "• Avoir gradué dans les 12 derniers mois",
                  "• Aucune expérience minimum requise",
                ],
              },
            ],
          },
          {
            candidates: [
              "Candidat civil 1, 2",
              "RECL 1, 2",
              "MÉ 1, 2 (qualifié)",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "• Diplôme d’un programme d’infirmier auxiliaire",
                  "• Détention d’une autorisation en règle de travailler comme infirmier auxiliaire autorisé/immatriculé émise par un organisme de réglementation provincial ou territorial 3, 4, 5",
                  "• Lettre de l’organisme de réglementation de la profession du candidat attestant que ce dernier est « en règle » 5",
                ],
                experience: [
                  "• Avoir atteint le NPC6 comme 00372 TECH BO ou 00334-03 TECH MÉD - BO dans la F rég",
                  "• Au moins 1 500 heures de pratique clinique au cours des deux dernières années",
                ],
              },
            ],
          },
          {
            candidates: ["PIES-MR 1, 2, 7", "Candidat civil", "RECL", "MÉ"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "• Être accepté sans condition ou être présentement enrôlé comme étudiant à temps plein, dans un programme d’études d’infirmier auxiliaire autorisé/immatriculé 7 à un établissement postsecondaire sélectionné par les FAC",
                  "OU détenir :",
                  "  o Diplôme d’un programme d’infirmier auxiliaire",
                  "  o Une autorisation en règle de travailler comme infirmier auxiliaire autorisé/immatriculé émise par un organisme de réglementation provincial ou territorial 3, 4, 5",
                  "  o Lettre de l’organisme de réglementation de la profession du candidat attestant que ce dernier est « en règle » 5 ; et",
                  "  o Être inscrit ou admissible à s'inscrire à un programme de soins infirmiers peropératoires 7, 8 dans un établissement postsecondaire sélectionné par les FAC",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Les candidats d’enrôlement direct (ED)/RECL/MÉ, pour initier une évaluation de reconnaissance des acquis, doivent soumettre une liste de documents requis via les services de santé des FAC.",
          "3. Par « permis en règle », on entend un permis complet, sans restriction et illimité d’agir comme infirmier auxiliaire/immatriculé ou TECH BO dans une province ou un territoire du Canada.",
          "4. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP).",
          "5. La liste des établissements postsecondaires et des programmes approuvés par le CAF se trouve sur le portail FAC ACE.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1, 2", "MÉ 1, 2 (qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "• Diplôme d’un programme d’infirmier auxiliaire",
                  "• Détention d’une autorisation en règle de travailler comme infirmier auxiliaire ou territorial 3, 4, 5",
                  "• Lettre de l’organisme de réglementation de la profession du candidat attestant que ce dernier est « en règle » 5",
                ],
                experience: [
                  "• Avoir atteint le NPC6 comme 00372 TECH BO ou 00334-03 TECH MÉD - BO dans la F rég",
                  "• Au moins 1 500 heures de pratique clinique au cours des deux dernières années",
                ],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1, 2", "RECL 1, 2", "MÉ 1, 2"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "• Diplôme d’un programme d’infirmier auxiliaire",
                  "• Détention d’une autorisation en règle de travailler comme infirmier auxiliaire émise par un organisme de réglementation provincial ou territorial 3, 4, 5",
                  "• Lettre de l’organisme de réglementation de la profession du candidat attestant que ce dernier est « en règle » 5",
                  "• Certification comme infirmier auxiliaire autorisé/immatriculé en soins peropératoires",
                ],
                experience: [
                  "• Expérience actuelle comme infirmier auxiliaire autorisé/immatriculé en soins peropératoires",
                  "• Au moins 1 500 heures de pratique clinique au cours des deux dernières années",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "6 ans",
      },
      {
        program: "PFS-MR",
        duration: "9 ans",
      },
    ],
  },
  {
    id: "00374",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "ADJOINT AU MÉDECIN",
    titleEn: "PHYSICIAN ASSISTANT",
    abbreviation: "AM",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Maîtrise ou Baccalauréat d'un prog. accrédité d'adjoint au médecin, certf. de CCAMC, permis provincial et de l'expérience (Idéal: >1500h).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "PSAC 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "• Maîtrise ou baccalauréat dans un programme d’études accrédité d’adjoint au médecin (AM) 2",
                  "• Certificat en règle du Conseil de certification des adjoints au médecin du Canada (CCAMC) et permis/licence en règle (en vigueur) d’exercer comme adjoint au médecin délivré(e) par une autorité réglementaire 3 d’une province ou d’un territoire du Canada",
                  "• Lettre de l’autorité professionnelle réglementaire 3 ou de son superviseur en clinique, selon le cas, attestant que le candidat est en règle",
                ],
                experience: [
                  "• Emploi actuel à temps plein ou partiel dans l’un des domaines suivants : Soins primaires, Urgence, Formation clinique 4 ou autre expérience clinique pertinente 5, 7",
                  "• Expérience 7 d’au moins 1 500 heures au cours des deux dernières années dans l’un ou plusieurs des domaines susmentionnés",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "• Maîtrise ou baccalauréat dans un programme d’études accrédité d’adjoint au médecin (AM) 2",
                  "• Certificat en règle du Conseil de certification des adjoints au médecin du Canada (CCAMC) et permis/licence en règle (en vigueur) d’exercer comme adjoint au médecin délivré(e) par une autorité réglementaire 3 d’une province ou d’un territoire du Canada",
                  "• Lettre de l’autorité professionnelle réglementaire 3 ou de son superviseur en clinique, selon le cas, attestant que le candidat est en règle",
                ],
                experience: [
                  "• Diplôme obtenu au cours des 12 derniers mois: aucune expérience requise",
                  "OU diplôme obtenu il y a plus de 12 mois :",
                  "  - comme l’idéal, expérience 7 minimale de 1 500 heures comme AM au cours des cinq dernières années dans l’un ou plusieurs des domaines susmentionnés",
                  "  - OU comme l’idéal, expérience 7 minimale de 600 heures comme AM au cours des deux dernières années dans l’un ou plusieurs des domaines susmentionnés, et atteinte du NPC 6 dans son GPM actuel",
                ],
              },
            ],
          },
          {
            candidates: ["PFOR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "• Obtenir une acceptation inconditionnelle dans un programme de formation accrédité de baccalauréat au Canada pour les adjoints au médecin (AM) 2",
                  "OU être présentement inscrit en tant qu’étudiant à temps plein et en règle dans un programme d’études universitaires comme adjoint au médecin à une université du Canada 2",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PFOS 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "• Obtenir une acceptation inconditionnelle dans un programme de formation accrédité de maîtrise au Canada pour les adjoints au médecin (AM) 2",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PFAMM 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "• Obtenir une acceptation inconditionnelle dans un programme de formation accrédité de maîtrise ou de baccalauréat au Canada pour les adjoints au médecin (AM) 2",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. On trouve les programmes d’études agréés au Canada menant à un maîtrise ou baccalauréat d’adjoint au médecin au site de la CAPA.",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM.",
          "4. Un candidat ayant une expérience dans un autre domaine ou en nombre d’heures insuffisant peut faire parvenir une demande d’Évaluation de sa formation antérieure (EFA) au Groupe des services de santé des Forces canadiennes.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "PSAC 1", "RECL 1", "MSÉ 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "• Maîtrise ou baccalauréat dans un programme d’études accrédité d’adjoint au médecin (AM) 2",
                  "• Certificat en règle du Conseil de certification des adjoints au médecin du Canada (CCAMC) et permis/licence en règle (en vigueur) d’exercer comme adjoint au médecin",
                  "• Lettre de l’autorité professionnelle réglementaire 3 ou de son superviseur en clinique, selon le cas, attestant que le candidat est en règle",
                ],
                experience: [
                  "• Emploi actuel à temps plein ou partiel dans l’un des domaines de Soins primaires, Urgence, Formation clinique, etc.",
                  "• Expérience 7 minimale de 1 500 heures au cours des deux dernières années dans l’un ou plusieurs des domaines susmentionnés",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "• Maîtrise ou baccalauréat dans un programme d’études accrédité d’adjoint au médecin (AM) 2",
                  "• Certificat en règle du Conseil de certification des adjoints au médecin du Canada (CCAMC) et permis/licence en règle (en vigueur) d’exercer comme adjoint au médecin",
                  "• Lettre de l’autorité professionnelle réglementaire 3 ou de son superviseur en clinique, selon le cas, attestant que le candidat est en règle",
                ],
                experience: [
                  "• Expérience 7 minimale de 1 500 heures comme AM au cours des cinq dernières années dans l’un ou plusieurs des domaines susmentionnés conformément aux normes du candidat « Idéal »",
                  "OU Expérience 7 minimale de 600 heures comme AM au cours des deux dernières années dans l’un ou plusieurs des domaines susmentionnés conformément aux normes du candidat « Idéal », et Atteinte du NPC 6 dans le GPM actuel",
                ],
              },
            ],
          },
          {
            candidates: ["PIRO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "• Être présentement inscrit en tant qu’étudiant à temps plein et en règle dans ou obtenir une acceptation inconditionnelle dans un programme de formation accrédité de maîtrise ou de baccalauréat au Canada pour les adjoints au médecin (AM) 2",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "5 ans",
      },
      {
        program: "PFAMM/PFOS",
        duration: "9 ans",
      },
    ],
  },
  {
    id: "00375",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 3, a: 5, u: 5 },
    title: "ADMINISTRATEUR – RESSOURCES HUMAINES",
    titleEn: "HUMAN RESOURCES ADMINISTRATOR",
    abbreviation: "ADM RH",
    requirements:
      "FORCE RÉGULIÈRE & FORCE DE LA RÉSERVE: Diplôme d’études secondaires avec mathématiques de 11e / Sec V (Idéal) ou 10e année / Secondaire IV avec math appliquées de Sec IV (Acceptable).",
    details: [
      {
        force: "FORCE RÉGULIÈRE & FORCE DE LA RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant :",
                  "• Math appliquées de 11e année / Sec V",
                  "• Cours d’anglais ou de français de 11e année / Sec V",
                ],
                experience: [
                  "Expérience de six mois dans l’utilisation de tous les programmes qui suivent dans le cadre d’un emploi au cours des trois dernières années :",
                  "• Microsoft Excel",
                  "• Microsoft PowerPoint",
                  "• Microsoft Word",
                  "• Microsoft Windows",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV comportant :",
                  "• Math appliquées de 10e année / Sec IV",
                  "• Cours d’anglais ou de français de 10e année / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1 (qualifié)"],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou l’équivalent"],
                experience: [
                  "Atteinte du NPC 2 comme 00298 COMMIS SGR ou 00375 ADM HR dans la F rég ou la P rés",
                ],
              },
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du NPC 2 comme 00298 COMMIS SGR ou 00375 ADM HR dans la F rég ou la P rés",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP).",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "3 ans",
      },
    ],
  },
  {
    id: "00376",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 3, a: 5, u: 5 },
    title: "ADMINISTRATEUR – SERVICES FINANCIERS",
    titleEn: "FINANCIAL SERVICES ADMINISTRATOR",
    abbreviation: "ADM SERV FIN",
    requirements:
      "FORCE RÉGULIÈRE & FORCE DE LA RÉSERVE: Diplôme d’études secondaires avec mathématiques de 11e / Sec V (Idéal) ou 10e année / Secondaire IV avec math appliquées de Sec IV (Acceptable).",
    details: [
      {
        force: "FORCE RÉGULIÈRE & FORCE DE LA RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent, comportant :",
                  "• Math appliquées de 11e année / Sec V",
                  "• Cours d’anglais ou de français de 11e année / Sec V",
                ],
                experience: [
                  "Expérience de six mois dans l’utilisation de tous les programmes qui suivent dans le cadre d’un emploi au cours des trois dernières années :",
                  "• Microsoft Excel",
                  "• Microsoft PowerPoint",
                  "• Microsoft Word",
                  "• Microsoft Windows",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV comportant :",
                  "• Math appliquées de 10e année / Sec IV",
                  "• Cours d’anglais ou de français de 10e année / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1 (qualifié)"],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou l’équivalent"],
                experience: [
                  "Atteinte du NPC 2 comme 00298 COMMIS SGR ou 00376 ADM SERV FIN dans la F rég ou la P rés",
                ],
              },
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du NPC 2 comme 00298 COMMIS SGR ou 00376 ADM SERV FIN dans la F rég ou la P rés",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP).",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "3 ans",
      },
    ],
  },
  {
    id: "00378",
    medicalStandard: { v: 4, cv: 3, h: 2, g: 3, o: 3, a: 5, u: 5 },
    title: "CYBEROPÉRATEUR",
    titleEn: "CYBER OPERATOR",
    abbreviation: "CYBEROPÉRATEUR",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme/Bac en cybersécurité/informatique (Idéal) ou diplôme d'études secondaires V / 12e année avec mathématiques avancées du Sec V/12e (Acceptable).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: [
              "Candidat civil 1, 2, 3",
              "RECL 1, 2, 3",
              "MÉ 1, 2, 3",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "• Obtention d’un diplôme ou d’un baccalauréat dans un domaine associé à la cybersécurité, à un établissement d’études postsecondaires agréé (Informatique, Sécurité des réseaux, Technologie des systèmes informatiques, Systèmes informatiques, Sécurité des systèmes informatiques ou Systèmes informatiques : cybersécurité),",
                  "• OU de l’instruction ou une certification reconnue en cybersécurité (CompTIA Security +, CISSP/ISC2, SANS, CE, OSCP)",
                ],
                experience: [
                  "• Aucune expérience requise (si diplôme complété),",
                  "• OU si certification : Avoir occupé pendant au moins un an un emploi relié à la cybersécurité au cours des trois dernières années (Analyste, Spécialiste d'incident, Vérificateur, Ingénieur, etc.)",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires, Secondaire V au Québec ou l’équivalent, comportant :",
                  "• Mathématiques appliquées de 12e année ou Mathématiques 526 / SN V/TS V au Québec,",
                  "• OU Études informatiques de 12e année ou de Secondaire V, comportant informatique, science informatique, ou programmation informatique",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PESMR 1, 2, 3", "Candidat civil", "RECL", "MÉ"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition ou être présentement enrôlé comme étudiant à temps plein dans un programme d’études à un établissement d’enseignement postsecondaire choisi par les FAC",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces canadiennes (TAFC). Un candidat civil/RECL/MÉ/SMÉ qui ne détient pas de diplôme ou de baccalauréat, ainsi qu’un candidat PESMR est tenu d’obtenir la note de passage du TAFC.",
          "2. Le candidat civil doit être en mesure d’obtenir une cote de sécurité de niveau III (Très secret – Accès spécial).",
          "3. On trouve les établissements postsecondaires offrant des programmes d'études PES MR acceptables pour les FAC sur le portail FAC ACE.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: [
              "Candidat civil 1, 2, 3",
              "RECL 1, 2, 3",
              "MÉ 1, 2, 3",
              "MSÉ 1, 2, 3",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "• Obtention d’un diplôme ou d’un baccalauréat dans un domaine associé à la cybersécurité (Informatique, Sécurité réseau, Génie informatique, Technologie des systèmes informatiques, Systèmes informatiques, Sécurité des systèmes informatiques ou Systèmes informatiques: cybersécurité),",
                  "• OU de l’instruction ou certification (CompTIA Security +, ISC2, SANS, CE, OSCP)",
                ],
                experience: [
                  "• Occuper présentement un emploi à temps plein dans un des champs liés à la cybersécurité (Analyste en sécurité, Soutien réseau, Incidentologue, Ingénieur de sécurité, etc.)",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires, Secondaire V au Québec ou l’équivalent, comportant :",
                  "• Mathématiques appliquées de 12e année ou Mathématiques 526 / SN V/TS V au Québec,",
                  "• OU Études de 12e année en informatique, science informatique, ou programmation informatique",
                ],
                experience: [
                  "• Avoir occupé pendant au moins deux ans un emploi à temps plein relié à la cybersécurité au cours des trois dernières années",
                ],
              },
              {
                level: "Acceptable (Étudiant)",
                education: [
                  "Être présentement inscrit à temps plein à un programme de baccalauréat dans un domaine lié à la cybersécurité à un établissement d’études postsecondaires ou à une université",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces canadiennes (TAFC).",
          "2. Le candidat civil doit être en mesure d’obtenir une cote de sécurité de niveau III (Très secret – Accès spécial).",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "6 ans",
      },
      {
        program: "PFS-MR",
        duration: "8 ans",
      },
    ],
  },
  {
    id: "00383",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "OPÉRATEUR DES TRANSMISSIONS",
    titleEn: "SIGNAL OPERATOR",
    abbreviation: "OP TRANS",
    requirements:
      "FORCE RÉGULIÈRE & FORCE DE RÉSERVE: Diplôme d’études secondaires avec mathématiques appliquées de 11e / Sec V (Idéal) ou 10e année / Secondaire IV avec math appliquées de Sec IV (Acceptable).",
    details: [
      {
        force: "FORCE RÉGULIÈRE & FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent comportant :",
                  "• Mathématiques appliquées de 11e année / Sec V",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV comportant :",
                  "• Mathématiques appliquées de 10e année / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1 (qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV comprenant :",
                  "• Mathématiques appliquées de 10e année / Sec IV",
                ],
                experience: [
                  "Atteinte du NPC2 comme 00362-01 SSCIAT ou 00383 OP TRANS",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM.",
          "3. Dans la plupart des cas, un ancien 00362-01 SSCIAT devra combler un écart d’instruction pour obtenir la qualification 00383 OP TRANS. Une EFA devra être soumise.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
    ],
  },
  {
    id: "00384",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "POSEUR DE LIGNE",
    titleEn: "LINE TECHNICIAN",
    abbreviation: "PL",
    requirements:
      "FORCE RÉGULIÈRE & FORCE DE RÉSERVE: Diplôme d’études secondaires avec mathématiques de 11e / Sec V et six mois d'expérience comme poseur de ligne (Idéal) ou 10e année / Secondaire IV avec math de Sec IV (Acceptable, aucune expérience).",
    details: [
      {
        force: "FORCE RÉGULIÈRE & FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent comportant :",
                  "• Mathématiques appliquées de 11e année / Sec V",
                ],
                experience: [
                  "• Six mois d’expérience dans l’industrie des télécommunications comme poseur de lignes",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV comportant :",
                  "• Mathématiques appliquées de 10e année / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1 (qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV comportant :",
                  "• Mathématiques appliquées de 10e année / Sec IV",
                ],
                experience: [
                  "Atteinte du NPC2 comme 00362 SSCIAT – TST et 00384 PL",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM.",
          "3. Une Évaluation de la formation antérieure (EFA) devra être soumise.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
    ],
  },
  {
    id: "00385",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN DES TRANSMISSIONS",
    titleEn: "SIGNALS TECHNICIAN",
    abbreviation: "TECH TRANS",
    requirements:
      "FORCE RÉGULIÈRE & FORCE DE RÉSERVE: Diplôme d’études secondaires avec mathématiques de 11e / Sec V et physique (Idéal) ou 10e année / Secondaire IV avec math de Sec IV et sciences (Acceptable).",
    details: [
      {
        force: "FORCE RÉGULIÈRE & FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou équivalent, comportant :",
                  "• Mathématiques appliquées de 11e année / Sec V",
                  "• Physique de 11e année / Sec V",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV, comportant :",
                  "• Mathématiques académiques de 10e année / Sec IV",
                  "• Science de 10e année / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1 (qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire, comportant :",
                  "• Math académiques de 10e année / Sec IV",
                  "• Science de 10e année",
                ],
                experience: [
                  "Atteinte du NPC2 comme 00362 SSCIAT – TSC, 00362 SSCIAT-TSI or 00385 TECH TRANS",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM.",
          "3. Dans la plupart des cas, un ancien SSCIAT – SC ou TSI devra combler un écart d’instruction pour obtenir la qualification 00385 TECH TRANS.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
    ],
  },
  {
    id: "00386",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN DE SOUTIEN AUX OPÉRATIONS AÉRIENNES",
    titleEn: "AIR OPERATIONS SUPPORT TECHNICIAN",
    abbreviation: "TECH SOA",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme d’études secondaires ou l’équivalent (Idéal) ou 10e année / Secondaire IV (Acceptable).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou l’équivalent"],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1 (qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du niveau professionnel de compétence (NPC) 2 dans 00386 TECH SOA",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le niveau Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
        ],
      },
      {
        force: "FORCE DE LA RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "MSÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: ["Diplôme d’études secondaires ou l’équivalent"],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: [
              "Candidat civil 1",
              "RECL 1",
              "MÉ 1",
              "MSÉ 1 (qualifié)",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du niveau professionnel de compétence (NPC) 2 dans 00386 TECH SOA",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le niveau Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP)",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "5 ans",
      },
    ],
  },
  {
    id: "00387",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN DES SYSTÈMES DE LARGAGE AÉRIEN",
    titleEn: "AIR DROP SYSTEMS TECHNICIAN",
    abbreviation: "TECH SLA",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme d'études secondaires (Idéal) ou 10e année / Secondaire IV (Acceptable) - Expérience avec textiles ou couture/parachutisme est un atout.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1, 2", "RECL 1, 2", "MÉ 1, 2"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou diplôme de Secondaire V au Québec",
                ],
                experience: [
                  "Expérience / de qualifications au travail dans les domaines suivants :",
                  "• Travail avec des textiles",
                  "• Avoir travaillé avec une machine à coudre et l’avoir entretenue",
                  "• Parachutisme",
                  "• Certification d’arrimage de parachutes (FAA/CSPA)",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année d’études secondaires ou Secondaire IV au Québec",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: [
              "Candidat civil 1, 2",
              "RECL 1, 2",
              "MÉ 1, 2 (qualifié)",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou diplôme de Secondaire V au Québec",
                ],
                experience: [
                  "Avoir atteint le NPC comme 00387 TECH SLA au cours des 5 dernières années",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année d’études secondaires ou Secondaire IV au Québec",
                ],
                experience: [
                  "Avoir atteint le NPC comme 00387 TECH SLA au cours des 5 dernières années",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. S'ils sont sélectionnés, les membres devront passer Test d’aptitude physique – parachutistes des Forces canadiennes à leur arrivée à l'école de Trenton. S'il n'est pas atteint, soumis à un reconditionnement physique.",
          "3. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: [
              "Candidat civil 1, 2",
              "RECL 1, 2",
              "MÉ 1, 2",
              "MSÉ 1, 2",
            ],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou diplôme de Secondaire V au Québec",
                ],
                experience: [
                  "Expérience / de qualifications au travail dans les domaines suivants :",
                  "• Travail avec des textiles",
                  "• Avoir travaillé avec une machine à coudre et l’avoir entretenue",
                  "• Parachutisme",
                  "• Certification d’arrimage de parachutes (FAA/CSPA)",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année d’études secondaires ou Secondaire IV au Québec",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. S'ils sont sélectionnés, les membres devront passer Test d’aptitude physique – parachutistes à leur arrivée à Trenton.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "5 ans",
      },
    ],
  },
  {
    id: "00389",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 3, a: 5, u: 5 },
    title: "OFFICIER DES OPÉRATIONS AÉRIENNES",
    titleEn: "AIR OPERATIONS OFFICER",
    abbreviation: "O OPS AIR",
    requirements:
      "FORCE RÉGULIÈRE & FORCE DE RÉSERVE: Maîtrise académique (Idéal) ou Baccalauréat dans n'importe quel domaine (Acceptable).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "PSAC 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: ["Maîtrise académique en : n'importe lequel"],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: ["Baccalauréat : n'importe lequel"],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PFOR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition à un programme de baccalauréat dans l'un des domaines suivants : n'importe lequel",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PFUMR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Avoir terminé au moins deux cours d’un an au niveau universitaire ou l’équivalent (p. ex. quatre cours d’un semestre)",
                  "ET Être accepté sans condition à un programme d'étude menant à l'obtention d'un baccalauréat (n'importe lequel)",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PFOEP 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent",
                  "ET Compléter un programme de baccalauréat (n'importe lequel)",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent",
                  "OU Diplôme ou baccalauréat représentant au moins deux ans d'études universitaires à plein temps",
                ],
                experience: [
                  "Détenir le grade effectif de M2/Sgt ou plus dans le groupe professionnel :",
                  "• 00337 OP CA",
                  "• 00019 OP DEA",
                  "• 00021 MÉC B",
                  "• 00101 TECH SAR",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Détenir le grade effectif de PM1/Adjuc et détenir le grade d'Adjum en :",
                  "• 00337 OP CA",
                  "• 00019 OP DEA",
                  "• 00021 MÉC B",
                  "• 00101 TECH SAR",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "PSAC 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: ["Maîtrise académique en : n'importe lequel"],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: ["Baccalauréat : n'importe lequel"],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIRO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Inscrit comme étudiant à temps partiel, à temps plein ou à distance dans un établissement postsecondaire canadien dans un programme menant à un baccalauréat (n'importe lequel)",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIOSR 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Diplôme d’études secondaires ou l’équivalent",
                  "OU Diplôme ou baccalauréat représentant au moins deux ans d'études universitaires à plein temps",
                ],
                experience: [
                  "Détenir le grade effectif de M2/Sgt ou plus dans le groupe professionnel :",
                  "• 00337 OP CA",
                  "• 00019 OP DEA",
                  "• 00021 MÉC B",
                  "• 00101 TECH SAR",
                ],
              },
            ],
          },
          {
            candidates: ["PNSCO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Détenir le grade effectif de PM1/Adjuc et détenir le grade d'Adjum en :",
                  "• 00337 OP CA",
                  "• 00019 OP DEA",
                  "• 00021 MÉC B",
                  "• 00101 TECH SAR",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Pour les candidats du Québec, cela comprend l'inscription à un programme CÉGEP préuniversitaire approprié conformément au DOAD 5002-8, PIRO.",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "6 ans",
      },
      {
        program: "PFOR",
        duration: "10 ans",
      },
    ],
  },
  {
    id: "00390",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "MÉDECIN SPÉCIALISTE",
    titleEn: "MEDICAL SPECIALIST",
    abbreviation: "MÉD SPÉC",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme de médecine (MD), formation spécialisée (résidence agréée) d'une discipline énumérée (Anesthésiologie, Chirurgie, Psychiatrie, Radiologie, etc.), Certification/Fellow du Collège royal, permis d’exercice canadien valide et sans restriction.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "MÉ 1, 10"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "• Diplôme de médecine délivré par une université canadienne agréée ou équivalences du Conseil médical du Canada (CMC),",
                  "• Achèvement d'une formation spécialisée (résidence agréée) en médecine interne, anesthésiologie, chirurgie générale, chirurgie orthopédique, psychiatrie, radiologie, physiatrie, médecine d'urgence,",
                  "• Certification et titre de fellow du Collège royal des médecins et chirurgiens du Canada dans l'une de ces spécialités,",
                  "• Permis d'exercice valide et sans restriction,",
                  "• Attestation de bonne conduite professionnelle",
                ],
                experience: [
                  "• Pour toutes les spécialités (sauf psychiatrie et physiatrie) : Être employé à temps plein dans un poste clinique au sein d’un établissement de soins de santé civil.",
                ],
              },
            ],
          },
          {
            candidates: ["RECL 1, 10, 12 (Formé comme MÉD 00393)"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "• Diplôme de médecine agréé / CMC,",
                  "• Admission sans restriction à un programme de résidence agréé dans l'une des spécialités d'exercice,",
                  "• Certification en médecine familiale,",
                  "• Permis d'exercice valide et sans restriction,",
                  "• Attestation de bonne conduite",
                ],
                experience: [
                  "• Avoir travaillé pendant 3 ans comme Médecin militaire général (MMG)",
                ],
              },
            ],
          },
          {
            candidates: ["PFOS 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "• Diplôme de médecine agréé / CMC,",
                  "• Admission et inscription à un programme de résidence en spécialité d'une université canadienne,",
                  "• Attestations requises",
                ],
                experience: ["• Aucune expérience minimale requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
          "2. Un médecin formé à l'étranger fait l'objet d'une évaluation d'équivalences des Services de santé (Svcs S).",
          "3. L'enrôlement et spécialité admis dépendent directement des postes vacants.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: [
              "EDO 1",
              "MÉ 1 (formé comme MÉD SPÉC 00390)",
              "RECL 1 (Qualifié dans l’une des spécialités)",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "• Diplôme de médecine agréé / CMC,",
                  "• Résidence complétée,",
                  "• Certification de Fellow,",
                  "• Permis d'exercice et attestation de bonne conduite",
                ],
                experience: [
                  "• Pour toutes les spécialités : Être employé à temps plein dans un poste clinique au sein d’un établissement de soins de santé civil.",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO",
        duration: "5 ans",
      },
      {
        program: "PFOS",
        duration: "12 ans",
      },
    ],
  },
  {
    id: "00393",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "MÉDECIN MILITAIRE",
    titleEn: "MEDICAL OFFICER",
    abbreviation: "MÉD",
    requirements:
      "FORCE RÉGULIÈRE & RÉSERVE: Diplôme en médecine (MD) agréé, autorisation d’exercer la médecine en règle et sans restriction (Médecin de famille ou Urgentologue), certification en médecine familiale (CMFC / CMFC-MU).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "RECL 1", "MÉ 1 (Médecin de famille)"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "• Diplôme en médecine agréé ou équivalent CMC,",
                  "• Autorisation d'exercer la médecine de famille,",
                  "• Certification en médecine familiale du Collège des médecins de famille du Canada",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: [
              "EDO 1",
              "RECL 1",
              "MÉ 1 (Médecin d’urgence agréé par le CMFC)",
            ],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "• Diplôme en médecine agréé ou équivalent CMC,",
                  "• Autorisation d'exercer la médecine d'urgence,",
                  "• Certification en médecine familiale et compétences supplémentaires en médecine d'urgence",
                ],
                experience: [
                  "Aucune expérience requise",
                  "Exigence d'affectation au service des urgences",
                ],
              },
            ],
          },
          {
            candidates: ["PFOS 1, 9"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être présentement inscrit à temps plein ou accepté à une école de médecine ou résidence en médecine familiale au Canada",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Tous les candidats doivent subir le Test d’aptitude des Forces canadiennes (TAFC), mais sont exemptés si diplôme de premier cycle.",
          "2. Les médecins formés à l'étranger font l'objet d'une évaluation d'équivalences d'autorisation par les Svc San.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "RECL 1", "MÉ 1 (Médecin de famille)"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "• Diplôme en médecine agréé ou équivalent CMC,",
                  "• Autorisation d'exercer sans restriction,",
                  "• Certificat en médecine de famille",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["EDO 1", "RECL 1", "MÉ 1 (Médecin d’urgence)"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "• Diplôme en médecine agréé ou équivalent CMC,",
                  "• Autorisation d'exercer,",
                  "• Certification en médecine de famille et Certificat de compétences en urgence",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["PIRO 1"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être inscrit à temps plein en médecine familiale dans une université agréée ou être accepté à une école de médecine",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: ["1. Même norme applicable."],
      },
    ],
    contracts: [
      {
        program: "EDO",
        duration: "5 ans",
      },
      {
        program: "PMEM/PFOS",
        duration: "12 ans",
      },
    ],
  },
  {
    id: "00394",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN DES SYSTÈMES D’INFORMATION",
    titleEn: "INFORMATION SYSTEMS TECHNICIAN",
    abbreviation: "TECH SI",
    requirements:
      "FORCE RÉGULIÈRE & FORCE DE RÉSERVE: Diplôme d’études secondaires avec mathématiques de 11e / Sec V et physique (Idéal) ou 10e année / Secondaire IV avec mathématiques théoriques de Sec IV et tout cours de sciences de Sec IV (Acceptable).",
    details: [
      {
        force: "FORCE RÉGULIÈRE & FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou équivalent, comportant :",
                  "• Mathématiques appliquées de 11e année / Sec V",
                  "• Physique de 11e année / Sec V",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV, comportant :",
                  "• Mathématiques théoriques, 10e année / Sec IV",
                  "• Tout cours de sciences, 10e année / Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1 (qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du NPC2 comme as 00362 SSCIAT – TSC3, 00362 SSCIAT-TSI3, 00394 TECH SI",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
          "2. Le Niveau professionnel de compétence (NPC) est décrit dans chaque description de GPM, au lien suivant: Directeur – Besoins en production du personnel (DBPP).",
          "3. Dans la plupart des cas, un ancien SSCIAT – SC ou SSCIAT -TSI devra combler un écart d’instruction pour obtenir la qualification TECH SI 00394. Une EFA devra être soumise.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
    ],
  },
  {
    id: "00398",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "GESTION DES SERVICES DE SANTÉ",
    abbreviation: "GSS",
    requirements:
      "FORCE RÉGULIÈRE & FORCE DE RÉSERVE: Maîtrise en gestion des services de santé/administration des affaires/publique/GRH (Idéal) ou Baccalauréat dans un de ces domaines ou disciplines connexes en santé (Acceptable).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["EDO 1", "RECL 1", "MÉ 1", "PSAC 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Maîtrise : Gestion des services de santé, Administration des soins de santé, Administration de la santé, Gestion des soins de santé, Administration des affaires, Administration publique ou Gestion des ressources humaines",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "Diplôme de baccalauréat : Gestion des services de santé, Administration des soins de santé, Administration de la santé, Gestion des soins de santé, Administration des affaires, Administration publique ou Gestion des ressources humaines",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "Baccalauréat ou diplôme d’études supérieures dans une discipline des sciences de la santé",
                ],
                experience: [
                  "Un minimum de deux années d’expérience cumulative en gestion à temps plein au cours des cinq dernières années dans un milieu de soins de santé",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
    ],
    contracts: [
      {
        program: "EDO/PSAC",
        duration: "10 ans",
      },
      {
        program: "PFOR",
        duration: "14 ans",
      },
    ],
  },
  {
    id: "00402",
    title: "MATELOT",
    abbreviation: "MAT",
    requirements:
      "FORCE RÉGULIÈRE & FORCE DE RÉSERVE: Diplôme d’études secondaires ou équivalent, comportant : Mathématiques appliquées de 11e année / Sec V (Idéal), ou 10e année du secondaire / Secondaire IV (Acceptable). Aucune expérience requise.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou équivalent, comportant : Mathématiques appliquées de 11e année / Sec V",
                ],
                experience: ["No minimum experience required"],
              },
              {
                level: "Acceptable",
                education: ["10e année du secondaire / Secondaire IV"],
                experience: ["No minimum experience required"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires ou équivalent, comportant : Mathématiques appliquées de 11e année / Sec V",
                ],
                experience: ["No minimum experience required"],
              },
              {
                level: "Acceptable",
                education: ["10e année du secondaire / Secondaire IV"],
                experience: ["No minimum experience required"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent rencontrer la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "1 an",
      },
    ],
  },
  {
    id: "00404",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN EN ÉLECTRICITÉ DES SYSTEMS DE MARINE",
    abbreviation: "TESM",
    requirements:
      "FORCE RÉGULIÈRE: Diplôme d’études postsecondaires en génie, en technologie du génie ou en sciences appliquées (Idéal) ou 10e année / Secondaire IV, incluant : Mathématiques appliquées, 10e année / Sec IV et Tout cours de sciences, 10e année / Sec IV (Acceptable). Aucune expérience minimale requise.",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études postsecondaires en génie, en technologie du génie ou en sciences appliquées",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV, incluant :",
                  "o Mathématiques appliquées, 10e année / Sec IV",
                  "o Tout cours de sciences, 10e année / Sec IV",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIESMR 1", "Candidat civil", "RECL", "MÉ"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition ou être présentement enrôlé comme étudiant à temps plein, dans un programme d’études à un établissement postsecondaire sélectionné par les FAC",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ1 (qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC) dans 00404 TESM",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études postsecondaires en génie, en technologie du génie ou en sciences appliquées",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV, incluant :",
                  "o Mathématiques appliquées, 10e année / Sec IV",
                  "o Tout cours de sciences, 10e année / Sec IV",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ1 (qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC) dans 00404 TESM",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
      {
        program: "PFS-MR",
        duration: "8 ans",
      },
    ],
  },
  {
    id: "00405",
    medicalStandard: { v: 4, cv: 2, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "TECHNICIEN EN MÉCANIQUE DES SYSTÈMES DE MARINE",
    abbreviation: "TMSM",
    requirements:
      "FORCE RÉGULIÈRE & FORCE DE RÉSERVE: Diplôme d’études postsecondaires en génie, en technologie du génie ou en sciences appliquées (Idéal) ou 10e année / Secondaire IV, incluant : Mathématiques appliquées, 10e année / Sec IV et Tout cours de sciences, 10e année / Sec IV (Acceptable).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études postsecondaires en génie, en technologie du génie ou en sciences appliquées",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV, incluant :",
                  "o Mathématiques appliquées, 10e année / Sec IV",
                  "o Tout cours de sciences, 10e année / Sec IV",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["PIESMR 1", "Candidat civil", "RECL", "MÉ"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition ou être présentement enrôlé comme étudiant à temps plein, dans un programme d’études à un établissement postsecondaire sélectionné par les FAC",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ1 (qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC) dans 00405 TMSM",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études postsecondaires en génie, en technologie du génie ou en sciences appliquées",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Secondaire IV, incluant :",
                  "o Mathématiques appliquées, 10e année / Sec IV",
                  "o Tout cours de sciences, 10e année / Sec IV",
                ],
                experience: ["Aucune expérience minimale requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ1 (qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC) dans 00405 TMSM",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "4 ans",
      },
      {
        program: "PFS-MR",
        duration: "8 ans",
      },
    ],
  },
  {
    id: "00406",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 3, o: 2, a: 5, u: 5 },
    title: "PROFESSIONNEL PARAMÉDICAL",
    abbreviation: "PPMD",
    requirements:
      "FORCE RÉGULIÈRE: Certificat ou diplôme dans un programme de formation en soins paramédicaux agréé ou équivalent, et Inscription en vigueur pour exercer (Idéal) avec plus de 3400h d'expérience ou (Acceptable) sans exigence minimale d'expérience pour diplômés récents (24 derniers mois).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Certificat ou diplôme dans un programme de formation en soins paramédicaux agréé ou équivalent",
                  "Inscription, permis, privilèges hospitaliers de base ou certification en vigueur pour exercer à titre de paramédical(e), délivrés par un organisme de réglementation provincial ou territorial canadien",
                ],
                experience: [
                  "Plus de 3 400 heures d’expérience professionnelle dans le domaine des soins paramédicaux primaires, avancés ou critiques",
                ],
              },
              {
                level: "Acceptable",
                education: [
                  "Certificat ou diplôme dans un programme de formation en soins paramédicaux agréé ou équivalent",
                  "Inscription actuelle ou en cours, permis, privilèges hospitaliers de base ou certification",
                ],
                experience: [
                  "Diplômé(e) d’un programme agréé : Depuis plus de 24 mois, avec 1 700 heures dans un rôle de paramédical(e) en soins primaires; ou Au cours des 24 derniers mois, sans exigence minimale d’expérience",
                ],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1 (qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Certificat ou diplôme dans un programme de formation en soins paramédicaux agréé ou équivalent",
                  "Inscription actuelle ou en cours, permis, privilèges hospitaliers de base ou certification",
                ],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC) dans 00406 PPMD ou 00334 TECH MED",
                ],
              },
            ],
          },
          {
            candidates: ["PIESMR 1", "Candidat civil", "RECL", "MÉ"],
            requirements: [
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition ou être présentement inscrit comme étudiant à temps plein dans un programme d’études approuvé d’un établissement d’enseignement postsecondaire choisi par les FAC",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1", "SMÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Certificat ou diplôme dans un programme de formation en soins paramédicaux agréé ou équivalent",
                  "Inscription, permis, privilèges hospitaliers de base ou certification en vigueur pour exercer",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "Être accepté sans condition ou être présentement enrôlé comme étudiant à temps plein, dans un programme d’études à un établissement postsecondaire sélectionné",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC) pour le programme concerné.",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "6 ans",
      },
      {
        program: "PFS-MR",
        duration: "9 ans",
      },
    ],
  },
  {
    id: "00407",
    medicalStandard: { v: 4, cv: 3, h: 3, g: 2, o: 2, a: 5, u: 5 },
    title: "PERSONNEL MÉDICAL AU COMBAT",
    abbreviation: "PMDC",
    requirements:
      "FORCE RÉGULIÈRE & FORCE DE RÉSERVE: Diplôme d’études secondaires ou l’équivalent, incluant : Un cours de biologie ou chimie de 11e année / Sec V, et mathématiques appliquées de 10e année / Sec IV (Idéal) ou 10e année / Sec IV incluant un cours de sciences et mathématiques appliquées (Acceptable).",
    details: [
      {
        force: "FORCE RÉGULIÈRE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires/équivalent avec cours de biologie/chimie de Sec V (11e) et mathématiques appliquées de Sec IV (10e)",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Sec IV incluant un cours de sciences et mathématiques appliquées de niveau Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1 (qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC) dans l’un des GPM suivants: 00150 A MED, 00334 TECH MÉD, 00406 PPMD, 00407 PMDC",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
      {
        force: "FORCE DE RÉSERVE",
        candidateGroups: [
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1"],
            requirements: [
              {
                level: "Idéal",
                education: [
                  "Diplôme d’études secondaires/équivalent avec cours de biologie/chimie de Sec V (11e) et mathématiques appliquées de Sec IV (10e)",
                ],
                experience: ["Aucune expérience requise"],
              },
              {
                level: "Acceptable",
                education: [
                  "10e année / Sec IV incluant un cours de sciences et mathématiques appliquées de niveau Sec IV",
                ],
                experience: ["Aucune expérience requise"],
              },
            ],
          },
          {
            candidates: ["Candidat civil 1", "RECL 1", "MÉ 1 (qualifié)"],
            requirements: [
              {
                level: "Acceptable",
                education: ["10e année / Secondaire IV"],
                experience: [
                  "Atteinte du Niveau professionnel de compétence (NPC) dans l'un des GPM requis.",
                ],
              },
            ],
          },
        ],
        notes: [
          "1. Le cas échéant, les candidats doivent atteindre la norme minimale applicable du Test d’aptitude des Forces canadiennes (TAFC).",
        ],
      },
    ],
    contracts: [
      {
        program: "Enrôlement direct",
        duration: "3 ans",
      },
    ],
  },
];
