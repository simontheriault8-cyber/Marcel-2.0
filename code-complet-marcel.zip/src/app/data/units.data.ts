export interface UnitSession {
  id: string;
  uic: string;
  abbrevCFR: string;
  officialName: string;
  addressHtml: string;
  addressPlain: string;
}

export const UNITS_LIST: UnitSession[] = [
  {
    "id": "1126",
    "uic": "1126",
    "abbrevCFR": "U Sherbroo",
    "officialName": "UNIVERSITE DE SHERBROOKE",
    "addressHtml": "2500 BD DE L'UNIVERSITÉ SHERBROOKE<br>QC J1N 3C6<br>CAN",
    "addressPlain": "2500 BD DE L'UNIVERSITÉ SHERBROOKE\\nQC J1N 3C6\\nCAN"
  },
  {
    "id": "1550",
    "uic": "1550",
    "abbrevCFR": "RPCNU REP",
    "officialName": "PERMANENTE DE CANADA A L'ONU",
    "addressHtml": "1 DAG HAMMARSKJOLD PLAZA 885 SECOND AVE 14TH FLOOR NEW YORK<br>NY 10017<br>USA",
    "addressPlain": "1 DAG HAMMARSKJOLD PLAZA 885 SECOND AVE 14TH FLOOR NEW YORK\\nNY 10017\\nUSA"
  },
  {
    "id": "5039",
    "uic": "5039",
    "abbrevCFR": "49 RAC",
    "officialName": "49E (SAULT STE. MARIE) RÉGIMENT D'ARTILLERIE DE CAMPAGNE, ARC",
    "addressHtml": "1 GARRISON WAY SAULT STE MARIE<br>ON P6B 3E6<br>CAN",
    "addressPlain": "1 GARRISON WAY SAULT STE MARIE\\nON P6B 3E6\\nCAN"
  },
  {
    "id": "3207",
    "uic": "3207",
    "abbrevCFR": "CFILO(L) BUREAU",
    "officialName": "- LIAISON RENSEIGNEMENT DES FORCES CANADIENNES (LONDRES)",
    "addressHtml": "1 GROSVENOR SQUARE LONDON<br>GBR",
    "addressPlain": "1 GROSVENOR SQUARE LONDON\\nGBR"
  },
  {
    "id": "2989",
    "uic": "2989",
    "abbrevCFR": "CEC CONNAU",
    "officialName": "CENTRE D'ENTRAINEMENT DES CADETS DE CONNAUGHT",
    "addressHtml": "1 LEWIS GUN ROAD NEPEAN<br>ON K2K 2W6<br>CAN",
    "addressPlain": "1 LEWIS GUN ROAD NEPEAN\\nON K2K 2W6\\nCAN"
  },
  {
    "id": "1331",
    "uic": "1331",
    "abbrevCFR": "NCSM CHIPPAWA",
    "officialName": "NAVIRE CANADIAN DE SA MAJESTÉ CHIPPAWA",
    "addressHtml": "1 NAVY WAY WINNIPEG<br>MB R3C 4J7<br>CAN",
    "addressPlain": "1 NAVY WAY WINNIPEG\\nMB R3C 4J7\\nCAN"
  },
  {
    "id": "5094",
    "uic": "5094",
    "abbrevCFR": "RHFC THE",
    "officialName": "ROYAL HIGHLAND FUSILIERS OF CANADA",
    "addressHtml": "1 VALOUR PLACE CAMBRIDGE<br>ON N1R 3P1<br>CAN",
    "addressPlain": "1 VALOUR PLACE CAMBRIDGE\\nON N1R 3P1\\nCAN"
  },
  {
    "id": "4038",
    "uic": "4038",
    "abbrevCFR": "CI 4DC DE",
    "officialName": "DÉTACHEMENT TORONTO, CENTRE D'INSTRUCTION DE LA 4E DIVISION DU CANADA",
    "addressHtml": "1 YUKON LANE PO BOX 5000 TORONTO NORTH YORK<br>ON M3M 3J5<br>CAN",
    "addressPlain": "1 YUKON LANE PO BOX 5000 TORONTO NORTH YORK\\nON M3M 3J5\\nCAN"
  },
  {
    "id": "5023",
    "uic": "5023",
    "abbrevCFR": "6 RAC",
    "officialName": "6E RÉGIMENT D'ARTILLERIE DE CAMPAGNE, ARC",
    "addressHtml": "10 RUE DE L'ARSENAL LEVIS<br>QC G6V 4P7<br>CAN",
    "addressPlain": "10 RUE DE L'ARSENAL LEVIS\\nQC G6V 4P7\\nCAN"
  },
  {
    "id": "5100",
    "uic": "5100",
    "abbrevCFR": "R de Chaud",
    "officialName": "LE RÉGIMENT DE LA CHAUDIÈRE",
    "addressHtml": "10 RUE DE L'ARSENAL LEVIS<br>QC G6V 4P7<br>CAN",
    "addressPlain": "10 RUE DE L'ARSENAL LEVIS\\nQC G6V 4P7\\nCAN"
  },
  {
    "id": "5090",
    "uic": "5090",
    "abbrevCFR": "PWOR THE",
    "officialName": "PRINCESS OF WALES' OWN REGIMENT",
    "addressHtml": "100 MONTREAL ST KINGSTON<br>ON K7K 3E8<br>CAN",
    "addressPlain": "100 MONTREAL ST KINGSTON\\nON K7K 3E8\\nCAN"
  },
  {
    "id": "1537",
    "uic": "1537",
    "abbrevCFR": "NCSM Radisson",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ RADISSON",
    "addressHtml": "1000 lLE ST-CHRISTOPHE TROIS-RIVIERES<br>QC G9A 5C9<br>CAN",
    "addressPlain": "1000 lLE ST-CHRISTOPHE TROIS-RIVIERES\\nQC G9A 5C9\\nCAN"
  },
  {
    "id": "0316",
    "uic": "0316",
    "abbrevCFR": "RAQDN Qc",
    "officialName": "WORKCENTRE DE L'ASSURANCE DE QUALITÉ (VILLE DE QUÉBEC)",
    "addressHtml": "1000 SUCC FORCESBAT 500 COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "1000 SUCC FORCESBAT 500 COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "0203",
    "uic": "0203",
    "abbrevCFR": "CRFC DET E",
    "officialName": "DÉTACHEMENT EDMONTON, CENTRE DE RECRUTEMENT DES FORCES CANADIENNES CALGARY",
    "addressHtml": "10027 106 ST EDMONTON<br>AB T5J 1G3<br>CAN",
    "addressPlain": "10027 106 ST EDMONTON\\nAB T5J 1G3\\nCAN"
  },
  {
    "id": "3679",
    "uic": "3679",
    "abbrevCFR": "QG 1ER",
    "officialName": "DA DÉTACHEMENT OTTAWA, QUARTIER GÉNÉRAL DE LA 1ER DIVISION AÉRIENNE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6342",
    "uic": "6342",
    "abbrevCFR": "1 UD OTTAW",
    "officialName": "1RE UNITÉ DENTAIRE DÉTACHEMENT OTTAWA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "8358",
    "uic": "8358",
    "abbrevCFR": "QG 3 DSC",
    "officialName": "QUARTIER GÉNÉRAL DE LA 3E DIVISION SPATIALE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "5036",
    "uic": "5036",
    "abbrevCFR": "30 RAC",
    "officialName": "30E RÉGIMENT D'ARTILLERIE DE CAMPAGNE, ARC",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3659",
    "uic": "3659",
    "abbrevCFR": "QG 33 GBC",
    "officialName": "QUARTIER GÉNÉRAL DU 33E GROUPE-BRIGADE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6520",
    "uic": "6520",
    "abbrevCFR": "414 Esc SG",
    "officialName": "414E ESCADRON DE SOUTIEN DE LA GUERRE ÉLÈCTRONIQUE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "4035",
    "uic": "4035",
    "abbrevCFR": "CI 4DC DE",
    "officialName": "DÉTACHEMENT OTTAWA, CENTRE D'INSTRUCTION DE LA 4E DIVISION DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3175",
    "uic": "3175",
    "abbrevCFR": "7 Cie Rens",
    "officialName": "RÉGIMENT DU RENSEIGNEMENT DE L'ARMÉE CANADIENNE DÉTACHEMENT OTTAWA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "8362",
    "uic": "8362",
    "abbrevCFR": "7 ESC SO",
    "officialName": "7E ESCADRON DE SOUTIEN AUX OPÉRATIONS",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "8361",
    "uic": "8361",
    "abbrevCFR": "7 ESC OS",
    "officialName": "7E ESCADRON D'OPÉRATIONS SPATIALES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "8360",
    "uic": "8360",
    "abbrevCFR": "QG 7 ERE E",
    "officialName": "QUARTIER GÉNÉRAL - 7E ESCADRE (ESPACE)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6952",
    "uic": "6952",
    "abbrevCFR": "SMAD(SN) SOUS-MINISTRE",
    "officialName": "ADJOINT DÉLÉGUÉ (SERVICES NUMÉRIQUES) ET DIRIGEANT PRINCIPAL - TECHNOLOGIE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2207",
    "uic": "2207",
    "abbrevCFR": "SMA(RDDC) SOUS-MINISTRE",
    "officialName": "ADJOINT (RECHERCHE ET DÉVELOPPEMENT POUR LA DÉFENSE CANADA)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3330",
    "uic": "3330",
    "abbrevCFR": "SMA(SN) SOUS-MINISTRE",
    "officialName": "ADJOINT (SERVICES NUMÉRIQUES) ET DIRIGEANT PRINCIPAL - NUMÉRIQUE DE LA DÉFENSE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3336",
    "uic": "3336",
    "abbrevCFR": "SMA(SN) RP",
    "officialName": "SOUS-MINISTRE ADJOINT (SERVICES NUMÉRIQUES) LISTE RESSOURCES EN PERSONNEL POUR LA GESTION DE PROJET",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0152",
    "uic": "0152",
    "abbrevCFR": "SMA(FIN)/D SOUS-MINISTRE",
    "officialName": "ADJOINT (FINANCES)/DIRIGEANT PRINCIPAL DES FINANCES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "1541",
    "uic": "1541",
    "abbrevCFR": "SMA(RH-CIV) SOUS-MINISTRE",
    "officialName": "ADJOINT (RESSOURCES HUMAINES - CIVILS)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2189",
    "uic": "2189",
    "abbrevCFR": "SMA(IE) SOUS-MINISTRE",
    "officialName": "ADJOINT (INFRASTRUCTURE ET ENVIRONNEMENT)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0148",
    "uic": "0148",
    "abbrevCFR": "SMA(POL) SOUS-MINISTRE",
    "officialName": "ADJOINT (POLITIQUES)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0976",
    "uic": "0976",
    "abbrevCFR": "SVCS EX",
    "officialName": "SOUS-MINISTRE ADJOINT (SERVICES D'EXAMEN)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2671",
    "uic": "2671",
    "abbrevCFR": "CETA CENTRE",
    "officialName": "D'ESSAIS TECHNIQUE (AEROSPATIAL)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3988",
    "uic": "3988",
    "abbrevCFR": "SM DÉL",
    "officialName": "SOUS-MINISTRE DÉLÉGUÉ DE LA DÉFENSE NATIONALE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2282",
    "uic": "2282",
    "abbrevCFR": "ACPM CHEF",
    "officialName": "ADJOINT DU PERSONNEL MILITAIRE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6947",
    "uic": "6947",
    "abbrevCFR": "CEMC CHEF",
    "officialName": "D'ÉTAT-MAJOR DU CYBERESPACE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2300",
    "uic": "2300",
    "abbrevCFR": "CG Fin",
    "officialName": "CHEF - GESTION FINANCIÈRE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2278",
    "uic": "2278",
    "abbrevCFR": "C RÉS",
    "officialName": "CHEF - RÉSERVES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "1184",
    "uic": "1184",
    "abbrevCFR": "LRP AC",
    "officialName": "LISTE RÉSERVE PRIMAIRE - L'ARMÉE CANADIENNE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6343",
    "uic": "6343",
    "abbrevCFR": "Dét Ottawa",
    "officialName": "DÉTACHEMENT OTTAWA QUARTIER GÉNÉRAL DU CENTRE DE DOCTRINE ET D'INSTRUCTION DE L'ARMÉE CANADIENNE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6976",
    "uic": "6976",
    "abbrevCFR": "UT FAC RCN",
    "officialName": "UNITÉ DE TRANSITION DES FORCES ARMÉES CANADIENNES (RÉGION DE LA CAPITALE NATIONALE)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6461",
    "uic": "6461",
    "abbrevCFR": "LRP COMFOS",
    "officialName": "LISTE RÉSERVE PRIMAIRE - COMMANDEMENT - FORCES D'OPÉRATIONS SPÉCIALES DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0095",
    "uic": "0095",
    "abbrevCFR": "BADC AUSTR",
    "officialName": "DÉTACHEMENT AUSTRALIE, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3971",
    "uic": "3971",
    "abbrevCFR": "BADC BRÉSI",
    "officialName": "DÉTACHEMENT BRÉSIL, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0143",
    "uic": "0143",
    "abbrevCFR": "BADC CHINE",
    "officialName": "DÉTACHEMENT CHINE, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3970",
    "uic": "3970",
    "abbrevCFR": "BADC COLOM",
    "officialName": "DÉTACHEMENT COLOMBIE, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6566",
    "uic": "6566",
    "abbrevCFR": "BADC CUBA",
    "officialName": "BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA (CUBA)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0076",
    "uic": "0076",
    "abbrevCFR": "BADC ÉGYPT",
    "officialName": "DÉTACHEMENT RÉPUBLIQUE ARABE D'ÉGYPTE, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0070",
    "uic": "0070",
    "abbrevCFR": "BADC FRANC",
    "officialName": "DÉTACHEMENT FRANCE, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0071",
    "uic": "0071",
    "abbrevCFR": "BADC ALLEM",
    "officialName": "DÉTACHEMENT ALLEMAGNE, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "4784",
    "uic": "4784",
    "abbrevCFR": "BADC INDE",
    "officialName": "DÉTACHEMENT INDE, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0066",
    "uic": "0066",
    "abbrevCFR": "BADC ISRAE",
    "officialName": "DÉTACHEMENT ISRAEL, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0067",
    "uic": "0067",
    "abbrevCFR": "BADC ITALI",
    "officialName": "DÉTACHEMENT ITALIE, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0069",
    "uic": "0069",
    "abbrevCFR": "BADC JAPON",
    "officialName": "DÉTACHEMENT JAPON, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3969",
    "uic": "3969",
    "abbrevCFR": "BADC KENYA",
    "officialName": "DÉTACHEMENT RÉPUBLIQUE DU KENYA, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0225",
    "uic": "0225",
    "abbrevCFR": "BADC CORÉE",
    "officialName": "DÉTACHEMENT RÉPUBLIQUE DE CORÉE, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2447",
    "uic": "2447",
    "abbrevCFR": "BADC MEXIQ",
    "officialName": "DÉTACHEMENT MEXIQUE, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0072",
    "uic": "0072",
    "abbrevCFR": "BADC PAYS-",
    "officialName": "DÉTACHEMENT PAYS-BAS, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "4783",
    "uic": "4783",
    "abbrevCFR": "BADC PAKIS",
    "officialName": "DÉTACHEMENT PAKISTAN, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0061",
    "uic": "0061",
    "abbrevCFR": "BADC POLOG",
    "officialName": "DÉTACHEMENT POLOGNE, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0064",
    "uic": "0064",
    "abbrevCFR": "BADC RUSSI",
    "officialName": "DÉTACHEMENT RUSSIE, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3617",
    "uic": "3617",
    "abbrevCFR": "BADC AS",
    "officialName": "DÉTACHEMENT AFRIQUE DU SUD, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0077",
    "uic": "0077",
    "abbrevCFR": "BADC SERBI",
    "officialName": "DÉTACHEMENT SERBIA, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "4939",
    "uic": "4939",
    "abbrevCFR": "BADC THAÏL",
    "officialName": "DÉTACHEMENT THAÏLANDE, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0075",
    "uic": "0075",
    "abbrevCFR": "BADC TURQU",
    "officialName": "DÉTACHEMENT TURQUIE, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6354",
    "uic": "6354",
    "abbrevCFR": "BADC (EAU)",
    "officialName": "DÉTACHEMENT ÉMIRATS ARABES UNIS, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3677",
    "uic": "3677",
    "abbrevCFR": "BADC UKRAI",
    "officialName": "DÉTACHEMENT UKRAINE, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6629",
    "uic": "6629",
    "abbrevCFR": "BADC, CHIL",
    "officialName": "BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA (CHILE)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "1699",
    "uic": "1699",
    "abbrevCFR": "BADC, INDO",
    "officialName": "DÉTACHEMENT INDONÉSIE, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6731",
    "uic": "6731",
    "abbrevCFR": "BADC, JORD",
    "officialName": "BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA (JORDANIE)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6633",
    "uic": "6633",
    "abbrevCFR": "BADCSENEG BUREAU",
    "officialName": "DE L'ATTACHÉ DE DÉFENSE DU CANADA (SENEGAL)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2268",
    "uic": "2268",
    "abbrevCFR": "CRD CHEF",
    "officialName": "DE RENSEIGNEMENT DE LA DÉFENSE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "1376",
    "uic": "1376",
    "abbrevCFR": "MUS CTR",
    "officialName": "LA MUSIQUE CENTRALE DES FORCES ARMÉES CANADIENNES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2858",
    "uic": "2858",
    "abbrevCFR": "CEREMON GD GUARDE CÉRÉMONIAL",
    "officialName": "(DÉTACHEMENT GGFG)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6433",
    "uic": "6433",
    "abbrevCFR": "DétO CGAFC",
    "officialName": "DÉTACHEMENT OTTAWA, CENTRE DE GUERRE AÉROSPATIALE DES FORCES CANADIENNES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "1018",
    "uic": "1018",
    "abbrevCFR": "CGEFC CENTRE",
    "officialName": "DE GUERRE ÉLECTRONIQUE DES FORCES CANADIENNES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3700",
    "uic": "3700",
    "abbrevCFR": "ALFC AGENCE",
    "officialName": "DE LOGEMENT DES FORCES CANADIENNES (BUREAU PRINCIPAL)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3719",
    "uic": "3719",
    "abbrevCFR": "ALFC OTTAW",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (OTTAWA)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6821",
    "uic": "6821",
    "abbrevCFR": "QG Gp Rens",
    "officialName": "QUARTIER GÉNÉRAL DU GROUPE DU RENSEIGNEMENT DES FORCES CANADIENNES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6820",
    "uic": "6820",
    "abbrevCFR": "QG COMRENS",
    "officialName": "QUARTIER GÉNÉRAL DU COMMANDEMENT DU RENSEIGNEMENT DES FORCES CANADIENNES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2690",
    "uic": "2690",
    "abbrevCFR": "ELFC ÉCOLE",
    "officialName": "DES LANGUES DES FORCES CANADIENNES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6681",
    "uic": "6681",
    "abbrevCFR": "QGGPPMFC QUARTIER",
    "officialName": "GÉNÉRAL DU GROUPE DE LA POLICE MILITAIRE DES FORCES CANADIENNES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3635",
    "uic": "3635",
    "abbrevCFR": "Dét Ottawa",
    "officialName": "DÉTACHEMENT OTTAWA, CENTRE DE GUERRE NAVALE DES FORCES CANADIENNES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6481",
    "uic": "6481",
    "abbrevCFR": "USPFC UNITÉ",
    "officialName": "DES SERVICES DE PROTECTION DES FORCES CANADIENNES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6840",
    "uic": "6840",
    "abbrevCFR": "QGGpOpsImm QUARTIER",
    "officialName": "GÉNÉRAL DU GROUPE DES OPÉRATIONS IMMOBILIÈRES DES FORCES CANADIENNES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "5111",
    "uic": "5111",
    "abbrevCFR": "CH OF O",
    "officialName": "THE CAMERON HIGHLANDERS OF OTTAWA (DUKE OF EDINBURGH'S OWN)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2290",
    "uic": "2290",
    "abbrevCFR": "AMN GEN",
    "officialName": "AUMÔNIER GÉNÉRAL",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "8371",
    "uic": "8371",
    "abbrevCFR": "COIC - BUR",
    "officialName": "COMMANDEMENT DES OPÉRATIONS INTERARMÉES DU CANADA - BUREAU DE LA SOLDE DU SERVICE DE CLASSE C",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6775",
    "uic": "6775",
    "abbrevCFR": "QG COIC",
    "officialName": "QUARTIER GÉNÉRAL DU COMMANDEMENT DES OPÉRATIONS INTERARMÉES DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "4891",
    "uic": "4891",
    "abbrevCFR": "CGIC CENTRE",
    "officialName": "DE GUERRE INTERARMÉES DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0149",
    "uic": "0149",
    "abbrevCFR": "CPM CHEF",
    "officialName": "DU PERSONNEL MILITAIRE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6447",
    "uic": "6447",
    "abbrevCFR": "QG GSMC",
    "officialName": "QUARTIER GÉNÉRAL DU GROUPE DE SOUTIEN EN MATÉRIEL DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6766",
    "uic": "6766",
    "abbrevCFR": "SEC GÉN",
    "officialName": "SECRÉTAIRE GÉNÉRAL",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "7688",
    "uic": "7688",
    "abbrevCFR": "CEM(POL) CHEF",
    "officialName": "D'ÉTAT-MAJOR (POLITIQUES)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "8339",
    "uic": "8339",
    "abbrevCFR": "CEM(CCPC)",
    "officialName": "CHEF D'ÉTAT-MAJOR",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2177",
    "uic": "2177",
    "abbrevCFR": "CEM(MAT) CHEF",
    "officialName": "D'ÉTAT-MAJOR (MATÉRIELS)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6505",
    "uic": "6505",
    "abbrevCFR": "CEM (RDDC)",
    "officialName": "CHEF D'ÉTAT MAJOR (RECHERCHE ET DÉVELOPPEMENT POUR LA DÉFENSE CANADA)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "7809",
    "uic": "7809",
    "abbrevCFR": "CCPC CHEF",
    "officialName": "- CONDUITE PROFESSIONNELLE EDT CULTURE (HEAD QUARTERS)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2213",
    "uic": "2213",
    "abbrevCFR": "CST CENTRE",
    "officialName": "DE SÉCURITÉ DES TÉLÉCOMMUNICATIONS",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6817",
    "uic": "6817",
    "abbrevCFR": "Dét (LFIC)",
    "officialName": "RÉGIMENT DU RENSEIGNEMENT DE L'ARMÉE CANADIENNE DÉTACHEMENT OTTAWA (LFIC)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3180",
    "uic": "3180",
    "abbrevCFR": "DLE DIRECTEUR",
    "officialName": "- LIAISON AVEC L'ÉTRANGER",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "7689",
    "uic": "7689",
    "abbrevCFR": "DG POL DEF",
    "officialName": "DIRECTEUR GÉNÉRAL - POLITIQUE DE DÉFENSE CONTINENTALE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "7746",
    "uic": "7746",
    "abbrevCFR": "DG - DEF A",
    "officialName": "DIRECTEUR GÉNÉRAL - AFFAIRES INTERGOUVERNEMENTALES DE DÉFENSE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "8341",
    "uic": "8341",
    "abbrevCFR": "DG EPR",
    "officialName": "DIRECTEUR GÉNÉRAL - ENGAGEMENT, POLITIQUE ET RECHERCHE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2309",
    "uic": "2309",
    "abbrevCFR": "DG Pol SI",
    "officialName": "DIRECTEUR GÉNÉRAL - POLITIQUE DE SÉCURITÉ INTERNATIONALE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2186",
    "uic": "2186",
    "abbrevCFR": "DG ExP",
    "officialName": "DIRECTEUR GÉNÉRAL - EXIGENCES DU PORTEFEUILLE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "8343",
    "uic": "8343",
    "abbrevCFR": "DG CDP",
    "officialName": "DIRECTEUR GÉNÉRAL - CONDUITE ET DÉVELOPPEMENT PROFESSIONNELS",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2308",
    "uic": "2308",
    "abbrevCFR": "DG COORD P",
    "officialName": "DIRECTEUR GÉNÉRAL - COORDINATION DES POLITIQUES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2310",
    "uic": "2310",
    "abbrevCFR": "DG POL DS",
    "officialName": "DIRECTEUR GÉNÉRAL - POLITIQUE DE DÉFENSE STRATÉGIQUE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2188",
    "uic": "2188",
    "abbrevCFR": "DGAA DIRECTEUR",
    "officialName": "GÉNÉRAL - AFFAIRES AUTOCHTONES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2182",
    "uic": "2182",
    "abbrevCFR": "DGGPEA DIRECTEUR",
    "officialName": "GÉNÉRAL - GEATION DU PROGRAMME D'ÉQUIPEMENT AÉROSPATIAL",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "8340",
    "uic": "8340",
    "abbrevCFR": "DGCC DIRECTEUR",
    "officialName": "GÉNÉRAL - CULTURE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2286",
    "uic": "2286",
    "abbrevCFR": "DGRAS DIRECTEUR",
    "officialName": "GÉNÉRAL - RÉMUNÉRATION ET AVANTAGES SOCIAUX",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "7695",
    "uic": "7695",
    "abbrevCFR": "DGRASC RÉMUNÉRATION",
    "officialName": "ET AVANTAGES SOCIAUX CIVILS (DGRASC)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "8338",
    "uic": "8338",
    "abbrevCFR": "DGAGFC DIRECTEUR",
    "officialName": "GÉNÉRAL - AUTORITÉ DES GRIEFS DES FORCE CANADIENNES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6767",
    "uic": "6767",
    "abbrevCFR": "DGECPIA DIRECTEUR",
    "officialName": "GÉNÉRAL ¿ ÉTABLISSEMENT DES COÛTS, PLANIFICATION DES INVESTISSEMENTS ET APPROBATION",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6328",
    "uic": "6328",
    "abbrevCFR": "DGGICP DIRECTEUR",
    "officialName": "GÉNÉRAL - GESTION INTÉGRÉE DES CONFLITS ET DES PLAINTES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "8342",
    "uic": "8342",
    "abbrevCFR": "DGSSC DIRECTEUR",
    "officialName": "GÉNÉRAL - SOLUTION ET SERVICES EN MATIÈRE DE CONFLITS",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "7798",
    "uic": "7798",
    "abbrevCFR": "DGDAGI DIRECTEUR",
    "officialName": "GÉNÉRAL DONNÉES, ANALYTIQUE ET GESTION DE L'INFORMATION",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "7799",
    "uic": "7799",
    "abbrevCFR": "DGMSED DIRECTEUR",
    "officialName": "GÉNÉRAL - MODERNISATION ET SOLUTIONS D'ENTREPRISE DE LA DÉFENSE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6835",
    "uic": "6835",
    "abbrevCFR": "DGSD DIRECTEUR",
    "officialName": "GÉNÉRAL - SÉCURITÉ DE LA DÉFENSE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6326",
    "uic": "6326",
    "abbrevCFR": "DGSAE DIRECTEUR",
    "officialName": "GÉNÉRAL - SERVICE DES APPLICATIONS DE L'ENTREPRISE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6953",
    "uic": "6953",
    "abbrevCFR": "DGEGD",
    "officialName": "DIRECTEUR",
    "addressHtml": "GENERAL - ENVIRONNEMENT ET GESTION DURABLE 101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "GENERAL - ENVIRONNEMENT ET GESTION DURABLE 101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6362",
    "uic": "6362",
    "abbrevCFR": "DGOSF DIRECTEUR",
    "officialName": "GÉNÉRAL - OPÉRATIONS ET SERVICES FINANCIERS",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3785",
    "uic": "3785",
    "abbrevCFR": "DGOGRHC DIRECTEUR",
    "officialName": "GÉNÉRAL - OPÉRATIONS DE GESTION DE RESSOURCES HUMAINE CIVILES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "4928",
    "uic": "4928",
    "abbrevCFR": "DGOSRH DIRECTEUR",
    "officialName": "GÉNÉRAL - ORIENTATIONS STRATÉGIQUES EN RESSOURCES HUMAINES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2203",
    "uic": "2203",
    "abbrevCFR": "DGS",
    "officialName": "SAN DIRECTEUR",
    "addressHtml": "GENERAL - SERVICES DE SANTE 101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "GENERAL - SERVICES DE SANTE 101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6948",
    "uic": "6948",
    "abbrevCFR": "DGDFCI DIRECTEUR",
    "officialName": "GÉNÉRAL - DÉVELOPPEMENT DES FORCES (CAPACITÉS D'INFORMATION)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2187",
    "uic": "2187",
    "abbrevCFR": "DGSIIE DIRECTEUR",
    "officialName": "GÉNÉRAL - SERVICES D'INGÉNIERIE (INFRASTRUCTURE ET ENVIRONNEMENT)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2178",
    "uic": "2178",
    "abbrevCFR": "DGIIP DIRECTEUR",
    "officialName": "GÉNÉRAL - PROGRAMMES INTERNATIONAUX ET INDUSTRIELS",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "8395",
    "uic": "8395",
    "abbrevCFR": "DGITI DIRECTEUR",
    "officialName": "GÉNÉRAL - INFRASTRUCTURE DE LA TECHNOLOGIE DE L'INFORMATION",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "8703",
    "uic": "8703",
    "abbrevCFR": "DGGPEI DIRECTEUR",
    "officialName": "GÉNÉRAL - GESTION DU PROGRAMME D'ÉQUIPEMENT INTERARMÉES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2184",
    "uic": "2184",
    "abbrevCFR": "DGGPET DIRECTEUR",
    "officialName": "GÉNÉRAL - GESTION DU PROGRAMME D'ÉQUIPEMENT TERRESTRE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3398",
    "uic": "3398",
    "abbrevCFR": "DGCM DIRECTEUR",
    "officialName": "GÉNÉRAL - RECRUTEMENT ET CARRIÈRES MILITAIRES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2183",
    "uic": "2183",
    "abbrevCFR": "DGMEPM DIRECTEUR",
    "officialName": "GÉNÉRAL - GESTION DU PROGRAMME D'ÉQUIPEMENT MARITIME",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2294",
    "uic": "2294",
    "abbrevCFR": "DGPM Strat",
    "officialName": "DIRECTEUR GÉNÉRAL - PERSONNEL MILITAIRE STRATÉGIQUE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6451",
    "uic": "6451",
    "abbrevCFR": "DGRGP A&AT",
    "officialName": "DIRECTEUR GÉNÉRAL - RÉALISATION DE GRANDS PROJETS (AIR ET ARMÉE DE TERRE)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6508",
    "uic": "6508",
    "abbrevCFR": "DGRGP MARI",
    "officialName": "DIRECTEUR GÉNÉRAL - RÉALISATION DE GRANDS PROJETS (MARINE)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "8387",
    "uic": "8387",
    "abbrevCFR": "N",
    "officialName": "ASSIGNE Director",
    "addressHtml": "General Military Personnel Generation 101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "General Military Personnel Generation 101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6483",
    "uic": "6483",
    "abbrevCFR": "DGRAPM DIRECTEUR",
    "officialName": "GÉNÉRAL - RECHERCHE ET ANALYSE (PERSONNEL MILITAIRE)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6917",
    "uic": "6917",
    "abbrevCFR": "DGSSPM DIRECTEUR",
    "officialName": "GÉNÉRAL - SERVICES DE SOUTIEN AU PERSONNEL MILITAIRE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6381",
    "uic": "6381",
    "abbrevCFR": "DGSMCA DIRECTEUR",
    "officialName": "GÉNÉRAL - SYSTÈMES DE MATÉRIEL ET CHAÎNE D'APPROVISIONNEMENT",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6962",
    "uic": "6962",
    "abbrevCFR": "DGTM DIRECTEUR",
    "officialName": "GÉNÉRAL - TRANSITION MILITAIRE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6456",
    "uic": "6456",
    "abbrevCFR": "DGSBM Directeur",
    "officialName": "général - Services bien-être et moral",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6369",
    "uic": "6369",
    "abbrevCFR": "DGSvcsAcq DIRECTEUR",
    "officialName": "GÉNÉRAL - SERVICES D'ACQUISITION",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "7758",
    "uic": "7758",
    "abbrevCFR": "DGIRD DIRECTEUR",
    "officialName": "GÉNÉRAL - INNOVATION (R ET D)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "7772",
    "uic": "7772",
    "abbrevCFR": "DGPRD DIRECTEUR",
    "officialName": "GÉNÉRAL - PROGRAMME (R ET D)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "7759",
    "uic": "7759",
    "abbrevCFR": "DGPCRD DIRECTEUR",
    "officialName": "GÉNÉRAL - POLITIQUES ET CONSEILS (R ET D)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "7749",
    "uic": "7749",
    "abbrevCFR": "DGSIRD DIRECTEUR",
    "officialName": "GÉNÉRAL - SCIENCE ET INGÉNIERIE (R ET D)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "7757",
    "uic": "7757",
    "abbrevCFR": "DGPSRD DIRECTEUR",
    "officialName": "GÉNÉRAL - PARTENARIATS STRATÉGIQUES (R ET D)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "7802",
    "uic": "7802",
    "abbrevCFR": "DGISFR DIRECTEUR",
    "officialName": "GÉNÉRAL - INITIATIVES STRATÉGIQUES (FORCE DE RÉSERVE)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6928",
    "uic": "6928",
    "abbrevCFR": "DGGFS DIRECTEUR",
    "officialName": "GÉNÉRAL - GOUVERNANCE FINANCIÈRE STRATÉGIQUE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6954",
    "uic": "6954",
    "abbrevCFR": "DGISP",
    "officialName": "DIRECTEUR",
    "addressHtml": "GENERAL - INITIATIVES STRATEGIQUES DU PORTEFEUILLE 101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "GENERAL - INITIATIVES STRATEGIQUES DU PORTEFEUILLE 101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3334",
    "uic": "3334",
    "abbrevCFR": "DGTIU DIRECTEUR",
    "officialName": "GÉNÉRAL - TECHNOLOGIE DE L'INFORMATION DES UTILISATEURS",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2297",
    "uic": "2297",
    "abbrevCFR": "DGDMO DIRECTEUR",
    "officialName": "GÉNÉRAL - DÉVELOPPEMENT DE LA MAIN-D'OEUVRE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2295",
    "uic": "2295",
    "abbrevCFR": "DGGMT DIRECTEUR",
    "officialName": "GÉNÉRAL - GESTION DU MILIEU DE TRAVAIL",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6579",
    "uic": "6579",
    "abbrevCFR": "DSUFGI DIRECTEUR",
    "officialName": "- SERVICES À L'UTILISATEUR FINAL (GESTION DE L'INFORMATION)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3626",
    "uic": "3626",
    "abbrevCFR": "RDDC ATLAN",
    "officialName": "RECHERCHE ET DÉVELOPPEMENT POUR LA DÉFENSE CANADA (ATLANTIQUE) DÉTACHEMENT OTTAWA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3150",
    "uic": "3150",
    "abbrevCFR": "RDDC CARO",
    "officialName": "RECHERCHE ET DÉVELOPPEMENT POUR LA DÉFENSE CANADA-CENTRE D'ANALYSE ET DE RECHERCHE OPÉRATIONNELLE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6465",
    "uic": "6465",
    "abbrevCFR": "RDDC CSS",
    "officialName": "RECHERCHE ET DÉVELOPPEMENT POUR LA DÉFENSE CANADA-CENTRE DES SCIENCES POUR LA SÉCURITÉ",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6519",
    "uic": "6519",
    "abbrevCFR": "USM RDDC",
    "officialName": "UNITÉ DE SOUTIEN MILITAIRE - RECHERCHE ET DEVELOPPEMENT POUR LA DÉFENSE CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "7742",
    "uic": "7742",
    "abbrevCFR": "DE SMRL",
    "officialName": "DIRECTEUR EXÉCUTIF - SUPERVISION MINISTÉRIELLE DE LA RÉGLEMENTATION ET DES LITIGES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "5083",
    "uic": "5083",
    "abbrevCFR": "GGFG GOVERNOR",
    "officialName": "GENERAL'S FOOT GUARDS",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3584",
    "uic": "3584",
    "abbrevCFR": "Svc S OTTA",
    "officialName": "CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES OTTAWA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "1325",
    "uic": "1325",
    "abbrevCFR": "NCSM CARLE",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ CARLETON",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3993",
    "uic": "3993",
    "abbrevCFR": "LRP JAG",
    "officialName": "LISTE RÉSERVE PRIMAINE - JUGE-AVOCAT GÉNÉRAL",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "8375",
    "uic": "8375",
    "abbrevCFR": "CORI CENRE",
    "officialName": "DES OPÉRATIONS DU RENSEIGNEMENT INTERARMÉES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6596",
    "uic": "6596",
    "abbrevCFR": "UISP QUARTIER",
    "officialName": "GÉNÉRAL DU GROUPE DE TRANSITION DES FORCES ARMÉES CANADIENNES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3048",
    "uic": "3048",
    "abbrevCFR": "FOI 2 DEUXIÈME",
    "officialName": "FORCE OPÉRATIONNELLE INTERARMÉES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3656",
    "uic": "3656",
    "abbrevCFR": "MAT RPGP",
    "officialName": "SOUS-MIINISTRE ADJOINT (MATÉRIELS) LISTE DES RESSOURCES DE PERSONNEL DES GESTION PROJET",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6569",
    "uic": "6569",
    "abbrevCFR": "MAT EU",
    "officialName": "SOUS-MINISTRE ADJOINT (MATÉRIELS) HORS CANADA - ÉTATS-UNIS",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "1786",
    "uic": "1786",
    "abbrevCFR": "S Carto",
    "officialName": "SERVICE DE CARTOGRAPHIE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6359",
    "uic": "6359",
    "abbrevCFR": "CPR COMPER",
    "officialName": "CADRE DE LA PREMIÈRE RÉSERVE DU COMMANDEMENT DU PERSONNEL MILITAIRE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3886",
    "uic": "3886",
    "abbrevCFR": "CPPM COMMISSION",
    "officialName": "D'EXAMEN DES PLAINTES (POLICE MILITAIRES)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6675",
    "uic": "6675",
    "abbrevCFR": "UPM OTTAWA",
    "officialName": "UNITÉ DE LA POLICE MILITAIRE OTTAWA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "4287",
    "uic": "4287",
    "abbrevCFR": "QG CRJC NA",
    "officialName": "QUARTIER GÉNÉRAL DU GROUPE DE SOUTIEN NATIONAL AUX CADETS ET AUX RANGERS JUNIORS CANADIENS",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "1175",
    "uic": "1175",
    "abbrevCFR": "CPR QGDN",
    "officialName": "CADRE DE LA PREMIÈRE RÉSERVE DU QUARTIER GÉNÉRAL DE LA DÉFENSE NATIONALE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6671",
    "uic": "6671",
    "abbrevCFR": "QGGPPMN QUARTIER",
    "officialName": "GÉNÉRAL DU GROUPE DE LA POLICE MILITAIRE NAVAL",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3629",
    "uic": "3629",
    "abbrevCFR": "Pol EUROPE",
    "officialName": "SOUS-MINISTRE ADJOINT (POLITIQUES) HORS CANADA - EUROPE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3907",
    "uic": "3907",
    "abbrevCFR": "Pol RM",
    "officialName": "SOUS-MINISTRE ADJOINT (POLITIQUES) HORS CANADA - RESTE DU MONDE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3540",
    "uic": "3540",
    "abbrevCFR": "Pol EU",
    "officialName": "SOUS-MINISTRE ADJOINT (POLITIQUES) HORS CANADA - ÉTATS-UNIS",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6993",
    "uic": "6993",
    "abbrevCFR": "SSP O-G",
    "officialName": "SERVICES DE SOUTIEN AU PERSONNEL (OTTAWA-GATINEAU)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "1400",
    "uic": "1400",
    "abbrevCFR": "SECLIST SECLIST",
    "officialName": "MISCELLANEOUS - OTTAWA AREA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6680",
    "uic": "6680",
    "abbrevCFR": "UPM FOS",
    "officialName": "UNITÉ DE LA POLICE MILITAIRE DES FORCES D'OPÉRATIONS SPÉCIALES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6399",
    "uic": "6399",
    "abbrevCFR": "QG COMFOS",
    "officialName": "QUARTIER GÉNÉRAL DU COMMANDEMENT - FORCES D'OPÉRATIONS SPÉCIALES DU CANADA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "9933",
    "uic": "9933",
    "abbrevCFR": "LEPND LISTE",
    "officialName": "DES EFFECTIFS DU PERSONNEL NON DISPONSIBLES",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0812",
    "uic": "0812",
    "abbrevCFR": "RÉS SUPP",
    "officialName": "RÉSERVE SUPPLÉMENTAIRE",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6687",
    "uic": "6687",
    "abbrevCFR": "CT OTTAWA",
    "officialName": "CENTRE DE TRANSITION OTTAWA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6994",
    "uic": "6994",
    "abbrevCFR": "SST (O-G) DES",
    "officialName": "SERVICES DE SOUTIEN TECHNIQUE (OTTAWA-GATINEAU)",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "1100",
    "uic": "1100",
    "abbrevCFR": "U VICTORIA",
    "officialName": "UNIVERSITY OF VICTORIA",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2485",
    "uic": "2485",
    "abbrevCFR": "CIIFC CENTRE",
    "officialName": "D'IMAGERIE INTERARMÉES DES FORCES CANADIENNES",
    "addressHtml": "101 GOLDEN ROD, TUNNEY'S PASTURE OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 GOLDEN ROD, TUNNEY'S PASTURE OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6670",
    "uic": "6670",
    "abbrevCFR": "QGGPPMARMÉ QUARTIER",
    "officialName": "GÉNÉRAL DU GROUPE DE LA POLICE MILITAIRE DE L'ARMÉE",
    "addressHtml": "101 PROM COLONEL BY OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 PROM COLONEL BY OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3716",
    "uic": "3716",
    "abbrevCFR": "ALFC Mtl",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (MONTRÉAL)",
    "addressHtml": "105 SALABERRY SAINT-HUBERT<br>QC J3Y 3Y6<br>CAN",
    "addressPlain": "105 SALABERRY SAINT-HUBERT\\nQC J3Y 3Y6\\nCAN"
  },
  {
    "id": "2906",
    "uic": "2906",
    "abbrevCFR": "OUEST SOUS-MINISTRE",
    "officialName": "ADJOINT (AFFAIRES PUBLIQUES) DU PACIFIQUE",
    "addressHtml": "1090 PENDER ST W SUITE 201 VANCOUVER<br>BC V6E 2N7<br>CAN",
    "addressPlain": "1090 PENDER ST W SUITE 201 VANCOUVER\\nBC V6E 2N7\\nCAN"
  },
  {
    "id": "5033",
    "uic": "5033",
    "abbrevCFR": "26 RAC",
    "officialName": "26E RÉGIMENT D'ARTILLERIE DE CAMPAGNE, ARC",
    "addressHtml": "1116 VICTORIA AVE BRANDON<br>MB R7A 1B2<br>CAN",
    "addressPlain": "1116 VICTORIA AVE BRANDON\\nMB R7A 1B2\\nCAN"
  },
  {
    "id": "6718",
    "uic": "6718",
    "abbrevCFR": "36 SR Det",
    "officialName": "DÉTACHEMENT CHARLOTTETOWN, 36E RÉGIMENT DES TRANSMISSIONS",
    "addressHtml": "112 BRIGHTON RD CHARLOTTETOWN<br>PE C1A 1V1<br>CAN",
    "addressPlain": "112 BRIGHTON RD CHARLOTTETOWN\\nPE C1A 1V1\\nCAN"
  },
  {
    "id": "6645",
    "uic": "6645",
    "abbrevCFR": "Det Freder",
    "officialName": "DÉTACHEMENT FREDERICTON, CENTRE DE RECRUTEMENT DES FORCES CANADIENNES HALIFAX",
    "addressHtml": "1133 REGENT ST SUITE 109 FREDERICTON<br>NB E3B 3Z2<br>CAN",
    "addressPlain": "1133 REGENT ST SUITE 109 FREDERICTON\\nNB E3B 3Z2\\nCAN"
  },
  {
    "id": "6539",
    "uic": "6539",
    "abbrevCFR": "USM dét TO",
    "officialName": "UNITÉ DE SOUTIEN MILITAIRE - RECHERCHE ET DÉVELOPPEMENT POUR LA DÉFENSE CANADA DÉTACHEMENT TORONTO",
    "addressHtml": "1133 SHEPPARD AVE WEST PO BOX 2000 TORONTO<br>ON M3M 3B9<br>CAN",
    "addressPlain": "1133 SHEPPARD AVE WEST PO BOX 2000 TORONTO\\nON M3M 3B9\\nCAN"
  },
  {
    "id": "2670",
    "uic": "2670",
    "abbrevCFR": "CFEME CENTRE",
    "officialName": "DE MÉDECINE ENVIRONNEMENTAL DES FORCES CANADIENNES",
    "addressHtml": "1133 SHEPPARD AVE. WEST TORONTO<br>ON M3K 2C9<br>CAN",
    "addressPlain": "1133 SHEPPARD AVE. WEST TORONTO\\nON M3K 2C9\\nCAN"
  },
  {
    "id": "1450",
    "uic": "1450",
    "abbrevCFR": "RDDC TORON",
    "officialName": "RECHERCHE ET DÉVELOPPEMENT POUR LA DÉFENSE CANADA (TORONTO)",
    "addressHtml": "1133 SHEPPARD AVE. WEST TORONTO<br>ON M3K 2C9<br>CAN",
    "addressPlain": "1133 SHEPPARD AVE. WEST TORONTO\\nON M3K 2C9\\nCAN"
  },
  {
    "id": "7693",
    "uic": "7693",
    "abbrevCFR": "37OH",
    "officialName": "ECARC",
    "addressHtml": "37 ORVILLE HAND CADETS DE L'AVIATION ROYALE DU CANADA 115 Back St. Bradford<br>ON L3Z 1W8<br>CAN",
    "addressPlain": "37 ORVILLE HAND CADETS DE L'AVIATION ROYALE DU CANADA 115 Back St. Bradford\\nON L3Z 1W8\\nCAN"
  },
  {
    "id": "5160",
    "uic": "5160",
    "abbrevCFR": "35 Amb C",
    "officialName": "35E AMBULANCE DE CAMPAGNE (SYDNEY)",
    "addressHtml": "115 THE BOULEVARD ST JOHN S<br>NL A1A 0P5<br>CAN",
    "addressPlain": "115 THE BOULEVARD ST JOHN S\\nNL A1A 0P5\\nCAN"
  },
  {
    "id": "1338",
    "uic": "1338",
    "abbrevCFR": "NCSM NONSUCH",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ NONSUCH",
    "addressHtml": "11807 KINGSWAY AVE EDMONTON<br>AB T5G 2W5<br>CAN",
    "addressPlain": "11807 KINGSWAY AVE EDMONTON\\nAB T5G 2W5\\nCAN"
  },
  {
    "id": "5013",
    "uic": "5013",
    "abbrevCFR": "SALH THE",
    "officialName": "SOUTH ALBERTA LIGHT HORSE",
    "addressHtml": "120 CUYLER RD MEDICINE HAT<br>AB T1B 3M4<br>CAN",
    "addressPlain": "120 CUYLER RD MEDICINE HAT\\nAB T1B 3M4\\nCAN"
  },
  {
    "id": "1601",
    "uic": "1601",
    "abbrevCFR": "CC 1ST AF",
    "officialName": "CANADIAN CONTINGENT 1ST AIR FORCE / CONUS NORAD REGION HEADQUARTERS",
    "addressHtml": "1210 BEACON BEACH RD, SUITE 200 TYNDALL AFB<br>FL 324035549<br>CAN",
    "addressPlain": "1210 BEACON BEACH RD, SUITE 200 TYNDALL AFB\\nFL 324035549\\nCAN"
  },
  {
    "id": "6644",
    "uic": "6644",
    "abbrevCFR": "Det Winnip",
    "officialName": "DÉTACHEMENT WINNIPEG, CENTRE DE RECRUTEMENT DES FORCES CANADIENNES CALGARY",
    "addressHtml": "125 GARRY ST MAIN FLOOR WINNIPEG<br>MB R3C 4J1<br>CAN",
    "addressPlain": "125 GARRY ST MAIN FLOOR WINNIPEG\\nMB R3C 4J1\\nCAN"
  },
  {
    "id": "4049",
    "uic": "4049",
    "abbrevCFR": "Dét T Bay",
    "officialName": "DÉTACHEMENT THUNDER BAY 23E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES",
    "addressHtml": "125 NORTH ALGOMA ST THUNDER BAY<br>ON P7A 4Z5<br>CAN",
    "addressPlain": "125 NORTH ALGOMA ST THUNDER BAY\\nON P7A 4Z5\\nCAN"
  },
  {
    "id": "1330",
    "uic": "1330",
    "abbrevCFR": "NCSM GRIFFON",
    "officialName": "NAVIRE CANADIAN DE SA MAJESTÉ GRIFFON",
    "addressHtml": "125 NORTH ALGOMA ST THUNDER BAY<br>ON P7A 4Z5<br>CAN",
    "addressPlain": "125 NORTH ALGOMA ST THUNDER BAY\\nON P7A 4Z5\\nCAN"
  },
  {
    "id": "6199",
    "uic": "6199",
    "abbrevCFR": "NS HIGHR",
    "officialName": "THE NOVA SCOTIA HIGHLANDERS",
    "addressHtml": "126 WILLOW ST TRURO<br>NS B2N 4Z6<br>CAN",
    "addressPlain": "126 WILLOW ST TRURO\\nNS B2N 4Z6\\nCAN"
  },
  {
    "id": "5266",
    "uic": "5266",
    "abbrevCFR": "25 Amb C",
    "officialName": "25E AMBULANCE DE CAMPAGNE (TORONTO)",
    "addressHtml": "130 QUEEN ST E TORONTO<br>ON M5A 1R9<br>CAN",
    "addressPlain": "130 QUEEN ST E TORONTO\\nON M5A 1R9\\nCAN"
  },
  {
    "id": "5114",
    "uic": "5114",
    "abbrevCFR": "48 HIGHRS",
    "officialName": "48TH HIGHLANDERS OF CANADA",
    "addressHtml": "130 QUEEN ST E TORONTO<br>ON M5A 1R9<br>CAN",
    "addressPlain": "130 QUEEN ST E TORONTO\\nON M5A 1R9\\nCAN"
  },
  {
    "id": "5024",
    "uic": "5024",
    "abbrevCFR": "7 TOR",
    "officialName": "REGT 7TH TORONTO REGIMENT ARC",
    "addressHtml": "130 QUEEN ST E TORONTO<br>ON M5A 1R9<br>CAN",
    "addressPlain": "130 QUEEN ST E TORONTO\\nON M5A 1R9\\nCAN"
  },
  {
    "id": "5085",
    "uic": "5085",
    "abbrevCFR": "QOR OF C",
    "officialName": "THE QUEEN'S OWN REIFLES OF CANADA",
    "addressHtml": "130 QUEEN ST E TORONTO<br>ON M5A 1R9<br>CAN",
    "addressPlain": "130 QUEEN ST E TORONTO\\nON M5A 1R9\\nCAN"
  },
  {
    "id": "2672",
    "uic": "2672",
    "abbrevCFR": "USFC(CS) UNITÉ",
    "officialName": "DE SOUTIEN DES FORCES CANADIENNES À COLORADO SPRINGS",
    "addressHtml": "135 EAST ENT AVENUE, BUILDING 365 PETERSON AFB<br>CO 809141115<br>USA",
    "addressPlain": "135 EAST ENT AVENUE, BUILDING 365 PETERSON AFB\\nCO 809141115\\nUSA"
  },
  {
    "id": "2350",
    "uic": "2350",
    "abbrevCFR": "NORAD HQ",
    "officialName": "DEPUTY COMMANDER NORTH AMERICAN AEROSPACE DEFENCE COMMAND",
    "addressHtml": "135 EAST ENT AVENUE, BUILDING 365 PETERSON AFB<br>CO 809141115<br>USA",
    "addressPlain": "135 EAST ENT AVENUE, BUILDING 365 PETERSON AFB\\nCO 809141115\\nUSA"
  },
  {
    "id": "6749",
    "uic": "6749",
    "abbrevCFR": "CT MEAFORD",
    "officialName": "CENTRE DE TRANSITION MEAFORD",
    "addressHtml": "139152 VALOUR RD RR#1 MEAFORD<br>ON N4L 0A1<br>CAN",
    "addressPlain": "139152 VALOUR RD RR#1 MEAFORD\\nON N4L 0A1\\nCAN"
  },
  {
    "id": "4993",
    "uic": "4993",
    "abbrevCFR": "Dét Barrie",
    "officialName": "DÉTACHEMENT BARRIE, CENTRE DE RECRUTEMENT DES FORCES CANADIENNES TORONTO",
    "addressHtml": "14 CEDAR POINT DRIVE, UNIT 1509 BARRIE<br>ON L4N 5R7<br>CAN",
    "addressPlain": "14 CEDAR POINT DRIVE, UNIT 1509 BARRIE\\nON L4N 5R7\\nCAN"
  },
  {
    "id": "0026",
    "uic": "0026",
    "abbrevCFR": "CRFC KINGS",
    "officialName": "DÉTACHEMENT KINGSTON, CENTRE DE RECRUTEMENT DES FORCES CANADIENNES OTTAWA",
    "addressHtml": "1412 PRINCESS STREET KINGSTON<br>ON K7M 3E5<br>CAN",
    "addressPlain": "1412 PRINCESS STREET KINGSTON\\nON K7M 3E5\\nCAN"
  },
  {
    "id": "5096",
    "uic": "5096",
    "abbrevCFR": "Brockville Rifles",
    "officialName": "THE BROCKVILLE RIFLES",
    "addressHtml": "144 KING ST E BROCKVILLE<br>ON K6V 1C2<br>CAN",
    "addressPlain": "144 KING ST E BROCKVILLE\\nON K6V 1C2\\nCAN"
  },
  {
    "id": "8456",
    "uic": "8456",
    "abbrevCFR": "UOI(Q) DUN",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (OUEST) DÉTACHEMENT DUNDURN",
    "addressHtml": "155 VOGELSANG AVE DUNDURN<br>SK S0K 1K0<br>CAN",
    "addressPlain": "155 VOGELSANG AVE DUNDURN\\nSK S0K 1K0\\nCAN"
  },
  {
    "id": "5026",
    "uic": "5026",
    "abbrevCFR": "10 RAC",
    "officialName": "10E RÉGIMENT D'ARTILLERIE DE CAMPAGNE, ARC",
    "addressHtml": "1600 ELPHINSTONE ST REGINA<br>SK S4T 3N1<br>CAN",
    "addressPlain": "1600 ELPHINSTONE ST REGINA\\nSK S4T 3N1\\nCAN"
  },
  {
    "id": "5264",
    "uic": "5264",
    "abbrevCFR": "16 Amb C",
    "officialName": "16E AMBULANCE DE CAMPAGNE (RÉGINA)",
    "addressHtml": "1600 ELPHINSTONE ST REGINA<br>SK S4T 3N1<br>CAN",
    "addressPlain": "1600 ELPHINSTONE ST REGINA\\nSK S4T 3N1\\nCAN"
  },
  {
    "id": "4024",
    "uic": "4024",
    "abbrevCFR": "3 DC HQ DE",
    "officialName": "DÉTACHEMENT SASKATCHEWAN, QUARTIER GÉNÉRAL DE LA 3E DIVISION DU CANADA",
    "addressHtml": "1600 ELPHINSTONE ST REGINA<br>SK S4T 3N1<br>CAN",
    "addressPlain": "1600 ELPHINSTONE ST REGINA\\nSK S4T 3N1\\nCAN"
  },
  {
    "id": "5232",
    "uic": "5232",
    "abbrevCFR": "38 SBn Reg",
    "officialName": "DÉTACHEMENT REGINA, 38E BATAILLION DES SERVICES",
    "addressHtml": "1600 ELPHINSTONE ST REGINA<br>SK S4T 3N1<br>CAN",
    "addressPlain": "1600 ELPHINSTONE ST REGINA\\nSK S4T 3N1\\nCAN"
  },
  {
    "id": "6723",
    "uic": "6723",
    "abbrevCFR": "38 SR Det",
    "officialName": "DÉTACHEMENT REGINA, 38E RÉGIMENT DES TRANSMISSIONS",
    "addressHtml": "1600 ELPHINSTONE ST REGINA<br>SK S4T 3N1<br>CAN",
    "addressPlain": "1600 ELPHINSTONE ST REGINA\\nSK S4T 3N1\\nCAN"
  },
  {
    "id": "5120",
    "uic": "5120",
    "abbrevCFR": "Régt Royal",
    "officialName": "Régina THE ROYAL REGINA RIFLES",
    "addressHtml": "1600 ELPHINSTONE ST REGINA<br>SK S4T 3N1<br>CAN",
    "addressPlain": "1600 ELPHINSTONE ST REGINA\\nSK S4T 3N1\\nCAN"
  },
  {
    "id": "6392",
    "uic": "6392",
    "abbrevCFR": "CRFC Qc Det Mtl",
    "officialName": "DÉTACHEMENT MONTRÉAL, CENTRE DE RECRUTEMENT DES FORCES CANADIENNES QUÉBEC",
    "addressHtml": "1600 RENE-LEVESQUE BOULEVARD WEST SUITE 140 MONTREAL<br>QC H3H 1P9<br>CAN",
    "addressPlain": "1600 RENE-LEVESQUE BOULEVARD WEST SUITE 140 MONTREAL\\nQC H3H 1P9\\nCAN"
  },
  {
    "id": "0347",
    "uic": "0347",
    "abbrevCFR": "CRFC CORNE",
    "officialName": "DÉTACHEMENT CORNER BROOK, CENTRE DE RECRUTEMENT DES FORCES CANADIENNES HALIFAX",
    "addressHtml": "165 DUCKWORTH STREET ST JOHN S<br>NL A1C 1G4<br>CAN",
    "addressPlain": "165 DUCKWORTH STREET ST JOHN S\\nNL A1C 1G4\\nCAN"
  },
  {
    "id": "6272",
    "uic": "6272",
    "abbrevCFR": "28 Amb C",
    "officialName": "28E AMBULANCE DE CAMPAGNE (OTTAWA)",
    "addressHtml": "1745 ALTA VISTA DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "1745 ALTA VISTA DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "5263",
    "uic": "5263",
    "abbrevCFR": "12 Amb C",
    "officialName": "12E AMBULANCE DE CAMPAGNE (VANCOUVER)",
    "addressHtml": "1755 W 1ST Ave VANCOUVER<br>BC V6J 0G7<br>CAN",
    "addressPlain": "1755 W 1ST Ave VANCOUVER\\nBC V6J 0G7\\nCAN"
  },
  {
    "id": "3665",
    "uic": "3665",
    "abbrevCFR": "QG 39 GBC",
    "officialName": "QUARTIER GÉNÉRAL DU 39E GROUPE-BRIGADE DU CANADA",
    "addressHtml": "1755 W 1ST Ave VANCOUVER<br>BC V6J 0G7<br>CAN",
    "addressPlain": "1755 W 1ST Ave VANCOUVER\\nBC V6J 0G7\\nCAN"
  },
  {
    "id": "6710",
    "uic": "6710",
    "abbrevCFR": "39 Régt trans",
    "officialName": "39E RÉGIMENT DES TRANSMISSIONS",
    "addressHtml": "1755 W 1ST Ave VANCOUVER<br>BC V6J 0G7<br>CAN",
    "addressPlain": "1755 W 1ST Ave VANCOUVER\\nBC V6J 0G7\\nCAN"
  },
  {
    "id": "3429",
    "uic": "3429",
    "abbrevCFR": "6 INT COY",
    "officialName": "DÉTACHEMENT VANCOUVER 6E COMPAGNIE DU RENSEIGNEMENT",
    "addressHtml": "1755 W 1ST Ave VANCOUVER<br>BC V6J 0G7<br>CAN",
    "addressPlain": "1755 W 1ST Ave VANCOUVER\\nBC V6J 0G7\\nCAN"
  },
  {
    "id": "3962",
    "uic": "3962",
    "abbrevCFR": "Dét Vancou",
    "officialName": "DÉTACHEMENT VANCOUVER, CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES (PACIFIQUE)",
    "addressHtml": "1755 W 1ST Ave VANCOUVER<br>BC V6J 0G7<br>CAN",
    "addressPlain": "1755 W 1ST Ave VANCOUVER\\nBC V6J 0G7\\nCAN"
  },
  {
    "id": "0337",
    "uic": "0337",
    "abbrevCFR": "AQWC VAN",
    "officialName": "WORKCENTRE DE L'ASSURANCE DE QUALITÉ (VANCOUVER)",
    "addressHtml": "1755 W 1ST Ave VANCOUVER<br>BC V6J 0G7<br>CAN",
    "addressPlain": "1755 W 1ST Ave VANCOUVER\\nBC V6J 0G7\\nCAN"
  },
  {
    "id": "5128",
    "uic": "5128",
    "abbrevCFR": "SEAFORTH O",
    "officialName": "THE SEAFORTH HIGHLANDERS OF CANADA",
    "addressHtml": "1755 W 1ST Ave VANCOUVER<br>BC V6J 0G7<br>CAN",
    "addressPlain": "1755 W 1ST Ave VANCOUVER\\nBC V6J 0G7\\nCAN"
  },
  {
    "id": "6738",
    "uic": "6738",
    "abbrevCFR": "CT VANCOUV",
    "officialName": "CENTRE DE TRANSITION VANCOUVER",
    "addressHtml": "1755 W 1ST Ave VANCOUVER<br>BC V6J 0G7<br>CAN",
    "addressPlain": "1755 W 1ST Ave VANCOUVER\\nBC V6J 0G7\\nCAN"
  },
  {
    "id": "5097",
    "uic": "5097",
    "abbrevCFR": "42 RAC",
    "officialName": "42E RÉGIMENT D'ARTILLERIE DE CAMPAGNE (LANARK ET RENFREW SCOTTISH), ARC",
    "addressHtml": "177 VICTORIA ST PEMBROKE<br>ON K8A 4K2<br>CAN",
    "addressPlain": "177 VICTORIA ST PEMBROKE\\nON K8A 4K2\\nCAN"
  },
  {
    "id": "5042",
    "uic": "5042",
    "abbrevCFR": "56 RAC",
    "officialName": "56E RÉGIMENT D'ARTILLERIE DE CAMPAGNE, ARC",
    "addressHtml": "18 BRANT AVE BRANTFORD<br>ON N3T 3G5<br>CAN",
    "addressPlain": "18 BRANT AVE BRANTFORD\\nON N3T 3G5\\nCAN"
  },
  {
    "id": "3712",
    "uic": "3712",
    "abbrevCFR": "ALFC HALIF",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (HALIFAX)",
    "addressHtml": "18 HIGHFIELD PARK DRIVE DARTMOUTH<br>NS B3A 4S8<br>CAN",
    "addressPlain": "18 HIGHFIELD PARK DRIVE DARTMOUTH\\nNS B3A 4S8\\nCAN"
  },
  {
    "id": "3964",
    "uic": "3964",
    "abbrevCFR": "5 Amb",
    "officialName": "C Det Rim DÉTACHEMENT RIMOUSKI 5E AMBULANCE DE CAMPAGNE",
    "addressHtml": "180 DE LA CATHEDRALE RIMOUSKI<br>QC G5L 5H9<br>CAN",
    "addressPlain": "180 DE LA CATHEDRALE RIMOUSKI\\nQC G5L 5H9\\nCAN"
  },
  {
    "id": "6726",
    "uic": "6726",
    "abbrevCFR": "41 SR Det",
    "officialName": "DÉTACHEMENT CALGARY, 41E RÉGIMENT DES TRANSMISSIONS",
    "addressHtml": "1820 24 ST SW CALGARY<br>AB T2T 0G6<br>CAN",
    "addressPlain": "1820 24 ST SW CALGARY\\nAB T2T 0G6\\nCAN"
  },
  {
    "id": "1333",
    "uic": "1333",
    "abbrevCFR": "NCSM TECUMSEH",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ TECUMSEH",
    "addressHtml": "1820 24 ST SW CALGARY<br>AB T2T 0G6<br>CAN",
    "addressPlain": "1820 24 ST SW CALGARY\\nAB T2T 0G6\\nCAN"
  },
  {
    "id": "5091",
    "uic": "5091",
    "abbrevCFR": "HAST & PER",
    "officialName": "THE HASTINGS AND PRINCE EDWARD REGIMENT",
    "addressHtml": "187 PINNACLE ST BELLEVILLE<br>ON K8N 3A5<br>CAN",
    "addressPlain": "187 PINNACLE ST BELLEVILLE\\nON K8N 3A5\\nCAN"
  },
  {
    "id": "5019",
    "uic": "5019",
    "abbrevCFR": "R de Hull",
    "officialName": "LE RÉGIMENT DE HULL (CBRC)",
    "addressHtml": "188 BOUL ALEXANDRE TACHE HULL<br>QC J8Y 3L5<br>CAN",
    "addressPlain": "188 BOUL ALEXANDRE TACHE HULL\\nQC J8Y 3L5\\nCAN"
  },
  {
    "id": "3484",
    "uic": "3484",
    "abbrevCFR": "NCSM PREVO",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ PRÉVOST",
    "addressHtml": "19 BECHER ST LONDON<br>ON N6C 1A4<br>CAN",
    "addressPlain": "19 BECHER ST LONDON\\nON N6C 1A4\\nCAN"
  },
  {
    "id": "0021",
    "uic": "0021",
    "abbrevCFR": "CRFC DET C",
    "officialName": "DÉTACHEMENT CHARLOTTETOWN, CENTRE DE RECRUTEMENT DES FORCES CANADIENNES HALIFAX",
    "addressHtml": "191 UNIVERSITY AVENUE SUITE 106B CHARLOTTETOWN<br>PE C1A 1N3<br>CAN",
    "addressPlain": "191 UNIVERSITY AVENUE SUITE 106B CHARLOTTETOWN\\nPE C1A 1N3\\nCAN"
  },
  {
    "id": "3643",
    "uic": "3643",
    "abbrevCFR": "EOCAFC ÉCOLE",
    "officialName": "DES OPÉRATIONS DE CONTRÔLE AEROSPATIAL DES FORCES CANADIENNES",
    "addressHtml": "1950 MONTREAL RD CORNWALL<br>ON K6H 6L2<br>CAN",
    "addressPlain": "1950 MONTREAL RD CORNWALL\\nON K6H 6L2\\nCAN"
  },
  {
    "id": "5095",
    "uic": "5095",
    "abbrevCFR": "Lorne Scots",
    "officialName": "THE LORNE SCOTS (PEEL, DUFFERIN AND HALTON REGIMENT)",
    "addressHtml": "2 CHAPEL ST BRAMPTON<br>ON L6W 2H1<br>CAN",
    "addressPlain": "2 CHAPEL ST BRAMPTON\\nON L6W 2H1\\nCAN"
  },
  {
    "id": "2987",
    "uic": "2987",
    "abbrevCFR": "CEMC CENTRE",
    "officialName": "D'ENTRAîNEMENT MUSICAL DES CADETS",
    "addressHtml": "200 BOUL SAINT-SACREMENT SAINT-GABRIEL-DE-VALCARTIER<br>QC G0A 4S0<br>CAN",
    "addressPlain": "200 BOUL SAINT-SACREMENT SAINT-GABRIEL-DE-VALCARTIER\\nQC G0A 4S0\\nCAN"
  },
  {
    "id": "2526",
    "uic": "2526",
    "abbrevCFR": "412 Esc (T",
    "officialName": "412E ESCADRON DE TRANSPORT",
    "addressHtml": "200 COMET PRIVATE OTTAWA<br>ON K1V 9B2<br>CAN",
    "addressPlain": "200 COMET PRIVATE OTTAWA\\nON K1V 9B2\\nCAN"
  },
  {
    "id": "5074",
    "uic": "5074",
    "abbrevCFR": "31 Régt tr",
    "officialName": "31E RÉGIMENT DES TRANSMISSIONS",
    "addressHtml": "200 JAMES ST N HAMILTON<br>ON L8R 2L1<br>CAN",
    "addressPlain": "200 JAMES ST N HAMILTON\\nON L8R 2L1\\nCAN"
  },
  {
    "id": "5116",
    "uic": "5116",
    "abbrevCFR": "A&SH OF C",
    "officialName": "THE ARGYLL AND SUTHERLAND HIGHLANDERS OF CANADA (PRINCESS LOUISE'S)",
    "addressHtml": "200 JAMES ST N HAMILTON<br>ON L8R 2L1<br>CAN",
    "addressPlain": "200 JAMES ST N HAMILTON\\nON L8R 2L1\\nCAN"
  },
  {
    "id": "5089",
    "uic": "5089",
    "abbrevCFR": "RHLI THE",
    "officialName": "ROYAL HAMILTON LIGHT INFANTRY (WENTWORTH REGIMENT)",
    "addressHtml": "200 JAMES ST N HAMILTON<br>ON L8R 2L1<br>CAN",
    "addressPlain": "200 JAMES ST N HAMILTON\\nON L8R 2L1\\nCAN"
  },
  {
    "id": "4994",
    "uic": "4994",
    "abbrevCFR": "Dét Oshawa",
    "officialName": "DÉTACHEMENT OSHAWA, CENTRE DE RECRUTEMENT DES FORCES CANADIENNES TORONTO",
    "addressHtml": "200 JOHN ST W OSHAWA<br>ON L1J 2B4<br>CAN",
    "addressPlain": "200 JOHN ST W OSHAWA\\nON L1J 2B4\\nCAN"
  },
  {
    "id": "2601",
    "uic": "2601",
    "abbrevCFR": "3 EPFC",
    "officialName": "3E ÉCOLE DE PILOTAGE DES FORCES CANADIENNES 200-55 MUSKETEER RD E SOUTHPORT",
    "addressHtml": "MB R0H 1N1<br>CAN",
    "addressPlain": "MB R0H 1N1\\nCAN"
  },
  {
    "id": "5029",
    "uic": "5029",
    "abbrevCFR": "15 RAC",
    "officialName": "15E RÉGIMENT D'ARTILLERIE DE CAMPAGNE, ARC",
    "addressHtml": "2025 11TH AVE W VANCOUVER<br>BC V6J 2C7<br>CAN",
    "addressPlain": "2025 11TH AVE W VANCOUVER\\nBC V6J 2C7\\nCAN"
  },
  {
    "id": "5086",
    "uic": "5086",
    "abbrevCFR": "RHC THE",
    "officialName": "BLACK WATCH (ROYAL HIGHLAND REGIMENT) OF CANADA",
    "addressHtml": "2067 DE BLEURY ST MONTREAL<br>QC H3A 2K2<br>CAN",
    "addressPlain": "2067 DE BLEURY ST MONTREAL\\nQC H3A 2K2\\nCAN"
  },
  {
    "id": "4019",
    "uic": "4019",
    "abbrevCFR": "NCSM QUEEN",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ QUEEN CHARLOTTE",
    "addressHtml": "210 WATER STREET CHARLOTTETOWN<br>PE C1A 9M5<br>CAN",
    "addressPlain": "210 WATER STREET CHARLOTTETOWN\\nPE C1A 9M5\\nCAN"
  },
  {
    "id": "5101",
    "uic": "5101",
    "abbrevCFR": "4 R22eR",
    "officialName": "4E BATAILLON, ROYAL 22E RÉGIMENT (CHÂTEAUGUAY)",
    "addressHtml": "2100 BOULEVARD LE CARREFOUR LAVAL<br>QC H7S 2M7<br>CAN",
    "addressPlain": "2100 BOULEVARD LE CARREFOUR LAVAL\\nQC H7S 2M7\\nCAN"
  },
  {
    "id": "5062",
    "uic": "5062",
    "abbrevCFR": "33 RGC",
    "officialName": "33E RÉGIMENT DU GÉNIE DE COMBAT",
    "addressHtml": "2100 WALKLEY RD OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "2100 WALKLEY RD OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6699",
    "uic": "6699",
    "abbrevCFR": "33 Bon Svc",
    "officialName": "33E BATAILLON DES SERVICES",
    "addressHtml": "2100 WALKLEY RD OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "2100 WALKLEY RD OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "8160",
    "uic": "8160",
    "abbrevCFR": "CFC COLLÈGE",
    "officialName": "DES FORCES CANADIENNES",
    "addressHtml": "215 YONGE BLVD NORTH YORK<br>ON M5M 3H9<br>CAN",
    "addressPlain": "215 YONGE BLVD NORTH YORK\\nON M5M 3H9\\nCAN"
  },
  {
    "id": "5102",
    "uic": "5102",
    "abbrevCFR": "6 R22eR",
    "officialName": "6E BATAILLON, ROYAL 22E RÉGIMENT",
    "addressHtml": "2155 BOUL LAFRAMBOISE SAINT-HYACINTHE<br>QC J2S 4X5<br>CAN",
    "addressPlain": "2155 BOUL LAFRAMBOISE SAINT-HYACINTHE\\nQC J2S 4X5\\nCAN"
  },
  {
    "id": "3692",
    "uic": "3692",
    "abbrevCFR": "SNEFC SERVICE",
    "officialName": "NATIONAL DES ENQUÊTES DES FORCES CANADIENNES",
    "addressHtml": "2200 WALKLEY RD OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "2200 WALKLEY RD OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6291",
    "uic": "6291",
    "abbrevCFR": "Dét Moncto",
    "officialName": "DÉTACHEMENT MONCTON, CENTRE DE RECRUTEMENT DES FORCES CANADIENNES HALIFAX",
    "addressHtml": "230 CHAMPLAIN ST, SUITE 102 DIEPPE<br>NB E1A 1P1<br>CAN",
    "addressPlain": "230 CHAMPLAIN ST, SUITE 102 DIEPPE\\nNB E1A 1P1\\nCAN"
  },
  {
    "id": "6722",
    "uic": "6722",
    "abbrevCFR": "38 SR Det",
    "officialName": "DÉTACHEMENT SASKATOON, 38E RÉGIMENT DES TRANSMISSIONS",
    "addressHtml": "2321 HANSELMAN AVE SASKATOON<br>SK S7L 5Z3<br>CAN",
    "addressPlain": "2321 HANSELMAN AVE SASKATOON\\nSK S7L 5Z3\\nCAN"
  },
  {
    "id": "0025",
    "uic": "0025",
    "abbrevCFR": "CFRC OTTAW",
    "officialName": "CENTRE DE RECRUTEMENT DES FORCES CANADIENNES OTTAWA",
    "addressHtml": "240 SPARKS ST OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "240 SPARKS ST OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2774",
    "uic": "2774",
    "abbrevCFR": "ÉCON FC",
    "officialName": "LES ÉCONOMATS DES FORCES CANADIENNES",
    "addressHtml": "245 COOPER ST OTTAWA<br>ON K2P 0G2<br>CAN",
    "addressPlain": "245 COOPER ST OTTAWA\\nON K2P 0G2\\nCAN"
  },
  {
    "id": "6540",
    "uic": "6540",
    "abbrevCFR": "USM RDDC",
    "officialName": "Det Val USM - R ET D POUR LA DÉFENSE CANADA DÉTACHEMENT VALCARTIER",
    "addressHtml": "2459 ROUTE DE LA BRAVOURE QUEBEC<br>QC G3J 1X5<br>CAN",
    "addressPlain": "2459 ROUTE DE LA BRAVOURE QUEBEC\\nQC G3J 1X5\\nCAN"
  },
  {
    "id": "1430",
    "uic": "1430",
    "abbrevCFR": "RDDC Val",
    "officialName": "RECHERCHE ET DÉVELOPPEMENT POUR LA DÉFENSE CANADA (VALCARTIER)",
    "addressHtml": "2459 ROUTE DE LA BRAVOURE QUEBEC<br>QC G3J 1X5<br>CAN",
    "addressPlain": "2459 ROUTE DE LA BRAVOURE QUEBEC\\nQC G3J 1X5\\nCAN"
  },
  {
    "id": "2683",
    "uic": "2683",
    "abbrevCFR": "CEEM CENTRE",
    "officialName": "D'ESSAIS ET D'EXPÉRIMENTATION DES MUNITIONS",
    "addressHtml": "2459 ROUTE DE LA BRAVOURE QUEBEC<br>QC G3J 1X5<br>CAN",
    "addressPlain": "2459 ROUTE DE LA BRAVOURE QUEBEC\\nQC G3J 1X5\\nCAN"
  },
  {
    "id": "3660",
    "uic": "3660",
    "abbrevCFR": "QG 34 GBC",
    "officialName": "QUARTIER GÉNÉRAL DU 34E GROUPE-BRIGADE DU CANADA",
    "addressHtml": "25 GRAND BERNIER SUD SAINT-JEAN-SUR-RICHELIEU<br>QC J0J 1R0<br>CAN",
    "addressPlain": "25 GRAND BERNIER SUD SAINT-JEAN-SUR-RICHELIEU\\nQC J0J 1R0\\nCAN"
  },
  {
    "id": "5110",
    "uic": "5110",
    "abbrevCFR": "R de Mais",
    "officialName": "LE RÉGIMENT DE MAISONNEUVE",
    "addressHtml": "25 GRAND BERNIER SUD SAINT-JEAN-SUR-RICHELIEU<br>QC J0J 1R0<br>CAN",
    "addressPlain": "25 GRAND BERNIER SUD SAINT-JEAN-SUR-RICHELIEU\\nQC J0J 1R0\\nCAN"
  },
  {
    "id": "0012",
    "uic": "0012",
    "abbrevCFR": "CRFC DET L",
    "officialName": "DÉTACHEMENT LONDON, CENTRE DE RECRUTEMENT DES FORCES CANADIENNES TORONTO",
    "addressHtml": "250 YORK STREET, UNIT 100A LONDON<br>ON N6A 6K2<br>CAN",
    "addressPlain": "250 YORK STREET, UNIT 100A LONDON\\nON N6A 6K2\\nCAN"
  },
  {
    "id": "0202",
    "uic": "0202",
    "abbrevCFR": "CRFC Qc",
    "officialName": "CENTRE DE RECRUTEMENT DES FORCES CANADIENNES QUÉBEC",
    "addressHtml": "2575 BOUL SAINTE-ANNE, BUREAU 120 QUEBEC<br>QC G1J 0G7<br>CAN",
    "addressPlain": "2575 BOUL SAINTE-ANNE, BUREAU 120 QUEBEC\\nQC G1J 0G7\\nCAN"
  },
  {
    "id": "5064",
    "uic": "5064",
    "abbrevCFR": "35 RGC",
    "officialName": "35E RÉGIMENT DU GÉNIE DE COMBAT",
    "addressHtml": "2630 BOUL HOCHELAGA QUEBEC<br>QC G1V 0H2<br>CAN",
    "addressPlain": "2630 BOUL HOCHELAGA QUEBEC\\nQC G1V 0H2\\nCAN"
  },
  {
    "id": "5105",
    "uic": "5105",
    "abbrevCFR": "RNBR THE",
    "officialName": "ROYAL NEW BRUNSWICK REGIMENT (CARLTON & YORK)",
    "addressHtml": "3 CARLETON ST FREDERICTON<br>NB E3B 3T1<br>CAN",
    "addressPlain": "3 CARLETON ST FREDERICTON\\nNB E3B 3T1\\nCAN"
  },
  {
    "id": "3661",
    "uic": "3661",
    "abbrevCFR": "QG 35 GBC",
    "officialName": "QUARTIER GÉNÉRAL DU 35E GROUPE-BRIGADE DU CANADA",
    "addressHtml": "3 COTE DE LA CITADELLE QUEBEC<br>QC G1R 3R2<br>CAN",
    "addressPlain": "3 COTE DE LA CITADELLE QUEBEC\\nQC G1R 3R2\\nCAN"
  },
  {
    "id": "2952",
    "uic": "2952",
    "abbrevCFR": "CEC VERNON",
    "officialName": "CENTRE D'ENTRAINEMENT DES CADETS DE VERNON",
    "addressHtml": "3100 15TH AVENUE VERNON<br>BC V1T 0A6<br>CAN",
    "addressPlain": "3100 15TH AVENUE VERNON\\nBC V1T 0A6\\nCAN"
  },
  {
    "id": "5265",
    "uic": "5265",
    "abbrevCFR": "18 Amb C",
    "officialName": "18E AMBULANCE DE CAMPAGNE (THUNDER BAY)",
    "addressHtml": "317 PARK AVE THUNDER BAY<br>ON P7B 1C7<br>CAN",
    "addressPlain": "317 PARK AVE THUNDER BAY\\nON P7B 1C7\\nCAN"
  },
  {
    "id": "5147",
    "uic": "5147",
    "abbrevCFR": "38 SBn TBa",
    "officialName": "DÉTACHEMENT THUNDER BAY, 38E BATAILLON DES SERVICES",
    "addressHtml": "317 PARK AVE THUNDER BAY<br>ON P7B 1C7<br>CAN",
    "addressPlain": "317 PARK AVE THUNDER BAY\\nON P7B 1C7\\nCAN"
  },
  {
    "id": "6721",
    "uic": "6721",
    "abbrevCFR": "38 SR Det",
    "officialName": "DÉTACHEMENT THUNDER BAY, 38E RÉGIMENT DES TRANSMISSIONS",
    "addressHtml": "317 PARK AVE THUNDER BAY<br>ON P7B 1C7<br>CAN",
    "addressPlain": "317 PARK AVE THUNDER BAY\\nON P7B 1C7\\nCAN"
  },
  {
    "id": "0594",
    "uic": "0594",
    "abbrevCFR": "BFC WINNIP",
    "officialName": "DÉTACHEMENT THUNDER BAY, BASE DES FORCES CANADIENNES WINNIPEG",
    "addressHtml": "317 PARK AVE THUNDER BAY<br>ON P7B 1C7<br>CAN",
    "addressPlain": "317 PARK AVE THUNDER BAY\\nON P7B 1C7\\nCAN"
  },
  {
    "id": "5117",
    "uic": "5117",
    "abbrevCFR": "LAKE SUP Scott Régt",
    "officialName": "THE LAKE SUPERIOR SCOTTISH REGIMENT",
    "addressHtml": "317 PARK AVE THUNDER BAY<br>ON P7B 1C7<br>CAN",
    "addressPlain": "317 PARK AVE THUNDER BAY\\nON P7B 1C7\\nCAN"
  },
  {
    "id": "5131",
    "uic": "5131",
    "abbrevCFR": "2 IRISH R",
    "officialName": "2E BATAILLON, IRISH REGIMENT OF CANADA",
    "addressHtml": "333 RIVERSIDE DR SUDBURY<br>ON P3E 1H5<br>CAN",
    "addressPlain": "333 RIVERSIDE DR SUDBURY\\nON P3E 1H5\\nCAN"
  },
  {
    "id": "4043",
    "uic": "4043",
    "abbrevCFR": "CI 4DC DE",
    "officialName": "DÉTACHEMENT SUDBURY, CENTRE D'INSTRUCTION DE LA 4E DIVISION DU CANADA",
    "addressHtml": "333 RIVERSIDE DR SUDBURY<br>ON P3E 1H5<br>CAN",
    "addressPlain": "333 RIVERSIDE DR SUDBURY\\nON P3E 1H5\\nCAN"
  },
  {
    "id": "0016",
    "uic": "0016",
    "abbrevCFR": "CRFC Qc Det Chic",
    "officialName": "DÉTACHEMENT CHICOUTIMI, CENTRE DE RECRUTEMENT DES FORCES CANADIENNES QUEBEC",
    "addressHtml": "345 DES SAGUENEENS SAGUENAY<br>QC G7H 6K9<br>CAN",
    "addressPlain": "345 DES SAGUENEENS SAGUENAY\\nQC G7H 6K9\\nCAN"
  },
  {
    "id": "1324",
    "uic": "1324",
    "abbrevCFR": "NCSM Donnacona",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ DONNACONA",
    "addressHtml": "3525 ST-JACQUES ST MONTREAL<br>QC H4C 0A1<br>CAN",
    "addressPlain": "3525 ST-JACQUES ST MONTREAL\\nQC H4C 0A1\\nCAN"
  },
  {
    "id": "5055",
    "uic": "5055",
    "abbrevCFR": "39 GRC",
    "officialName": "39E RÉGIMENT DU GÉNIE DE COMBAT 3-5535 KOREA",
    "addressHtml": "ROAD CHILLIWACK<br>BC V2R 5P2<br>CAN",
    "addressPlain": "ROAD CHILLIWACK\\nBC V2R 5P2\\nCAN"
  },
  {
    "id": "5285",
    "uic": "5285",
    "abbrevCFR": "3042 CCRAC",
    "officialName": "CORPS DE CADETS ROYAUX DE L¿ARMÉE CANADIENNE,",
    "addressHtml": "3042 MATAWINIE 3604 rue Albert Rawdon<br>QC J0K 1S0<br>CAN",
    "addressPlain": "3042 MATAWINIE 3604 rue Albert Rawdon\\nQC J0K 1S0\\nCAN"
  },
  {
    "id": "4018",
    "uic": "4018",
    "abbrevCFR": "NCSM Jolliet",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ JOLLIET",
    "addressHtml": "366 AV ARNAUD SEPT-ILES<br>QC G4R 3A7<br>CAN",
    "addressPlain": "366 AV ARNAUD SEPT-ILES\\nQC G4R 3A7\\nCAN"
  },
  {
    "id": "0601",
    "uic": "0601",
    "abbrevCFR": "EADS DÉTACHEMENT",
    "officialName": "CANADIEN SECTEUR DE LA DÉFENSE AÉRIENNE DE L'EST",
    "addressHtml": "366 OTIS ST ROME<br>NY 134414812<br>USA",
    "addressPlain": "366 OTIS ST ROME\\nNY 134414812\\nUSA"
  },
  {
    "id": "5003",
    "uic": "5003",
    "abbrevCFR": "GREY & SIM",
    "officialName": "THE GREY AND SIMCOE FORESTERS",
    "addressHtml": "37 PARKSIDE DRIVE BARRIE<br>ON L4N 1W8<br>CAN",
    "addressPlain": "37 PARKSIDE DRIVE BARRIE\\nON L4N 1W8\\nCAN"
  },
  {
    "id": "1410",
    "uic": "1410",
    "abbrevCFR": "RDDC OTTAW",
    "officialName": "RECHERCHE ET DÉVELOPPEMENT POUR LA DÉFENSE CANADA (OTTAWA)",
    "addressHtml": "3701 CARLING AVE OTTAWA<br>ON K1A 0Z4<br>CAN",
    "addressPlain": "3701 CARLING AVE OTTAWA\\nON K1A 0Z4\\nCAN"
  },
  {
    "id": "5103",
    "uic": "5103",
    "abbrevCFR": "Fus MR",
    "officialName": "LES FUSILIERS MONT-ROYAL",
    "addressHtml": "3721 AV HENRI JULIEN MONTREAL<br>QC H2X 3H4<br>CAN",
    "addressPlain": "3721 AV HENRI JULIEN MONTREAL\\nQC H2X 3H4\\nCAN"
  },
  {
    "id": "6264",
    "uic": "6264",
    "abbrevCFR": "36 SBn",
    "officialName": "Syd DÉTACHMENT SYDNEY, 36E BATAILLON DES SERVICES",
    "addressHtml": "4 GARRISON RD VICTORIA PARK SYDNEY<br>NS B1P 6Z2<br>CAN",
    "addressPlain": "4 GARRISON RD VICTORIA PARK SYDNEY\\nNS B1P 6Z2\\nCAN"
  },
  {
    "id": "6719",
    "uic": "6719",
    "abbrevCFR": "36 SR Det",
    "officialName": "DÉTACHEMENT GLACE BAY, 36E RÉGIMENT DES TRANSMISSIONS",
    "addressHtml": "4 GARRISON RD VICTORIA PARK SYDNEY<br>NS B1P 6Z2<br>CAN",
    "addressPlain": "4 GARRISON RD VICTORIA PARK SYDNEY\\nNS B1P 6Z2\\nCAN"
  },
  {
    "id": "4760",
    "uic": "4760",
    "abbrevCFR": "GS 5DIV CB",
    "officialName": "GROUPE DE SOUTIEN DE LA 5E DIVISION DU CANADA DÉTACHMENT CAPE BRETON",
    "addressHtml": "4 GARRISON RD VICTORIA PARK SYDNEY<br>NS B1P 6Z2<br>CAN",
    "addressPlain": "4 GARRISON RD VICTORIA PARK SYDNEY\\nNS B1P 6Z2\\nCAN"
  },
  {
    "id": "5109",
    "uic": "5109",
    "abbrevCFR": "CB Highrs",
    "officialName": "THE CAPE BRETON HIGHLANDERS",
    "addressHtml": "4 GARRISON RD VICTORIA PARK SYDNEY<br>NS B1P 6Z2<br>CAN",
    "addressPlain": "4 GARRISON RD VICTORIA PARK SYDNEY\\nNS B1P 6Z2\\nCAN"
  },
  {
    "id": "5004",
    "uic": "5004",
    "abbrevCFR": "31 RGC",
    "officialName": "31E RÉGIMENT DE GÉNIE DE COMBAT (THE ELGIN'S)",
    "addressHtml": "40 WILSON AVENUE ST THOMAS<br>ON N5R 3R2<br>CAN",
    "addressPlain": "40 WILSON AVENUE ST THOMAS\\nON N5R 3R2\\nCAN"
  },
  {
    "id": "6254",
    "uic": "6254",
    "abbrevCFR": "31 SBn Win",
    "officialName": "DÉTACHEMENT WINDSOR, 31E BATAILLON DES SERVICES",
    "addressHtml": "4007 SANDWICH STREET WINDSOR<br>ON N9C 1C3<br>CAN",
    "addressPlain": "4007 SANDWICH STREET WINDSOR\\nON N9C 1C3\\nCAN"
  },
  {
    "id": "5113",
    "uic": "5113",
    "abbrevCFR": "E&K SCOT",
    "officialName": "THE ESSEX AND KENT SCOTTISH",
    "addressHtml": "4007 SANDWICH STREET WINDSOR<br>ON N9C 1C3<br>CAN",
    "addressPlain": "4007 SANDWICH STREET WINDSOR\\nON N9C 1C3\\nCAN"
  },
  {
    "id": "5020",
    "uic": "5020",
    "abbrevCFR": "WINDSOR R",
    "officialName": "THE WINDSOR REGIMENT (CBRC)",
    "addressHtml": "4007 SANDWICH STREET WINDSOR<br>ON N9C 1C3<br>CAN",
    "addressPlain": "4007 SANDWICH STREET WINDSOR\\nON N9C 1C3\\nCAN"
  },
  {
    "id": "1332",
    "uic": "1332",
    "abbrevCFR": "NCSM UNICORN",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ UNICORN",
    "addressHtml": "405 24TH ST E SASKATOON<br>SK S7K 0K7<br>CAN",
    "addressPlain": "405 24TH ST E SASKATOON\\nSK S7K 0K7\\nCAN"
  },
  {
    "id": "3730",
    "uic": "3730",
    "abbrevCFR": "ALFC VANCO",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (VANCOUVER)",
    "addressHtml": "4050 WEST 4TH AVENUE VANCOUVER<br>BC V6R 1P6<br>CAN",
    "addressPlain": "4050 WEST 4TH AVENUE VANCOUVER\\nBC V6R 1P6\\nCAN"
  },
  {
    "id": "5084",
    "uic": "5084",
    "abbrevCFR": "CGG THE",
    "officialName": "CANADIAN GRENADIER GUARDS",
    "addressHtml": "4171 DE L'ESPLANADE AVE MONTREAL<br>QC H2W 1S9<br>CAN",
    "addressPlain": "4171 DE L'ESPLANADE AVE MONTREAL\\nQC H2W 1S9\\nCAN"
  },
  {
    "id": "5047",
    "uic": "5047",
    "abbrevCFR": "2 RAC",
    "officialName": "2E RÉGIMENT D'ARTILLERIE DE CAMPAGNE, ARC",
    "addressHtml": "4185 COTE-DES-NEIGES RD MONTREAL<br>QC H3H 1X2<br>CAN",
    "addressPlain": "4185 COTE-DES-NEIGES RD MONTREAL\\nQC H3H 1X2\\nCAN"
  },
  {
    "id": "5011",
    "uic": "5011",
    "abbrevCFR": "RCH THE",
    "officialName": "ROYAL CANADIAN HUSSARS (MONTRÉAL)",
    "addressHtml": "4185 COTE-DES-NEIGES RD MONTREAL<br>QC H3H 1X2<br>CAN",
    "addressPlain": "4185 COTE-DES-NEIGES RD MONTREAL\\nQC H3H 1X2\\nCAN"
  },
  {
    "id": "6727",
    "uic": "6727",
    "abbrevCFR": "41 SR Det",
    "officialName": "DÉTACHEMENT RED DEER, 41E RÉGIMENT DES TRANSMISSIONS",
    "addressHtml": "4402 55th ST RED DEER<br>AB T4N 2H1<br>CAN",
    "addressPlain": "4402 55th ST RED DEER\\nAB T4N 2H1\\nCAN"
  },
  {
    "id": "6145",
    "uic": "6145",
    "abbrevCFR": "78",
    "officialName": "Bte",
    "addressHtml": "20 78E BATTERIE DE CAMPAIGNE, 20E RÉGIMENT D'ARTILLERIE DE CAMPAGNE, ARC 4402 55th ST RED DEER<br>AB T4N 2H1<br>CAN",
    "addressPlain": "20 78E BATTERIE DE CAMPAIGNE, 20E RÉGIMENT D'ARTILLERIE DE CAMPAGNE, ARC 4402 55th ST RED DEER\\nAB T4N 2H1\\nCAN"
  },
  {
    "id": "2970",
    "uic": "2970",
    "abbrevCFR": "CEC WHITEH",
    "officialName": "CENTRE D'ENTRAINEMENT DES CADETS DE WHITEHORSE",
    "addressHtml": "45 FIREWEED DRIVE WHITEHORSE<br>YT Y1A 5T8<br>CAN",
    "addressPlain": "45 FIREWEED DRIVE WHITEHORSE\\nYT Y1A 5T8\\nCAN"
  },
  {
    "id": "1567",
    "uic": "1567",
    "abbrevCFR": "JTFNHQ YUK",
    "officialName": "DÉTACHEMENT YUKON, QUARTIER GÉNÉRAL DE LA FORCE OPÉRATIONNELLE INTERARMÉES (NORD)",
    "addressHtml": "45 FIREWEED DRIVE WHITEHORSE<br>YT Y1A 5T8<br>CAN",
    "addressPlain": "45 FIREWEED DRIVE WHITEHORSE\\nYT Y1A 5T8\\nCAN"
  },
  {
    "id": "3715",
    "uic": "3715",
    "abbrevCFR": "ALFC MONCT",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (MONCTON)",
    "addressHtml": "456 ST GEORGE ST MONCTON<br>NB E1C 1Y1<br>CAN",
    "addressPlain": "456 ST GEORGE ST MONCTON\\nNB E1C 1Y1\\nCAN"
  },
  {
    "id": "5082",
    "uic": "5082",
    "abbrevCFR": "34 Regt Trans",
    "officialName": "34E RÉGIMENT DES TRANSMISSIONS",
    "addressHtml": "4625 SAINTE-CATHERINE ST W WESTMOUNT<br>QC H3Z 1S4<br>CAN",
    "addressPlain": "4625 SAINTE-CATHERINE ST W WESTMOUNT\\nQC H3Z 1S4\\nCAN"
  },
  {
    "id": "5130",
    "uic": "5130",
    "abbrevCFR": "RMR THE",
    "officialName": "ROYAL MONTREAL REGIMENT",
    "addressHtml": "4625 SAINTE-CATHERINE ST W WESTMOUNT<br>QC H3Z 1S4<br>CAN",
    "addressPlain": "4625 SAINTE-CATHERINE ST W WESTMOUNT\\nQC H3Z 1S4\\nCAN"
  },
  {
    "id": "5267",
    "uic": "5267",
    "abbrevCFR": "51 Amb C",
    "officialName": "51E AMBULANCE DE CAMPAGNE (MONTRÉAL)",
    "addressHtml": "4895 DE BULLION ST MONTREAL<br>QC H2T 1Z6<br>CAN",
    "addressPlain": "4895 DE BULLION ST MONTREAL\\nQC H2T 1Z6\\nCAN"
  },
  {
    "id": "0201",
    "uic": "0201",
    "abbrevCFR": "CFRC TORON",
    "officialName": "CENTRE DE RECRUTEMENT DES FORCES CANADIENNES TORONTO",
    "addressHtml": "4900 YONGE ST SUITE 100 NORTH YORK<br>ON M2N 6A4<br>CAN",
    "addressPlain": "4900 YONGE ST SUITE 100 NORTH YORK\\nON M2N 6A4\\nCAN"
  },
  {
    "id": "0322",
    "uic": "0322",
    "abbrevCFR": "WCAQ ON",
    "officialName": "& WORKCENTRE DE L'ASSURANCE DE QUALITÉ (ONTARIO et PRAIRIES)",
    "addressHtml": "4900 YONGE ST SUITE 600 NORTH YORK<br>ON M2N 6B7<br>CAN",
    "addressPlain": "4900 YONGE ST SUITE 600 NORTH YORK\\nON M2N 6B7\\nCAN"
  },
  {
    "id": "3965",
    "uic": "3965",
    "abbrevCFR": "41 C",
    "officialName": "Svc S FC Det Sher DÉTACHEMENT SHERBROOKE 41E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES",
    "addressHtml": "50 PLACE DE LA CITE 315 RUE KING OBUREAU 112 SHERBROOKE<br>QC J1H 4G9<br>CAN",
    "addressPlain": "50 PLACE DE LA CITE 315 RUE KING OBUREAU 112 SHERBROOKE\\nQC J1H 4G9\\nCAN"
  },
  {
    "id": "4871",
    "uic": "4871",
    "abbrevCFR": "CRFC Qc Det Sher",
    "officialName": "DÉTACHEMENT SHERBROOKE, CENTRE DE RECRUTEMENT DES FORCES CANADIENNES QUÉBEC",
    "addressHtml": "50 PLACE DE LA CITE 315 RUE KING OBUREAU 112 SHERBROOKE<br>QC J1H 4G9<br>CAN",
    "addressPlain": "50 PLACE DE LA CITE 315 RUE KING OBUREAU 112 SHERBROOKE\\nQC J1H 4G9\\nCAN"
  },
  {
    "id": "0045",
    "uic": "0045",
    "abbrevCFR": "ELFC(W) ÉTAT-MAJOR",
    "officialName": "DE LIAISON DES FORCES CANADIENNES (WASHINGTON)",
    "addressHtml": "501 PENNSYLVANIA AVE NW WASHINGTON<br>DC 20001<br>USA",
    "addressPlain": "501 PENNSYLVANIA AVE NW WASHINGTON\\nDC 20001\\nUSA"
  },
  {
    "id": "1418",
    "uic": "1418",
    "abbrevCFR": "BLRFC(W) BUREAU",
    "officialName": "- LIAISON RENSEIGNEMENT DES FORCES CANADIENNES (WASHINGTON)",
    "addressHtml": "501 PENNSYLVANIA AVE NW WASHINGTON<br>DC 20001<br>USA",
    "addressPlain": "501 PENNSYLVANIA AVE NW WASHINGTON\\nDC 20001\\nUSA"
  },
  {
    "id": "4098",
    "uic": "4098",
    "abbrevCFR": "DET MEADE",
    "officialName": "QUARTIER GÉNÉRAL DU COMMANDEMENT CYBER DES FORCES ARMÉES CANADIENNES DÉTACHEMENT FORT GEORGE MEADE",
    "addressHtml": "501 PENNSYLVANIA AVE NW WASHINGTON<br>DC 20001<br>USA",
    "addressPlain": "501 PENNSYLVANIA AVE NW WASHINGTON\\nDC 20001\\nUSA"
  },
  {
    "id": "6023",
    "uic": "6023",
    "abbrevCFR": "DET USN",
    "officialName": "QUARTIER GÉNÉRAL DU COMMANDEMENT CYBER DES FORCES ARMÉES CANADIENNES BUREAU USN CO MANNING",
    "addressHtml": "501 PENNSYLVANIA AVE NW WASHINGTON<br>DC 20001<br>USA",
    "addressPlain": "501 PENNSYLVANIA AVE NW WASHINGTON\\nDC 20001\\nUSA"
  },
  {
    "id": "3984",
    "uic": "3984",
    "abbrevCFR": "Gp Svc S",
    "officialName": "QUARTIER GÉNÉRAL DU GROUPE DES SERVICES DE SANTÉ DES FORCES CANADIENNES DÉTACHEMENT WASHINGTON",
    "addressHtml": "501 PENNSYLVANIA AVE NW WASHINGTON<br>DC 20001<br>USA",
    "addressPlain": "501 PENNSYLVANIA AVE NW WASHINGTON\\nDC 20001\\nUSA"
  },
  {
    "id": "0720",
    "uic": "0720",
    "abbrevCFR": "OUTCAN EU",
    "officialName": "ACADÉMIE CANADIENNE DE LA DÉFENSE HORS CANADA - ÉTATS-UNIS",
    "addressHtml": "501 PENNSYLVANIA AVE NW WASHINGTON, DC<br>DE<br>USA",
    "addressPlain": "501 PENNSYLVANIA AVE NW WASHINGTON, DC\\nDE\\nUSA"
  },
  {
    "id": "5098",
    "uic": "5098",
    "abbrevCFR": "SD &",
    "officialName": "G HIG STORMONT, DUNDAS AND GLENGARRY HIGHLANDERS",
    "addressHtml": "505 4TH ST E CORNWALL<br>ON K6H 2J7<br>CAN",
    "addressPlain": "505 4TH ST E CORNWALL\\nON K6H 2J7\\nCAN"
  },
  {
    "id": "6873",
    "uic": "6873",
    "abbrevCFR": "OP UNIFIER",
    "officialName": "OPÉRATION UNIFIER",
    "addressHtml": "5214 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "5214 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "5005",
    "uic": "5005",
    "abbrevCFR": "ONT Regt",
    "officialName": "THE ONTARIO REGIMENT (CBRC)",
    "addressHtml": "53 SIMCOE ST N OSHAWA<br>ON L1G 4R9<br>CAN",
    "addressPlain": "53 SIMCOE ST N OSHAWA\\nON L1G 4R9\\nCAN"
  },
  {
    "id": "5127",
    "uic": "5127",
    "abbrevCFR": "Régt Royal",
    "officialName": "Westminster THE ROYAL WESTMINSTER REGIMENT",
    "addressHtml": "530 QUEENS AVE NEW WESTMINSTER<br>BC V3L 1K3<br>CAN",
    "addressPlain": "530 QUEENS AVE NEW WESTMINSTER\\nBC V3L 1K3\\nCAN"
  },
  {
    "id": "5045",
    "uic": "5045",
    "abbrevCFR": "62 RAC",
    "officialName": "62E RÉGIMENT D'ARTILLERIE DE CAMPAGNE, ARC",
    "addressHtml": "5315 BOUL ROYAL SHAWINIGAN<br>QC G9N 8G6<br>CAN",
    "addressPlain": "5315 BOUL ROYAL SHAWINIGAN\\nQC G9N 8G6\\nCAN"
  },
  {
    "id": "5222",
    "uic": "5222",
    "abbrevCFR": "33 SBn NBa",
    "officialName": "DÉTACHEMENT NORTH BAY, 33E BATAILLON DES SERVICES",
    "addressHtml": "540 CHIPPEWA ST W NORTH BAY<br>ON P1B 8G6<br>CAN",
    "addressPlain": "540 CHIPPEWA ST W NORTH BAY\\nON P1B 8G6\\nCAN"
  },
  {
    "id": "0006",
    "uic": "0006",
    "abbrevCFR": "CFRC DET V",
    "officialName": "DÉTACHEMENT VICTORIA, CENTRE DE RECRUTEMENT DES FORCES CANADIENNES VANCOUVER",
    "addressHtml": "541 SUPERIOR STREET VICTORIA<br>BC V8V 0E4<br>CAN",
    "addressPlain": "541 SUPERIOR STREET VICTORIA\\nBC V8V 0E4\\nCAN"
  },
  {
    "id": "5018",
    "uic": "5018",
    "abbrevCFR": "Fort Garry Horse",
    "officialName": "THE FORT GARRY HORSE",
    "addressHtml": "551 MACHRAY AVE WINNIPEG<br>MB R2W 1A8<br>CAN",
    "addressPlain": "551 MACHRAY AVE WINNIPEG\\nMB R2W 1A8\\nCAN"
  },
  {
    "id": "6891",
    "uic": "6891",
    "abbrevCFR": "UOI CHILLIWACK",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (PACIFIQUE) DÉTACHMENT CHILLIWACK",
    "addressHtml": "5535 KOREA RD CHILLIWACK<br>BC V2R 5P2<br>CAN",
    "addressPlain": "5535 KOREA RD CHILLIWACK\\nBC V2R 5P2\\nCAN"
  },
  {
    "id": "5008",
    "uic": "5008",
    "abbrevCFR": "12 RBC M",
    "officialName": "12E RÉGIMENT BLINDÉ DU CANADA (MILICE)",
    "addressHtml": "574 ST-FRANCOIS-XAVIER TROIS-RIVIERES<br>QC G9A 1R6<br>CAN",
    "addressPlain": "574 ST-FRANCOIS-XAVIER TROIS-RIVIERES\\nQC G9A 1R6\\nCAN"
  },
  {
    "id": "5022",
    "uic": "5022",
    "abbrevCFR": "3 RAC",
    "officialName": "3E RÉGIMENT D'ARTILLERIE DE CAMPAGNE (THE LOYAL COMPANY), ARC",
    "addressHtml": "60 BROADVIEW AVE SAINT JOHN<br>NB E2L 5C5<br>CAN",
    "addressPlain": "60 BROADVIEW AVE SAINT JOHN\\nNB E2L 5C5\\nCAN"
  },
  {
    "id": "6266",
    "uic": "6266",
    "abbrevCFR": "37 SBn StJ",
    "officialName": "DÉTACHEMENT SAINT JOHN, 37E BATAILLON DES SERVICES",
    "addressHtml": "60 BROADVIEW AVE SAINT JOHN<br>NB E2L 5C5<br>CAN",
    "addressPlain": "60 BROADVIEW AVE SAINT JOHN\\nNB E2L 5C5\\nCAN"
  },
  {
    "id": "6720",
    "uic": "6720",
    "abbrevCFR": "37 SR Dét",
    "officialName": "DÉTACHEMENT SAINT JOHN, 37E RÉGIMENT DES TRANSMISSIONS",
    "addressHtml": "60 BROADVIEW AVE SAINT JOHN<br>NB E2L 5C5<br>CAN",
    "addressPlain": "60 BROADVIEW AVE SAINT JOHN\\nNB E2L 5C5\\nCAN"
  },
  {
    "id": "4999",
    "uic": "4999",
    "abbrevCFR": "1 Hôp OTTA",
    "officialName": "1ER HÔPITAL DE CAMPAGNE DU CANADA DÉTACHEMENT OTTAWA",
    "addressHtml": "60 MOODIE DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "60 MOODIE DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3373",
    "uic": "3373",
    "abbrevCFR": "CEMFA CHEF",
    "officialName": "D'ÉTAT-MAJOR DE LA FORCE AÉRIENNE",
    "addressHtml": "60 MOODIE DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "60 MOODIE DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3639",
    "uic": "3639",
    "abbrevCFR": "C PROG",
    "officialName": "CHEF DE PROGRAMME",
    "addressHtml": "60 MOODIE DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "60 MOODIE DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3304",
    "uic": "3304",
    "abbrevCFR": "QG Gp SVC",
    "officialName": "QUARTIER GÉNÉRAL DU GROUPE DES SERVICES DE SANTÉ DES FORCES CANADIENNES",
    "addressHtml": "60 MOODIE DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "60 MOODIE DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6454",
    "uic": "6454",
    "abbrevCFR": "CDF CHEF",
    "officialName": "DE DÉVELOPEMENT DES FORCES",
    "addressHtml": "60 MOODIE DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "60 MOODIE DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0000010019",
    "uic": "0000010019",
    "abbrevCFR": "DICM DIRECTEUR",
    "officialName": "- INTÉGRATION DES CAPACITÉS DE MUNITIONS",
    "addressHtml": "60 MOODIE DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "60 MOODIE DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "8347",
    "uic": "8347",
    "abbrevCFR": "DGO DIRECTEUR",
    "officialName": "GÉNÉRAL - OPÉRATIONS",
    "addressHtml": "60 MOODIE DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "60 MOODIE DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0150",
    "uic": "0150",
    "abbrevCFR": "VCEMAD VICE-CHEF",
    "officialName": "D'ÉTAT-MAJOR ADJOINT DE LA DÉFENSE",
    "addressHtml": "60 MOODIE DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "60 MOODIE DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6594",
    "uic": "6594",
    "abbrevCFR": "C S",
    "officialName": "OUTCAN (URS) COORDINATION ET SOUTIEN HORS CANADA",
    "addressHtml": "60 MOODIE DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "60 MOODIE DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6444",
    "uic": "6444",
    "abbrevCFR": "EMIS ÉTAT-MAJOR",
    "officialName": "INTERARMÉES STRATÉGIQUE",
    "addressHtml": "60 MOODIE DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "60 MOODIE DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0159",
    "uic": "0159",
    "abbrevCFR": "VCEMD VICE-CHEF D'ÉTAT-MAJOR DE",
    "officialName": "LA DÉFENSE",
    "addressHtml": "60 MOODIE DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "60 MOODIE DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "1931",
    "uic": "1931",
    "abbrevCFR": "1 Unité",
    "officialName": "de 1RE UNITÉ DENTAIRE",
    "addressHtml": "60 MOODIE DRIVE, BLDG 8 NEPEAN<br>ON K1A 0K6<br>CAN",
    "addressPlain": "60 MOODIE DRIVE, BLDG 8 NEPEAN\\nON K1A 0K6\\nCAN"
  },
  {
    "id": "2255",
    "uic": "2255",
    "abbrevCFR": "SSPFC OTTA",
    "officialName": "SECTON DU SERVICE POSTALE DES FORCES CANADIENNES OTTAWA",
    "addressHtml": "60 MOODIE DRIVE, BLDG 8 NEPEAN<br>ON K1A 0K6<br>CAN",
    "addressPlain": "60 MOODIE DRIVE, BLDG 8 NEPEAN\\nON K1A 0K6\\nCAN"
  },
  {
    "id": "3697",
    "uic": "3697",
    "abbrevCFR": "DSCN DÉTACHEMENT",
    "officialName": "SPATIAL CANADIEN DU NORAD",
    "addressHtml": "6080 11TH STREET SUITE 125 VANDENBERG AFB<br>CA 93437<br>USA",
    "addressPlain": "6080 11TH STREET SUITE 125 VANDENBERG AFB\\nCA 93437\\nUSA"
  },
  {
    "id": "4895",
    "uic": "4895",
    "abbrevCFR": "PMR ATLANT",
    "officialName": "PROCURER MILITAIRE REGION DE L'ATLANTIQUE",
    "addressHtml": "6080 YOUNG STREET, SUITE 506 HALIFAX<br>NS B3K 5L2<br>CAN",
    "addressPlain": "6080 YOUNG STREET, SUITE 506 HALIFAX\\nNS B3K 5L2\\nCAN"
  },
  {
    "id": "5012",
    "uic": "5012",
    "abbrevCFR": "BCR THE",
    "officialName": "BRITISH COLUMBIA REGIMENT (DUKE OF CONNAUGHT'S OWN)",
    "addressHtml": "620 BEATTY ST VANCOUVER<br>BC V6B 2L9<br>CAN",
    "addressPlain": "620 BEATTY ST VANCOUVER\\nBC V6B 2L9\\nCAN"
  },
  {
    "id": "6674",
    "uic": "6674",
    "abbrevCFR": "UPM BORDEN",
    "officialName": "UNITÉ DE LA POLICE MILITAIRE BORDEN",
    "addressHtml": "620 ORTONA RD BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "620 ORTONA RD BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "0005",
    "uic": "0005",
    "abbrevCFR": "CRFC VANCO",
    "officialName": "CENTRE DE RECRUTEMENT DES FORCES CANADIENNES VANCOUVER",
    "addressHtml": "620 ROYAL AVE NEW WESTMINSTER<br>BC V3M 1J2<br>CAN",
    "addressPlain": "620 ROYAL AVE NEW WESTMINSTER\\nBC V3M 1J2\\nCAN"
  },
  {
    "id": "5167",
    "uic": "5167",
    "abbrevCFR": "23 Amb C",
    "officialName": "23E AMBULANCE DE CAMPAGNE (HAMILTON)",
    "addressHtml": "650 CATHARINE ST N HAMILTON<br>ON L8L 4V7<br>CAN",
    "addressPlain": "650 CATHARINE ST N HAMILTON\\nON L8L 4V7\\nCAN"
  },
  {
    "id": "5235",
    "uic": "5235",
    "abbrevCFR": "31 SBn Ham",
    "officialName": "DÉTACHEMENT HAMILTON, 31E BATAILLON DES SERVICES",
    "addressHtml": "650 CATHARINE ST N HAMILTON<br>ON L8L 4V7<br>CAN",
    "addressPlain": "650 CATHARINE ST N HAMILTON\\nON L8L 4V7\\nCAN"
  },
  {
    "id": "1329",
    "uic": "1329",
    "abbrevCFR": "NCSM STAR",
    "officialName": "NAVIRE CANADIAN DE SA MAJESTÉ STAR",
    "addressHtml": "650 CATHARINE ST N HAMILTON<br>ON L8L 4V7<br>CAN",
    "addressPlain": "650 CATHARINE ST N HAMILTON\\nON L8L 4V7\\nCAN"
  },
  {
    "id": "1930",
    "uic": "1930",
    "abbrevCFR": "1 U",
    "officialName": "Dent Det Mtl 1ER UNITÉ DENTAIRE DÉTACHEMENT LONGUE POINTE",
    "addressHtml": "6560 HOCHELAGA ST MONTREAL<br>QC H1N 1X9<br>CAN",
    "addressPlain": "6560 HOCHELAGA ST MONTREAL\\nQC H1N 1X9\\nCAN"
  },
  {
    "id": "1985",
    "uic": "1985",
    "abbrevCFR": "202 DA",
    "officialName": "202E DÉPÔT D'ATELIERS",
    "addressHtml": "6560 HOCHELAGA ST MONTREAL<br>QC H1N 1X9<br>CAN",
    "addressPlain": "6560 HOCHELAGA ST MONTREAL\\nQC H1N 1X9\\nCAN"
  },
  {
    "id": "1941",
    "uic": "1941",
    "abbrevCFR": "25 DAFC",
    "officialName": "25E DÉPOT D'APPROVISIONNEMENT DES FORCES CANADIENNES",
    "addressHtml": "6560 HOCHELAGA ST MONTREAL<br>QC H1N 1X9<br>CAN",
    "addressPlain": "6560 HOCHELAGA ST MONTREAL\\nQC H1N 1X9\\nCAN"
  },
  {
    "id": "3162",
    "uic": "3162",
    "abbrevCFR": "3 USC",
    "officialName": "3E UNITÉ DE SOUTIEN DU CANADA",
    "addressHtml": "6560 HOCHELAGA ST MONTREAL<br>QC H1N 1X9<br>CAN",
    "addressPlain": "6560 HOCHELAGA ST MONTREAL\\nQC H1N 1X9\\nCAN"
  },
  {
    "id": "5050",
    "uic": "5050",
    "abbrevCFR": "34 RGC",
    "officialName": "34E RÉGIMENT DU GÉNIE DE COMBAT",
    "addressHtml": "6560 HOCHELAGA ST MONTREAL<br>QC H1N 1X9<br>CAN",
    "addressPlain": "6560 HOCHELAGA ST MONTREAL\\nQC H1N 1X9\\nCAN"
  },
  {
    "id": "2479",
    "uic": "2479",
    "abbrevCFR": "4 UCMFC",
    "officialName": "4E UNITÉ DE CONTRÔLE DES MOUVEMENTS DES FORCES CANADIENNES",
    "addressHtml": "6560 HOCHELAGA ST MONTREAL<br>QC H1N 1X9<br>CAN",
    "addressPlain": "6560 HOCHELAGA ST MONTREAL\\nQC H1N 1X9\\nCAN"
  },
  {
    "id": "6819",
    "uic": "6819",
    "abbrevCFR": "Svc TI",
    "officialName": "ESCADRON DES TRANSMISSIONS DU GROUPE DE SOUTIEN DE LA 2E DIVISON DU CANADA",
    "addressHtml": "6560 HOCHELAGA ST MONTREAL<br>QC H1N 1X9<br>CAN",
    "addressPlain": "6560 HOCHELAGA ST MONTREAL\\nQC H1N 1X9\\nCAN"
  },
  {
    "id": "0311",
    "uic": "0311",
    "abbrevCFR": "RAQDN Mtl",
    "officialName": "WORKCENTRE DE L'ASSURANCE DE QUALITÉ (QUÉBEC)",
    "addressHtml": "6560 HOCHELAGA ST MONTREAL<br>QC H1N 1X9<br>CAN",
    "addressPlain": "6560 HOCHELAGA ST MONTREAL\\nQC H1N 1X9\\nCAN"
  },
  {
    "id": "6844",
    "uic": "6844",
    "abbrevCFR": "UOI (Quebec)",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (QUÉBEC)",
    "addressHtml": "6560 HOCHELAGA ST MONTREAL<br>QC H1N 1X9<br>CAN",
    "addressPlain": "6560 HOCHELAGA ST MONTREAL\\nQC H1N 1X9\\nCAN"
  },
  {
    "id": "6975",
    "uic": "6975",
    "abbrevCFR": "CT Mtl",
    "officialName": "CENTRE DE TRANSITION MONTRÉAL",
    "addressHtml": "6560 HOCHELAGA ST MONTREAL<br>QC H1N 1X9<br>CAN",
    "addressPlain": "6560 HOCHELAGA ST MONTREAL\\nQC H1N 1X9\\nCAN"
  },
  {
    "id": "2825",
    "uic": "2825",
    "abbrevCFR": "AJAG Est",
    "officialName": "ASSISTANT AU JUGE-AVOCAT GÉNÉRAL DE L'EST",
    "addressHtml": "6560 HOCHELAGA ST BLDG 214 MONTREAL<br>QC H1N 1X9<br>CAN",
    "addressPlain": "6560 HOCHELAGA ST BLDG 214 MONTREAL\\nQC H1N 1X9\\nCAN"
  },
  {
    "id": "1327",
    "uic": "1327",
    "abbrevCFR": "NCSM YORK",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ YORK",
    "addressHtml": "659 LAKESHORE BLVD W TORONTO<br>ON M5V 1A7<br>CAN",
    "addressPlain": "659 LAKESHORE BLVD W TORONTO\\nON M5V 1A7\\nCAN"
  },
  {
    "id": "5132",
    "uic": "5132",
    "abbrevCFR": "TOR SCOT R",
    "officialName": "THE TORONTO SCOTTISH REGIMENT (QUEEN ELIZABETH THE QUEEN MOTHER'S OWN)",
    "addressHtml": "66 BIRMINGHAM ST TORONTO<br>ON M8V 3W6<br>CAN",
    "addressPlain": "66 BIRMINGHAM ST TORONTO\\nON M8V 3W6\\nCAN"
  },
  {
    "id": "6705",
    "uic": "6705",
    "abbrevCFR": "32 Régt tr",
    "officialName": "32E RÉGIMENT DES TRANSMISSIONS",
    "addressHtml": "660 FLEET ST W TORONTO<br>ON M5V 1A9<br>CAN",
    "addressPlain": "660 FLEET ST W TORONTO\\nON M5V 1A9\\nCAN"
  },
  {
    "id": "5006",
    "uic": "5006",
    "abbrevCFR": "QY RANG",
    "officialName": "THE QUEEN'S YORK RANGERS (1ST AMERICAN REGIMENT) (RCAC)",
    "addressHtml": "660 FLEET ST W TORONTO<br>ON M5V 1A9<br>CAN",
    "addressPlain": "660 FLEET ST W TORONTO\\nON M5V 1A9\\nCAN"
  },
  {
    "id": "5088",
    "uic": "5088",
    "abbrevCFR": "R REGT OF",
    "officialName": "THE ROYAL REGIMENT OF CANADA",
    "addressHtml": "660 FLEET ST W TORONTO<br>ON M5V 1A9<br>CAN",
    "addressPlain": "660 FLEET ST W TORONTO\\nON M5V 1A9\\nCAN"
  },
  {
    "id": "5027",
    "uic": "5027",
    "abbrevCFR": "11 RAC",
    "officialName": "11E RÉGIMENT D'ARTILLERIE DE CAMPAGNE, ARC",
    "addressHtml": "7 WYNDHAM ST S GUELPH<br>ON N1H 4C4<br>CAN",
    "addressPlain": "7 WYNDHAM ST S GUELPH\\nON N1H 4C4\\nCAN"
  },
  {
    "id": "7806",
    "uic": "7806",
    "abbrevCFR": "1405",
    "officialName": "CCRAC",
    "addressHtml": "1405 POLICE MILITAIRE CORPS DE CADETS ROYAUX DE L'ARMÉE CANADIENNE 70 Bales Dr. E, East Gwillimbury<br>ON L0G 1V0<br>CAN",
    "addressPlain": "1405 POLICE MILITAIRE CORPS DE CADETS ROYAUX DE L'ARMÉE CANADIENNE 70 Bales Dr. E, East Gwillimbury\\nON L0G 1V0\\nCAN"
  },
  {
    "id": "0017",
    "uic": "0017",
    "abbrevCFR": "CRFC Qc Det Rim",
    "officialName": "DÉTACHEMENT RIMOUSKI, CENTRE DE RECRUTEMENT DES FORCES CANADIENNES QUÉBEC",
    "addressHtml": "70 RUE ST-GERMAIN EST SUITE 025 RIMOUSKI<br>QC G5L 7J9<br>CAN",
    "addressPlain": "70 RUE ST-GERMAIN EST SUITE 025 RIMOUSKI\\nQC G5L 7J9\\nCAN"
  },
  {
    "id": "6717",
    "uic": "6717",
    "abbrevCFR": "35 Regt",
    "officialName": "Trans Det Sher DÉTACHEMENT SHERBROOKE, 35E RÉGIMENT DES TRANSMISSIONS",
    "addressHtml": "700 RUE WOODWARD SHERBROOKE<br>QC J1G 1W3<br>CAN",
    "addressPlain": "700 RUE WOODWARD SHERBROOKE\\nQC J1G 1W3\\nCAN"
  },
  {
    "id": "5162",
    "uic": "5162",
    "abbrevCFR": "52 Amb C",
    "officialName": "52E AMBULANCE DE CAMPAGNE (SHERBROOKE)",
    "addressHtml": "700 RUE WOODWARD SHERBROOKE<br>QC J1G 1W3<br>CAN",
    "addressPlain": "700 RUE WOODWARD SHERBROOKE\\nQC J1G 1W3\\nCAN"
  },
  {
    "id": "5126",
    "uic": "5126",
    "abbrevCFR": "Fus de",
    "officialName": "Sher LES FUSILIERS DE SHERBROOKE",
    "addressHtml": "700 RUE WOODWARD SHERBROOKE<br>QC J1G 1W3<br>CAN",
    "addressPlain": "700 RUE WOODWARD SHERBROOKE\\nQC J1G 1W3\\nCAN"
  },
  {
    "id": "5007",
    "uic": "5007",
    "abbrevCFR": "Sher H",
    "officialName": "THE SHERBROOKE HUSSARS",
    "addressHtml": "700 RUE WOODWARD SHERBROOKE<br>QC J1G 1W3<br>CAN",
    "addressPlain": "700 RUE WOODWARD SHERBROOKE\\nQC J1G 1W3\\nCAN"
  },
  {
    "id": "5009",
    "uic": "5009",
    "abbrevCFR": "1 H",
    "officialName": "1ST HUSSARS",
    "addressHtml": "701 OXFORD ST. EAST LONDON<br>ON N5Y 4T7<br>CAN",
    "addressPlain": "701 OXFORD ST. EAST LONDON\\nON N5Y 4T7\\nCAN"
  },
  {
    "id": "3657",
    "uic": "3657",
    "abbrevCFR": "QG 31 CBG",
    "officialName": "QUARTIER GÉNÉRAL DU 31E GROUPE-BRIGADE DU CANADA",
    "addressHtml": "701 OXFORD ST. EAST LONDON<br>ON N5Y 4T7<br>CAN",
    "addressPlain": "701 OXFORD ST. EAST LONDON\\nON N5Y 4T7\\nCAN"
  },
  {
    "id": "6698",
    "uic": "6698",
    "abbrevCFR": "31 Bon Svc",
    "officialName": "31E BATAILLON DES SERVICES",
    "addressHtml": "701 OXFORD ST. EAST LONDON<br>ON N5Y 4T7<br>CAN",
    "addressPlain": "701 OXFORD ST. EAST LONDON\\nON N5Y 4T7\\nCAN"
  },
  {
    "id": "4042",
    "uic": "4042",
    "abbrevCFR": "CI 4 DC DE",
    "officialName": "DÉTACHEMENT LONDON, CENTRE D'INSTRUCTION DE LA 4E DIVISION DU CANADA",
    "addressHtml": "701 OXFORD ST. EAST LONDON<br>ON N5Y 4T7<br>CAN",
    "addressPlain": "701 OXFORD ST. EAST LONDON\\nON N5Y 4T7\\nCAN"
  },
  {
    "id": "5093",
    "uic": "5093",
    "abbrevCFR": "4 RCR 4BATTALION,",
    "officialName": "THE ROYAL CANADIAN REGIMENT",
    "addressHtml": "701 OXFORD ST. EAST LONDON<br>ON N5Y 4T7<br>CAN",
    "addressPlain": "701 OXFORD ST. EAST LONDON\\nON N5Y 4T7\\nCAN"
  },
  {
    "id": "3948",
    "uic": "3948",
    "abbrevCFR": "Dét London",
    "officialName": "DÉTACHEMENT LONDON 32E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES",
    "addressHtml": "701 OXFORD ST. EAST LONDON<br>ON N5Y 4T7<br>CAN",
    "addressPlain": "701 OXFORD ST. EAST LONDON\\nON N5Y 4T7\\nCAN"
  },
  {
    "id": "6305",
    "uic": "6305",
    "abbrevCFR": "Dét London",
    "officialName": "DÉTACHEMENT LONDON 23E AMBULANCE DE CAMPAGNE (HAMILTON)",
    "addressHtml": "701 OXFORD ST. EAST LONDON<br>ON N5Y 4T7<br>CAN",
    "addressPlain": "701 OXFORD ST. EAST LONDON\\nON N5Y 4T7\\nCAN"
  },
  {
    "id": "0372",
    "uic": "0372",
    "abbrevCFR": "URSC(C) LO",
    "officialName": "UNITÉ RÉGIONALE DE SOUTIEN AUX CADETS (CENTRE) DÉTACHEMENT LONDON",
    "addressHtml": "701 OXFORD ST. EAST LONDON<br>ON N5Y 4T7<br>CAN",
    "addressPlain": "701 OXFORD ST. EAST LONDON\\nON N5Y 4T7\\nCAN"
  },
  {
    "id": "6750",
    "uic": "6750",
    "abbrevCFR": "CT LONDON",
    "officialName": "CENTRE DE TRANSITION LONDON",
    "addressHtml": "701 OXFORD ST. EAST LONDON<br>ON N5Y 4T7<br>CAN",
    "addressPlain": "701 OXFORD ST. EAST LONDON\\nON N5Y 4T7\\nCAN"
  },
  {
    "id": "6142",
    "uic": "6142",
    "abbrevCFR": "5 RAC",
    "officialName": "5E RÉGIMENT D'ARTILLERIE DE CAMPAGNE (COLOMBIE-BRITANNIQUE), ARC",
    "addressHtml": "715 BAY ST VICTORIA<br>BC V8T 1R1<br>CAN",
    "addressPlain": "715 BAY ST VICTORIA\\nBC V8T 1R1\\nCAN"
  },
  {
    "id": "5129",
    "uic": "5129",
    "abbrevCFR": "C SCOT Régt",
    "officialName": "THE CANADIAN SCOTTISH REGIMENT (PRINCESS MARY'S)",
    "addressHtml": "715 BAY ST VICTORIA<br>BC V8T 1R1<br>CAN",
    "addressPlain": "715 BAY ST VICTORIA\\nBC V8T 1R1\\nCAN"
  },
  {
    "id": "5017",
    "uic": "5017",
    "abbrevCFR": "BCD THE",
    "officialName": "BRITISH COLUMBIA DRAGOONS",
    "addressHtml": "720 LAWRENCE AVE KELOWNA<br>BC V1Y 6L9<br>CAN",
    "addressPlain": "720 LAWRENCE AVE KELOWNA\\nBC V1Y 6L9\\nCAN"
  },
  {
    "id": "5262",
    "uic": "5262",
    "abbrevCFR": "11 Amb C",
    "officialName": "11E AMBULANCE DE CAMPAGNE (VICTORIA)",
    "addressHtml": "724 VANALMAN AVE VICTORIA<br>BC V8Z 3B5<br>CAN",
    "addressPlain": "724 VANALMAN AVE VICTORIA\\nBC V8Z 3B5\\nCAN"
  },
  {
    "id": "5250",
    "uic": "5250",
    "abbrevCFR": "39 SBn",
    "officialName": "Vic DÉTACHMENT VICTORIA, 39E BATAILLION DES SERVICES",
    "addressHtml": "724 VANALMAN AVE VICTORIA<br>BC V8Z 3B5<br>CAN",
    "addressPlain": "724 VANALMAN AVE VICTORIA\\nBC V8Z 3B5\\nCAN"
  },
  {
    "id": "4233",
    "uic": "4233",
    "abbrevCFR": "552 ACW CC",
    "officialName": "CANADIAN DETACHMENT",
    "addressHtml": "552 AIR CONTROL WING 7556 SENTRY BLVD SUITE 37 OKLAHOMA CITY OK<br>73145<br>USA",
    "addressPlain": "552 AIR CONTROL WING 7556 SENTRY BLVD SUITE 37 OKLAHOMA CITY OK\\n73145\\nUSA"
  },
  {
    "id": "5099",
    "uic": "5099",
    "abbrevCFR": "Fus du",
    "officialName": "St-L LES FUSILIERS DU ST-LAURENT",
    "addressHtml": "77, 2IEME RUE OUEST RIMOUSKI<br>QC G5L 4X3<br>CAN",
    "addressPlain": "77, 2IEME RUE OUEST RIMOUSKI\\nQC G5L 4X3\\nCAN"
  },
  {
    "id": "5087",
    "uic": "5087",
    "abbrevCFR": "Voltigeurs LES",
    "officialName": "VOLTIGEURS DE QUÉBEC",
    "addressHtml": "805 AVENUE WILFRID-LAURIER QUEBEC<br>QC G1R 2L3<br>CAN",
    "addressPlain": "805 AVENUE WILFRID-LAURIER QUEBEC\\nQC G1R 2L3\\nCAN"
  },
  {
    "id": "5092",
    "uic": "5092",
    "abbrevCFR": "LINC & WEL",
    "officialName": "THE LINCOLN AND WELLAND REGIMENT",
    "addressHtml": "81 LAKE ST ST CATHARINES<br>ON L2R 5X3<br>CAN",
    "addressPlain": "81 LAKE ST ST CATHARINES\\nON L2R 5X3\\nCAN"
  },
  {
    "id": "6706",
    "uic": "6706",
    "abbrevCFR": "35 Regt Trans",
    "officialName": "35E RÉGIMENT DES TRANSMISSIONS",
    "addressHtml": "835 BOUL PIERRE-BERTRAND QUEBEC<br>QC G1M 2E7<br>CAN",
    "addressPlain": "835 BOUL PIERRE-BERTRAND QUEBEC\\nQC G1M 2E7\\nCAN"
  },
  {
    "id": "0176",
    "uic": "0176",
    "abbrevCFR": "QG RESNAV",
    "officialName": "QUARTIER GÉNÉRAL DE LA RÉSERVE NAVALE",
    "addressHtml": "835 BOULEVARD PIERRE-BERTRAND QUEBEC<br>QC G1M 2E7<br>CAN",
    "addressPlain": "835 BOULEVARD PIERRE-BERTRAND QUEBEC\\nQC G1M 2E7\\nCAN"
  },
  {
    "id": "0555",
    "uic": "0555",
    "abbrevCFR": "CCP(Q) CENTRE",
    "officialName": "DE CONTRÔLE DU PERSONNEL (QUÉBEC)",
    "addressHtml": "835 BOULEVARD PIERRE-BERTRAND NAVAL RESERVE HEADQUARTERS QUEBEC<br>QC G1M 2E7<br>CAN",
    "addressPlain": "835 BOULEVARD PIERRE-BERTRAND NAVAL RESERVE HEADQUARTERS QUEBEC\\nQC G1M 2E7\\nCAN"
  },
  {
    "id": "1538",
    "uic": "1538",
    "abbrevCFR": "NCSM D'Iberville",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ D'IBERVILLE",
    "addressHtml": "84 MONTEE INDUSTRIELLE-ET-COMMERCIALE RIMOUSKI<br>QC G5M 1B1<br>CAN",
    "addressPlain": "84 MONTEE INDUSTRIELLE-ET-COMMERCIALE RIMOUSKI\\nQC G5M 1B1\\nCAN"
  },
  {
    "id": "5057",
    "uic": "5057",
    "abbrevCFR": "41 RGC",
    "officialName": "41E RÉGIMENT DU GÉNIE DE COMBAT",
    "addressHtml": "8403 ROPER ROAD EDMONTON<br>AB T6E 6T5<br>CAN",
    "addressPlain": "8403 ROPER ROAD EDMONTON\\nAB T6E 6T5\\nCAN"
  },
  {
    "id": "6711",
    "uic": "6711",
    "abbrevCFR": "41 Régt trans",
    "officialName": "41E RÉGIMENT DES TRANSMISSIONS",
    "addressHtml": "8403 ROPER ROAD EDMONTON<br>AB T6E 6T5<br>CAN",
    "addressPlain": "8403 ROPER ROAD EDMONTON\\nAB T6E 6T5\\nCAN"
  },
  {
    "id": "0604",
    "uic": "0604",
    "abbrevCFR": "JBLM BASE",
    "officialName": "COMMUNE DU DÉTACHEMENT CANADIEN LEWIS-MCCHORD",
    "addressHtml": "852 LINCOLN BLVD MCCHORD AFB<br>WA 984381317<br>USA",
    "addressPlain": "852 LINCOLN BLVD MCCHORD AFB\\nWA 984381317\\nUSA"
  },
  {
    "id": "4079",
    "uic": "4079",
    "abbrevCFR": "D Ch'town",
    "officialName": "DÉTACHEMENT CHARLOTTETOWN, BASE DE SOUTIEN DE LA 5E DIVISION DU CANADA, GAGETOWN",
    "addressHtml": "88 WATTS AVE CHARLOTTETOWN<br>PE C1E 2C1<br>CAN",
    "addressPlain": "88 WATTS AVE CHARLOTTETOWN\\nPE C1E 2C1\\nCAN"
  },
  {
    "id": "5010",
    "uic": "5010",
    "abbrevCFR": "PEI Regt",
    "officialName": "THE PRINCE EDWARD ISLAND REGIMENT (CBRC)",
    "addressHtml": "88 WATTS AVE CHARLOTTETOWN<br>PE C1E 2C1<br>CAN",
    "addressPlain": "88 WATTS AVE CHARLOTTETOWN\\nPE C1E 2C1\\nCAN"
  },
  {
    "id": "1328",
    "uic": "1328",
    "abbrevCFR": "NCSM HUNTE",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ HUNTER",
    "addressHtml": "90 MILL STREET WINDSOR<br>ON N9C 0C9<br>CAN",
    "addressPlain": "90 MILL STREET WINDSOR\\nON N9C 0C9\\nCAN"
  },
  {
    "id": "6697",
    "uic": "6697",
    "abbrevCFR": "38 RGC",
    "officialName": "38E RÉGIMENT DU GÉNIE DE COMBAT",
    "addressHtml": "930 IDYLWYLD DR SASKATOON<br>SK S7L 0Z6<br>CAN",
    "addressPlain": "930 IDYLWYLD DR SASKATOON\\nSK S7L 0Z6\\nCAN"
  },
  {
    "id": "5119",
    "uic": "5119",
    "abbrevCFR": "Régt Sask Nord",
    "officialName": "THE NORTH SASKATCHEWAN REGIMENT",
    "addressHtml": "930 IDYLWYLD DR SASKATOON<br>SK S7L 0Z6<br>CAN",
    "addressPlain": "930 IDYLWYLD DR SASKATOON\\nSK S7L 0Z6\\nCAN"
  },
  {
    "id": "2711",
    "uic": "2711",
    "abbrevCFR": "CETM CENTRE",
    "officialName": "D'ESSAIS TECHNIQUES (MER)",
    "addressHtml": "9401 WANKLYN ST LA SALLE<br>QC H8R 1Z2<br>CAN",
    "addressPlain": "9401 WANKLYN ST LA SALLE\\nQC H8R 1Z2\\nCAN"
  },
  {
    "id": "0603",
    "uic": "0603",
    "abbrevCFR": "JBER BASE",
    "officialName": "COMMUNE DU DÉTACHEMENT CANADIEN ELMENDORF-RICHARDSON",
    "addressHtml": "9477 PEASE AVENUE JOINT BASE ELMENDORF-RICHARDSON (JBER) ELMENDORF AFB<br>AK 99506<br>USA",
    "addressPlain": "9477 PEASE AVENUE JOINT BASE ELMENDORF-RICHARDSON (JBER) ELMENDORF AFB\\nAK 99506\\nUSA"
  },
  {
    "id": "5169",
    "uic": "5169",
    "abbrevCFR": "17 Amb C",
    "officialName": "17E AMBULANCE DE CAMPAGNE (WINNIPEG)",
    "addressHtml": "969 ST MATTHEWS AVE WINNIPEG<br>MB R3G 0J7<br>CAN",
    "addressPlain": "969 ST MATTHEWS AVE WINNIPEG\\nMB R3G 0J7\\nCAN"
  },
  {
    "id": "5233",
    "uic": "5233",
    "abbrevCFR": "38 SBn Win",
    "officialName": "DÉTACHEMENT WINNIPEG, 38E BATAILLION DES SERVICES",
    "addressHtml": "969 ST MATTHEWS AVE WINNIPEG<br>MB R3G 0J7<br>CAN",
    "addressPlain": "969 ST MATTHEWS AVE WINNIPEG\\nMB R3G 0J7\\nCAN"
  },
  {
    "id": "6709",
    "uic": "6709",
    "abbrevCFR": "38 Régt trans",
    "officialName": "38E RÉGIMENT DES TRANSMSISSIONS",
    "addressHtml": "969 ST MATTHEWS AVE WINNIPEG<br>MB R3G 0J7<br>CAN",
    "addressPlain": "969 ST MATTHEWS AVE WINNIPEG\\nMB R3G 0J7\\nCAN"
  },
  {
    "id": "6702",
    "uic": "6702",
    "abbrevCFR": "38 Bon Svc",
    "officialName": "38E BATAILLON DES SERVICES",
    "addressHtml": "969 ST MATTHEWS AVE WINNIPEG<br>MB R3G 0J7<br>CAN",
    "addressPlain": "969 ST MATTHEWS AVE WINNIPEG\\nMB R3G 0J7\\nCAN"
  },
  {
    "id": "5124",
    "uic": "5124",
    "abbrevCFR": "CAMERONS O",
    "officialName": "THE QUEEN'S OWN CAMERON HIGHLANDERS OF CANADA",
    "addressHtml": "969 ST MATTHEWS AVE WINNIPEG<br>MB R3G 0J7<br>CAN",
    "addressPlain": "969 ST MATTHEWS AVE WINNIPEG\\nMB R3G 0J7\\nCAN"
  },
  {
    "id": "5112",
    "uic": "5112",
    "abbrevCFR": "R WPG RIF",
    "officialName": "THE ROYAL WINNIPEG RIFLES",
    "addressHtml": "969 ST MATTHEWS AVE WINNIPEG<br>MB R3G 0J7<br>CAN",
    "addressPlain": "969 ST MATTHEWS AVE WINNIPEG\\nMB R3G 0J7\\nCAN"
  },
  {
    "id": "5063",
    "uic": "5063",
    "abbrevCFR": "34 RGC Det Rouyn",
    "officialName": "DÉTACHEMENT ROUYN 34E RÉGIMENT DU GÉNIE DE COMBAT",
    "addressHtml": "97 RUE PERREAULT E C.P. 368, SUCCBUREAU-CHEF ROUYN NORANDA<br>QC J9X 5C4<br>CAN",
    "addressPlain": "97 RUE PERREAULT E C.P. 368, SUCCBUREAU-CHEF ROUYN NORANDA\\nQC J9X 5C4\\nCAN"
  },
  {
    "id": "0722",
    "uic": "0722",
    "abbrevCFR": "OUTCAN EUR",
    "officialName": "ACADÉMIE CANADIENNE DE LA DÉFENSE HORS CANADA - ÉTATS-UNIS ATT: ECJ4-LH (SNR CDN OFFICER ILOCEUROPE) APO NEW YORK",
    "addressHtml": "NY 091284209<br>USA",
    "addressPlain": "NY 091284209\\nUSA"
  },
  {
    "id": "6470",
    "uic": "6470",
    "abbrevCFR": "QGFOIN NUN",
    "officialName": "DÉTACHEMENT NUNAVUT QUARTIER GÉNÉRAL DE LA FORCE OPÉRATIONNELLE INTERARMÉES (NORD) BAG",
    "addressHtml": "3000 IQALUIT<br>NU X0A 0H0<br>CAN",
    "addressPlain": "3000 IQALUIT\\nNU X0A 0H0\\nCAN"
  },
  {
    "id": "0010",
    "uic": "0010",
    "abbrevCFR": "CRFC CALGARY",
    "officialName": "CENTRE DE RECRUTEMENT DES FORCES CANADIENNES CALGARY BANTREL TOWER",
    "addressHtml": "700 6TH AVE SW SUITE 100 CALGARY<br>AB T2P 0T8<br>CAN",
    "addressPlain": "700 6TH AVE SW SUITE 100 CALGARY\\nAB T2P 0T8\\nCAN"
  },
  {
    "id": "6323",
    "uic": "6323",
    "abbrevCFR": "CORFC CENTRE",
    "officialName": "D'OPÉRATIONS DES RÉSEAUX DES FORCES CANADIENNES CANADIAN FORCES STATION LEITRIM",
    "addressHtml": "3545 LEITRIM RD OTTAWA<br>ON K1A 0K4<br>CAN",
    "addressPlain": "3545 LEITRIM RD OTTAWA\\nON K1A 0K4\\nCAN"
  },
  {
    "id": "0207",
    "uic": "0207",
    "abbrevCFR": "SFC LEITRI",
    "officialName": "STATION DES FORCES CANADIENNES LEITRIM CANADIAN FORCES STATION LEITRIM",
    "addressHtml": "3545 LEITRIM RD OTTAWA<br>ON K1A 0K4<br>CAN",
    "addressPlain": "3545 LEITRIM RD OTTAWA\\nON K1A 0K4\\nCAN"
  },
  {
    "id": "0204",
    "uic": "0204",
    "abbrevCFR": "QG CYBER",
    "officialName": "QUARTIER GÉNÉRAL DU COMMANDEMENT CYBER DES FORCES CANADIENNES CANADIAN FORCES STATION LEITRIM",
    "addressHtml": "3545 LEITRIM RD OTTAWA<br>ON K1A 0K4<br>CAN",
    "addressPlain": "3545 LEITRIM RD OTTAWA\\nON K1A 0K4\\nCAN"
  },
  {
    "id": "6370",
    "uic": "6370",
    "abbrevCFR": "NATO IMS",
    "officialName": "ÉTAT-MAJOR MILITAIRE INTERNATIONAL DE L'OTAN CANADIAN INTERNATIONAL MILITARY STAFF NATO HQ BRUSSELS",
    "addressHtml": "PO BOX 5053 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5053 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "6377",
    "uic": "6377",
    "abbrevCFR": "REPCACMIL REPRÉSENTANT",
    "officialName": "DU CANADA AUPRÈS DU COMITÉ MILITAIRE CANADIAN MILITARY REP TO THE NATO MIL COMMITTEE NATO HQ BRUSSELS POBOX",
    "addressHtml": "5053 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "5053 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "0891",
    "uic": "0891",
    "abbrevCFR": "FO EL GORA",
    "officialName": "FORCE OPÉRATIONELLE EL GORAH CCMFO",
    "addressHtml": "PO BOX 5237 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5237 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "6315",
    "uic": "6315",
    "abbrevCFR": "FO TAMPA",
    "officialName": "FORCE OPÉRATIONELLE TAMPA COALITION CV-3 ATTN: CANADA 7115SOUTH BOUNDARY",
    "addressHtml": "BLVD MACDILL AFB<br>FL 33621<br>USA",
    "addressPlain": "BLVD MACDILL AFB\\nFL 33621\\nUSA"
  },
  {
    "id": "1319",
    "uic": "1319",
    "abbrevCFR": "1ULLFC SAN",
    "officialName": "1ER UNITÉ DE LIAISON LOGISTIQUE DES FORCES CANADIENNES DÉTACHEMENT SAN DIEGO CODE 300E BLDG 94B",
    "addressHtml": "PO BOX 357058NAVAL AVIATION DEPOT NORTH ISLAND SAN DIEGO<br>CA 921357058<br>USA",
    "addressPlain": "PO BOX 357058NAVAL AVIATION DEPOT NORTH ISLAND SAN DIEGO\\nCA 921357058\\nUSA"
  },
  {
    "id": "5242",
    "uic": "5242",
    "abbrevCFR": "35 Bon Svc",
    "officialName": "35E BATAILLON DES SERVICES",
    "addressHtml": "COMPLEXE MILITAIRE SAINT-MALO 1020 RUE VINCENT-MASSEY QUEBEC<br>QC G1N 1M8<br>CAN",
    "addressPlain": "COMPLEXE MILITAIRE SAINT-MALO 1020 RUE VINCENT-MASSEY QUEBEC\\nQC G1N 1M8\\nCAN"
  },
  {
    "id": "5161",
    "uic": "5161",
    "abbrevCFR": "55 Amb C",
    "officialName": "55E AMBULANCE DE CAMPAGNE (QUÉBEC)",
    "addressHtml": "COMPLEXE MILITAIRE SAINT-MALO 1020 RUE VINCENT-MASSEY QUEBEC<br>QC G1N 1M8<br>CAN",
    "addressPlain": "COMPLEXE MILITAIRE SAINT-MALO 1020 RUE VINCENT-MASSEY QUEBEC\\nQC G1N 1M8\\nCAN"
  },
  {
    "id": "2181",
    "uic": "2181",
    "abbrevCFR": "DGSGST DIRECTEUR",
    "officialName": "GÉNÉRAL - SERVICES GÉNÉRAUX (SCIENCE ET TECHNOLOGIE) CONSTITUTION BLDG",
    "addressHtml": "101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2089",
    "uic": "2089",
    "abbrevCFR": "1 U",
    "officialName": "Dent Det Sjn 1ER UNITÉ DENTAIRE DÉTACHEMENT ST-JEAN",
    "addressHtml": "CP 100 SUCC BUREAU-CHEF RICHELAIN<br>QC J0J 1R0<br>CAN",
    "addressPlain": "CP 100 SUCC BUREAU-CHEF RICHELAIN\\nQC J0J 1R0\\nCAN"
  },
  {
    "id": "3380",
    "uic": "3380",
    "abbrevCFR": "BS 2",
    "officialName": "Div CA Det St-Jean DÉTACHEMENT ST-JEAN, BASE DE SOUTIEN DE LA 2E DIVISION DU CANADA, VALCARTIER",
    "addressHtml": "CP 100 SUCC BUREAU-CHEF RICHELAIN<br>QC J0J 1R0<br>CAN",
    "addressPlain": "CP 100 SUCC BUREAU-CHEF RICHELAIN\\nQC J0J 1R0\\nCAN"
  },
  {
    "id": "3581",
    "uic": "3581",
    "abbrevCFR": "41 C",
    "officialName": "Svc S FC 41E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES",
    "addressHtml": "CP 100 SUCC BUREAU-CHEF RICHELAIN<br>QC J0J 1R0<br>CAN",
    "addressPlain": "CP 100 SUCC BUREAU-CHEF RICHELAIN\\nQC J0J 1R0\\nCAN"
  },
  {
    "id": "7009",
    "uic": "7009",
    "abbrevCFR": "438 ETAH",
    "officialName": "438E ESCADRON TACTIQUE D'HÉLICOPTÈRES",
    "addressHtml": "CP 100 SUCC BUREAU-CHEF RICHELAIN<br>QC J0J 1R0<br>CAN",
    "addressPlain": "CP 100 SUCC BUREAU-CHEF RICHELAIN\\nQC J0J 1R0\\nCAN"
  },
  {
    "id": "6771",
    "uic": "6771",
    "abbrevCFR": "77 Regt",
    "officialName": "Ligne det Sjn 77E RÉGIMENT DES LIGNES DÉTACHEMENT",
    "addressHtml": "ST JEAN CP 100 SUCC BUREAU-CHEF RICHELAIN<br>QC J0J 1R0<br>CAN",
    "addressPlain": "ST JEAN CP 100 SUCC BUREAU-CHEF RICHELAIN\\nQC J0J 1R0\\nCAN"
  },
  {
    "id": "4292",
    "uic": "4292",
    "abbrevCFR": "ERIC Est",
    "officialName": "ÉCOLE RÉGIONALE D'INSTRUCTION DES CADETS (EST)",
    "addressHtml": "CP 100 SUCC BUREAU-CHEF RICHELAIN<br>QC J0J 1R0<br>CAN",
    "addressPlain": "CP 100 SUCC BUREAU-CHEF RICHELAIN\\nQC J0J 1R0\\nCAN"
  },
  {
    "id": "3934",
    "uic": "3934",
    "abbrevCFR": "URSC Est",
    "officialName": "UNITÉ RÉGIONALE DE SOUTIEN AUX CADETS (EST)",
    "addressHtml": "CP 100 SUCC BUREAU-CHEF RICHELAIN<br>QC J0J 1R0<br>CAN",
    "addressPlain": "CP 100 SUCC BUREAU-CHEF RICHELAIN\\nQC J0J 1R0\\nCAN"
  },
  {
    "id": "2978",
    "uic": "2978",
    "abbrevCFR": "ERV Est",
    "officialName": "CENTRE D'ENTRAîNEMENT DE VOL DES CADETS ST-JEAN",
    "addressHtml": "CP 100 SUCC BUREAU-CHEF RICHELAIN<br>QC J0J 1R0<br>CAN",
    "addressPlain": "CP 100 SUCC BUREAU-CHEF RICHELAIN\\nQC J0J 1R0\\nCAN"
  },
  {
    "id": "6893",
    "uic": "6893",
    "abbrevCFR": "Det UOI St-Jean",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (QUÉBEC) DÉTACHMENT ST-JEAN",
    "addressHtml": "CP 100 SUCC BUREAU-CHEF RICHELAIN<br>QC J0J 1R0<br>CAN",
    "addressPlain": "CP 100 SUCC BUREAU-CHEF RICHELAIN\\nQC J0J 1R0\\nCAN"
  },
  {
    "id": "1014",
    "uic": "1014",
    "abbrevCFR": "QG 1",
    "officialName": "DA Det Val 2E ESCADRON D OPERATIONS D?APPUI AERIEN ESCADRILLE C",
    "addressHtml": "CP 1000 SUCC FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "CP 1000 SUCC FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "2060",
    "uic": "2060",
    "abbrevCFR": "1 U",
    "officialName": "Dent Det Val 1ER UNITÉ DENTAIRE DÉTACHEMENT VALCARTIER",
    "addressHtml": "CP 1000 SUCC FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "CP 1000 SUCC FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "1853",
    "uic": "1853",
    "abbrevCFR": "1 R22eR",
    "officialName": "1ER BATAILLON, ROYAL 22E RÉGIMENT",
    "addressHtml": "CP 1000 SUCC FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "CP 1000 SUCC FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "1012",
    "uic": "1012",
    "abbrevCFR": "QG 1",
    "officialName": "ERE Det Val DÉTACHEMENT VALCARTIER, QUARTIER GÉNÉRAL DE 1ER ESCADRE",
    "addressHtml": "CP 1000 SUCC FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "CP 1000 SUCC FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "5246",
    "uic": "5246",
    "abbrevCFR": "12 RBC",
    "officialName": "12E RÉGIMENT BLINDÉ DU CANADA",
    "addressHtml": "CP 1000 SUCC FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "CP 1000 SUCC FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "0166",
    "uic": "0166",
    "abbrevCFR": "CI 2 Div CA",
    "officialName": "CENTRE D' INSTRUCTION DE LA 2e DIVISION DU CANADA",
    "addressHtml": "CP 1000 SUCC FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "CP 1000 SUCC FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "0106",
    "uic": "0106",
    "abbrevCFR": "BS 2",
    "officialName": "Div CA Valcartier BASE DE SOUTIEN DE LA 2E DIVISION DU CANADA, VALCARTIER",
    "addressHtml": "CP 1000 SUCC FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "CP 1000 SUCC FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "1852",
    "uic": "1852",
    "abbrevCFR": "2 R22eR",
    "officialName": "2E BATAILLON, ROYAL 22E RÉGIMENT",
    "addressHtml": "CP 1000 SUCC FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "CP 1000 SUCC FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "3521",
    "uic": "3521",
    "abbrevCFR": "3 R22eR",
    "officialName": "3E BATAILLON, ROYAL 22E RÉGIMENT",
    "addressHtml": "CP 1000 SUCC FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "CP 1000 SUCC FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "2570",
    "uic": "2570",
    "abbrevCFR": "430 ETAH",
    "officialName": "430E ESCADRON TACTIQUE D'HÉLICOPTÈRES",
    "addressHtml": "CP 1000 SUCC FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "CP 1000 SUCC FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "1779",
    "uic": "1779",
    "abbrevCFR": "5 RGC",
    "officialName": "5E RÉGIMENT DU GÉNIE DE COMBAT",
    "addressHtml": "CP 1000 SUCC FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "CP 1000 SUCC FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "2106",
    "uic": "2106",
    "abbrevCFR": "5 Amb C",
    "officialName": "5E AMBULANCE DE CAMPAGNE",
    "addressHtml": "CP 1000 SUCC FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "CP 1000 SUCC FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "1735",
    "uic": "1735",
    "abbrevCFR": "5 RALC",
    "officialName": "5E RÉGIMENT D'ARTILLERIE LÉGÈRE DU CANADA",
    "addressHtml": "CP 1000 SUCC FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "CP 1000 SUCC FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "1708",
    "uic": "1708",
    "abbrevCFR": "5 Regt Trans",
    "officialName": "QUARTIER GÉNÉRAL ET ESCADRON DES TRANSMISSIONS DU 5E GROUPE-BRIGADE MÉCANISÉ DU CANADA",
    "addressHtml": "CP 1000 SUCC FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "CP 1000 SUCC FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "2107",
    "uic": "2107",
    "abbrevCFR": "5 Bon Svc",
    "officialName": "5E BATAILLON DES SERVICES",
    "addressHtml": "CP 1000 SUCC FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "CP 1000 SUCC FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "6816",
    "uic": "6816",
    "abbrevCFR": "Regt Rens AC",
    "officialName": "RÉGIMENT DU RENSEIGNEMENT DE L'ARMÉE CANADIENNE DÉTACHMENT VALCARTIER",
    "addressHtml": "CP 1000 SUCC FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "CP 1000 SUCC FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "3726",
    "uic": "3726",
    "abbrevCFR": "ALFC Val",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (VALCARTIER)",
    "addressHtml": "CP 1000 SUCC FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "CP 1000 SUCC FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "2962",
    "uic": "2962",
    "abbrevCFR": "CIECA Val",
    "officialName": "CENTRE D'ENTRAîNEMENT DES CADETS VALCARTIER",
    "addressHtml": "CP 1000 SUCC FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "CP 1000 SUCC FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "1323",
    "uic": "1323",
    "abbrevCFR": "NCSM Montcalm",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ MONTCALM",
    "addressHtml": "CP 1000 SUCC FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "CP 1000 SUCC FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "3558",
    "uic": "3558",
    "abbrevCFR": "MUS R22eR",
    "officialName": "LA MUSIQUE DU ROYAL 22E RÉGIMENT",
    "addressHtml": "CP 1000 SUCC FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "CP 1000 SUCC FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "6856",
    "uic": "6856",
    "abbrevCFR": "Det UOI Valcartier",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (QUÉBEC) DÉTACHMENT VALCARTIER",
    "addressHtml": "CP 1000 SUCC FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "CP 1000 SUCC FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "4017",
    "uic": "4017",
    "abbrevCFR": "CIEC NCSM Quebec",
    "officialName": "CENTRE D'INSTRUCTION D' ÉTÉ DES CADETS DE LA MARINE NCSM QUÉBEC",
    "addressHtml": "CP 3530 SUCC STE-ANGELE-DE-LAVAL BECANCOUR<br>QC G9H 4T1<br>CAN",
    "addressPlain": "CP 3530 SUCC STE-ANGELE-DE-LAVAL BECANCOUR\\nQC G9H 4T1\\nCAN"
  },
  {
    "id": "2092",
    "uic": "2092",
    "abbrevCFR": "Dét",
    "officialName": "B",
    "addressHtml": "1 UD 1ER UNITÉ DENTAIRE DÉTACHEMENT BAGOTVILLE CP 5000 SUCC BUREAU-CHEF ALOUETTE<br>QC G0V 1A0<br>CAN",
    "addressPlain": "1 UD 1ER UNITÉ DENTAIRE DÉTACHEMENT BAGOTVILLE CP 5000 SUCC BUREAU-CHEF ALOUETTE\\nQC G0V 1A0\\nCAN"
  },
  {
    "id": "6532",
    "uic": "6532",
    "abbrevCFR": "Dét 10FTTS",
    "officialName": "DÉTACHEMENT BAGOTVILLE, 10E ESCADRON D'INSTRUCTION TECHNIQUE APPLIQUÉE",
    "addressHtml": "CP 5000 SUCC BUREAU-CHEF ALOUETTE<br>QC G0V 1A0<br>CAN",
    "addressPlain": "CP 5000 SUCC BUREAU-CHEF ALOUETTE\\nQC G0V 1A0\\nCAN"
  },
  {
    "id": "4591",
    "uic": "4591",
    "abbrevCFR": "12 Esc RDR",
    "officialName": "12E ESCADRON DE RADAR",
    "addressHtml": "CP 5000 SUCC BUREAU-CHEF ALOUETTE<br>QC G0V 1A0<br>CAN",
    "addressPlain": "CP 5000 SUCC BUREAU-CHEF ALOUETTE\\nQC G0V 1A0\\nCAN"
  },
  {
    "id": "3568",
    "uic": "3568",
    "abbrevCFR": "25 C SVC S",
    "officialName": "25E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES",
    "addressHtml": "CP 5000 SUCC BUREAU-CHEF ALOUETTE<br>QC G0V 1A0<br>CAN",
    "addressPlain": "CP 5000 SUCC BUREAU-CHEF ALOUETTE\\nQC G0V 1A0\\nCAN"
  },
  {
    "id": "3230",
    "uic": "3230",
    "abbrevCFR": "3 EMA",
    "officialName": "3E ESCADRON DE MAINTENANCE (AIR)",
    "addressHtml": "CP 5000 SUCC BUREAU-CHEF ALOUETTE<br>QC G0V 1A0<br>CAN",
    "addressPlain": "CP 5000 SUCC BUREAU-CHEF ALOUETTE\\nQC G0V 1A0\\nCAN"
  },
  {
    "id": "0772",
    "uic": "0772",
    "abbrevCFR": "425 Esc AT",
    "officialName": "425E ESCADRON D'APPUI TACTIQUE",
    "addressHtml": "CP 5000 SUCC BUREAU-CHEF ALOUETTE<br>QC G0V 1A0<br>CAN",
    "addressPlain": "CP 5000 SUCC BUREAU-CHEF ALOUETTE\\nQC G0V 1A0\\nCAN"
  },
  {
    "id": "6871",
    "uic": "6871",
    "abbrevCFR": "433 Esc A",
    "officialName": "433E ESCADRON D'APPUI TACTIQUE",
    "addressHtml": "CP 5000 SUCC BUREAU-CHEF ALOUETTE<br>QC G0V 1A0<br>CAN",
    "addressPlain": "CP 5000 SUCC BUREAU-CHEF ALOUETTE\\nQC G0V 1A0\\nCAN"
  },
  {
    "id": "3277",
    "uic": "3277",
    "abbrevCFR": "439 ESC SC",
    "officialName": "439E ESCADRON DE SOUTIEN AU COMBAT",
    "addressHtml": "CP 5000 SUCC BUREAU-CHEF ALOUETTE<br>QC G0V 1A0<br>CAN",
    "addressPlain": "CP 5000 SUCC BUREAU-CHEF ALOUETTE\\nQC G0V 1A0\\nCAN"
  },
  {
    "id": "8168",
    "uic": "8168",
    "abbrevCFR": "CEC BAGOT",
    "officialName": "CENTRE D'ENTRAîNEMENT DES CADETS BAGOTVILLE",
    "addressHtml": "CP 5000 SUCC BUREAU-CHEF ALOUETTE<br>QC G0V 1A0<br>CAN",
    "addressPlain": "CP 5000 SUCC BUREAU-CHEF ALOUETTE\\nQC G0V 1A0\\nCAN"
  },
  {
    "id": "0138",
    "uic": "0138",
    "abbrevCFR": "BFC BAGOTV",
    "officialName": "BASE DES FORCES CANADIENNES BAGOTVILLE",
    "addressHtml": "CP 5000 SUCC BUREAU-CHEF ALOUETTE<br>QC G0V 1A0<br>CAN",
    "addressPlain": "CP 5000 SUCC BUREAU-CHEF ALOUETTE\\nQC G0V 1A0\\nCAN"
  },
  {
    "id": "3701",
    "uic": "3701",
    "abbrevCFR": "ALFC BAGOT",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (BAGOTVILLE)",
    "addressHtml": "CP 5000 SUCC BUREAU-CHEF ALOUETTE<br>QC G0V 1A0<br>CAN",
    "addressPlain": "CP 5000 SUCC BUREAU-CHEF ALOUETTE\\nQC G0V 1A0\\nCAN"
  },
  {
    "id": "1197",
    "uic": "1197",
    "abbrevCFR": "NCSM Champlain",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ CHAMPLAIN",
    "addressHtml": "CP 5000 SUCC BUREAU-CHEF ALOUETTE<br>QC G0V 1A0<br>CAN",
    "addressPlain": "CP 5000 SUCC BUREAU-CHEF ALOUETTE\\nQC G0V 1A0\\nCAN"
  },
  {
    "id": "5115",
    "uic": "5115",
    "abbrevCFR": "R du Sag",
    "officialName": "LE RÉGIMENT DU SAGUENAY",
    "addressHtml": "CP 5000 SUCC BUREAU-CHEF ALOUETTE<br>QC G0V 1A0<br>CAN",
    "addressPlain": "CP 5000 SUCC BUREAU-CHEF ALOUETTE\\nQC G0V 1A0\\nCAN"
  },
  {
    "id": "6892",
    "uic": "6892",
    "abbrevCFR": "UOI BAGOTVILLE",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (QUÉBEC) DÉTACHMENT BAGOTVILLE",
    "addressHtml": "CP 5000 SUCC BUREAU-CHEF ALOUETTE<br>QC G0V 1A0<br>CAN",
    "addressPlain": "CP 5000 SUCC BUREAU-CHEF ALOUETTE\\nQC G0V 1A0\\nCAN"
  },
  {
    "id": "6752",
    "uic": "6752",
    "abbrevCFR": "CT BAGOTVI",
    "officialName": "CENTRE DE TRANSITION BAGOTVILLE",
    "addressHtml": "CP 5000 SUCC BUREAU-CHEF ALOUETTE<br>QC G0V 1A0<br>CAN",
    "addressPlain": "CP 5000 SUCC BUREAU-CHEF ALOUETTE\\nQC G0V 1A0\\nCAN"
  },
  {
    "id": "1241",
    "uic": "1241",
    "abbrevCFR": "NCSM VILLE",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ VILLE DE QUÉBEC",
    "addressHtml": "CP 99000 SUCC FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "CP 99000 SUCC FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "6995",
    "uic": "6995",
    "abbrevCFR": "CEEPC CENTRE",
    "officialName": "D'ENTRAINEMENT ÉLÉMENTAIRE DU POLYGONE DE CONNAUGHT CRPTC4 SNIDER RD, OTTAWA",
    "addressHtml": "ON K2K 2W6<br>CAN",
    "addressPlain": "ON K2K 2W6\\nCAN"
  },
  {
    "id": "6978",
    "uic": "6978",
    "abbrevCFR": "UT FAC S O",
    "officialName": "UNITÉ DE TRANSITION DES FORCES ARMÉES CANADIENNES (SUD DE L'ONTARIO) DENISON ARMOURY",
    "addressHtml": "1 YUKON LANE, B260 TORONTO<br>ON M3K 0A1<br>CAN",
    "addressPlain": "1 YUKON LANE, B260 TORONTO\\nON M3K 0A1\\nCAN"
  },
  {
    "id": "0375",
    "uic": "0375",
    "abbrevCFR": "URSC(C) NO",
    "officialName": "UNITÉ RÉGIONALE DE SOUTIEN AUX CADETS (CENTRE), DÉTACHEMENT NORTH BAY DETACHMENT NORTH BAY",
    "addressHtml": "15 MANSTON CRES HORNELL HEIGHTS<br>ON P0H 1P0<br>CAN",
    "addressPlain": "15 MANSTON CRES HORNELL HEIGHTS\\nON P0H 1P0\\nCAN"
  },
  {
    "id": "6602",
    "uic": "6602",
    "abbrevCFR": "CISSFC Centre",
    "officialName": "d'instruction des services de santé des Forces Canadiennes",
    "addressHtml": "EDIFICE O-166 30 ORTONA RD BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "EDIFICE O-166 30 ORTONA RD BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "3010",
    "uic": "3010",
    "abbrevCFR": "QG 2",
    "officialName": "Div CA FOIE QUARTIER GÉNÉRAL DE LA 2e DIVISION DU CANADA",
    "addressHtml": "EDIFICE PIERRE LEMOYNE D'IBERVILLE6560 RUE HOCHELAGA MONTREAL<br>QC H1N 1X9<br>CAN",
    "addressPlain": "EDIFICE PIERRE LEMOYNE D'IBERVILLE6560 RUE HOCHELAGA MONTREAL\\nQC H1N 1X9\\nCAN"
  },
  {
    "id": "6438",
    "uic": "6438",
    "abbrevCFR": "QG 2",
    "officialName": "Div CA FOIE QUARTIER GÉNÉRAL DE LA FORCE OPÉRATIONNELLE INTERARMÉES (EST)",
    "addressHtml": "EDIFICE PIERRE LEMOYNE D'IBERVILLE6560 RUE HOCHELAGA MONTREAL<br>QC H1N 1X9<br>CAN",
    "addressPlain": "EDIFICE PIERRE LEMOYNE D'IBERVILLE6560 RUE HOCHELAGA MONTREAL\\nQC H1N 1X9\\nCAN"
  },
  {
    "id": "6632",
    "uic": "6632",
    "abbrevCFR": "Dét H CFRC",
    "officialName": "DÉTACHEMENT HAMILTON, CENTRE DE RECRUTEMENT DES FORCES CANADIENNES TORONTO FEDERAL BUILDING",
    "addressHtml": "55 BAY ST N HAMILTON<br>ON L8R 3P7<br>CAN",
    "addressPlain": "55 BAY ST N HAMILTON\\nON L8R 3P7\\nCAN"
  },
  {
    "id": "3963",
    "uic": "3963",
    "abbrevCFR": "Dét Hamilt",
    "officialName": "DÉTACHEMENT HAMILTON 32E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES FEDERAL BUILDING",
    "addressHtml": "55 BAY ST N HAMILTON<br>ON L8R 3P7<br>CAN",
    "addressPlain": "55 BAY ST N HAMILTON\\nON L8R 3P7\\nCAN"
  },
  {
    "id": "6661",
    "uic": "6661",
    "abbrevCFR": "Dét 37 RGC",
    "officialName": "DÉTACHEMENT FREDERICTON, 37E RÉGIMENT DU GÉNIE DE COMBAT GD STN A FREDERICTON",
    "addressHtml": "NB E3B 4Y1<br>CAN",
    "addressPlain": "NB E3B 4Y1\\nCAN"
  },
  {
    "id": "6725",
    "uic": "6725",
    "abbrevCFR": "39 SR Det",
    "officialName": "DÉTACHEMENT NANAIMO, 39E RÉGIMENT DES TRANSMISSIONS GD STN A NANAIMO",
    "addressHtml": "BC V9R 5J9<br>CAN",
    "addressPlain": "BC V9R 5J9\\nCAN"
  },
  {
    "id": "2083",
    "uic": "2083",
    "abbrevCFR": "1 UD NORTH",
    "officialName": "1ER UNITÉ DENTAIRE DÉTACHEMENT NORTH BAY GD STN MAIN HORNELL HEIGHTS",
    "addressHtml": "ON P0H 1P0<br>CAN",
    "addressPlain": "ON P0H 1P0\\nCAN"
  },
  {
    "id": "1264",
    "uic": "1264",
    "abbrevCFR": "1 UD WAINW",
    "officialName": "1ER UNITÉ DENTAIRE, DÉTACHEMENT WAINWRIGHT GD STN MAIN DENWOOD",
    "addressHtml": "AB T0B 1B0<br>CAN",
    "addressPlain": "AB T0B 1B0\\nCAN"
  },
  {
    "id": "6352",
    "uic": "6352",
    "abbrevCFR": "Dét",
    "officialName": "QG",
    "addressHtml": "1 E DÉTACHEMENT WAINWRIGHT CCEM QUARTIER GÉNÉRAL DE 1ER ESCADRE GD STN MAIN DENWOOD<br>AB T0B 1B0<br>CAN",
    "addressPlain": "1 E DÉTACHEMENT WAINWRIGHT CCEM QUARTIER GÉNÉRAL DE 1ER ESCADRE GD STN MAIN DENWOOD\\nAB T0B 1B0\\nCAN"
  },
  {
    "id": "5249",
    "uic": "5249",
    "abbrevCFR": "116 INDEP",
    "officialName": "116E BATTERIE AUTONOME DE CAMPAGNE, ARC GD STN MAIN KENORA",
    "addressHtml": "ON P9N 3W9<br>CAN",
    "addressPlain": "ON P9N 3W9\\nCAN"
  },
  {
    "id": "3591",
    "uic": "3591",
    "abbrevCFR": "12 C Svc S",
    "officialName": "12E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES GD STN MAIN DENWOOD",
    "addressHtml": "AB T0B 1B0<br>CAN",
    "addressPlain": "AB T0B 1B0\\nCAN"
  },
  {
    "id": "2437",
    "uic": "2437",
    "abbrevCFR": "21 ESC CAA",
    "officialName": "21E ESCADRON DE CONTRÔLE ET D'ALERTE (AEROSPATIALE) GD STN MAIN HORNELL HEIGHTS",
    "addressHtml": "ON P0H 1P0<br>CAN",
    "addressPlain": "ON P0H 1P0\\nCAN"
  },
  {
    "id": "9966",
    "uic": "9966",
    "abbrevCFR": "22 ERE",
    "officialName": "22E ESCADRE GD STN MAIN HORNELL HEIGHTS",
    "addressHtml": "ON P0H 1P0<br>CAN",
    "addressPlain": "ON P0H 1P0\\nCAN"
  },
  {
    "id": "0168",
    "uic": "0168",
    "abbrevCFR": "CI 3 Div C",
    "officialName": "CENTRE D'INSTRUCTION DE LA 3E DIVISION DU CANADA GD STN MAIN DENWOOD",
    "addressHtml": "AB T0B 1B0<br>CAN",
    "addressPlain": "AB T0B 1B0\\nCAN"
  },
  {
    "id": "2438",
    "uic": "2438",
    "abbrevCFR": "51 AC&W SQ",
    "officialName": "51E ESCADRON D'ENTRAINEMENT OPÉRATIONNEL DE CONTRÔLE ET D'ALERTE (AEROSPATIALE)) GD STN MAIN HORNELL HEIGHTS",
    "addressHtml": "ON P0H 1P0<br>CAN",
    "addressPlain": "ON P0H 1P0\\nCAN"
  },
  {
    "id": "4162",
    "uic": "4162",
    "abbrevCFR": "CDSG SIG S",
    "officialName": "DÉTACHEMENT WAINWRIGHT ESCADRON DES TRANSMISSIONS DU GS",
    "addressHtml": "3 DIV C GD STN MAIN DENWOOD<br>AB T0B 1B0<br>CAN",
    "addressPlain": "3 DIV C GD STN MAIN DENWOOD\\nAB T0B 1B0\\nCAN"
  },
  {
    "id": "1955",
    "uic": "1955",
    "abbrevCFR": "DMFC DUNDURN",
    "officialName": "DÉPÔT DE MUNITIONS DES FORCES CANADIENNES DUNDURN GD STN MAIN DUNDURN",
    "addressHtml": "SK S0K 1K0<br>CAN",
    "addressPlain": "SK S0K 1K0\\nCAN"
  },
  {
    "id": "0135",
    "uic": "0135",
    "abbrevCFR": "BFC NORTH",
    "officialName": "BASE DES FORCES CANADIENNES NORTH BAY GD STN MAIN HORNELL HEIGHTS",
    "addressHtml": "ON P0H 1P0<br>CAN",
    "addressPlain": "ON P0H 1P0\\nCAN"
  },
  {
    "id": "2585",
    "uic": "2585",
    "abbrevCFR": "BFC WINNIP",
    "officialName": "DÉTACHEMENT DUNDURN, BASE DES FORCES CANADIENNES WINNIPEG GD STN MAIN DUNDURN",
    "addressHtml": "SK S0K 1K0<br>CAN",
    "addressPlain": "SK S0K 1K0\\nCAN"
  },
  {
    "id": "3718",
    "uic": "3718",
    "abbrevCFR": "ALFC NORTH",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (NORTH BAY) GD STN MAIN HORNELL HEIGHTS",
    "addressHtml": "ON P0H 1P0<br>CAN",
    "addressPlain": "ON P0H 1P0\\nCAN"
  },
  {
    "id": "3727",
    "uic": "3727",
    "abbrevCFR": "ALFC WAINW",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (WAINWRIGHT) GD STN MAIN DENWOOD",
    "addressHtml": "AB T0B 1B0<br>CAN",
    "addressPlain": "AB T0B 1B0\\nCAN"
  },
  {
    "id": "6322",
    "uic": "6322",
    "abbrevCFR": "CCEM CENTRE",
    "officialName": "CANADIEN D'ENTRAINEMENT AUX MANOEUVRES GD STN MAIN DENWOOD",
    "addressHtml": "AB T0B 1B0<br>CAN",
    "addressPlain": "AB T0B 1B0\\nCAN"
  },
  {
    "id": "3967",
    "uic": "3967",
    "abbrevCFR": "Dét Dundur",
    "officialName": "DÉTACHEMENT DUNDURN 23E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES GD STN MAIN DUNDURN",
    "addressHtml": "SK S0K 1K0<br>CAN",
    "addressPlain": "SK S0K 1K0\\nCAN"
  },
  {
    "id": "3583",
    "uic": "3583",
    "abbrevCFR": "Dét North",
    "officialName": "DÉTACHEMENT NORTH BAY 31E CENTRE DE SERVICES DE SANTÉ DES FORCES CANADIENNES GD STN MAIN HORNELL HEIGHTS",
    "addressHtml": "ON P0H 1P0<br>CAN",
    "addressPlain": "ON P0H 1P0\\nCAN"
  },
  {
    "id": "6428",
    "uic": "6428",
    "abbrevCFR": "Dét Wainwr DÉTACHMENT WAINWRIGHT,",
    "officialName": "BASE DE SOUTIEN DE LA 3E CANADIAN DIVISION, EDMONTON GD STN MAIN DENWOOD",
    "addressHtml": "AB T0B 1B0<br>CAN",
    "addressPlain": "AB T0B 1B0\\nCAN"
  },
  {
    "id": "6900",
    "uic": "6900",
    "abbrevCFR": "UOI WAINWRIGHT",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (OUEST) DÉTACHMENT WAINWRIGHT GD STN MAIN DENWOOD",
    "addressHtml": "AB T0B 1B0<br>CAN",
    "addressPlain": "AB T0B 1B0\\nCAN"
  },
  {
    "id": "6890",
    "uic": "6890",
    "abbrevCFR": "UOI NORTH BAY",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (ONTARIO) DÉTACHMENT NORTH BAY GD STN MAIN HORNELL HEIGHTS",
    "addressHtml": "ON P0H 1P0<br>CAN",
    "addressPlain": "ON P0H 1P0\\nCAN"
  },
  {
    "id": "6751",
    "uic": "6751",
    "abbrevCFR": "CT NORTH B",
    "officialName": "CENTRE DE TRANSITION NORTH BAY GD STN MAIN HORNELL HEIGHTS",
    "addressHtml": "ON P0H 1P0<br>CAN",
    "addressPlain": "ON P0H 1P0\\nCAN"
  },
  {
    "id": "6743",
    "uic": "6743",
    "abbrevCFR": "CT WAINWRI",
    "officialName": "CENTRE DE TRANSITION WAINWRIGHT",
    "addressHtml": "GENERAL DELIVERY STATION MAIN DENWOOD<br>AB T0B 1B0<br>CAN",
    "addressPlain": "GENERAL DELIVERY STATION MAIN DENWOOD\\nAB T0B 1B0\\nCAN"
  },
  {
    "id": "3325",
    "uic": "3325",
    "abbrevCFR": "WCAQ LOND",
    "officialName": "WORKCENTRE DE L'ASSURANCE DE QUALITÉ (LONDON)",
    "addressHtml": "GENERAL DYNAMICS LAND SYSTEMS CANADA 1991 OXFORD ST E LONDON<br>ON N5V 2Z7<br>CAN",
    "addressPlain": "GENERAL DYNAMICS LAND SYSTEMS CANADA 1991 OXFORD ST E LONDON\\nON N5V 2Z7\\nCAN"
  },
  {
    "id": "2790",
    "uic": "2790",
    "abbrevCFR": "41 RGC Det",
    "officialName": "DÉTACHEMENT CALGARY 41E RÉGIMENT DU GÉNIE DE COMBAT",
    "addressHtml": "GENERAL SIR ARTHUR CURRIE BUILDING4225 CROWCHILD TRAIL SW CALGARY<br>AB T3E 1T8<br>CAN",
    "addressPlain": "GENERAL SIR ARTHUR CURRIE BUILDING4225 CROWCHILD TRAIL SW CALGARY\\nAB T3E 1T8\\nCAN"
  },
  {
    "id": "5230",
    "uic": "5230",
    "abbrevCFR": "41 SBn",
    "officialName": "Cal DÉTACHMENT CALGARY, 41E BATAILLON DES SERVICES",
    "addressHtml": "GENERAL SIR ARTHUR CURRIE BUILDING4225 CROWCHILD TRAIL SW CALGARY<br>AB T3E 1T8<br>CAN",
    "addressPlain": "GENERAL SIR ARTHUR CURRIE BUILDING4225 CROWCHILD TRAIL SW CALGARY\\nAB T3E 1T8\\nCAN"
  },
  {
    "id": "6704",
    "uic": "6704",
    "abbrevCFR": "41 Bon Svc",
    "officialName": "41E BATAILLON DES SERVICES",
    "addressHtml": "GENERAL SIR ARTHUR CURRIE BUILDING4225 CROWCHILD TRAIL SW CALGARY<br>AB T3E 1T8<br>CAN",
    "addressPlain": "GENERAL SIR ARTHUR CURRIE BUILDING4225 CROWCHILD TRAIL SW CALGARY\\nAB T3E 1T8\\nCAN"
  },
  {
    "id": "3593",
    "uic": "3593",
    "abbrevCFR": "Dét Calgar",
    "officialName": "DÉTACHEMENT CALGARY 1RE AMBULANCE DE CAMPAGNE",
    "addressHtml": "GENERAL SIR ARTHUR CURRIE BUILDING4225 CROWCHILD TRAIL SW CALGARY<br>AB T3E 1T8<br>CAN",
    "addressPlain": "GENERAL SIR ARTHUR CURRIE BUILDING4225 CROWCHILD TRAIL SW CALGARY\\nAB T3E 1T8\\nCAN"
  },
  {
    "id": "3418",
    "uic": "3418",
    "abbrevCFR": "WCAQ CAL",
    "officialName": "WORKCENTRE DE L'ASSURANCE DE QUALITÉ (CALGARY)",
    "addressHtml": "GENERAL SIR ARTHUR CURRIE BUILDING4225 CROWCHILD TRAIL SW CALGARY<br>AB T3E 1T8<br>CAN",
    "addressPlain": "GENERAL SIR ARTHUR CURRIE BUILDING4225 CROWCHILD TRAIL SW CALGARY\\nAB T3E 1T8\\nCAN"
  },
  {
    "id": "6742",
    "uic": "6742",
    "abbrevCFR": "CT CALGARY",
    "officialName": "CENTRE DE TRANSITION CALGARY",
    "addressHtml": "GENERAL SIR ARTHUR CURRIE BUILDING4225 CROWCHILD TRAIL SW CALGARY<br>AB T3E 1T8<br>CAN",
    "addressPlain": "GENERAL SIR ARTHUR CURRIE BUILDING4225 CROWCHILD TRAIL SW CALGARY\\nAB T3E 1T8\\nCAN"
  },
  {
    "id": "6379",
    "uic": "6379",
    "abbrevCFR": "RGN NORF",
    "officialName": "RÉGION NORFOLK HEADQUARTERS SUPREME ALLIED COMMANDTRANSFORMATION",
    "addressHtml": "7857 BLANDY ROAD,SUITE 100 NORFOLK VA<br>235512490<br>USA",
    "addressPlain": "7857 BLANDY ROAD,SUITE 100 NORFOLK VA\\n235512490\\nUSA"
  },
  {
    "id": "6375",
    "uic": "6375",
    "abbrevCFR": "RGN TUR",
    "officialName": "RÉGION TURQUIE HEADQUARTERS SUPREME ALLIED COMMANDTRANSFORMATION",
    "addressHtml": "7857 BLANDY ROAD,SUITE 100 NORFOLK VA<br>235512490<br>USA",
    "addressPlain": "7857 BLANDY ROAD,SUITE 100 NORFOLK VA\\n235512490\\nUSA"
  },
  {
    "id": "3509",
    "uic": "3509",
    "abbrevCFR": "CF-18 GSA",
    "officialName": "Mirabel CF-18 WEAPON SYSTEM MANAGER DÉTACHEMENT MIRABEL L3 COMMUNICATIONS, DEPARTMENT",
    "addressHtml": "62610000 HELEN-BRISTOL ST MIRABEL<br>QC J7N 1H3<br>CAN",
    "addressPlain": "62610000 HELEN-BRISTOL ST MIRABEL\\nQC J7N 1H3\\nCAN"
  },
  {
    "id": "5014",
    "uic": "5014",
    "abbrevCFR": "SASK Dragoons",
    "officialName": "THE SASKATCHEWAN DRAGOONS LCOL D.V. CURRIE VC ARMOURY",
    "addressHtml": "1215 MAIN ST N MOOSE JAW<br>SK S6H 6M3<br>CAN",
    "addressPlain": "1215 MAIN ST N MOOSE JAW\\nSK S6H 6M3\\nCAN"
  },
  {
    "id": "5742",
    "uic": "5742",
    "abbrevCFR": "2729 CCRAC",
    "officialName": "CORPS DE CADETS ROYAUX DE L'ARMÉE CANADIENNE,",
    "addressHtml": "2729 TERREBONNE Légion Royale Canadienne, Filiale 120225 Chemin des Anglais Mascouche<br>QC J7L 3P1<br>CAN",
    "addressPlain": "2729 TERREBONNE Légion Royale Canadienne, Filiale 120225 Chemin des Anglais Mascouche\\nQC J7L 3P1\\nCAN"
  },
  {
    "id": "2772",
    "uic": "2772",
    "abbrevCFR": "SSPM SERVICE",
    "officialName": "DE SÉCURITÉ DE LA POLICE MILITAIRE LESTER B. PEARSON BUILDING",
    "addressHtml": "125 SUSSEX DR OTTAWA<br>ON K1A 0G2<br>CAN",
    "addressPlain": "125 SUSSEX DR OTTAWA\\nON K1A 0G2\\nCAN"
  },
  {
    "id": "5125",
    "uic": "5125",
    "abbrevCFR": "CALG HIGHR",
    "officialName": "THE CALGARY HIGHLANDERS MEWATA ARMOURY801",
    "addressHtml": "11 ST SW CALGARY<br>AB T2P 2C4<br>CAN",
    "addressPlain": "11 ST SW CALGARY\\nAB T2P 2C4\\nCAN"
  },
  {
    "id": "3347",
    "uic": "3347",
    "abbrevCFR": "Dét Calgar",
    "officialName": "DÉTACHEMENT CALGARY 15E AMBULANCE DE CAMPAGNE (EDMONTON) MEWATA ARMOURY801",
    "addressHtml": "11 ST SW CALGARY<br>AB T2P 2C4<br>CAN",
    "addressPlain": "11 ST SW CALGARY\\nAB T2P 2C4\\nCAN"
  },
  {
    "id": "5016",
    "uic": "5016",
    "abbrevCFR": "KO CALG Régt",
    "officialName": "THE KING'S OWN CALGARY REGIMENT (CBRC) MEWATA ARMOURY801",
    "addressHtml": "11 ST SW CALGARY<br>AB T2P 2C4<br>CAN",
    "addressPlain": "11 ST SW CALGARY\\nAB T2P 2C4\\nCAN"
  },
  {
    "id": "0050",
    "uic": "0050",
    "abbrevCFR": "76 Regt Comm",
    "officialName": "76E RÉGIMENT DES COMMUNICATIONS",
    "addressHtml": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "4181",
    "uic": "4181",
    "abbrevCFR": "QG7GpComm QUARTIER",
    "officialName": "GÉNÉRAL DU 7E GROUPE DES COMMUNICATIONS",
    "addressHtml": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0153",
    "uic": "0153",
    "abbrevCFR": "SMA(MAT) SOUS-MINISTRE",
    "officialName": "ADJOINT (MATERIELS)",
    "addressHtml": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0161",
    "uic": "0161",
    "abbrevCFR": "SMA(AP) SOUS-MINISTRE",
    "officialName": "ADJOINT (AFFAIRES PUBLIQUES) ET DIRIGEANT PRINCIPAL DE LA PROTECTION DE LA VIE PRIVÉE",
    "addressHtml": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3372",
    "uic": "3372",
    "abbrevCFR": "CEMA CHEF",
    "officialName": "D'ÉTAT-MAJOR DE L'ARMÉE",
    "addressHtml": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3371",
    "uic": "3371",
    "abbrevCFR": "CEMM CHEF",
    "officialName": "D'ÉTAT-MAJOR DE LA MARINE",
    "addressHtml": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0002",
    "uic": "0002",
    "abbrevCFR": "BFC O-G",
    "officialName": "LA BASE DES FORCES CANADIENNES (OTTAWA-GATINEAU)",
    "addressHtml": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3740",
    "uic": "3740",
    "abbrevCFR": "UNCIFC UNITÉ",
    "officialName": "NATIONALE DE CONTRE-INGÉRENCE DES FORCES CANADIENNES",
    "addressHtml": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3763",
    "uic": "3763",
    "abbrevCFR": "JMC CABINET",
    "officialName": "DU JUGE MILITAIRE EN CHEF",
    "addressHtml": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3994",
    "uic": "3994",
    "abbrevCFR": "CEM - GSN",
    "officialName": "CHEF D'ÉTAT-MAJOR - GROUPE DES SERVICES NUMÉRIQUES ET J6 FAC",
    "addressHtml": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3332",
    "uic": "3332",
    "abbrevCFR": "DGRPGI DIRECTEUR",
    "officialName": "GÉNÉRAL - RÉALISATION DE PROJETS (GESTION DE L'INFORMATION)",
    "addressHtml": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2851",
    "uic": "2851",
    "abbrevCFR": "JAA OTTAWA",
    "officialName": "JUGE-AVOCAT ADJOINT (OTTAWA)",
    "addressHtml": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0163",
    "uic": "0163",
    "abbrevCFR": "SM BUREAU",
    "officialName": "SOUS-MINISTRE DE LA DÉFENSE NATIONALE",
    "addressHtml": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "3681",
    "uic": "3681",
    "abbrevCFR": "CJ MDN/FC",
    "officialName": "CONSEILLER JURIDIQUE AUPRÈS DU MINISTÈRE DE LA DÉFENSE NATIONALE ET DES FORCES CANADIENNES",
    "addressHtml": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0162",
    "uic": "0162",
    "abbrevCFR": "BUREAU-MDN BUREAU",
    "officialName": "- MINISTRE DE LA DÉFENSE NATIONALE",
    "addressHtml": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0001",
    "uic": "0001",
    "abbrevCFR": "NDHQ QUARTIER",
    "officialName": "GÉNÉRAL DE LA DÉFENSE NATIONALE",
    "addressHtml": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0321",
    "uic": "0321",
    "abbrevCFR": "WCAQ RCN",
    "officialName": "WORKCENTRE DE L'ASSURANCE DE QUALITÉ (RÉGION DE LA CAPITALE NATIONALE)",
    "addressHtml": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "2689",
    "uic": "2689",
    "abbrevCFR": "CETQ CENTRE",
    "officialName": "D'ESSAIS TECHNIQUES DE LA QUALITÉ",
    "addressHtml": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "MGEN GEORGE R. PEARKES BLDG 101 COLONEL BY DR OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "0200",
    "uic": "0200",
    "abbrevCFR": "CRFC Halif",
    "officialName": "CENTRE DE RECRUTEMENT DES FORCES CANADIENNES HALIFAX MUMFORD PROFESSIONAL CENTRE",
    "addressHtml": "6960 MUMFORD ROAD SUITE 130 HALIFAX<br>NS B3L 4P1<br>CAN",
    "addressPlain": "6960 MUMFORD ROAD SUITE 130 HALIFAX\\nNS B3L 4P1\\nCAN"
  },
  {
    "id": "8679",
    "uic": "8679",
    "abbrevCFR": "QG GP LI C",
    "officialName": "QUARTIER GÉNÉRAL, GROUPE - LOGISTIQUE INTERARMÉES DES FORCES ARMÉES CANADIENNES NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "9026",
    "uic": "9026",
    "abbrevCFR": "GP LI FAC",
    "officialName": "GROUPE - LOGISTIQUE INTERARMÉES DES FORCES ARMÉES CANADIENNES NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "7715",
    "uic": "7715",
    "abbrevCFR": "BADC - MAL",
    "officialName": "BUREAU DE L' ATTACHE DE DEFENSE DU CANADA - MALAYSIA NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "7726",
    "uic": "7726",
    "abbrevCFR": "CDAO GHANA",
    "officialName": "BUREAU DE L'ATTACHÉ DE DEFENSE DU CANADA GHANA NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "6914",
    "uic": "6914",
    "abbrevCFR": "BADC, LETT",
    "officialName": "BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA (LETTONIE) NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "0073",
    "uic": "0073",
    "abbrevCFR": "BADC NORVE",
    "officialName": "DÉTACHEMENT NORVÈGE, BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "7725",
    "uic": "7725",
    "abbrevCFR": "BADC VIETN",
    "officialName": "BUREAU DE L' ATTACHE DE DEFENSE DU CANADA - VIETNAM NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "6919",
    "uic": "6919",
    "abbrevCFR": "BADC, ETHI",
    "officialName": "BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA (ETHIOPIE) NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "6913",
    "uic": "6913",
    "abbrevCFR": "BADC, IRAK",
    "officialName": "BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA (IRAK) NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "6912",
    "uic": "6912",
    "abbrevCFR": "BADC, LIB",
    "officialName": "BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA (LIBAN) NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "6925",
    "uic": "6925",
    "abbrevCFR": "BADC, SING",
    "officialName": "BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA (SINGAPORE) NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "6938",
    "uic": "6938",
    "abbrevCFR": "BADC, ESPA",
    "officialName": "BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA (ESPAGNE) NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "6920",
    "uic": "6920",
    "abbrevCFR": "BADC, TUNI",
    "officialName": "BUREAU DE L'ATTACHÉ DE DÉFENSE DU CANADA (TUNISIE) NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "6524",
    "uic": "6524",
    "abbrevCFR": "UADC UNITÉ",
    "officialName": "DE L'ATTACHÉ DE DÉFENSE DU CANADA NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "9025",
    "uic": "9025",
    "abbrevCFR": "CFIC COMMANDEMENT",
    "officialName": "DES FORCES INTERARMÉES DU CANADA NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "0695",
    "uic": "0695",
    "abbrevCFR": "COIC EUR",
    "officialName": "COMMANDEMENT DES OPÉRATIONS INTERARMÉES DU CANADA HORS CANADA - EUROPE NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "0696",
    "uic": "0696",
    "abbrevCFR": "COIC RM",
    "officialName": "COMMANDEMENT DES OPÉRATIONS INTERARMÉES DU CANADA HORS CANADA - RESTE DU MONDE NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "0693",
    "uic": "0693",
    "abbrevCFR": "COIC EU",
    "officialName": "COMMANDEMENT DES OPÉRATIONS INTERARMÉES DU CANADA HORS CANADA - ÉTATS-UNIS NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "6858",
    "uic": "6858",
    "abbrevCFR": "OP IMPACT",
    "officialName": "OPÉRATION IMPACT NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "6949",
    "uic": "6949",
    "abbrevCFR": "OP PRESENC",
    "officialName": "OPERATION PRESENCE NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "6754",
    "uic": "6754",
    "abbrevCFR": "CT CHARLOT",
    "officialName": "CENTRE DE TRANSITION CHARLOTTETOWN NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "6936",
    "uic": "6936",
    "abbrevCFR": "FO MOYEN O",
    "officialName": "FORCE OPÉRATINNELLE MOYEN-ORIENT NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "6846",
    "uic": "6846",
    "abbrevCFR": "FO LATVIA",
    "officialName": "FORCE OPÉRATIONELLE (OPÉRATION OPEN SPIRIT) NO POSTAL ADDRESS OTTAWA",
    "addressHtml": "ON K1A 0K2<br>CAN",
    "addressPlain": "ON K1A 0K2\\nCAN"
  },
  {
    "id": "3889",
    "uic": "3889",
    "abbrevCFR": "TFDRC FORCE",
    "officialName": "OPÉRATIONELLE (RÉPUBLIQUE DÉMOCRATIQUE DU CONGO) OP CROCODILE CANADIAN EMBASSY KNSHA C/O DFAIT",
    "addressHtml": "125 SUSSEX DR OTTAWA<br>ON K1A 0G2<br>CAN",
    "addressPlain": "125 SUSSEX DR OTTAWA\\nON K1A 0G2\\nCAN"
  },
  {
    "id": "6479",
    "uic": "6479",
    "abbrevCFR": "5 Regt PM",
    "officialName": "5E RÉGIMENT DE LA POLICE MILITAIRE",
    "addressHtml": "PIERRE LEMOYNE D'IBERVILLE BUILDING6560 HOCHELAGA ST MONTREAL<br>QC H1N 1X9<br>CAN",
    "addressPlain": "PIERRE LEMOYNE D'IBERVILLE BUILDING6560 HOCHELAGA ST MONTREAL\\nQC H1N 1X9\\nCAN"
  },
  {
    "id": "3505",
    "uic": "3505",
    "abbrevCFR": "ECCA Est",
    "officialName": "DÉT ÉLÉMENT DE COORDINATION DE LA COMPOSANTE AÉRIENNE EST, QUARTIER GÉNÉRAL DE LA 1ER DAC",
    "addressHtml": "PIERRE LEMOYNE D'IBERVILLE BUILDING6560 HOCHELAGA ST MONTREAL<br>QC H1N 1X9<br>CAN",
    "addressPlain": "PIERRE LEMOYNE D'IBERVILLE BUILDING6560 HOCHELAGA ST MONTREAL\\nQC H1N 1X9\\nCAN"
  },
  {
    "id": "2839",
    "uic": "2839",
    "abbrevCFR": "BAPDN RQ",
    "officialName": "SOUS-MINISTRE ADJOINT (AFFAIRES PUBLIQUES) QUÉBEC",
    "addressHtml": "PLACE GUY FAVREAU 200 BOUL RENE-LEVESQUE O BUREAU 911 MONTREAL<br>QC H2Z 1X4<br>CAN",
    "addressPlain": "PLACE GUY FAVREAU 200 BOUL RENE-LEVESQUE O BUREAU 911 MONTREAL\\nQC H2Z 1X4\\nCAN"
  },
  {
    "id": "3686",
    "uic": "3686",
    "abbrevCFR": "2 GPRC",
    "officialName": "2E GROUPE DE PATROUILLE DES RANGERS CANADIENS",
    "addressHtml": "PO BOX 100 STN BUREAU-CHEF RICHELAIN<br>QC J0J 1R0<br>CAN",
    "addressPlain": "PO BOX 100 STN BUREAU-CHEF RICHELAIN\\nQC J0J 1R0\\nCAN"
  },
  {
    "id": "5240",
    "uic": "5240",
    "abbrevCFR": "34 Bon Svc",
    "officialName": "34E BATAILLON DES SERVICES",
    "addressHtml": "PO BOX 100 STN BUREAU-CHEF RICHELAIN<br>QC J0J 1R0<br>CAN",
    "addressPlain": "PO BOX 100 STN BUREAU-CHEF RICHELAIN\\nQC J0J 1R0\\nCAN"
  },
  {
    "id": "6924",
    "uic": "6924",
    "abbrevCFR": "76 St Jean",
    "officialName": "76E RÉGIMENT DES COMMUNICATIONS DÉTACHEMENT",
    "addressHtml": "ST JEAN PO BOX 100 STN BUREAU-CHEF RICHELAIN<br>QC J0J 1R0<br>CAN",
    "addressPlain": "ST JEAN PO BOX 100 STN BUREAU-CHEF RICHELAIN\\nQC J0J 1R0\\nCAN"
  },
  {
    "id": "6310",
    "uic": "6310",
    "abbrevCFR": "C Fmn",
    "officialName": "Svc S FC Det Sjn CENTRE DE FORMATION DES SERVICES DE SANTÉ DES FORCES CANADIENNES DÉTACHEMENT ST-JEAN",
    "addressHtml": "PO BOX 100 STN BUREAU-CHEF RICHELAIN<br>QC J0J 1R0<br>CAN",
    "addressPlain": "PO BOX 100 STN BUREAU-CHEF RICHELAIN\\nQC J0J 1R0\\nCAN"
  },
  {
    "id": "3613",
    "uic": "3613",
    "abbrevCFR": "ELRFC ÉCOLE",
    "officialName": "DE LEADERSHIP ET DE RECRUES DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 100 STN BUREAU-CHEF RICHELAIN<br>QC J0J 1R0<br>CAN",
    "addressPlain": "PO BOX 100 STN BUREAU-CHEF RICHELAIN\\nQC J0J 1R0\\nCAN"
  },
  {
    "id": "2607",
    "uic": "2607",
    "abbrevCFR": "ELFC Det Sjn",
    "officialName": "DÉTACHEMENT ÉCOLE DES LANGUES DES FORCES CANADIENNES (SAINT-JEAN)",
    "addressHtml": "PO BOX 100 STN BUREAU-CHEF RICHELAIN<br>QC J0J 1R0<br>CAN",
    "addressPlain": "PO BOX 100 STN BUREAU-CHEF RICHELAIN\\nQC J0J 1R0\\nCAN"
  },
  {
    "id": "6509",
    "uic": "6509",
    "abbrevCFR": "CMRSJ COLLÈGE",
    "officialName": "MILITAIRE ROYAL DE SAINT-JEAN",
    "addressHtml": "PO BOX 100 STN BUREAU-CHEF RICHELAIN<br>QC J0J 1R0<br>CAN",
    "addressPlain": "PO BOX 100 STN BUREAU-CHEF RICHELAIN\\nQC J0J 1R0\\nCAN"
  },
  {
    "id": "6688",
    "uic": "6688",
    "abbrevCFR": "CT Sjn",
    "officialName": "CENTRE DE TRANSITION ST-JEAN",
    "addressHtml": "PO BOX 100 STN BUREAU-CHEF RICHELAIN<br>QC J0J 1R0<br>CAN",
    "addressPlain": "PO BOX 100 STN BUREAU-CHEF RICHELAIN\\nQC J0J 1R0\\nCAN"
  },
  {
    "id": "2080",
    "uic": "2080",
    "abbrevCFR": "1 UD TRENT",
    "officialName": "1ER UNITÉ DENTAIRE DÉTACHEMENT TRENTON",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "2518",
    "uic": "2518",
    "abbrevCFR": "2 Esc mouv",
    "officialName": "2E ESCADRON DES MOUVEMENTS AÉRIENS",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "6443",
    "uic": "6443",
    "abbrevCFR": "QG 2",
    "officialName": "Div CA Det Valcartier DÉTACHEMENT VALCARTIER QUARTIER GÉNÉRAL DE LA 2E DIVISION DU CANADA",
    "addressHtml": "PO BOX 1000 STN FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "3589",
    "uic": "3589",
    "abbrevCFR": "24 C SVC S",
    "officialName": "24E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "2521",
    "uic": "2521",
    "abbrevCFR": "424 ETS",
    "officialName": "424E ESCADRON DE TRANSPORT ET DE SAUVETAGE",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "2520",
    "uic": "2520",
    "abbrevCFR": "426 (T) TR",
    "officialName": "426E ESCADRON D'ENTRAÎNEMENT AU TRANSPORT",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "6507",
    "uic": "6507",
    "abbrevCFR": "429 Esc(T)",
    "officialName": "429E ESCADRON DE TRANSPORT",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "3014",
    "uic": "3014",
    "abbrevCFR": "434 ESC EE",
    "officialName": "434E ESCADRON D' ESSAIS ET D'ÉVALUATION OPÉRATIONNELS",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "2523",
    "uic": "2523",
    "abbrevCFR": "436 Esc (T",
    "officialName": "436E ESCADRON DE TRANSPORT",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "2516",
    "uic": "2516",
    "abbrevCFR": "437 Esc (T",
    "officialName": "437E ESCADRON DE TRANSPORT",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "2665",
    "uic": "2665",
    "abbrevCFR": "8 ETCA",
    "officialName": "8E ESCADRON DE TRANSMISSIONS ET CONTRÔLE (AIR)",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "3752",
    "uic": "3752",
    "abbrevCFR": "8 ESC SSCA",
    "officialName": "8E ESCADRON DE SERVICE DE SOUTIEN (COMBAT AÉRIEN)",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "3231",
    "uic": "3231",
    "abbrevCFR": "8 EMA",
    "officialName": "8E ESCADRON DE MAINTENANCE (AIR)",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "3753",
    "uic": "3753",
    "abbrevCFR": "8 Esc GC",
    "officialName": "8E ESCADRON DU GÉNIE CONTRUCTION",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "9947",
    "uic": "9947",
    "abbrevCFR": "8 ERE",
    "officialName": "8E ESCADRE",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "3474",
    "uic": "3474",
    "abbrevCFR": "ESTTMA ESCADRON",
    "officialName": "DE SOUTIEN TECHNIQUE DES TÉLÉCOMMUNICATIONS ET DES MOYENS AEROSPATIAUX",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "3526",
    "uic": "3526",
    "abbrevCFR": "CISGTAC CENTRE",
    "officialName": "D'INSTRUCTION SUPÉRIEURE EN GUERRE TERRESTRE DE L'ARMÉE CANADIENNE",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "6974",
    "uic": "6974",
    "abbrevCFR": "UT FAC QC",
    "officialName": "UNITÉ DE TRANSITION DES FORCES ARMÉES CANADIENNES (QUÉBEC)",
    "addressHtml": "PO BOX 1000 STN FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "3609",
    "uic": "3609",
    "abbrevCFR": "CSPNFC CENTRE",
    "officialName": "DE SÉLECTION DU PERSONNEL NAVIGANT DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "0125",
    "uic": "0125",
    "abbrevCFR": "BFC TRENTO",
    "officialName": "BASE DES FORCES CANADIENNES TRENTON",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "3725",
    "uic": "3725",
    "abbrevCFR": "ALFC TRENT",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (TRENTON)",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "2238",
    "uic": "2238",
    "abbrevCFR": "SSPFC TREN",
    "officialName": "SECTON DU SERVICE POSTALE DES FORCES CANADIENNES (TRENTON)",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "1993",
    "uic": "1993",
    "abbrevCFR": "USPFC UNITÉ",
    "officialName": "DU SERVICE POSTAL DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "2237",
    "uic": "2237",
    "abbrevCFR": "USPFC CENT",
    "officialName": "UNITÉ POSTALE DES FORCES CANADIENNES DÉTACHEMENT CENTRE",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "2979",
    "uic": "2979",
    "abbrevCFR": "CEVC MOUNT",
    "officialName": "CENTRE D'ENTRAINEMENT DE VOL DES CADETS DE MOUNTAINVIEW",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "4948",
    "uic": "4948",
    "abbrevCFR": "UIIC-ICBRN UNITÉ",
    "officialName": "INTERARMÉES D'INTERVENTION DU CANADA - INCIDENTS CHIMIQUES, BIOLOGIQUES, RADIOLOGIQUES ET NUCL",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "3379",
    "uic": "3379",
    "abbrevCFR": "DCMM TRENT",
    "officialName": "DÉPÔT CENTRAL DE MATÉRIEL MÉDICAL, DÉTACHEMENT TRENTON",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "8164",
    "uic": "8164",
    "abbrevCFR": "CEC TRENTO",
    "officialName": "CENTRE D'ENTRAINEMENT DES CADETS DE TRENTON",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "3565",
    "uic": "3565",
    "abbrevCFR": "DART ÉQUIPE",
    "officialName": "D'INTERVENTION EN CAS DE CATASTROPHE",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "2405",
    "uic": "2405",
    "abbrevCFR": "JAA RESNAV JUGE-AVOCAT ADJOINT",
    "officialName": "QUARTIER GÉNÉRAL DE LA RÉSERVE NAVALE",
    "addressHtml": "PO BOX 1000 STN FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "2850",
    "uic": "2850",
    "abbrevCFR": "JAA TRENTO",
    "officialName": "JUGE-AVOCAT ADJOINT (TRENTON)",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "2826",
    "uic": "2826",
    "abbrevCFR": "JAA Val",
    "officialName": "JUGE-AVOCAT ADJOINT (VALCARTIER)",
    "addressHtml": "PO BOX 1000 STN FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "3997",
    "uic": "3997",
    "abbrevCFR": "CCCOS Tren",
    "officialName": "CENTRE CONJOINT DE COORDINATION DES OPÉRATIONS DE SAUVETAGE (TRENTON)",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "3058",
    "uic": "3058",
    "abbrevCFR": "EN(Q) L'ÉCOLE",
    "officialName": "NAVALE (QUÉBEC)",
    "addressHtml": "PO BOX 1000 STN FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "6431",
    "uic": "6431",
    "abbrevCFR": "QG CGA ARC",
    "officialName": "QUARTIER GÉNÉRAL DU CENTRE DE GUERRE AÉROSPATIALE DE L'AVIATION ROYALE CANADIENNE",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "4896",
    "uic": "4896",
    "abbrevCFR": "PMR Est",
    "officialName": "PROCURER MILITAIRE REGION DE L'EST",
    "addressHtml": "PO BOX 1000 STN FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "6888",
    "uic": "6888",
    "abbrevCFR": "UOI TRENTON",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (ONTARIO) DÉTACHEMENT TRENTON",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "6690",
    "uic": "6690",
    "abbrevCFR": "CT TRENTON",
    "officialName": "CENTRE DE TRANSITION TRENTON",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "6558",
    "uic": "6558",
    "abbrevCFR": "CT Val",
    "officialName": "CENTRE DE TRANSITION VALCARTIER",
    "addressHtml": "PO BOX 1000 STN FORCES COURCELETTE<br>QC G0A 4Z0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES COURCELETTE\\nQC G0A 4Z0\\nCAN"
  },
  {
    "id": "3924",
    "uic": "3924",
    "abbrevCFR": "TRSET DET DÉT TRENTON",
    "officialName": "QUARTIER GÉNÉRAL DE LA 1RE DIVISION AÉRIENNE DU CANADA TRANSPORT STANDARDS EVAL TEAM",
    "addressHtml": "PO BOX 1000 STN FORCES ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "PO BOX 1000 STN FORCES ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "6678",
    "uic": "6678",
    "abbrevCFR": "2",
    "officialName": "Esc PM",
    "addressHtml": "2 ESCADRON DE LA POLICE MILITAIRE PO BOX 1000 STN FORCESBUILDING 32 ASTRA<br>ON K0K 3W0<br>CAN",
    "addressPlain": "2 ESCADRON DE LA POLICE MILITAIRE PO BOX 1000 STN FORCESBUILDING 32 ASTRA\\nON K0K 3W0\\nCAN"
  },
  {
    "id": "6969",
    "uic": "6969",
    "abbrevCFR": "Det de Com",
    "officialName": "DETACHEMENT DE COMOX DU QG DE LA 1RE DIVISION AERIENNE DU CANADA (EENSAR)",
    "addressHtml": "PO BOX 1000 STN MAIN LAZO<br>BC V0R 2K0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN LAZO\\nBC V0R 2K0\\nCAN"
  },
  {
    "id": "3441",
    "uic": "3441",
    "abbrevCFR": "1 UD BORDE",
    "officialName": "1ER UNITÉ DENTAIRE DÉTACHEMENT BORDEN",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "2066",
    "uic": "2066",
    "abbrevCFR": "1 UD COMOX",
    "officialName": "1ER UNITÉ DENTAIRE DÉTACHEMENT COMOX",
    "addressHtml": "PO BOX 1000 STN MAIN LAZO<br>BC V0R 2K0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN LAZO\\nBC V0R 2K0\\nCAN"
  },
  {
    "id": "3391",
    "uic": "3391",
    "abbrevCFR": "QG 16 ERE",
    "officialName": "QUARTIER GÉNÉRAL DE LA 16E ESCADRE",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "3235",
    "uic": "3235",
    "abbrevCFR": "",
    "officialName": "19e EMA 19E ESCADRON DE MAINTENANCE (AIR)",
    "addressHtml": "PO BOX 1000 STN MAIN LAZO<br>BC V0R 2K0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN LAZO\\nBC V0R 2K0\\nCAN"
  },
  {
    "id": "9962",
    "uic": "9962",
    "abbrevCFR": "19 ERE",
    "officialName": "19E ESCADRE",
    "addressHtml": "PO BOX 1000 STN MAIN LAZO<br>BC V0R 2K0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN LAZO\\nBC V0R 2K0\\nCAN"
  },
  {
    "id": "3571",
    "uic": "3571",
    "abbrevCFR": "21 C Svc S",
    "officialName": "21E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 1000 STN MAIN LAZO<br>BC V0R 2K0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN LAZO\\nBC V0R 2K0\\nCAN"
  },
  {
    "id": "3687",
    "uic": "3687",
    "abbrevCFR": "3 GPRC",
    "officialName": "3E GROUPE DE PATROUILLE DES RANGERS CANADIENNES",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "3569",
    "uic": "3569",
    "abbrevCFR": "31 C Svc S",
    "officialName": "31E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "6716",
    "uic": "6716",
    "abbrevCFR": "32 SR Det",
    "officialName": "DÉTACHEMENT BORDEN, 32E RÉGIMENT DES TRANSMISSIONS",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "3606",
    "uic": "3606",
    "abbrevCFR": "400 ETAH",
    "officialName": "400E ESCADRON TACTIQUE D'HÉLICOPTÈRES",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "2552",
    "uic": "2552",
    "abbrevCFR": "407(PLP) S",
    "officialName": "407E ESCADRON DE PATROUILLE A LONGUE PORTÉE",
    "addressHtml": "PO BOX 1000 STN MAIN LAZO<br>BC V0R 2K0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN LAZO\\nBC V0R 2K0\\nCAN"
  },
  {
    "id": "6996",
    "uic": "6996",
    "abbrevCFR": "418 ESC",
    "officialName": "418E ESCADRON D'ENTRAINEMENT OPÉRATIONNEL RECHERCHE ET SAUVETAGE",
    "addressHtml": "PO BOX 1000 STN MAIN LAZO<br>BC V0R 2K0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN LAZO\\nBC V0R 2K0\\nCAN"
  },
  {
    "id": "2501",
    "uic": "2501",
    "abbrevCFR": "442 (T&S)",
    "officialName": "442E ESCADRON DE TRANSPORT ET DE SAUVETAGE",
    "addressHtml": "PO BOX 1000 STN MAIN LAZO<br>BC V0R 2K0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN LAZO\\nBC V0R 2K0\\nCAN"
  },
  {
    "id": "6526",
    "uic": "6526",
    "abbrevCFR": "Dét Borden",
    "officialName": "DÉTACHEMENT BORDEN, QUARTIER GÉNÉRAL DE L'ACADÉMIE CANADIENNE DE LA DÉFENSE",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "2493",
    "uic": "2493",
    "abbrevCFR": "DMFC ANGUS",
    "officialName": "DÉPÔT DE MUNITIONS DES FORCES CANADIENNES ANGUS",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "0113",
    "uic": "0113",
    "abbrevCFR": "BFC BORDEN",
    "officialName": "BASE DES FORCES CANADIENNES BORDEN",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "0133",
    "uic": "0133",
    "abbrevCFR": "BFC COMOX",
    "officialName": "BASE DES FORCES CANADIENNES COMOX",
    "addressHtml": "PO BOX 1000 STN MAIN LAZO<br>BC V0R 2K0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN LAZO\\nBC V0R 2K0\\nCAN"
  },
  {
    "id": "0144",
    "uic": "0144",
    "abbrevCFR": "CIFC BORDE",
    "officialName": "CENTRE D'INFORMATIQUE DES FORCES CANADIENNES DE BORDEN",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "6510",
    "uic": "6510",
    "abbrevCFR": "EPDCFC ÉCOLE",
    "officialName": "DES POMPIERS ET DE LA DÉFENSE CBRN DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "3702",
    "uic": "3702",
    "abbrevCFR": "ALFC BORDE",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (BORDEN)",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "3705",
    "uic": "3705",
    "abbrevCFR": "ALFC COMOX",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (COMOX)",
    "addressHtml": "PO BOX 1000 STN MAIN LAZO<br>BC V0R 2K0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN LAZO\\nBC V0R 2K0\\nCAN"
  },
  {
    "id": "2046",
    "uic": "2046",
    "abbrevCFR": "CILFC CENTRE",
    "officialName": "D'INSTRUCTION DE LOGISTIQUE DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "2008",
    "uic": "2008",
    "abbrevCFR": "EPMFC ÉCOLE",
    "officialName": "DE LA POLICE MILITAIRE DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "2241",
    "uic": "2241",
    "abbrevCFR": "SSPFC BORD",
    "officialName": "SECTON DU SERVICE POSTALE DES FORCES CANADIENNES (BORDEN)",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "3827",
    "uic": "3827",
    "abbrevCFR": "QG RFC",
    "officialName": "QUARTIER GÉNÉRAL DU GROUPE DE RECRUTEMENT DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "0871",
    "uic": "0871",
    "abbrevCFR": "ÉTGAFC ÉCOLE",
    "officialName": "DE TECHNOLOGIE ET DU GÉNIE AÉROSPATIAL DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "2548",
    "uic": "2548",
    "abbrevCFR": "ERSFC ÉCOLE",
    "officialName": "DE RECHERCHE ET DE SAUVETAGE DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 1000 STN MAIN LAZO<br>BC V0R 2K0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN LAZO\\nBC V0R 2K0\\nCAN"
  },
  {
    "id": "3249",
    "uic": "3249",
    "abbrevCFR": "CDIFC CENTRE",
    "officialName": "DE DÉVELOPPEMENT DE L'INSTRUCTION DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "3445",
    "uic": "3445",
    "abbrevCFR": "CEC BLACKD",
    "officialName": "CENTRE D'ENTRAINEMENT DES CADETS BLACKDOWN",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "2849",
    "uic": "2849",
    "abbrevCFR": "JAA BORDEN",
    "officialName": "JUGE-AVOCAT ADJOINT (BORDEN)",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "2109",
    "uic": "2109",
    "abbrevCFR": "JAA COMOX",
    "officialName": "JUGE-AVOCAT ADJOINT (COMOX)",
    "addressHtml": "PO BOX 1000 STN MAIN LAZO<br>BC V0R 2K0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN LAZO\\nBC V0R 2K0\\nCAN"
  },
  {
    "id": "4013",
    "uic": "4013",
    "abbrevCFR": "NCSM QUADR",
    "officialName": "CENTRE D'ENTRAINEMENT DES CADETS NCSM QUADRA",
    "addressHtml": "PO BOX 1000 STN MAIN LAZO<br>BC V0R 2K0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN LAZO\\nBC V0R 2K0\\nCAN"
  },
  {
    "id": "3342",
    "uic": "3342",
    "abbrevCFR": "",
    "officialName": "École ARC ÉCOLE DE L'AVIATION ROYALE CANADIENNE",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "2981",
    "uic": "2981",
    "abbrevCFR": "CORCA PAC",
    "officialName": "CENTRE OPÉRATIONNEL DE RÉGION DES CADETS D'AIR (PACIFIQUE)",
    "addressHtml": "PO BOX 1000 STN MAIN LAZO<br>BC V0R 2K0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN LAZO\\nBC V0R 2K0\\nCAN"
  },
  {
    "id": "0870",
    "uic": "0870",
    "abbrevCFR": "E GEMRC",
    "officialName": "ECOLE DU GÉNIE ÉLECTRIQUE ET MÉCANIQUE ROYAL CANADIEN",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "4291",
    "uic": "4291",
    "abbrevCFR": "ERIC (C)",
    "officialName": "ÉCOLE RÉGIONALE D'INSTRUCTION DES CADETS (CENTRE)",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "3935",
    "uic": "3935",
    "abbrevCFR": "URSC CENTR",
    "officialName": "UNITÉ RÉGIONALE DE SOUTIEN AUX CADETS (CENTRE)",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "6854",
    "uic": "6854",
    "abbrevCFR": "UOI BORDEN",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (ONTARIO) DÉTACHMENT BORDEN",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "6862",
    "uic": "6862",
    "abbrevCFR": "UOI COMOX",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (PACIFIQUE) DÉTACHMENT COMOX",
    "addressHtml": "PO BOX 1000 STN MAIN LAZO<br>BC V0R 2K0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN LAZO\\nBC V0R 2K0\\nCAN"
  },
  {
    "id": "6748",
    "uic": "6748",
    "abbrevCFR": "CT BORDEN",
    "officialName": "CENTRE DE TRANSITION BORDEN",
    "addressHtml": "PO BOX 1000 STN MAIN BORDEN<br>ON L0M 1C0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN BORDEN\\nON L0M 1C0\\nCAN"
  },
  {
    "id": "6740",
    "uic": "6740",
    "abbrevCFR": "CT COMOX",
    "officialName": "CENTRE DE TRANSITION COMOX",
    "addressHtml": "PO BOX 1000 STN MAIN LAZO<br>BC V0R 2K0<br>CAN",
    "addressPlain": "PO BOX 1000 STN MAIN LAZO\\nBC V0R 2K0\\nCAN"
  },
  {
    "id": "1431",
    "uic": "1431",
    "abbrevCFR": "RDDC ATLAN",
    "officialName": "RECHERCHE ET DÉVELOPPEMENT POUR LA DÉFENSE CANADA (ATLANTIQUE)",
    "addressHtml": "PO BOX 1012 STN MAIN DARTMOUTH<br>NS B2Y 3Z7<br>CAN",
    "addressPlain": "PO BOX 1012 STN MAIN DARTMOUTH\\nNS B2Y 3Z7\\nCAN"
  },
  {
    "id": "3531",
    "uic": "3531",
    "abbrevCFR": "144",
    "officialName": "Ele GC",
    "addressHtml": "144 ESCADRILLE DU GÉNIE CONSTRUCTION (PICTOU) PO BOX 1030237 WELSFORD ST PICTOU<br>NS B0K 1H0<br>CAN",
    "addressPlain": "144 ESCADRILLE DU GÉNIE CONSTRUCTION (PICTOU) PO BOX 1030237 WELSFORD ST PICTOU\\nNS B0K 1H0\\nCAN"
  },
  {
    "id": "3507",
    "uic": "3507",
    "abbrevCFR": "1 DAC",
    "officialName": "Det DÉT ÉLÉMENT DE COORDINATION DE LA COMPOSANTE AÉRIENNE OUEST, QUARTIER GÉNÉRAL DE LA 1ER DAC",
    "addressHtml": "PO BOX 10500 STATION FORCESBUILDING700, VIMY AVE EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STATION FORCESBUILDING700, VIMY AVE EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "2781",
    "uic": "2781",
    "abbrevCFR": "QG 3 Div C",
    "officialName": "QUARTIER GÉNÉRAL DE LA 3E DIVISION DU CANADA",
    "addressHtml": "PO BOX 10500 STATION FORCESBUILDING700, VIMY AVE EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STATION FORCESBUILDING700, VIMY AVE EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "3543",
    "uic": "3543",
    "abbrevCFR": "1 RGC",
    "officialName": "1ER RÉGIMENT DU GÉNIE DE COMBAT",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "1701",
    "uic": "1701",
    "abbrevCFR": "QG Esc Tra",
    "officialName": "QUARTIER GÉNÉRAL ET ESCADRON DES TRANSMISSIONS DU 1ER GROUPE-BRIGADE MÉCANISÉ DU CANADA",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "2069",
    "uic": "2069",
    "abbrevCFR": "1 UD EDMON",
    "officialName": "1ER UNITÉ DENTAIRE DÉTACHEMENT EDMONTON",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "3544",
    "uic": "3544",
    "abbrevCFR": "1 Amb C",
    "officialName": "1RE AMBULANCE DE CAMPAGNE",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "6601",
    "uic": "6601",
    "abbrevCFR": "QG 1 Gp Sv",
    "officialName": "QUARTIER GÉNÉRAL DU 1ER GROUPE DES SERVICES DE SANTÉ",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "6476",
    "uic": "6476",
    "abbrevCFR": "1 RÉGT PM",
    "officialName": "1ER RÉGIMENT DE LA POLICE MILITAIRE",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "1849",
    "uic": "1849",
    "abbrevCFR": "1 PPCLI",
    "officialName": "1ER BATAILLON, PRINCESS PATRICIA S CANADIAN LIGHT INFANTRY",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "3446",
    "uic": "3446",
    "abbrevCFR": "1 Bon Svc",
    "officialName": "1ER BATAILLON DES SERVICES (EDMONTON)",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "1011",
    "uic": "1011",
    "abbrevCFR": "Dét Edmont",
    "officialName": "DÉTACHEMENT EDMONTON, QUARTIER GÉNÉRAL DE 1ER ESCADRE",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "5173",
    "uic": "5173",
    "abbrevCFR": "15 Amb C",
    "officialName": "15E AMBULANCE DE CAMPAGNE (EDMONTON)",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "5031",
    "uic": "5031",
    "abbrevCFR": "20 RAC",
    "officialName": "20E RÉGIMENT D'ARTILLERIE DE CAMPAGNE, ARC",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "0127",
    "uic": "0127",
    "abbrevCFR": "GS 3 Div Edmonton",
    "officialName": "BASE DE SOUTIEN DE LA 3E DIVISION DU CANADA, EDMONTON",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "0048",
    "uic": "0048",
    "abbrevCFR": "ET",
    "officialName": "GS",
    "addressHtml": "3 Div ESCADRON DES TRANSMISSIONS DU GROUPE DE SOUTIEN DE LA 3E DIVISION DU CANADA PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "3 Div ESCADRON DES TRANSMISSIONS DU GROUPE DE SOUTIEN DE LA 3E DIVISION DU CANADA PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "3519",
    "uic": "3519",
    "abbrevCFR": "3 PPCLI",
    "officialName": "3E BATAILLON, PRINCESS PATRICIA'S CANADIAN LIGHT INFANTRY",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "6523",
    "uic": "6523",
    "abbrevCFR": "Dét CI 3DC",
    "officialName": "DÉTACHEMENT EDMONTON - CENTRE D'INSTRUCTIONDE LA 3E DIVISION DU CANADA",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "4893",
    "uic": "4893",
    "abbrevCFR": "Dét 4 GPRC",
    "officialName": "DÉTACHEMENT EDMONTON 4E GROUPE DE PATROUILLE DES RANGERS CANADIENS",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "2568",
    "uic": "2568",
    "abbrevCFR": "408 ETAH",
    "officialName": "408E ESCADRON TACTIQUE D'HÉLICOPTÈRES",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "5231",
    "uic": "5231",
    "abbrevCFR": "41 SBN Edm",
    "officialName": "DÉTACHEMENT EDMONTON, 41E BATAILLON DES SERVICES",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "3170",
    "uic": "3170",
    "abbrevCFR": "6 Cie Rens",
    "officialName": "6E COMPAGNIE DU RENSEIGNEMENT",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "2481",
    "uic": "2481",
    "abbrevCFR": "7 DAFC",
    "officialName": "7E DÉPÔT D'APPROVISIONNEMENT DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "6773",
    "uic": "6773",
    "abbrevCFR": "77 EDMON",
    "officialName": "77E RÉGIMENT DES LIGNES DÉTACHEMENT EDMONTON",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "1013",
    "uic": "1013",
    "abbrevCFR": "ELE A",
    "officialName": "2E ESCADRON D OPERATIONS D?APPUI AERIEN ESCADRILLE A",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "2877",
    "uic": "2877",
    "abbrevCFR": "AJAG OUEST",
    "officialName": "ASSISTANT JUGE-AVOCAT GÉNÉRAL DE L'OUEST",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "5054",
    "uic": "5054",
    "abbrevCFR": "B SQN SALH",
    "officialName": "ESCADRON B, THE SOUTH ALBERTA LIGHT HORSE",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "6980",
    "uic": "6980",
    "abbrevCFR": "UT FAC (AB)",
    "officialName": "UNITÉ DE TRANSITION DES FORCES ARMÉES CANADIENNES (ALBERTA ET NORD DU CANADA)",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "3706",
    "uic": "3706",
    "abbrevCFR": "ALFC EDMON",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (EDMONTON)",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "3695",
    "uic": "3695",
    "abbrevCFR": "SNEFC OUES",
    "officialName": "DÉTACHEMENT SERVICE NATIONAL DES ENQUÊTES DES FORCES CANADIENNES (RÉGION DE L'OUEST)",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "2006",
    "uic": "2006",
    "abbrevCFR": "CDPMFC CASERNE",
    "officialName": "DE DÉTENTION ET PRISON MILITAIRE DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "6814",
    "uic": "6814",
    "abbrevCFR": "Dét Edmont",
    "officialName": "RÉGIMENT DU RENSEIGNEMENT DE L'ARMÉE CANADIENNE DETACHMENT EDMONTON",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "6436",
    "uic": "6436",
    "abbrevCFR": "QG FOIO",
    "officialName": "QUARTIER GÉNÉRAL DE LA FORCE OPÉRATIONNELLE INTERARMÉES (OUEST)",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "3447",
    "uic": "3447",
    "abbrevCFR": "LDSH (RC)",
    "officialName": "LORD STRATHCONA'S HORSE (ROYAL CANADIANS)",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "5122",
    "uic": "5122",
    "abbrevCFR": "Loyal EDM Régt",
    "officialName": "THE LOYAL EDMONTON REGIMENT (4E BATAILLON, PRINCESS PATRICIA'S CANADIAN LIGHT INFANTRY)",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "2995",
    "uic": "2995",
    "abbrevCFR": "CV AN",
    "officialName": "CENTRE DE LA VOILE (ALBERTA NORD)",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "0332",
    "uic": "0332",
    "abbrevCFR": "WCAQ EDM",
    "officialName": "WORKCENTRE DE l'ASSURANCE DE QUALITÉ (EDMONTON)",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "3750",
    "uic": "3750",
    "abbrevCFR": "Musique ArtillerieRC",
    "officialName": "LA MUSIQUE DE L'ARTILLERIE ROYALE CANADIENNE",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "4897",
    "uic": "4897",
    "abbrevCFR": "PMR OUEST",
    "officialName": "PROCURER MILITAIRE REGION DE L'OUEST",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "6842",
    "uic": "6842",
    "abbrevCFR": "UOI (Ouest)",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (OUEST)",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "6554",
    "uic": "6554",
    "abbrevCFR": "CT EDMONTO",
    "officialName": "CENTRE DE TRANSITION EDMONTON",
    "addressHtml": "PO BOX 10500 STN FORCES EDMONTON<br>AB T5J 4J5<br>CAN",
    "addressPlain": "PO BOX 10500 STN FORCES EDMONTON\\nAB T5J 4J5\\nCAN"
  },
  {
    "id": "3760",
    "uic": "3760",
    "abbrevCFR": "14 ESC GC",
    "officialName": "14E ESCADRON DU GÉNIE CONSTRUCTION",
    "addressHtml": "PO BOX 110 STN MAIN BRIDGEWATER<br>NS B4V 2W8<br>CAN",
    "addressPlain": "PO BOX 110 STN MAIN BRIDGEWATER\\nNS B4V 2W8\\nCAN"
  },
  {
    "id": "3366",
    "uic": "3366",
    "abbrevCFR": "143",
    "officialName": "Ele GC",
    "addressHtml": "143 ESCADRILLE DU GÉNIE CONSTRUCTION (LUNENBURG COUNTY) PO BOX 110 STN MAIN BRIDGEWATER<br>NS B4V 2W8<br>CAN",
    "addressPlain": "143 ESCADRILLE DU GÉNIE CONSTRUCTION (LUNENBURG COUNTY) PO BOX 110 STN MAIN BRIDGEWATER\\nNS B4V 2W8\\nCAN"
  },
  {
    "id": "3131",
    "uic": "3131",
    "abbrevCFR": "1 DAC",
    "officialName": "DET DÉT. ÉLÉMENT DE COORDINATION DE LA COMPOSANTE AÉRIENNE PACIFIQUE, QUARTIER GÉNÉRAL DE LA 1ER DAC",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "3999",
    "uic": "3999",
    "abbrevCFR": "QG 1 DAC",
    "officialName": "QUARTIER GÉNÉRAL DE LA 1RE DIVISION AÉRIENNE DU CANADA",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "6590",
    "uic": "6590",
    "abbrevCFR": "QG 1 DC",
    "officialName": "QUARTIER GÉNÉRAL DE LA 1ER DIVISION DU CANADA",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "2082",
    "uic": "2082",
    "abbrevCFR": "",
    "officialName": "1re Unité dentaire 1ER UNITÉ DENTAIRE DÉTACHEMENT KINGSTON",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "2052",
    "uic": "2052",
    "abbrevCFR": "1 UD ESQUI",
    "officialName": "1ER UNITÉ DENTAIRE DÉTACHEMENT ESQUIMALT",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "2053",
    "uic": "2053",
    "abbrevCFR": "1 UD GAGET",
    "officialName": "1ER UNITÉ DENTAIRE DÉTACHEMENT GAGETOWN",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "2087",
    "uic": "2087",
    "abbrevCFR": "1 UD WINNI",
    "officialName": "1ER UNITÉ DENTAIRE DÉTACHEMENT WINNIPEG",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "3557",
    "uic": "3557",
    "abbrevCFR": "1 UAG",
    "officialName": "1ER UNITÉ D'APPUI DU GÉNIE",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "0994",
    "uic": "0994",
    "abbrevCFR": "Dét Gageto",
    "officialName": "DÉTACHEMENT GAGETOWN, QUARTIER GÉNÉRAL DE 1ER ESCADRE",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "3996",
    "uic": "3996",
    "abbrevCFR": "QG 1 ERE",
    "officialName": "QUARTIER GÉNÉRAL DE LA 1RE ESCADRE",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "9960",
    "uic": "9960",
    "abbrevCFR": "17 ERE",
    "officialName": "17E ESCADRE",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "6570",
    "uic": "6570",
    "abbrevCFR": "QG 2 DAC",
    "officialName": "QUARTIER GÉNÉRAL DE LA 2E DIVISION AÉRIENNE DU CANADA",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "1848",
    "uic": "1848",
    "abbrevCFR": "2 RCR",
    "officialName": "2E BATAILLON, THE ROYAL CANADIAN RÉGIMENT",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "4935",
    "uic": "4935",
    "abbrevCFR": "21 Regt GE",
    "officialName": "21E RÉGIMENT DE GUERRE ÉLECTRONIQUE",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "3956",
    "uic": "3956",
    "abbrevCFR": "23 C Svc S",
    "officialName": "23E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "4025",
    "uic": "4025",
    "abbrevCFR": "3 DC HQ DE",
    "officialName": "DÉTACHEMENT MANITOBA, QUARTIER GÉNÉRAL DE LA 3E DIVISION DU CANADA",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "3579",
    "uic": "3579",
    "abbrevCFR": "33 C",
    "officialName": "Svc S FC 33E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "3664",
    "uic": "3664",
    "abbrevCFR": "QG 38 GBC",
    "officialName": "QUARTIER GÉNÉRAL DU 38E GROUPE-BRIGADE DU CANADA",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "6724",
    "uic": "6724",
    "abbrevCFR": "39 SR Det",
    "officialName": "DÉTACHEMENT VICTORIA, 39E RÉGIMENT DES TRANSMISSIONS",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "3688",
    "uic": "3688",
    "abbrevCFR": "4 GPRC",
    "officialName": "4E GROUPE DE PATROUILLE DES RANGERS CANADIENS",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "4892",
    "uic": "4892",
    "abbrevCFR": "Dét 4 GPRC",
    "officialName": "DÉTACHEMENT WINNIPEG 4E GROUPE DE PATROUILLE DES RANGERS CANADIENS",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "1775",
    "uic": "1775",
    "abbrevCFR": "4 ESR",
    "officialName": "4E RÉGIMENT D'APPUI DU GÉNIE",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "3431",
    "uic": "3431",
    "abbrevCFR": "4 Régt (AG",
    "officialName": "4E RÉGIMENT D'ARTILLERIE (APPUI GÉNÉRAL), ARTILLERIE ROYALE CANADIENNE",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "7006",
    "uic": "7006",
    "abbrevCFR": "",
    "officialName": "402E ESC 402E ESCADRON",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "7717",
    "uic": "7717",
    "abbrevCFR": "403 EEOH",
    "officialName": "403E ESCADRON D'ENTRAINEMENT OPÉRATIONNEL D'HÉLICOPTÈRES",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "3574",
    "uic": "3574",
    "abbrevCFR": "42 C Svc S",
    "officialName": "42E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "3435",
    "uic": "3435",
    "abbrevCFR": "435 Esc (TetS)",
    "officialName": "435E ESCADRON DE TRANSPORT ET DE SAUVETAGE",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "1318",
    "uic": "1318",
    "abbrevCFR": "443 ESC HM",
    "officialName": "443E ESCADRON D'HÉLICOPTÈRE MARITIME",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "3182",
    "uic": "3182",
    "abbrevCFR": "CI 5 Div C",
    "officialName": "CENTRE D'INSTRUCTION DE LA 5E DIVISION DU CANADA",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "0105",
    "uic": "0105",
    "abbrevCFR": "BS 5 Div C",
    "officialName": "BASE DE SOUTIEN DE LA 5E DIVISION DU CANADA GAGETOWN",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "4129",
    "uic": "4129",
    "abbrevCFR": "ET",
    "officialName": "GS",
    "addressHtml": "5 Di ESCADRON DES TRANSMISSIONS DU GROUPE DE SOUTIEN DE LA 5E DIVISION DU CANADA PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "5 Di ESCADRON DES TRANSMISSIONS DU GROUPE DE SOUTIEN DE LA 5E DIVISION DU CANADA PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "6935",
    "uic": "6935",
    "abbrevCFR": "6 QG BACC",
    "officialName": "6E QUARTIER GÉNÉRAL DU BRIGADE D'APPUI AU COMBAT DU CANADA",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "3430",
    "uic": "3430",
    "abbrevCFR": "6 INT COY",
    "officialName": "DÉTACHEMENT WINNIPEG 6E COMPAGNIE DU RENSEIGNEMENT",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "0253",
    "uic": "0253",
    "abbrevCFR": "76 Dét ESQ",
    "officialName": "76E RÉGIMENT DES COMMUNICATIONS DÉTACHEMENT ESQUIMALT",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "6905",
    "uic": "6905",
    "abbrevCFR": "77 Regt Ligne",
    "officialName": "77E RÉGIMENT DES LIGNES",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "2900",
    "uic": "2900",
    "abbrevCFR": "AJAG PACIF",
    "officialName": "ASSISTANT JUGE-AVOCAT GÉNÉRAL PACIFIQUE",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "2875",
    "uic": "2875",
    "abbrevCFR": "AJAG PRAIR",
    "officialName": "ASSISTANT JUGE-AVOCAT GÉNÉRAL (PRAIRIE)",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "2971",
    "uic": "2971",
    "abbrevCFR": "ALBERT HD",
    "officialName": "CENTRE D'ENTRAINEMENT DES CADETS D'ALBERT HEAD",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "0103",
    "uic": "0103",
    "abbrevCFR": "BIS BASE",
    "officialName": "DES FORCES CANADIENNES ESQUIMALT",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "6983",
    "uic": "6983",
    "abbrevCFR": "CEMM DET E",
    "officialName": "CHEF D'ÉTAT-MAJOR DE LA MARINE DÉTACHEMENT ESQUIMALT",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "6878",
    "uic": "6878",
    "abbrevCFR": "Régt Rens",
    "officialName": "RÉGIMENT DU RENSEIGNEMENT DE L' ARMÉE CANADIENNE",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "2027",
    "uic": "2027",
    "abbrevCFR": "CCEMAC COLLEGE",
    "officialName": "DE COMMANDEMENT ET D' ÉTAT-MAJOR DE L'ARMÉE CANADIENNE",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "6460",
    "uic": "6460",
    "abbrevCFR": "QG Dét",
    "officialName": "Gag QG CDIAC DÉT GAGETOWN (CSAC)",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "3915",
    "uic": "3915",
    "abbrevCFR": "QG CDIAC",
    "officialName": "QUARTIER GÉNÉRAL DU CENTRE DE DOCTRINE ET D'INSTRUCTION DE L'ARMÉE CANADIENNE",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "6979",
    "uic": "6979",
    "abbrevCFR": "UT FAC (MB)",
    "officialName": "UNITÉ DE TRANSITION DES FORCES ARMÉES CANADIENNES (MANITOBA ET SASKATCHEWAN)",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "6971",
    "uic": "6971",
    "abbrevCFR": "UT FAC CB",
    "officialName": "UNITÉ DE TRANSITION DES FORCES ARMÉES CANADIENNES (COLOMBIE-BRITANNIQUE)",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "6973",
    "uic": "6973",
    "abbrevCFR": "UT FAC NB/",
    "officialName": "UNITÉ DE TRANSITION DES FORCES ARMÉES CANADIENNES (NOUVEAU-BRUNSWICK ET ÎLES-DU-PRINCE-ÉDOUARD)",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "3769",
    "uic": "3769",
    "abbrevCFR": "FLTCANPAC QUARTIER",
    "officialName": "GÉNÉRAL DE LA FLOTTE CANADIENNE DU PACIFIQUE",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "9524",
    "uic": "9524",
    "abbrevCFR": "FLTCANPAC FLOTTE",
    "officialName": "CANADIENNE DU PACIFIQUE",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "4877",
    "uic": "4877",
    "abbrevCFR": "QG FSC",
    "officialName": "QUARTIER GÉNÉRAL DE LA FORCE SOUS-MARINE CANADIENNE",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "3765",
    "uic": "3765",
    "abbrevCFR": "UACEE UNITÉ",
    "officialName": "DE L'ARMÉE CANADIENNE D'ÉSSAIS ET D'ÉVALUATION",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "4938",
    "uic": "4938",
    "abbrevCFR": "QG ACD",
    "officialName": "QUARTIER GÉNÉRAL DE L'ACADÉMIE CANADIENNE DE LA DÉFENSE",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "1231",
    "uic": "1231",
    "abbrevCFR": "DMFC ROCKY",
    "officialName": "DÉPÔT DE MUNITIONS DES FORCES CANADIENNES ROCKY POINT",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "0114",
    "uic": "0114",
    "abbrevCFR": "BFC Kingst",
    "officialName": "BASSE DES FORCES CANADIENNES, KINGSTON",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "0117",
    "uic": "0117",
    "abbrevCFR": "BFC WINNIP",
    "officialName": "BASE DES FORCES CANADIENNES WINNIPEG",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "1840",
    "uic": "1840",
    "abbrevCFR": "UMMCFC 6IEME",
    "officialName": "ESCADRON DES INFRASTRUCTURE CLASSIFIEE",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "3707",
    "uic": "3707",
    "abbrevCFR": "ALFC ESQUI",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (ESQUIMALT)",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "3708",
    "uic": "3708",
    "abbrevCFR": "ALFC GAGET",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (GAGETOWN)",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "3713",
    "uic": "3713",
    "abbrevCFR": "ALFC KINGS",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (KINGSTON)",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "3728",
    "uic": "3728",
    "abbrevCFR": "ALFC WINNI",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (WINNIPEG)",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "6776",
    "uic": "6776",
    "abbrevCFR": "QG GSOIFC",
    "officialName": "QUARTIER GÉNÉRAL DU GROUPE DE SOUTIEN OPÉRATIONNEL INTERARMÉES DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "3028",
    "uic": "3028",
    "abbrevCFR": "RTIFC RÉGIMENT",
    "officialName": "DES TRANSMISSIONS INTERARMÉES DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "2225",
    "uic": "2225",
    "abbrevCFR": "SSPFC GAGE",
    "officialName": "SECTON DU SERVICE POSTALE DES FORCES CANADIENNES (GAGETOWN)",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "2240",
    "uic": "2240",
    "abbrevCFR": "SSPFC KING",
    "officialName": "SECTON DU SERVICE POSTALE DES FORCES CANADIENNES (KINGSTON)",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "2250",
    "uic": "2250",
    "abbrevCFR": "SSPFC VICT",
    "officialName": "SECTON DU SERVICE POSTALE DES FORCES CANADIENNES (VICTORIA)",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "2245",
    "uic": "2245",
    "abbrevCFR": "SSPFC WINN",
    "officialName": "SECTON DU SERVICE POSTALE DES FORCES CANADIENNES (WINNIPEG)",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "3918",
    "uic": "3918",
    "abbrevCFR": "SFC KINGST",
    "officialName": "STATION DES FORCES CANADIENNES LEITRIM DÉTACHEMENT KINGSTON",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "2609",
    "uic": "2609",
    "abbrevCFR": "E Met FC",
    "officialName": "ÉCOLE DE MÉTÉOROLOGIE DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "1810",
    "uic": "1810",
    "abbrevCFR": "EECFC ÉCOLE",
    "officialName": "DE L' ÉLECTRONIQUE ET DES COMMUNICATIONS DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "1773",
    "uic": "1773",
    "abbrevCFR": "EGMFC ÉCOLE",
    "officialName": "DU GÉNIE MILITAIRE DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "3883",
    "uic": "3883",
    "abbrevCFR": "ERMFC ÉCOLE",
    "officialName": "DU RENSEIGNEMENT MILITAIRE DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "2612",
    "uic": "2612",
    "abbrevCFR": "ESMAFC ÉCOLE",
    "officialName": "DE SURVIE ET DE MÉDECINE DE L'AIR DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "2174",
    "uic": "2174",
    "abbrevCFR": "CEC ARGONA",
    "officialName": "CENTRE D'ENTRAINEMENT DES CADETS ARGONAUT",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "2976",
    "uic": "2976",
    "abbrevCFR": "CEC NCSM O",
    "officialName": "CENTRE D'ENTRAINEMENT DES CADETS NCSM ONTARIO",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "2037",
    "uic": "2037",
    "abbrevCFR": "QG CIC",
    "officialName": "QUARTIER GÉNÉRAL DU CENTRE D' INSTRUCTION AU COMBAT",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "1016",
    "uic": "1016",
    "abbrevCFR": "ELE D",
    "officialName": "2E ESCADRON D OPERATIONS D?APPUI AERIEN ESCADRILLE D",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "6813",
    "uic": "6813",
    "abbrevCFR": "Dét Kingst",
    "officialName": "RÉGIMENT DU RENSEIGNEMENT DE L'ARMÉE CANADIENNE DETACHMENT KINGSTON",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "6834",
    "uic": "6834",
    "abbrevCFR": "DET KINGST",
    "officialName": "DIRECTEUR GÉNÉRAL - DÉVELOPPEMENT DES FORCES (CAPACITÉS D'INFORMATION) DÉTACHEMENT KINGSTON",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "2801",
    "uic": "2801",
    "abbrevCFR": "JAA GAGETO",
    "officialName": "JUGE-AVOCAT ADJOINT (GAGETOWN)",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "0462",
    "uic": "0462",
    "abbrevCFR": "FA(P) FORMATION",
    "officialName": "AUGMENTATION (PACIFIQUE)",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "1227",
    "uic": "1227",
    "abbrevCFR": "UPF(P) UNITÉ",
    "officialName": "DE PLONGÉE DE LA FLOTTE (PACIFIQUE)",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "3555",
    "uic": "3555",
    "abbrevCFR": "IMF CAPE B",
    "officialName": "INSTALLATION DE MAINTENANCE DE LA FLOTTE - CAPE BRETON",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "4869",
    "uic": "4869",
    "abbrevCFR": "C SVC S(P)",
    "officialName": "CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES (PACIFIQUE)",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "3982",
    "uic": "3982",
    "abbrevCFR": "Gp Svc S",
    "officialName": "QUARTIER GÉNÉRAL DU GROUPE DES SERVICES DE SANTÉ DES FORCES CANADIENNES DÉTACHEMENT KINGSTON",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "6636",
    "uic": "6636",
    "abbrevCFR": "Gp Svc S",
    "officialName": "QUARTIER GÉNÉRAL DU GROUPE DES SERVICES DE SANTÉ DES FORCES CANADIENNES DÉTACHEMENT WINNIPEG",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "3361",
    "uic": "3361",
    "abbrevCFR": "NCSM BRAND",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ BRANDON",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "1235",
    "uic": "1235",
    "abbrevCFR": "NCSM CALGARY",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ CALGARY",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "1326",
    "uic": "1326",
    "abbrevCFR": "NCSM CATAR",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ CATARAQUI",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "3817",
    "uic": "3817",
    "abbrevCFR": "NCSM CORNE",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ CORNER BROOK",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "1335",
    "uic": "1335",
    "abbrevCFR": "NCSM MALAH",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ MALAHAT",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "6931",
    "uic": "6931",
    "abbrevCFR": "NCSM MAX B",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ MAX BERNAYS",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "1682",
    "uic": "1682",
    "abbrevCFR": "NCSM OTTAW",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ OTTAWA",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "8334",
    "uic": "8334",
    "abbrevCFR": "NCSM PROTE",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ PROTECTEUR",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "1236",
    "uic": "1236",
    "abbrevCFR": "NCSM REGINA",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ RÉGINA",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "6934",
    "uic": "6934",
    "abbrevCFR": "NCSM ROBET",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ ROBERT HAMPTON GRAY",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "3360",
    "uic": "3360",
    "abbrevCFR": "NCSM SASKA",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ SASKATOON",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "1242",
    "uic": "1242",
    "abbrevCFR": "NCSM VANCOUVER",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ VANCOUVER",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "0493",
    "uic": "0493",
    "abbrevCFR": "NCSM VENTU",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTE VENTURE",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "3815",
    "uic": "3815",
    "abbrevCFR": "NCSM VICTO",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ VICTORIA",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "3356",
    "uic": "3356",
    "abbrevCFR": "NCSM WHITE",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ WHITEHORSE",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "1679",
    "uic": "1679",
    "abbrevCFR": "NCSM WINNI",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ WINNIPEG",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "4231",
    "uic": "4231",
    "abbrevCFR": "BSH BUREAU",
    "officialName": "DES SERVICES HYDROGRAPHIQUE, ESQUIMALT",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "7753",
    "uic": "7753",
    "abbrevCFR": "INF SCHOOL",
    "officialName": "ÉCOLE DE L'INFANTERIE",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "6735",
    "uic": "6735",
    "abbrevCFR": "CMI CENTRE",
    "officialName": "MÉTÉOROLOGIQUE INTERARMÉES",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "4235",
    "uic": "4235",
    "abbrevCFR": "CCCOS Vict",
    "officialName": "CENTRE CONJOINT DE COORDINATION DES OPÉRATIONS DE SAUVETAGE (VICTORIA)",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "6599",
    "uic": "6599",
    "abbrevCFR": "FOI X",
    "officialName": "FORCE OPÉRATIONNELLE INTERARMÉES X",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "6435",
    "uic": "6435",
    "abbrevCFR": "QG FOIP",
    "officialName": "QUARTIER GÉNÉRAL DE LA FORCE OPÉRATIONNELLE INTERARMÉES (PACIFIQUE)",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "2993",
    "uic": "2993",
    "abbrevCFR": "CV MAN",
    "officialName": "CENTRE DE LA VOILE (MANITOBA)",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "3339",
    "uic": "3339",
    "abbrevCFR": "Musique FM",
    "officialName": "LA MUSIQUE DES FORCES MARITIMES DU PACIFIQUE",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "0097",
    "uic": "0097",
    "abbrevCFR": "QG FMAR(P)",
    "officialName": "QUARTIER GÉNÉRAL DES FORCES MARITIMES DU PACIFIQUE",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "6673",
    "uic": "6673",
    "abbrevCFR": "UPM ESQUIM",
    "officialName": "UNITÉ DE LA POLICE MILITAIRE ESQUIMALT",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "1347",
    "uic": "1347",
    "abbrevCFR": "EN (P)",
    "officialName": "L'ÉCOLE NAVALE (PACIFIQUE)",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "6942",
    "uic": "6942",
    "abbrevCFR": "ESN ÉQUIPE",
    "officialName": "DE SÉCURITÉ NAVALE",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "4878",
    "uic": "4878",
    "abbrevCFR": "QG GIM",
    "officialName": "QUARTIER GÉNÉRAL DU GROUPE DE L'INSTRUCTION DE LA MARINE",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "8161",
    "uic": "8161",
    "abbrevCFR": "GOTN GROUPE",
    "officialName": "DES OPÉRATIONS TACTIQUES NAVALES",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "6851",
    "uic": "6851",
    "abbrevCFR": "CCP PACIFI",
    "officialName": "CENTRE DE CONTRÔLE DU PERSONNEL (PACIFIQUE)",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "7085",
    "uic": "7085",
    "abbrevCFR": "UPE UNITÉ",
    "officialName": "DES PATROUILLEURS D'ENTRAINEMENT",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "3916",
    "uic": "3916",
    "abbrevCFR": "CFSP CENTRE",
    "officialName": "DE FORMATION POUR LE SOUTIEN DE LA PAIX",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "0182",
    "uic": "0182",
    "abbrevCFR": "WCAQ VICTO",
    "officialName": "WORKCENTRE DE L'ASSURANCE DE QUALITÉ (VICTORIA)",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "0333",
    "uic": "0333",
    "abbrevCFR": "WCAQ WIN",
    "officialName": "WORKCENTRE DE L'ASSURANCE DE QUALITÉ (WINNIPEG)",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "1760",
    "uic": "1760",
    "abbrevCFR": "",
    "officialName": "ÉCOLE ARC L'ÉCOLE DU RÉGIMENT ROYAL DE L'ARTILLERIE CANADIENNE",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "7752",
    "uic": "7752",
    "abbrevCFR": "ECBRC ÉCOLE",
    "officialName": "DU CORPS BLINDÉ ROYAL CANADIEN",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "2617",
    "uic": "2617",
    "abbrevCFR": "Musique AviationRC",
    "officialName": "MUSIQUE DE L'AVIATION ROYALE CANADIENNE",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "1661",
    "uic": "1661",
    "abbrevCFR": "",
    "officialName": "COLLEGE BA COLLÈGE AÉROSPATIALE DE L' AVIATION ROYALE CANADIENNE LCOL AVN WILLIAM G. BARKER VC",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "1183",
    "uic": "1183",
    "abbrevCFR": "LRP ARC",
    "officialName": "LISTE RÉSERVE PRIMAIRE - AVIATION ROYALE CANADIENNE",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "6668",
    "uic": "6668",
    "abbrevCFR": "RCD Dét Ga",
    "officialName": "DÉTACHEMENT GAGETOWN, THE ROYAL CANADIAN DRAGOONS",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "4289",
    "uic": "4289",
    "abbrevCFR": "RCIS (NO)",
    "officialName": "ÉCOLE RÉGIONALE D'INSTRUCTION DES CADETS (NORD-OUEST)",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "4288",
    "uic": "4288",
    "abbrevCFR": "ERIC (PAC)",
    "officialName": "ÉCOLE RÉGIONALE D'INSTRUCTION DES CADETS (PACIFIQUE)",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "3936",
    "uic": "3936",
    "abbrevCFR": "URSC N-O",
    "officialName": "UNITÉ RÉGIONALE DE SOUTIEN AUX CADETS (NORD-OUEST)",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "3937",
    "uic": "3937",
    "abbrevCFR": "URSC PACIF",
    "officialName": "UNITÉ RÉGIONALE DE SOUTIEN AUX CADETS (PACIFIQUE)",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "0046",
    "uic": "0046",
    "abbrevCFR": "CMR COLLÈGE",
    "officialName": "MILITAIRE ROYAL DU CANADA",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "6768",
    "uic": "6768",
    "abbrevCFR": "PMR PACIFI",
    "officialName": "PROCURER MILITAIRE REGION DU PACIFIQUE",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "6841",
    "uic": "6841",
    "abbrevCFR": "UOI (Pacifique)",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (PACIFIQUE)",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "6898",
    "uic": "6898",
    "abbrevCFR": "UOI GAGETOWN",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (ATLANTIQUE) DÉTACHEMENT GAGETOWN",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "6855",
    "uic": "6855",
    "abbrevCFR": "UOI KINGSTON",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (ONTARIO) DÉTACHMENT KINGSTON",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "6894",
    "uic": "6894",
    "abbrevCFR": "UOI WINNIPEG",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (OUEST) DÉTACHMENT WINNIPEG",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "3094",
    "uic": "3094",
    "abbrevCFR": "EM(P) ENTRAÎNEMENT",
    "officialName": "MARITIME (PACIFIQUE)",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "3900",
    "uic": "3900",
    "abbrevCFR": "E TAC",
    "officialName": "ÉCOLE DE LA TACTIQUE",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "6553",
    "uic": "6553",
    "abbrevCFR": "CT ESQUIMA",
    "officialName": "CENTRE DE TRANSITION ESQUIMALT",
    "addressHtml": "PO BOX 17000 STN FORCES VICTORIA<br>BC V9A 7N2<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES VICTORIA\\nBC V9A 7N2\\nCAN"
  },
  {
    "id": "6559",
    "uic": "6559",
    "abbrevCFR": "CT GAGETOW",
    "officialName": "CENTRE DE TRANSITION GAGETOWN",
    "addressHtml": "PO BOX 17000 STN FORCES OROMOCTO<br>NB E2V 4J5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES OROMOCTO\\nNB E2V 4J5\\nCAN"
  },
  {
    "id": "6689",
    "uic": "6689",
    "abbrevCFR": "CT KINGSTO",
    "officialName": "CENTRE DE TRANSITION KINGSTON",
    "addressHtml": "PO BOX 17000 STN FORCES KINGSTON<br>ON K7K 7B4<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES KINGSTON\\nON K7K 7B4\\nCAN"
  },
  {
    "id": "6555",
    "uic": "6555",
    "abbrevCFR": "CT WINNIPE",
    "officialName": "CENTRE DE TRANSITION WINNIPEG",
    "addressHtml": "PO BOX 17000 STN FORCES WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCES WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "6676",
    "uic": "6676",
    "abbrevCFR": "QG GP PM FA",
    "officialName": "QUARTIER GÉNÉRAL DU GROUPE DE LA POLICE MILITAIRE DE LA FORCE AÉRIENNE",
    "addressHtml": "PO BOX 17000 STN FORCESBUILDING 25 WINNIPEG<br>MB R3J 3Y5<br>CAN",
    "addressPlain": "PO BOX 17000 STN FORCESBUILDING 25 WINNIPEG\\nMB R3J 3Y5\\nCAN"
  },
  {
    "id": "2115",
    "uic": "2115",
    "abbrevCFR": "CEEM FC",
    "officialName": "CENTRES D'EXPÉRIMENTATION ET D'ESSAIS MARITIMES DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 188 STN MAIN NANOOSE BAY<br>BC V9P 9J9<br>CAN",
    "addressPlain": "PO BOX 188 STN MAIN NANOOSE BAY\\nBC V9P 9J9\\nCAN"
  },
  {
    "id": "3678",
    "uic": "3678",
    "abbrevCFR": "SFC MASSET",
    "officialName": "STATION DES FORCES CANADIENNES LEITRIM, DÉTACHEMENT MASSET",
    "addressHtml": "PO BOX 2000 STN MAIN MASSET<br>BC V0T 1M0<br>CAN",
    "addressPlain": "PO BOX 2000 STN MAIN MASSET\\nBC V0T 1M0\\nCAN"
  },
  {
    "id": "0022",
    "uic": "0022",
    "abbrevCFR": "CRFC DET",
    "officialName": "S DÉTACHEMENT",
    "addressHtml": "ST JOHN S, CENTRE DE RECRUTEMENT DES FORCES CANADIENNES HALIFAX PO BOX 2028 STN C ST JOHN S<br>NL A1C 6B5<br>CAN",
    "addressPlain": "ST JOHN S, CENTRE DE RECRUTEMENT DES FORCES CANADIENNES HALIFAX PO BOX 2028 STN C ST JOHN S\\nNL A1C 6B5\\nCAN"
  },
  {
    "id": "2035",
    "uic": "2035",
    "abbrevCFR": "1",
    "officialName": "UD",
    "addressHtml": "ST JO 1ER UNITÉ DENTAIRE DÉTACHEMENT ST JOHN'S PO BOX 2028 STN C ST JOHN S<br>NL A1C 6B5<br>CAN",
    "addressPlain": "ST JO 1ER UNITÉ DENTAIRE DÉTACHEMENT ST JOHN'S PO BOX 2028 STN C ST JOHN S\\nNL A1C 6B5\\nCAN"
  },
  {
    "id": "5133",
    "uic": "5133",
    "abbrevCFR": "1 R NFLD R",
    "officialName": "1ER BATAILLON, THE ROYAL NEWFOUNDLAND REGIMENT",
    "addressHtml": "PO BOX 2028 STN C ST JOHN S<br>NL A1C 6B5<br>CAN",
    "addressPlain": "PO BOX 2028 STN C ST JOHN S\\nNL A1C 6B5\\nCAN"
  },
  {
    "id": "5067",
    "uic": "5067",
    "abbrevCFR": "37 RGC",
    "officialName": "37E RÉGIMENT DU GÉNIE DE COMBAT",
    "addressHtml": "PO BOX 2028 STN C ST JOHN S<br>NL A1C 6B5<br>CAN",
    "addressPlain": "PO BOX 2028 STN C ST JOHN S\\nNL A1C 6B5\\nCAN"
  },
  {
    "id": "6708",
    "uic": "6708",
    "abbrevCFR": "37 Régt tr",
    "officialName": "37E RÉGIMENT DES TRANSMISSIONS",
    "addressHtml": "PO BOX 2028 STN C ST JOHN S<br>NL A1C 6B5<br>CAN",
    "addressPlain": "PO BOX 2028 STN C ST JOHN S\\nNL A1C 6B5\\nCAN"
  },
  {
    "id": "6701",
    "uic": "6701",
    "abbrevCFR": "37 Bon Svc",
    "officialName": "37E BATAILLON DES SERVICES",
    "addressHtml": "PO BOX 2028 STN C ST JOHN S<br>NL A1C 6B5<br>CAN",
    "addressPlain": "PO BOX 2028 STN C ST JOHN S\\nNL A1C 6B5\\nCAN"
  },
  {
    "id": "0139",
    "uic": "0139",
    "abbrevCFR": "GS 5 DIV C",
    "officialName": "GROUPE DE SOUTIEN DE LA 5e DIVISION DU CANADA (GARNISON",
    "addressHtml": "ST JOHN'S) PO BOX 2028 STN C ST JOHN S<br>NL A1C 6B5<br>CAN",
    "addressPlain": "ST JOHN'S) PO BOX 2028 STN C ST JOHN S\\nNL A1C 6B5\\nCAN"
  },
  {
    "id": "2988",
    "uic": "2988",
    "abbrevCFR": "AVALON SCS",
    "officialName": "CENTRE D'INSTRUCTION D'ÉTÉ DES CADETS DE LA MARINE - NCSM AVALON",
    "addressHtml": "PO BOX 2028 STN C ST JOHN S<br>NL A1C 6B5<br>CAN",
    "addressPlain": "PO BOX 2028 STN C ST JOHN S\\nNL A1C 6B5\\nCAN"
  },
  {
    "id": "3630",
    "uic": "3630",
    "abbrevCFR": "BFC Gan Dé",
    "officialName": "DÉTACHEMENT TORBAY, BASE DES FORCES CANADIENNES GANDER",
    "addressHtml": "PO BOX 2028 STN C ST JOHN S<br>NL A1C 6B5<br>CAN",
    "addressPlain": "PO BOX 2028 STN C ST JOHN S\\nNL A1C 6B5\\nCAN"
  },
  {
    "id": "3946",
    "uic": "3946",
    "abbrevCFR": "Dét St",
    "officialName": "Joh DÉTACHEMENT",
    "addressHtml": "ST JOHN'S 26 CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES PO BOX 2028 STN C ST JOHN S<br>NL A1C 6B5<br>CAN",
    "addressPlain": "ST JOHN'S 26 CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES PO BOX 2028 STN C ST JOHN S\\nNL A1C 6B5\\nCAN"
  },
  {
    "id": "6306",
    "uic": "6306",
    "abbrevCFR": "Dét St",
    "officialName": "Joh DÉTACHEMENT",
    "addressHtml": "ST JOHN'S 35E AMBULANCE DE CAMPAGNE (SYDNEY) PO BOX 2028 STN C ST JOHN S<br>NL A1A 0P5<br>CAN",
    "addressPlain": "ST JOHN'S 35E AMBULANCE DE CAMPAGNE (SYDNEY) PO BOX 2028 STN C ST JOHN S\\nNL A1A 0P5\\nCAN"
  },
  {
    "id": "1320",
    "uic": "1320",
    "abbrevCFR": "NCSM CABOT",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ CABOT",
    "addressHtml": "PO BOX 2028 STN C ST JOHN S<br>NL A1C 6B5<br>CAN",
    "addressPlain": "PO BOX 2028 STN C ST JOHN S\\nNL A1C 6B5\\nCAN"
  },
  {
    "id": "0360",
    "uic": "0360",
    "abbrevCFR": "URSC(A) ST",
    "officialName": "UNITÉ RÉGIONALE DE SOUTIEN AUX CADETS (ATLANTIQUE) DÉTACHEMENT",
    "addressHtml": "ST JOHN'S PO BOX 2028 STN C ST JOHN S<br>NL A1C 6B5<br>CAN",
    "addressPlain": "ST JOHN'S PO BOX 2028 STN C ST JOHN S\\nNL A1C 6B5\\nCAN"
  },
  {
    "id": "6755",
    "uic": "6755",
    "abbrevCFR": "CT ST-JOHN",
    "officialName": "CENTRE DE TRANSITION ST-JOHN'S",
    "addressHtml": "PO BOX 2028 STN C ST JOHN S<br>NL A1C 6B5<br>CAN",
    "addressPlain": "PO BOX 2028 STN C ST JOHN S\\nNL A1C 6B5\\nCAN"
  },
  {
    "id": "5123",
    "uic": "5123",
    "abbrevCFR": "RM RANGERS",
    "officialName": "THE ROCKY MOUNTAIN RANGERS",
    "addressHtml": "PO BOX 3250 STN TERMINAL MPP KAMLOOPS<br>BC V2C 6B8<br>CAN",
    "addressPlain": "PO BOX 3250 STN TERMINAL MPP KAMLOOPS\\nBC V2C 6B8\\nCAN"
  },
  {
    "id": "5028",
    "uic": "5028",
    "abbrevCFR": "84 Bie Aut",
    "officialName": "84E BATTERIE AUTONOME DE CAMPAGNE, ARC",
    "addressHtml": "PO BOX 340 STN MAIN YARMOUTH<br>NS B5A 4B3<br>CAN",
    "addressPlain": "PO BOX 340 STN MAIN YARMOUTH\\nNS B5A 4B3\\nCAN"
  },
  {
    "id": "4273",
    "uic": "4273",
    "abbrevCFR": "ÉCON FC",
    "officialName": "ES ÉCONOMATS DES FORCES CANADIENNES, DÉTACHEMENT ESQUIMALT",
    "addressHtml": "PO BOX 3725 STN CSC VICTORIA<br>BC V8W 3S7<br>CAN",
    "addressPlain": "PO BOX 3725 STN CSC VICTORIA\\nBC V8W 3S7\\nCAN"
  },
  {
    "id": "3532",
    "uic": "3532",
    "abbrevCFR": "192",
    "officialName": "Ele GC",
    "addressHtml": "192 ESCADRILLE DU GÉNIE CONSTRUCTION (ALDERGROVE) PO BOX 4000 STN ALDERGROVE ALDERGROVE<br>BC V4W 2V1<br>CAN",
    "addressPlain": "192 ESCADRILLE DU GÉNIE CONSTRUCTION (ALDERGROVE) PO BOX 4000 STN ALDERGROVE ALDERGROVE\\nBC V4W 2V1\\nCAN"
  },
  {
    "id": "3539",
    "uic": "3539",
    "abbrevCFR": "BFC ESQ DE",
    "officialName": "DÉTACHEMENT MATSQUI, BASE DES FORCES CANADIENNES ESQUIMALT",
    "addressHtml": "PO BOX 4000 STN ALDERGROVE ALDERGROVE<br>BC V4W 2V1<br>CAN",
    "addressPlain": "PO BOX 4000 STN ALDERGROVE ALDERGROVE\\nBC V4W 2V1\\nCAN"
  },
  {
    "id": "1445",
    "uic": "1445",
    "abbrevCFR": "RDDC SUFFIELD",
    "officialName": "RECHERCHE ET DÉVELOPPEMENT POUR LA DÉFENSE CANADA (SUFFIELD)",
    "addressHtml": "PO BOX 4000 STN MAIN MEDICINE HAT<br>AB T1A 8K6<br>CAN",
    "addressPlain": "PO BOX 4000 STN MAIN MEDICINE HAT\\nAB T1A 8K6\\nCAN"
  },
  {
    "id": "1334",
    "uic": "1334",
    "abbrevCFR": "NCSM DISCOVERY",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ DISCOVERY",
    "addressHtml": "PO BOX 45028 RPO ROBSON VANCOUVER<br>BC V6G 0A9<br>CAN",
    "addressPlain": "PO BOX 45028 RPO ROBSON VANCOUVER\\nBC V6G 0A9\\nCAN"
  },
  {
    "id": "6511",
    "uic": "6511",
    "abbrevCFR": "2 UCCA",
    "officialName": "2E UNITÉ DE COORDINATION DE LA COMPOSANTE AÉRIENNE",
    "addressHtml": "PO BOX 5000 STN BUREAU-CHEF ALOUETTE<br>QC G0V 1A0<br>CAN",
    "addressPlain": "PO BOX 5000 STN BUREAU-CHEF ALOUETTE\\nQC G0V 1A0\\nCAN"
  },
  {
    "id": "6512",
    "uic": "6512",
    "abbrevCFR": "2 ESC EA",
    "officialName": "2E ESCADRON EXPÉDITIONNAIRE AÉRIEN",
    "addressHtml": "PO BOX 5000 STN BUREAU-CHEF ALOUETTE<br>QC G0V 1A0<br>CAN",
    "addressPlain": "PO BOX 5000 STN BUREAU-CHEF ALOUETTE\\nQC G0V 1A0\\nCAN"
  },
  {
    "id": "6807",
    "uic": "6807",
    "abbrevCFR": "2 CDOE",
    "officialName": "2E CENTRE DE DISPONIBILITÉ OPÉRATIONNELLE EXPÉDITIONNAIRE",
    "addressHtml": "PO BOX 5000 STN BUREAU-CHEF ALOUETTE<br>QC G0V 1A0<br>CAN",
    "addressPlain": "PO BOX 5000 STN BUREAU-CHEF ALOUETTE\\nQC G0V 1A0\\nCAN"
  },
  {
    "id": "6806",
    "uic": "6806",
    "abbrevCFR": "QG 2 ERE",
    "officialName": "QUARTIER GÉNÉRAL DE LA 2E ESCADRE",
    "addressHtml": "PO BOX 5000 STN BUREAU-CHEF ALOUETTE<br>QC G0V 1A0<br>CAN",
    "addressPlain": "PO BOX 5000 STN BUREAU-CHEF ALOUETTE\\nQC G0V 1A0\\nCAN"
  },
  {
    "id": "0274",
    "uic": "0274",
    "abbrevCFR": "JAGA BAGOT",
    "officialName": "JUGE-AVOCAT ADMOINT (BAGOTVILLE)",
    "addressHtml": "PO BOX 5000 STN BUREAU-CHEF ALOUETTE<br>QC G0V 1A0<br>CAN",
    "addressPlain": "PO BOX 5000 STN BUREAU-CHEF ALOUETTE\\nQC G0V 1A0\\nCAN"
  },
  {
    "id": "2074",
    "uic": "2074",
    "abbrevCFR": "1 UD GREEN",
    "officialName": "1ER UNITÉ DENTAIRE DÉTACHEMENT GREENWOOD",
    "addressHtml": "PO BOX 5000 STN MAIN GREENWOOD<br>NS B0P 1N0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN GREENWOOD\\nNS B0P 1N0\\nCAN"
  },
  {
    "id": "2084",
    "uic": "2084",
    "abbrevCFR": "1 UD MOOSE",
    "officialName": "1ER UNITÉ DENTAIRE DÉTACHEMENT MOOSE JAW",
    "addressHtml": "PO BOX 5000 STN MAIN MOOSE JAW<br>SK S6H 7Z8<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN MOOSE JAW\\nSK S6H 7Z8\\nCAN"
  },
  {
    "id": "2058",
    "uic": "2058",
    "abbrevCFR": "1 UD SHILO",
    "officialName": "1ER UNITÉ DENTAIRE DÉTACHEMENT SHILO",
    "addressHtml": "PO BOX 5000 STN MAIN SHILO<br>MB R0K 2A0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN SHILO\\nMB R0K 2A0\\nCAN"
  },
  {
    "id": "1763",
    "uic": "1763",
    "abbrevCFR": "1 RCHA",
    "officialName": "1ER RÉGIMENT, ROYAL CANADIAN HORSE ARTILLERY",
    "addressHtml": "PO BOX 5000 STN MAIN SHILO<br>MB R0K 2A0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN SHILO\\nMB R0K 2A0\\nCAN"
  },
  {
    "id": "3586",
    "uic": "3586",
    "abbrevCFR": "11 C Svc S",
    "officialName": "11E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 5000 STN MAIN SHILO<br>MB R0K 2A0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN SHILO\\nMB R0K 2A0\\nCAN"
  },
  {
    "id": "3759",
    "uic": "3759",
    "abbrevCFR": "14 Esc SSC",
    "officialName": "14E ESCADRON DE SERVICE DE SOUTIEN (COMBAT AÉRIEN)",
    "addressHtml": "PO BOX 5000 STN MAIN GREENWOOD<br>NS B0P 1N0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN GREENWOOD\\nNS B0P 1N0\\nCAN"
  },
  {
    "id": "3233",
    "uic": "3233",
    "abbrevCFR": "14 EMA",
    "officialName": "14E ESCADRON DE MAINTENANCE (AIR)",
    "addressHtml": "PO BOX 5000 STN MAIN GREENWOOD<br>NS B0P 1N0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN GREENWOOD\\nNS B0P 1N0\\nCAN"
  },
  {
    "id": "9952",
    "uic": "9952",
    "abbrevCFR": "14 ERE",
    "officialName": "14E ESCADRE",
    "addressHtml": "PO BOX 5000 STN MAIN GREENWOOD<br>NS B0P 1N0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN GREENWOOD\\nNS B0P 1N0\\nCAN"
  },
  {
    "id": "9953",
    "uic": "9953",
    "abbrevCFR": "15 ERE",
    "officialName": "15E ESCADRE",
    "addressHtml": "PO BOX 5000 STN MAIN MOOSE JAW<br>SK S6H 7Z8<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN MOOSE JAW\\nSK S6H 7Z8\\nCAN"
  },
  {
    "id": "2597",
    "uic": "2597",
    "abbrevCFR": "2 EPFC",
    "officialName": "2E ÉCOLE DE PILOTAGE DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 5000 STN MAIN MOOSE JAW<br>SK S6H 7Z8<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN MOOSE JAW\\nSK S6H 7Z8\\nCAN"
  },
  {
    "id": "1850",
    "uic": "1850",
    "abbrevCFR": "2 PPCLI",
    "officialName": "2E BATAILLON, PRINCESS PATRICIA S CANADIAN LIGHT INFANTRY",
    "addressHtml": "PO BOX 5000 STN MAIN SHILO<br>MB R0K 2A0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN SHILO\\nMB R0K 2A0\\nCAN"
  },
  {
    "id": "3577",
    "uic": "3577",
    "abbrevCFR": "26 C Svc S",
    "officialName": "26E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 5000 STN MAIN GREENWOOD<br>NS B0P 1N0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN GREENWOOD\\nNS B0P 1N0\\nCAN"
  },
  {
    "id": "6588",
    "uic": "6588",
    "abbrevCFR": "Dét Shilo",
    "officialName": "DÉTACHEMENT SHILO CENTRE D'INSTRUCTION DE LA 3E DIVISION DU CANADA",
    "addressHtml": "PO BOX 5000 STN MAIN SHILO<br>MB R0K 2A0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN SHILO\\nMB R0K 2A0\\nCAN"
  },
  {
    "id": "2554",
    "uic": "2554",
    "abbrevCFR": "404 (PLP&E",
    "officialName": "404E ESCADRON DE PATROUILLE A LONGUE PORTÉE ET D'ENTRAINEMENT",
    "addressHtml": "PO BOX 5000 STN MAIN GREENWOOD<br>NS B0P 1N0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN GREENWOOD\\nNS B0P 1N0\\nCAN"
  },
  {
    "id": "2555",
    "uic": "2555",
    "abbrevCFR": "405(PLP) S",
    "officialName": "405E ESCADRON DE PATROUILLE A LONGUE PORTÉE",
    "addressHtml": "PO BOX 5000 STN MAIN GREENWOOD<br>NS B0P 1N0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN GREENWOOD\\nNS B0P 1N0\\nCAN"
  },
  {
    "id": "2557",
    "uic": "2557",
    "abbrevCFR": "413 (T&S)",
    "officialName": "413E ESCADRON DE TRANSPORT ET DE SAUVETAGE",
    "addressHtml": "PO BOX 5000 STN MAIN GREENWOOD<br>NS B0P 1N0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN GREENWOOD\\nNS B0P 1N0\\nCAN"
  },
  {
    "id": "2562",
    "uic": "2562",
    "abbrevCFR": "415 Esc PL",
    "officialName": "415E ESCADRON DE PATROUILLE A LONGUE PORTÉE (DÉVELOPPEMENT DE LA FORCE)",
    "addressHtml": "PO BOX 5000 STN MAIN GREENWOOD<br>NS B0P 1N0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN GREENWOOD\\nNS B0P 1N0\\nCAN"
  },
  {
    "id": "2604",
    "uic": "2604",
    "abbrevCFR": "431 E (DA)",
    "officialName": "431E ESCADRON DE DÉMONSTRATION AÉRIENNE",
    "addressHtml": "PO BOX 5000 STN MAIN MOOSE JAW<br>SK S6H 7Z8<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN MOOSE JAW\\nSK S6H 7Z8\\nCAN"
  },
  {
    "id": "0102",
    "uic": "0102",
    "abbrevCFR": "BFC GREENW",
    "officialName": "BASE DES FORCES CANADIENNES GREENWOOD",
    "addressHtml": "PO BOX 5000 STN MAIN GREENWOOD<br>NS B0P 1N0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN GREENWOOD\\nNS B0P 1N0\\nCAN"
  },
  {
    "id": "0121",
    "uic": "0121",
    "abbrevCFR": "BFC MOOSE",
    "officialName": "BASE DES FORCES CANADIENNES MOOSE JAW",
    "addressHtml": "PO BOX 5000 STN MAIN MOOSE JAW<br>SK S6H 7Z8<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN MOOSE JAW\\nSK S6H 7Z8\\nCAN"
  },
  {
    "id": "0118",
    "uic": "0118",
    "abbrevCFR": "BFC SHILO",
    "officialName": "BASE DES FORCES CANADIENNES SHILO",
    "addressHtml": "PO BOX 5000 STN MAIN SHILO<br>MB R0K 2A0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN SHILO\\nMB R0K 2A0\\nCAN"
  },
  {
    "id": "3711",
    "uic": "3711",
    "abbrevCFR": "ALFC GREEN",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (GREENWOOD)",
    "addressHtml": "PO BOX 5000 STN MAIN GREENWOOD<br>NS B0P 1N0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN GREENWOOD\\nNS B0P 1N0\\nCAN"
  },
  {
    "id": "3717",
    "uic": "3717",
    "abbrevCFR": "ALFC MOOSE",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (MOOSE JAW)",
    "addressHtml": "PO BOX 5000 STN MAIN MOOSE JAW<br>SK S6H 7Z8<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN MOOSE JAW\\nSK S6H 7Z8\\nCAN"
  },
  {
    "id": "3721",
    "uic": "3721",
    "abbrevCFR": "ALFC SHILO",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (SHILO)",
    "addressHtml": "PO BOX 5000 STN MAIN SHILO<br>MB R0K 2A0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN SHILO\\nMB R0K 2A0\\nCAN"
  },
  {
    "id": "2977",
    "uic": "2977",
    "abbrevCFR": "CEVC DEBER",
    "officialName": "CENTRE D'ENTRAINEMENT DE VOL DES CADETS DE DEBERT",
    "addressHtml": "PO BOX 5000 STN MAIN GREENWOOD<br>NS B0P 1N0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN GREENWOOD\\nNS B0P 1N0\\nCAN"
  },
  {
    "id": "8162",
    "uic": "8162",
    "abbrevCFR": "CEC GREEN",
    "officialName": "CENTRE D'ENTRAINEMENT DES CADETS DE GREENWOOD",
    "addressHtml": "PO BOX 5000 STN MAIN GREENWOOD<br>NS B0P 1N0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN GREENWOOD\\nNS B0P 1N0\\nCAN"
  },
  {
    "id": "3582",
    "uic": "3582",
    "abbrevCFR": "Dét Moose",
    "officialName": "DÉTACHEMENT MOOSE JAW 23E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 5000 STN MAIN MOOSE JAW<br>SK S6H 7Z8<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN MOOSE JAW\\nSK S6H 7Z8\\nCAN"
  },
  {
    "id": "3958",
    "uic": "3958",
    "abbrevCFR": "Dét Shilo",
    "officialName": "DÉTACHEMENT SHILO 1RE AMBULANCE DE CAMPAGNE",
    "addressHtml": "PO BOX 5000 STN MAIN SHILO<br>MB R0K 2A0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN SHILO\\nMB R0K 2A0\\nCAN"
  },
  {
    "id": "0081",
    "uic": "0081",
    "abbrevCFR": "JAA GREENW",
    "officialName": "JUGE-AVOCAT ADJOINT (GREENWOOD)",
    "addressHtml": "PO BOX 5000 STN MAIN GREENWOOD<br>NS B0P 1N0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN GREENWOOD\\nNS B0P 1N0\\nCAN"
  },
  {
    "id": "3925",
    "uic": "3925",
    "abbrevCFR": "MPSET DÉT GREENWOOD",
    "officialName": "QUARTIER GÉNÉRAL DE LA 1ER DIVISION AÉRIENNE LRP GROUPE D'ÉVALUATION STANDARDS",
    "addressHtml": "PO BOX 5000 STN MAIN GREENWOOD<br>NS B0P 1N0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN GREENWOOD\\nNS B0P 1N0\\nCAN"
  },
  {
    "id": "6899",
    "uic": "6899",
    "abbrevCFR": "UOI GREENWOOD",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (ATLANTIQUE) DÉTACHMENT GREENWOOD",
    "addressHtml": "PO BOX 5000 STN MAIN GREENWOOD<br>NS B0P 1N0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN GREENWOOD\\nNS B0P 1N0\\nCAN"
  },
  {
    "id": "8457",
    "uic": "8457",
    "abbrevCFR": "UOI(O) MO",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (OUEST) DÉTACHEMENT MOOSE JAW",
    "addressHtml": "PO BOX 5000 STN MAIN MOOSE JAW<br>SK S6H 7Z8<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN MOOSE JAW\\nSK S6H 7Z8\\nCAN"
  },
  {
    "id": "6896",
    "uic": "6896",
    "abbrevCFR": "UOI(O) SHI",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (OUEST) DÉTACHEMENT SHILO",
    "addressHtml": "PO BOX 5000 STN MAIN SHILO<br>MB R0K 2A0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN SHILO\\nMB R0K 2A0\\nCAN"
  },
  {
    "id": "1828",
    "uic": "1828",
    "abbrevCFR": "Dét ETGS3D",
    "officialName": "DÉTACHEMENT SHILO, ESCADRON DES TRANSMISSIONS DU GROUPE DE SOUTIEN DE LA 3E DIVISION DU CANADA",
    "addressHtml": "PO BOX 5000 STN MAIN SHILO<br>MB R0K 2A0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN SHILO\\nMB R0K 2A0\\nCAN"
  },
  {
    "id": "6758",
    "uic": "6758",
    "abbrevCFR": "CT GREENWO",
    "officialName": "CENTRE DE TRANSITION GREENWOOD",
    "addressHtml": "PO BOX 5000 STN MAIN GREENWOOD<br>NS B0P 1N0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN GREENWOOD\\nNS B0P 1N0\\nCAN"
  },
  {
    "id": "6745",
    "uic": "6745",
    "abbrevCFR": "CT MOOSE J",
    "officialName": "CENTRE DE TRANSITION MOOSE JAW",
    "addressHtml": "PO BOX 5000 STN MAIN MOOSE JAW<br>SK S6H 7Z8<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN MOOSE JAW\\nSK S6H 7Z8\\nCAN"
  },
  {
    "id": "6744",
    "uic": "6744",
    "abbrevCFR": "CT SHILO",
    "officialName": "CENTRE DE TRANSITION SHILO",
    "addressHtml": "PO BOX 5000 STN MAIN SHILO<br>MB R0K 2A0<br>CAN",
    "addressPlain": "PO BOX 5000 STN MAIN SHILO\\nMB R0K 2A0\\nCAN"
  },
  {
    "id": "6763",
    "uic": "6763",
    "abbrevCFR": "CSO ASO",
    "officialName": "CARREFOUR DE SOUTIEN OPÉRATIONNEL (ASIE DU SUD-OUEST)",
    "addressHtml": "PO BOX 5004 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5004 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "6373",
    "uic": "6373",
    "abbrevCFR": "RGN IT/RO",
    "officialName": "RÉGION ITALIE / ROUMANIE",
    "addressHtml": "PO BOX 5045 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5045 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "6309",
    "uic": "6309",
    "abbrevCFR": "1 UD CASTE",
    "officialName": "1RE UNITÉ DENTAIRE DÉTACHEMENT CASTEAU",
    "addressHtml": "PO BOX 5048 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5048 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "3986",
    "uic": "3986",
    "abbrevCFR": "Svc S CAST",
    "officialName": "CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES OTTAWA DÉTACHEMENT CASTEAU",
    "addressHtml": "PO BOX 5048 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5048 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "6378",
    "uic": "6378",
    "abbrevCFR": "EMI ÉTAT-MAJOR",
    "officialName": "MILITAIRE INTERNATIONAL",
    "addressHtml": "PO BOX 5048 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5048 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "6371",
    "uic": "6371",
    "abbrevCFR": "RGN CAST",
    "officialName": "RÉGION CASTEAU SUD OUEST",
    "addressHtml": "PO BOX 5048 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5048 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "0044",
    "uic": "0044",
    "abbrevCFR": "ELFC(L) ÉTAT-MAJOR",
    "officialName": "DE LIAISON DES FORCES CANADIENNES (LONDRES)",
    "addressHtml": "PO BOX 5051 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5051 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "3214",
    "uic": "3214",
    "abbrevCFR": "USFC(E) UK",
    "officialName": "DÉTACHEMENT UNITED KINGDOM UNITÉ DE SOUTIEN DES FORCES CANADIENNES (EUROPE)",
    "addressHtml": "PO BOX 5051 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5051 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "3374",
    "uic": "3374",
    "abbrevCFR": "DET DIGBY",
    "officialName": "QUARTIER GÉNÉRAL DU COMMANDEMENT CYBER DES FORCES ARMÉES CANADIENNES DÉTACHEMENT DIGBY",
    "addressHtml": "PO BOX 5051 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5051 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "6046",
    "uic": "6046",
    "abbrevCFR": "OP SNOWGOO",
    "officialName": "FORCE OPÉRATIONELLE CHYPRE (OPÉRATION SNOWGOOSE)",
    "addressHtml": "PO BOX 5051 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5051 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "6308",
    "uic": "6308",
    "abbrevCFR": "1 UD GEILE",
    "officialName": "1RE UNITÉ DENTAIRE DÉTACHEMENT GEILENKIRCHEN",
    "addressHtml": "PO BOX 5053 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5053 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "3533",
    "uic": "3533",
    "abbrevCFR": "76SELFKANT 76E",
    "officialName": "RÉGIMENT DES COMMUNICATIONS DÉTACHEMENT SELFKANT",
    "addressHtml": "PO BOX 5053 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5053 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "3132",
    "uic": "3132",
    "abbrevCFR": "USFC (E)",
    "officialName": "UNITÉ DE SOUTIEN DES FORCES CANADIENNES EN EUROPE",
    "addressHtml": "PO BOX 5053 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5053 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "6582",
    "uic": "6582",
    "abbrevCFR": "ESB LANSDS",
    "officialName": "ÉQUIPE DE SOUTIEN AUX BLESSÉS (CENTRE RÉGIONAL MÉDICAL DE LANDSTUHL)",
    "addressHtml": "PO BOX 5053 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5053 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "3985",
    "uic": "3985",
    "abbrevCFR": "Svc S GEIL",
    "officialName": "CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES OTTAWA DÉTACHEMENT GEILENKIRCHEN",
    "addressHtml": "PO BOX 5053 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5053 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "6774",
    "uic": "6774",
    "abbrevCFR": "CSO Europe",
    "officialName": "CARREFOUR DE SOUTIEN OPÉRATIONNEL (EUROPE)",
    "addressHtml": "PO BOX 5053 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5053 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "6372",
    "uic": "6372",
    "abbrevCFR": "RGN DEU",
    "officialName": "RÉGION ALLEMAGNE",
    "addressHtml": "PO BOX 5053 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5053 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "6643",
    "uic": "6643",
    "abbrevCFR": "LCS ALLEMA",
    "officialName": "DÉTACHEMENT D'ALLEMAGNE DES LIGNES DE COMMUNICATION STRATÉGIQUES",
    "addressHtml": "PO BOX 5053 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5053 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "2925",
    "uic": "2925",
    "abbrevCFR": "AJAG EUROP",
    "officialName": "ASSISTANT JUGE-AVOCAT GÉNÉRAL (EUROPE)",
    "addressHtml": "PO BOX 5053 STN FORCESSELFKANT KASERNE BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5053 STN FORCESSELFKANT KASERNE BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "0208",
    "uic": "0208",
    "abbrevCFR": "SFC ALERT",
    "officialName": "STATION DES FORCES CANADIENNES ALERT",
    "addressHtml": "PO BOX 5210 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5210 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "6522",
    "uic": "6522",
    "abbrevCFR": "FO DARFUR",
    "officialName": "FORCE OPÉRATIONELLE DARFUR",
    "addressHtml": "PO BOX 5225 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5225 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "6403",
    "uic": "6403",
    "abbrevCFR": "FO JERUSAL",
    "officialName": "FORCE OPÉRATIONELLE JERUSALEM",
    "addressHtml": "PO BOX 5240 STN FORCESOP PROTEUS BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5240 STN FORCESOP PROTEUS BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "6545",
    "uic": "6545",
    "abbrevCFR": "FO PRISTIN",
    "officialName": "FORCE OPÉRATIONELLE PRISTINA - KFOR",
    "addressHtml": "PO BOX 5249 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5249 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "6344",
    "uic": "6344",
    "abbrevCFR": "FO PORT AU",
    "officialName": "FORCE OPÉRATIONELLE PORT AU PRINCE",
    "addressHtml": "PO BOX 5250 STN FORCES BELLEVILLE<br>ON K8N 5W6<br>CAN",
    "addressPlain": "PO BOX 5250 STN FORCES BELLEVILLE\\nON K8N 5W6\\nCAN"
  },
  {
    "id": "2099",
    "uic": "2099",
    "abbrevCFR": "1 UD GANDE",
    "officialName": "1ER UNITÉ DENTAIRE DÉTACHEMENT GANDER",
    "addressHtml": "PO BOX 6000 STN MAIN GANDER<br>NL A1V 1X1<br>CAN",
    "addressPlain": "PO BOX 6000 STN MAIN GANDER\\nNL A1V 1X1\\nCAN"
  },
  {
    "id": "2575",
    "uic": "2575",
    "abbrevCFR": "103 SAR SQ",
    "officialName": "103E ESCADRON DE RECHERCHE ET DE SAUVETAGE DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 6000 STN MAIN GANDER<br>NL A1V 1X1<br>CAN",
    "addressPlain": "PO BOX 6000 STN MAIN GANDER\\nNL A1V 1X1\\nCAN"
  },
  {
    "id": "3689",
    "uic": "3689",
    "abbrevCFR": "5 GPRC",
    "officialName": "5E GROUPE DE PATROUILLE DES RANGERS CANADIENNES",
    "addressHtml": "PO BOX 6000 STN MAIN GANDER<br>NL A1V 1X1<br>CAN",
    "addressPlain": "PO BOX 6000 STN MAIN GANDER\\nNL A1V 1X1\\nCAN"
  },
  {
    "id": "9949",
    "uic": "9949",
    "abbrevCFR": "9 ERE",
    "officialName": "9E ESCADRE",
    "addressHtml": "PO BOX 6000 STN MAIN GANDER<br>NL A1V 1X1<br>CAN",
    "addressPlain": "PO BOX 6000 STN MAIN GANDER\\nNL A1V 1X1\\nCAN"
  },
  {
    "id": "3455",
    "uic": "3455",
    "abbrevCFR": "91",
    "officialName": "Ele GC",
    "addressHtml": "91 ESCADRILLE DU GÉNIE CONSTRUCTION (GANDER) PO BOX 6000 STN MAIN GANDER<br>NL A1V 1X1<br>CAN",
    "addressPlain": "91 ESCADRILLE DU GÉNIE CONSTRUCTION (GANDER) PO BOX 6000 STN MAIN GANDER\\nNL A1V 1X1\\nCAN"
  },
  {
    "id": "0213",
    "uic": "0213",
    "abbrevCFR": "BFC GANDER",
    "officialName": "STATION DES FORCES CANADIENNES ALERT",
    "addressHtml": "PO BOX 6000 STN MAIN GANDER<br>NL A1V 1X1<br>CAN",
    "addressPlain": "PO BOX 6000 STN MAIN GANDER\\nNL A1V 1X1\\nCAN"
  },
  {
    "id": "0142",
    "uic": "0142",
    "abbrevCFR": "BFC SUFFIE",
    "officialName": "BASE DES FORCES CANADIENNES, SUFFIELD",
    "addressHtml": "PO BOX 6000 STN MAIN MEDICINE HAT<br>AB T1A 8K8<br>CAN",
    "addressPlain": "PO BOX 6000 STN MAIN MEDICINE HAT\\nAB T1A 8K8\\nCAN"
  },
  {
    "id": "3709",
    "uic": "3709",
    "abbrevCFR": "ALFC GANDE",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (GANDER)",
    "addressHtml": "PO BOX 6000 STN MAIN GANDER<br>NL A1V 1X1<br>CAN",
    "addressPlain": "PO BOX 6000 STN MAIN GANDER\\nNL A1V 1X1\\nCAN"
  },
  {
    "id": "3723",
    "uic": "3723",
    "abbrevCFR": "ALFC SUFFI",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (SUFFIELD)",
    "addressHtml": "PO BOX 6000 STN MAIN MEDICINE HAT<br>AB T1A 8K8<br>CAN",
    "addressPlain": "PO BOX 6000 STN MAIN MEDICINE HAT\\nAB T1A 8K8\\nCAN"
  },
  {
    "id": "3739",
    "uic": "3739",
    "abbrevCFR": "SFC GANDER",
    "officialName": "STATION DES FORCES CANADIENNES LEITRIM DÉTACHEMENT GANDER",
    "addressHtml": "PO BOX 6000 STN MAIN GANDER<br>NL A1V 1X1<br>CAN",
    "addressPlain": "PO BOX 6000 STN MAIN GANDER\\nNL A1V 1X1\\nCAN"
  },
  {
    "id": "3575",
    "uic": "3575",
    "abbrevCFR": "Dét Gander",
    "officialName": "DÉTACHEMENT GANDER 27E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 6000 STN MAIN GANDER<br>NL A1V 1X1<br>CAN",
    "addressPlain": "PO BOX 6000 STN MAIN GANDER\\nNL A1V 1X1\\nCAN"
  },
  {
    "id": "3949",
    "uic": "3949",
    "abbrevCFR": "Dét Suffie",
    "officialName": "DÉTACHEMENT SUFFIELD 1ER AMBULANCE DE CAMPAGNE",
    "addressHtml": "PO BOX 6000 STN MAIN MEDICINE HAT<br>AB T1A 8K8<br>CAN",
    "addressPlain": "PO BOX 6000 STN MAIN MEDICINE HAT\\nAB T1A 8K8\\nCAN"
  },
  {
    "id": "6863",
    "uic": "6863",
    "abbrevCFR": "UOI GANDER",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (ATLANTIQUE) DÉTACHMENT GANDER",
    "addressHtml": "PO BOX 6000 STN MAIN GANDER<br>NL A1V 1X1<br>CAN",
    "addressPlain": "PO BOX 6000 STN MAIN GANDER\\nNL A1V 1X1\\nCAN"
  },
  {
    "id": "6897",
    "uic": "6897",
    "abbrevCFR": "UOI SUFFIELD",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (OUEST) DÉTACHMENT SUFFIELD",
    "addressHtml": "PO BOX 6000 STN MAIN MEDICINE HAT<br>AB T1A 8K8<br>CAN",
    "addressPlain": "PO BOX 6000 STN MAIN MEDICINE HAT\\nAB T1A 8K8\\nCAN"
  },
  {
    "id": "6756",
    "uic": "6756",
    "abbrevCFR": "CT GANDER",
    "officialName": "CENTRE DE TRANSITION GANDER",
    "addressHtml": "PO BOX 6000 STN MAIN GANDER<br>NL A1V 1X1<br>CAN",
    "addressPlain": "PO BOX 6000 STN MAIN GANDER\\nNL A1V 1X1\\nCAN"
  },
  {
    "id": "3663",
    "uic": "3663",
    "abbrevCFR": "QG 37 GBC",
    "officialName": "QUARTIER GÉNÉRAL DU 37E GROUPE-BRIGADE DU CANADA",
    "addressHtml": "PO BOX 6100 STN LCD 1 MONCTON<br>NB E1C 9L4<br>CAN",
    "addressPlain": "PO BOX 6100 STN LCD 1 MONCTON\\nNB E1C 9L4\\nCAN"
  },
  {
    "id": "5002",
    "uic": "5002",
    "abbrevCFR": "8 CH 8TH",
    "officialName": "CANADIAN HUSSARS (PRINCESS LOUISE'S)",
    "addressHtml": "PO BOX 6100 STN LCD 1 MONCTON<br>NB E1C 9L4<br>CAN",
    "addressPlain": "PO BOX 6100 STN LCD 1 MONCTON\\nNB E1C 9L4\\nCAN"
  },
  {
    "id": "3529",
    "uic": "3529",
    "abbrevCFR": "Dét Moncto",
    "officialName": "DÉTACHEMENT MONCTON, BASE DE SOUTIEN DE LA 5E DIVISION DU CANADA, GAGETOWN",
    "addressHtml": "PO BOX 6100 STN LCD 1 MONCTON<br>NB E1C 9L4<br>CAN",
    "addressPlain": "PO BOX 6100 STN LCD 1 MONCTON\\nNB E1C 9L4\\nCAN"
  },
  {
    "id": "3947",
    "uic": "3947",
    "abbrevCFR": "Dét Moncto",
    "officialName": "DÉTACHEMENT MONCTON 42E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 6100 STN LCD 1 MONCTON<br>NB E1C 9L4<br>CAN",
    "addressPlain": "PO BOX 6100 STN LCD 1 MONCTON\\nNB E1C 9L4\\nCAN"
  },
  {
    "id": "6753",
    "uic": "6753",
    "abbrevCFR": "CT MONCTON",
    "officialName": "CENTRE DE TRANSITION MONCTON",
    "addressHtml": "PO BOX 6100 STN LCD 1 MONCTON<br>NB E1C 9L4<br>CAN",
    "addressPlain": "PO BOX 6100 STN LCD 1 MONCTON\\nNB E1C 9L4\\nCAN"
  },
  {
    "id": "4012",
    "uic": "4012",
    "abbrevCFR": "CEC ACADIA",
    "officialName": "CENTRE D'ENTRAINEMENT DES CADETS NCSM ACADIA",
    "addressHtml": "PO BOX 63 STN MAIN CLEMENTSPORT<br>NS B0S 1E0<br>CAN",
    "addressPlain": "PO BOX 63 STN MAIN CLEMENTSPORT\\nNS B0S 1E0\\nCAN"
  },
  {
    "id": "3229",
    "uic": "3229",
    "abbrevCFR": "1 EMA",
    "officialName": "1ER ESCADRON DE MAINTENANCE (AIR)",
    "addressHtml": "PO BOX 6550 STN FORCES COLD LAKE<br>AB T9M 2C6<br>CAN",
    "addressPlain": "PO BOX 6550 STN FORCES COLD LAKE\\nAB T9M 2C6\\nCAN"
  },
  {
    "id": "2070",
    "uic": "2070",
    "abbrevCFR": "1 UD COLD",
    "officialName": "1ER UNITÉ DENTAIRE DÉTACHEMENT COLD LAKE",
    "addressHtml": "PO BOX 6550 STN FORCES COLD LAKE<br>AB T9M 2C6<br>CAN",
    "addressPlain": "PO BOX 6550 STN FORCES COLD LAKE\\nAB T9M 2C6\\nCAN"
  },
  {
    "id": "2410",
    "uic": "2410",
    "abbrevCFR": "10 EITA",
    "officialName": "10E ESCADRON D'INSTRUCTION TECHNIQUE APPLIQUÉE",
    "addressHtml": "PO BOX 6550 STN FORCES COLD LAKE<br>AB T9M 2C6<br>CAN",
    "addressPlain": "PO BOX 6550 STN FORCES COLD LAKE\\nAB T9M 2C6\\nCAN"
  },
  {
    "id": "3570",
    "uic": "3570",
    "abbrevCFR": "22 C Svc S",
    "officialName": "22E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 6550 STN FORCES COLD LAKE<br>AB T9M 2C6<br>CAN",
    "addressPlain": "PO BOX 6550 STN FORCES COLD LAKE\\nAB T9M 2C6\\nCAN"
  },
  {
    "id": "3756",
    "uic": "3756",
    "abbrevCFR": "4 Esc SSCA",
    "officialName": "4E ESCADRON DE SERVICE DE SOUTIEN (COMBAT AÉRIEN)",
    "addressHtml": "PO BOX 6550 STN FORCES COLD LAKE<br>AB T9M 2C6<br>CAN",
    "addressPlain": "PO BOX 6550 STN FORCES COLD LAKE\\nAB T9M 2C6\\nCAN"
  },
  {
    "id": "3227",
    "uic": "3227",
    "abbrevCFR": "4 Esc GC",
    "officialName": "4E ESCADRON DU GÉNIE CONSTRUCTION",
    "addressHtml": "PO BOX 6550 STN FORCES COLD LAKE<br>AB T9M 2C6<br>CAN",
    "addressPlain": "PO BOX 6550 STN FORCES COLD LAKE\\nAB T9M 2C6\\nCAN"
  },
  {
    "id": "9891",
    "uic": "9891",
    "abbrevCFR": "4 ERE",
    "officialName": "4E ESCADRE",
    "addressHtml": "PO BOX 6550 STN FORCES COLD LAKE<br>AB T9M 2C6<br>CAN",
    "addressPlain": "PO BOX 6550 STN FORCES COLD LAKE\\nAB T9M 2C6\\nCAN"
  },
  {
    "id": "6872",
    "uic": "6872",
    "abbrevCFR": "401 Esc A",
    "officialName": "401E ESCADRON D'APPUI TACTIQUE",
    "addressHtml": "PO BOX 6550 STN FORCES COLD LAKE<br>AB T9M 2C6<br>CAN",
    "addressPlain": "PO BOX 6550 STN FORCES COLD LAKE\\nAB T9M 2C6\\nCAN"
  },
  {
    "id": "6468",
    "uic": "6468",
    "abbrevCFR": "409 Esc AT",
    "officialName": "409E ESCADRON D'APPUI TACTIQUE",
    "addressHtml": "PO BOX 6550 STN FORCES COLD LAKE<br>AB T9M 2C6<br>CAN",
    "addressPlain": "PO BOX 6550 STN FORCES COLD LAKE\\nAB T9M 2C6\\nCAN"
  },
  {
    "id": "2663",
    "uic": "2663",
    "abbrevCFR": "410 Esc EOAT",
    "officialName": "410E ESCADRON D'ENTRAINEMENT OPÉRATIONNEL A L'APPUI TACTIQUE",
    "addressHtml": "PO BOX 6550 STN FORCES COLD LAKE<br>AB T9M 2C6<br>CAN",
    "addressPlain": "PO BOX 6550 STN FORCES COLD LAKE\\nAB T9M 2C6\\nCAN"
  },
  {
    "id": "2411",
    "uic": "2411",
    "abbrevCFR": "417 Esc SC",
    "officialName": "417E ESCADRON DE SOUTIEN AU COMBAT",
    "addressHtml": "PO BOX 6550 STN FORCES COLD LAKE<br>AB T9M 2C6<br>CAN",
    "addressPlain": "PO BOX 6550 STN FORCES COLD LAKE\\nAB T9M 2C6\\nCAN"
  },
  {
    "id": "2595",
    "uic": "2595",
    "abbrevCFR": "419 Esc",
    "officialName": "419E ESCADRON D'ENTRAINEMENT À L' APPUI TACTIQUE",
    "addressHtml": "PO BOX 6550 STN FORCES COLD LAKE<br>AB T9M 2C6<br>CAN",
    "addressPlain": "PO BOX 6550 STN FORCES COLD LAKE\\nAB T9M 2C6\\nCAN"
  },
  {
    "id": "2391",
    "uic": "2391",
    "abbrevCFR": "42 Esc Rdr",
    "officialName": "42E ESCADRON DE RADAR",
    "addressHtml": "PO BOX 6550 STN FORCES COLD LAKE<br>AB T9M 2C6<br>CAN",
    "addressPlain": "PO BOX 6550 STN FORCES COLD LAKE\\nAB T9M 2C6\\nCAN"
  },
  {
    "id": "0134",
    "uic": "0134",
    "abbrevCFR": "BFC COLD L",
    "officialName": "BASE DES FORCES CANADIENNES COLDE LAKE",
    "addressHtml": "PO BOX 6550 STN FORCES COLD LAKE<br>AB T9M 2C6<br>CAN",
    "addressPlain": "PO BOX 6550 STN FORCES COLD LAKE\\nAB T9M 2C6\\nCAN"
  },
  {
    "id": "3704",
    "uic": "3704",
    "abbrevCFR": "ALFC COLD",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (COLD LAKE)",
    "addressHtml": "PO BOX 6550 STN FORCES COLD LAKE<br>AB T9M 2C6<br>CAN",
    "addressPlain": "PO BOX 6550 STN FORCES COLD LAKE\\nAB T9M 2C6\\nCAN"
  },
  {
    "id": "2247",
    "uic": "2247",
    "abbrevCFR": "SSPFC COLD",
    "officialName": "SECTON DU SERVICE POSTALE DES FORCES CANADIENNES (COLD LAKE)",
    "addressHtml": "PO BOX 6550 STN FORCES COLD LAKE<br>AB T9M 2C6<br>CAN",
    "addressPlain": "PO BOX 6550 STN FORCES COLD LAKE\\nAB T9M 2C6\\nCAN"
  },
  {
    "id": "2892",
    "uic": "2892",
    "abbrevCFR": "JAA COLD",
    "officialName": "L JUGE-AVOCAT ADJOINT (COLD LAKE)",
    "addressHtml": "PO BOX 6550 STN FORCES COLD LAKE<br>AB T9M 2C6<br>CAN",
    "addressPlain": "PO BOX 6550 STN FORCES COLD LAKE\\nAB T9M 2C6\\nCAN"
  },
  {
    "id": "3923",
    "uic": "3923",
    "abbrevCFR": "FSET",
    "officialName": "DET",
    "addressHtml": "1 CANADIAN AIR DIVISION HEADQUARTERS FIGHTER STANDARDS EVALUATION TEAM DETACHMENT COLD LAKE PO BOX 6550 STN FORCES COLD LAKE<br>AB T9M 2C6<br>CAN",
    "addressPlain": "1 CANADIAN AIR DIVISION HEADQUARTERS FIGHTER STANDARDS EVALUATION TEAM DETACHMENT COLD LAKE PO BOX 6550 STN FORCES COLD LAKE\\nAB T9M 2C6\\nCAN"
  },
  {
    "id": "6895",
    "uic": "6895",
    "abbrevCFR": "UOI COLD LAKE",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (OUEST) DÉTACHMENT COLD LAKE",
    "addressHtml": "PO BOX 6550 STN FORCES COLD LAKE<br>AB T9M 2C6<br>CAN",
    "addressPlain": "PO BOX 6550 STN FORCES COLD LAKE\\nAB T9M 2C6\\nCAN"
  },
  {
    "id": "6741",
    "uic": "6741",
    "abbrevCFR": "CT COLD",
    "officialName": "LA CENTRE DE TRANSITION COLD LAKE",
    "addressHtml": "PO BOX 6550 STN FORCES COLD LAKE<br>AB T9M 2C6<br>CAN",
    "addressPlain": "PO BOX 6550 STN FORCES COLD LAKE\\nAB T9M 2C6\\nCAN"
  },
  {
    "id": "6677",
    "uic": "6677",
    "abbrevCFR": "1",
    "officialName": "Esc PM",
    "addressHtml": "1 ESCADRON DE LA POLICE MILITAIRE PO BOX 6550 STN FORCESBUILDING 170 COLD LAKE<br>AB T9M 2C6<br>CAN",
    "addressPlain": "1 ESCADRON DE LA POLICE MILITAIRE PO BOX 6550 STN FORCESBUILDING 170 COLD LAKE\\nAB T9M 2C6\\nCAN"
  },
  {
    "id": "3685",
    "uic": "3685",
    "abbrevCFR": "1 GPRC",
    "officialName": "1ER GROUPE DE PATROUILLE DES RANGERS CANADIENS",
    "addressHtml": "PO BOX 6666 STN MAIN YELLOWKNIFE<br>NT X1A 2R3<br>CAN",
    "addressPlain": "PO BOX 6666 STN MAIN YELLOWKNIFE\\nNT X1A 2R3\\nCAN"
  },
  {
    "id": "2640",
    "uic": "2640",
    "abbrevCFR": "440 Esc (T)",
    "officialName": "440E ESCADRON DE TRANSPORT",
    "addressHtml": "PO BOX 6666 STN MAIN YELLOWKNIFE<br>NT X1A 2R3<br>CAN",
    "addressPlain": "PO BOX 6666 STN MAIN YELLOWKNIFE\\nNT X1A 2R3\\nCAN"
  },
  {
    "id": "3950",
    "uic": "3950",
    "abbrevCFR": "Dét Yellow",
    "officialName": "DÉTACHEMENT YELLOWKNIFE 1RE AMBULANCE DE CAMPAGNE",
    "addressHtml": "PO BOX 6666 STN MAIN YELLOWKNIFE<br>NT X1A 2R3<br>CAN",
    "addressPlain": "PO BOX 6666 STN MAIN YELLOWKNIFE\\nNT X1A 2R3\\nCAN"
  },
  {
    "id": "1568",
    "uic": "1568",
    "abbrevCFR": "QG FOIN",
    "officialName": "QUARTIER GÉNÉRAL DE LA FORCE OPÉRATIONNELLE INTERARMÉES (NORD)",
    "addressHtml": "PO BOX 6666 STN MAIN YELLOWKNIFE<br>NT X1A 2R3<br>CAN",
    "addressPlain": "PO BOX 6666 STN MAIN YELLOWKNIFE\\nNT X1A 2R3\\nCAN"
  },
  {
    "id": "6593",
    "uic": "6593",
    "abbrevCFR": "Dét Yellow",
    "officialName": "DÉTACHEMENT YELLOWKNIFE THE LOYAL EDMONTON REGIMENT",
    "addressHtml": "PO BOX 6666 STN MAIN YELLOWKNIFE<br>NT X1A 2R3<br>CAN",
    "addressPlain": "PO BOX 6666 STN MAIN YELLOWKNIFE\\nNT X1A 2R3\\nCAN"
  },
  {
    "id": "6538",
    "uic": "6538",
    "abbrevCFR": "ERCA NORD",
    "officialName": "DÉT ÉLÉMENT DE COORDINATION DE LA COMPOSANTE AÉRIENNE NORD, QUARTIER GÉNÉRAL DE LA 1RE DAC",
    "addressHtml": "PO BOX 6666 STN MAIN YELLOWKNIFE<br>NT X1A 2R3<br>CAN",
    "addressPlain": "PO BOX 6666 STN MAIN YELLOWKNIFE\\nNT X1A 2R3\\nCAN"
  },
  {
    "id": "6853",
    "uic": "6853",
    "abbrevCFR": "IMM YELLOW",
    "officialName": "QUARTIER GÉNÉRAL DU GROUPE DES OPÉRATIONS IMMOBILIÈRES DES FORCES CANADIENNES DÉTACHEMENT YELLOWKNIFE",
    "addressHtml": "PO BOX 6666 STN MAIN YELLOWKNIFE<br>NT X1A 2R3<br>CAN",
    "addressPlain": "PO BOX 6666 STN MAIN YELLOWKNIFE\\nNT X1A 2R3\\nCAN"
  },
  {
    "id": "1322",
    "uic": "1322",
    "abbrevCFR": "NCSM BRUNS",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ SCOTIAN",
    "addressHtml": "PO BOX 668 STN MAIN SAINT JOHN<br>NB E2L 4A5<br>CAN",
    "addressPlain": "PO BOX 668 STN MAIN SAINT JOHN\\nNB E2L 4A5\\nCAN"
  },
  {
    "id": "3576",
    "uic": "3576",
    "abbrevCFR": "27 C Svc S",
    "officialName": "27E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 7002 STN A HAPPY VALLEY-GOOSE BAY<br>NL A0P 1S0<br>CAN",
    "addressPlain": "PO BOX 7002 STN A HAPPY VALLEY-GOOSE BAY\\nNL A0P 1S0\\nCAN"
  },
  {
    "id": "7697",
    "uic": "7697",
    "abbrevCFR": "444 ESC SC",
    "officialName": "444E ESCADRON DE SOUTIEN AU COMBAT",
    "addressHtml": "PO BOX 7002 STN A HAPPY VALLEY-GOOSE BAY<br>NL A0P 1S0<br>CAN",
    "addressPlain": "PO BOX 7002 STN A HAPPY VALLEY-GOOSE BAY\\nNL A0P 1S0\\nCAN"
  },
  {
    "id": "9895",
    "uic": "9895",
    "abbrevCFR": "5 ERE",
    "officialName": "5E ESCADRE",
    "addressHtml": "PO BOX 7002 STN A HAPPY VALLEY-GOOSE BAY<br>NL A0P 1S0<br>CAN",
    "addressPlain": "PO BOX 7002 STN A HAPPY VALLEY-GOOSE BAY\\nNL A0P 1S0\\nCAN"
  },
  {
    "id": "0123",
    "uic": "0123",
    "abbrevCFR": "BFC GOOSE",
    "officialName": "BASE DES FORCES CANADIENNES GOOSE BAY",
    "addressHtml": "PO BOX 7002 STN A HAPPY VALLEY-GOOSE BAY<br>NL A0P 1S0<br>CAN",
    "addressPlain": "PO BOX 7002 STN A HAPPY VALLEY-GOOSE BAY\\nNL A0P 1S0\\nCAN"
  },
  {
    "id": "3710",
    "uic": "3710",
    "abbrevCFR": "ALFC GOOSE",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (GOOSE BAY)",
    "addressHtml": "PO BOX 7002 STN A HAPPY VALLEY-GOOSE BAY<br>NL A0P 1S0<br>CAN",
    "addressPlain": "PO BOX 7002 STN A HAPPY VALLEY-GOOSE BAY\\nNL A0P 1S0\\nCAN"
  },
  {
    "id": "6887",
    "uic": "6887",
    "abbrevCFR": "IMM GOOSE",
    "officialName": "QUARTIER GÉNÉRAL DU GROUPE DES OPÉRATIONS IMMOBILIÈRES DES FORCES CANADIENNES DÉTACHEMENT GOOSE BAY",
    "addressHtml": "PO BOX 7002 STN A HAPPY VALLEY-GOOSE BAY<br>NL A0P 1S0<br>CAN",
    "addressPlain": "PO BOX 7002 STN A HAPPY VALLEY-GOOSE BAY\\nNL A0P 1S0\\nCAN"
  },
  {
    "id": "5000",
    "uic": "5000",
    "abbrevCFR": "ALQ Regt",
    "officialName": "THE ALGONQUIN REGIMENT",
    "addressHtml": "PO BOX 780GD STN MAIN NORTH BAY<br>ON P1B 8G6<br>CAN",
    "addressPlain": "PO BOX 780GD STN MAIN NORTH BAY\\nON P1B 8G6\\nCAN"
  },
  {
    "id": "4026",
    "uic": "4026",
    "abbrevCFR": "BS 5DC Det",
    "officialName": "DÉTACHEMENT ALDERSHOT, BASE DE SOUTIEN DE LA 5E DIVISION DU CANADA GAGETOWN",
    "addressHtml": "PO BOX 820 STN MAIN KENTVILLE<br>NS B4N 4H8<br>CAN",
    "addressPlain": "PO BOX 820 STN MAIN KENTVILLE\\nNS B4N 4H8\\nCAN"
  },
  {
    "id": "5107",
    "uic": "5107",
    "abbrevCFR": "WEST NSR",
    "officialName": "THE WEST NOVA SCOTIA REGIMENT",
    "addressHtml": "PO BOX 820 STN MAIN KENTVILLE<br>NS B4N 4H8<br>CAN",
    "addressPlain": "PO BOX 820 STN MAIN KENTVILLE\\nNS B4N 4H8\\nCAN"
  },
  {
    "id": "4245",
    "uic": "4245",
    "abbrevCFR": "ÉCON FC",
    "officialName": "HA ÉCONOMATS DES FORCES CANADIENNES, DÉTACHEMENT HALIFAX",
    "addressHtml": "PO BOX 8836 STN A HALIFAX<br>NS B3K 5M6<br>CAN",
    "addressPlain": "PO BOX 8836 STN A HALIFAX\\nNS B3K 5M6\\nCAN"
  },
  {
    "id": "6225",
    "uic": "6225",
    "abbrevCFR": "2 R",
    "officialName": "NFLD R 2ND BATTALION, THE ROYAL NEWFOUNDLAND REGIMENT",
    "addressHtml": "PO BOX 958 STN MAIN CORNER BROOK<br>NL A2H 6J3<br>CAN",
    "addressPlain": "PO BOX 958 STN MAIN CORNER BROOK\\nNL A2H 6J3\\nCAN"
  },
  {
    "id": "3927",
    "uic": "3927",
    "abbrevCFR": "1 CAD",
    "officialName": "DET DÉT SHEARWATER QUARTIER GÉNÉRAL DE LA 1ER DIVN AÉRIENNE DU CANADA MARITIME HELO STANDARDS EVAL TEAM",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3998",
    "uic": "3998",
    "abbrevCFR": "1 CAD",
    "officialName": "DET DÉT ÉLÉMENT DE COORDINATION DE LA COMPOSANTE AÉRIENNE ATLANTIQUE, QUARTIER GÉNÉRAL DE LA 1ER DAC",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "2073",
    "uic": "2073",
    "abbrevCFR": "1 UD HALIF",
    "officialName": "1ER UNITÉ DENTAIRE DÉTACHEMENT HALIFAX",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "5021",
    "uic": "5021",
    "abbrevCFR": "1 RAC",
    "officialName": "1ER RÉGIMENT D'ARTILLERIE DE CAMPAGNE (HALIFAX-DARTMOUTH), ARC",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3232",
    "uic": "3232",
    "abbrevCFR": "12 EMA",
    "officialName": "12E ESCADRON DE MAINTENANCE (AIR)",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3395",
    "uic": "3395",
    "abbrevCFR": "QG 12 ERE",
    "officialName": "QUARTIER GÉNÉRAL DE LA 12E ESCADRE",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3173",
    "uic": "3173",
    "abbrevCFR": "3 INT COY",
    "officialName": "3E COMPAGNIE DU RENSEIGNEMENT",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "6478",
    "uic": "6478",
    "abbrevCFR": "3 Régt PM",
    "officialName": "3E RÉGIMENT DE LA POLICE MILITAIRE",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "6273",
    "uic": "6273",
    "abbrevCFR": "33 Amb C",
    "officialName": "33E AMBULANCE DE CAMPAGNE (HALIFAX)",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3662",
    "uic": "3662",
    "abbrevCFR": "QG 36 GBC",
    "officialName": "QUARTIER GÉNÉRAL DU 36E GROUPE-BRIGADE DU CANADA",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "5052",
    "uic": "5052",
    "abbrevCFR": "36 RGC",
    "officialName": "36E RÉGIMENT DU GÉNIE DE COMBAT",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "5244",
    "uic": "5244",
    "abbrevCFR": "36 SBN Det",
    "officialName": "DÉTACHEMENT HALIFAX, 36E BATAILLON DES SERVICES (HALIFAX)",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "6707",
    "uic": "6707",
    "abbrevCFR": "36 Régt tr",
    "officialName": "36E RÉGIMENT DES TRANSMISSIONS",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "6700",
    "uic": "6700",
    "abbrevCFR": "36 Bon Svc",
    "officialName": "36E BATAILLON DES SERVICES",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3983",
    "uic": "3983",
    "abbrevCFR": "4 QG SVC S",
    "officialName": "DÉTACHEMENT HALIFAX QUARTIER GÉNÉRAL DU 4E GROUPE DES SERVICES DE SANTÉ",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "1315",
    "uic": "1315",
    "abbrevCFR": "406 Esc (M",
    "officialName": "406E ESCADRON MARITIME D'ENTRAINEMENT OPÉRATIONNEL",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "1312",
    "uic": "1312",
    "abbrevCFR": "423 Esc (H",
    "officialName": "423E ESCADRON D'HÉLICOPTÈRE MARITIME",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3011",
    "uic": "3011",
    "abbrevCFR": "QG 5 Div C",
    "officialName": "QUARTIER GÉNÉRAL DE LA 5E DIVISION DU CANADA",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "0251",
    "uic": "0251",
    "abbrevCFR": "76 Halifax",
    "officialName": "76E RÉGIMENT DES COMMUNICATIONS DÉTACHEMENT HALIFAX",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "6770",
    "uic": "6770",
    "abbrevCFR": "77 HALIFAX 77",
    "officialName": "RÉGIMENT DES LIGNES DÉTACHEMENT (HALIFAX)",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "2800",
    "uic": "2800",
    "abbrevCFR": "AJAG ATLAN",
    "officialName": "ASSISTANT JUGE-AVOCAT GÉNÉRAL ATLANTIQUE",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "6907",
    "uic": "6907",
    "abbrevCFR": "ASTERIX UNITÉ",
    "officialName": "NAVALE DE REVITAILLEMENT ASTÉRIX",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3640",
    "uic": "3640",
    "abbrevCFR": "CEMM HALIF",
    "officialName": "CHEF D'ÉTAT-MAJOR DE LA MARINE, DÉTACHEMENT HALIFAX",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "6972",
    "uic": "6972",
    "abbrevCFR": "UT FAC NS/",
    "officialName": "UNITÉ DE TRANSITION DES FORCES ARMÉES CANADIENNES (NOUVELLE-ÉCOSSE ET TERRE-NEUVE-ET-LABRADOR)",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3767",
    "uic": "3767",
    "abbrevCFR": "QG FLTCANL",
    "officialName": "QUARTIER GÉNÉRAL DE LA FLOTTE CANADIENNE DE L'ATLANTIQUE",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "9523",
    "uic": "9523",
    "abbrevCFR": "FLTCANLANT FLOTTE",
    "officialName": "CANADIENNE DE L'ATLANTIQUE",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "6865",
    "uic": "6865",
    "abbrevCFR": "QG FSC DET",
    "officialName": "QUARTIER GÉNÉRAL DE LA FORCE SOUS-MARINE CANADIENNE DET HALIFAX",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "1340",
    "uic": "1340",
    "abbrevCFR": "DMFC BEDFO",
    "officialName": "DÉPÔT DE MUNITIONS DES FORCES CANADIENNES BEDFORD",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "0100",
    "uic": "0100",
    "abbrevCFR": "BFC HALIFA",
    "officialName": "BASE DES FORCES CANADIENNES HALIFAX",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "2698",
    "uic": "2698",
    "abbrevCFR": "CGNFC CENTRE",
    "officialName": "DE GUERRE NAVALE DES FORCES CANADIENNES",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "2224",
    "uic": "2224",
    "abbrevCFR": "SSPFC Halifax",
    "officialName": "SECTON DU SERVICE POSTALE DES FORCES CANADIENNES (HALIFAX)",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3479",
    "uic": "3479",
    "abbrevCFR": "SFC HALIFA",
    "officialName": "STATION DES FORCES CANADIENNES LEITRIM, DÉTACHEMENT HALIFAX",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "0461",
    "uic": "0461",
    "abbrevCFR": "FA(A) FORMATION",
    "officialName": "AUGMENTATION (ATLANTIQUE)",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "1202",
    "uic": "1202",
    "abbrevCFR": "UPF(A) UNITÉ",
    "officialName": "DE PLONGÉE DE LA FLOTTE (ATLANTIQUE)",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3554",
    "uic": "3554",
    "abbrevCFR": "IMF CAPE S",
    "officialName": "INSTALLATION DE MAINTENANCE DE LA FLOTTE - CAPE SCOTT",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3578",
    "uic": "3578",
    "abbrevCFR": "C SVC S(A)",
    "officialName": "CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES (ATLANTIQUE)",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "6595",
    "uic": "6595",
    "abbrevCFR": "Hal Rif",
    "officialName": "THE HALIFAX RIFLES (RCAC)",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "7713",
    "uic": "7713",
    "abbrevCFR": "HMCS ATHAB",
    "officialName": "Navire canadien de Sa Majesté ATHABASKAN",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "1680",
    "uic": "1680",
    "abbrevCFR": "NCSM CHARL",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ CHARLOTTETOWN",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3818",
    "uic": "3818",
    "abbrevCFR": "NCSM CHICO",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ CHICOUTIMI",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "6906",
    "uic": "6906",
    "abbrevCFR": "NCSM DEWOL",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ HARRY DEWOLF",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3354",
    "uic": "3354",
    "abbrevCFR": "NCSM EDMON",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ EDMONTON",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "1678",
    "uic": "1678",
    "abbrevCFR": "NCSM FREDE",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ FRÉDERICTON",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "6933",
    "uic": "6933",
    "abbrevCFR": "NCSM FRÉDÉ",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ FRÉDÉRICK ROLETTE",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3352",
    "uic": "3352",
    "abbrevCFR": "NCSM GLACE",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ GLACE BAY",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3358",
    "uic": "3358",
    "abbrevCFR": "NCSM GOOSE",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ GOOSE BAY",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "1244",
    "uic": "1244",
    "abbrevCFR": "NCSM HALIF",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ HALIFAX",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3351",
    "uic": "3351",
    "abbrevCFR": "NCSM KINGS",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ KINGSTON",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "6930",
    "uic": "6930",
    "abbrevCFR": "NCSM MARGA",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ MARGARET BROOKE",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3359",
    "uic": "3359",
    "abbrevCFR": "NCSM MONCT",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ MONCTON",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "1677",
    "uic": "1677",
    "abbrevCFR": "NCSM MONTR",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ MONTRÉAL",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3353",
    "uic": "3353",
    "abbrevCFR": "NCSM NANAI",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ NANAIMO",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "1307",
    "uic": "1307",
    "abbrevCFR": "NCSM ORIOL",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ ORIOLE",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "1321",
    "uic": "1321",
    "abbrevCFR": "NCSM SCOTI",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ SCOTIAN",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3355",
    "uic": "3355",
    "abbrevCFR": "NCSM SHAWI",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ SHAWINIGAN",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "1681",
    "uic": "1681",
    "abbrevCFR": "NCSM ST JO",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ",
    "addressHtml": "ST JOHN'S PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "ST JOHN'S PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3362",
    "uic": "3362",
    "abbrevCFR": "NCSM SUMME",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ SUMMERSIDE",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "1237",
    "uic": "1237",
    "abbrevCFR": "NCSM TORON",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ TORONTO",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "6932",
    "uic": "6932",
    "abbrevCFR": "NCSM WILLI",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ WILLIAM HALL",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3816",
    "uic": "3816",
    "abbrevCFR": "NCSM WINDS",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ WINDSOR",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3357",
    "uic": "3357",
    "abbrevCFR": "NCSM YELLO",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ YELLOWKNIFE",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "4230",
    "uic": "4230",
    "abbrevCFR": "BSH BUREAU",
    "officialName": "DES SERVICES HYDROGRAPHIQUE, HALIFAX",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "4236",
    "uic": "4236",
    "abbrevCFR": "CCCOS Hali",
    "officialName": "CENTRE CONJOINT DE COORDINATION DES OPÉRATIONS DE SAUVETAGE (HALIFAX)",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "6398",
    "uic": "6398",
    "abbrevCFR": "QG FOIA",
    "officialName": "QUARTIER GÉNÉRAL DE LA FORCE OPÉRATIONNELLE INTERARMÉES",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "1377",
    "uic": "1377",
    "abbrevCFR": "MUSIQUE FM",
    "officialName": "LA MUSIQUE DES FORCES MARITIMES DE L'ATLANTIQUE",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3078",
    "uic": "3078",
    "abbrevCFR": "QG FMAR(A)",
    "officialName": "QUARTIER GÉNÉRAL DES FORCES MARITIMES DE L'ATLANTIQUE",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "6672",
    "uic": "6672",
    "abbrevCFR": "UPM HALIFA",
    "officialName": "UNITÉ DE LA POLICE MILITAIRE HALIFAX",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3293",
    "uic": "3293",
    "abbrevCFR": "EN (A)",
    "officialName": "L'ÉCOLE NAVALE (ATLANTIQUE)",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3292",
    "uic": "3292",
    "abbrevCFR": "CDIM(A) CENTRE",
    "officialName": "DE DEVELOPPEMENT DE L'INSTRUCTION DE LA MARINE (ATLANTIQUE)",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "8388",
    "uic": "8388",
    "abbrevCFR": "QG GIM DET",
    "officialName": "QUARTIER GÉNÉRAL DU GROUPE DE L'INSTRUCTION DE LA MARINE DÉTACHEMENT HALIFAX",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "6946",
    "uic": "6946",
    "abbrevCFR": "GOTN DET E",
    "officialName": "GROUPE DES OPÉRATIONS TACTIQUES NAVALES DÉTACHEMENT EST",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3973",
    "uic": "3973",
    "abbrevCFR": "AP ATLANTI",
    "officialName": "SOUS-MINISTRE ADJOINT (AFFAIRES PUBLIQUES) DE L'ATLANTIQUE",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3786",
    "uic": "3786",
    "abbrevCFR": "CCP ATLANT",
    "officialName": "CENTRE DE CONTRÔLE DU PERSONNEL (ATLANTIQUE)",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "5104",
    "uic": "5104",
    "abbrevCFR": "PLF THE",
    "officialName": "PRINCESS LOUISE FUSILIERS",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "0307",
    "uic": "0307",
    "abbrevCFR": "WCAQ COAST",
    "officialName": "WORKCENTRE DE L'ASSURANCE DE QUALITÉ (COASTAL et NCR)",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "4293",
    "uic": "4293",
    "abbrevCFR": "ERIC ATLAN",
    "officialName": "ÉCOLE RÉGIONALE D'INSTRUCTION DES CADETS (ATLANTIQUE)",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "4286",
    "uic": "4286",
    "abbrevCFR": "ERET ATLAN",
    "officialName": "ÉCOLE RÉGIONALE DE CADET D'ENTRAINEMENT TERRESTRE (ATLANTIQUE)",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "4285",
    "uic": "4285",
    "abbrevCFR": "ERNV ATLAN",
    "officialName": "ÉCOLE RÉGIONAL DE CADET DE NAV À VOILE (ATLANTIQUE)",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3933",
    "uic": "3933",
    "abbrevCFR": "URSC ATLAN",
    "officialName": "UNITÉ RÉGIONALE DE SOUTIEN AUX CADETS (ATLANTIQUE)",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "4299",
    "uic": "4299",
    "abbrevCFR": "URSC(A) HA",
    "officialName": "UNITÉ RÉGIONALE DE SOUTIEN AUX CADETS (ATLANTIQUE) DÉTACHEMENT HALIFAX",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "6845",
    "uic": "6845",
    "abbrevCFR": "UOI (Atlantic)",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (ATLANTIQUE)",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3093",
    "uic": "3093",
    "abbrevCFR": "EM(A) ENTRAÎNEMENT",
    "officialName": "MARITIME (ATLANTIQUE)",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "3225",
    "uic": "3225",
    "abbrevCFR": "TRINITY TRINITY,",
    "officialName": "LE CENTRE DE RENSEIGNEMENT ET DE SOUTIEN DES OPÉRATIONS MARITIMES",
    "addressHtml": "PO BOX 99000 STN FORCES HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCES HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "6560",
    "uic": "6560",
    "abbrevCFR": "CT Halifax",
    "officialName": "CENTRE DE TRANSITION HALIFAX",
    "addressHtml": "PO BOX 99000 STN FORCESBLDG S-21, CFB HALIFAX HALIFAX<br>NS B3K 5X5<br>CAN",
    "addressPlain": "PO BOX 99000 STN FORCESBLDG S-21, CFB HALIFAX HALIFAX\\nNS B3K 5X5\\nCAN"
  },
  {
    "id": "2112",
    "uic": "2112",
    "abbrevCFR": "1 Hop C CA",
    "officialName": "1ER HÔPITAL DE CAMPAGNE DU CANADA",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "2055",
    "uic": "2055",
    "abbrevCFR": "1 Unité",
    "officialName": "Dent 1ER UNITÉ DENTAIRE DÉTACHEMENT PETAWAWA",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "1847",
    "uic": "1847",
    "abbrevCFR": "1 RCR",
    "officialName": "1ER BATAILLON, THE ROYAL CANADIAN RÉGIMENT",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "0995",
    "uic": "0995",
    "abbrevCFR": "Dét Petawa",
    "officialName": "DÉTACHEMENT PETAWAWA, QUARTIER GÉNÉRAL DE 1ER ESCADRE",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "1774",
    "uic": "1774",
    "abbrevCFR": "2 RGC",
    "officialName": "2E RÉGIMENT DU GÉNIE DE COMBAT",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "1702",
    "uic": "1702",
    "abbrevCFR": "QG &",
    "officialName": "Esc Trans",
    "addressHtml": "2 GBMC QUARTIER GÉNÉRAL ET ESCADRON DES TRANSMISSIONS DU 2E GROUPE-BRIGADE MÉCANISÉ DU CANADA PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "2 GBMC QUARTIER GÉNÉRAL ET ESCADRON DES TRANSMISSIONS DU 2E GROUPE-BRIGADE MÉCANISÉ DU CANADA PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "2104",
    "uic": "2104",
    "abbrevCFR": "2 Amb C",
    "officialName": "2E AMBULANCE DE CAMPAGNE",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "1764",
    "uic": "1764",
    "abbrevCFR": "2 RCHA",
    "officialName": "2E RÉGIMENT, ROYAL CANADIAN HORSE ARTILLERY",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "2101",
    "uic": "2101",
    "abbrevCFR": "2 Bn Svc",
    "officialName": "2E BATAILLON DES SERVICES",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "3520",
    "uic": "3520",
    "abbrevCFR": "3 RCR",
    "officialName": "3E BATAILLON, THE ROYAL CANADIAN REGIMENT",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "0107",
    "uic": "0107",
    "abbrevCFR": "BS 4",
    "officialName": "Div Ca Petawawa BASSE DE SOUTIEN DE LA 4E DIVISION DU CANADA PETAWAWA",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "1832",
    "uic": "1832",
    "abbrevCFR": "ET",
    "officialName": "GS",
    "addressHtml": "4 Div CA ESCADRON DES TRANSMISSIONS DU GROUPE DE SOUTIEN DE LA 4E DIVISION DU CANADA PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "4 Div CA ESCADRON DES TRANSMISSIONS DU GROUPE DE SOUTIEN DE LA 4E DIVISION DU CANADA PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "3525",
    "uic": "3525",
    "abbrevCFR": "CI4DC DET",
    "officialName": "DÉTACHEMENT PETAWAWA, CENTRE D'INSTRUCTION DE LA 4E DIVISION DU CANADA",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "2569",
    "uic": "2569",
    "abbrevCFR": "427 ESC OS",
    "officialName": "427E ESCADRON D'OPÉRATIONS SPÉCIALES D'AVIATION",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "6772",
    "uic": "6772",
    "abbrevCFR": "77 PETAWAW",
    "officialName": "77E RÉGIMENT DES LIGNES DÉTACHEMENT PETAWAWA",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "1015",
    "uic": "1015",
    "abbrevCFR": "ELE B",
    "officialName": "2E ESCADRON D OPERATIONS D?APPUI AERIEN ESCADRILLE B",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "6977",
    "uic": "6977",
    "abbrevCFR": "UT FAC E O",
    "officialName": "UNITÉ DE TRANSITION DES FORCES ARMÉES CANADIENNES (EST DE L'ONTARIO)",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "3720",
    "uic": "3720",
    "abbrevCFR": "CFHA PETAW",
    "officialName": "AGENCE DE LOGEMENT DES FORCES CANADIENNES (PETAWAWA)",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "1910",
    "uic": "1910",
    "abbrevCFR": "CMED DÉPOT",
    "officialName": "CENTRAL DE MATÉRIEL MÉDICAL",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "6448",
    "uic": "6448",
    "abbrevCFR": "RÉGT OSC",
    "officialName": "RÉGIMENT DES OPÉRATIONS SPÉCIALES DU CANADA",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "6795",
    "uic": "6795",
    "abbrevCFR": "CEOSC CENTRE",
    "officialName": "D'ENTRAÎNEMENT DES OPÉRATIONS SPÉCIALES DU CANADA",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "6815",
    "uic": "6815",
    "abbrevCFR": "Dét Petawa",
    "officialName": "RÉGIMENT DU RENSEIGNEMENT DE L'ARMÉE CANADIENNE DETACHMENT PETAWAWA",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "2852",
    "uic": "2852",
    "abbrevCFR": "JAA PETAWAWA",
    "officialName": "JUGE-AVOCAT ADJOINT (PETAWAWA)",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "6557",
    "uic": "6557",
    "abbrevCFR": "Dét Petawa",
    "officialName": "CENTRE DE TRANSITION PETAWAWA",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "1754",
    "uic": "1754",
    "abbrevCFR": "RCD THE",
    "officialName": "ROYAL CANADIAN DRAGOONS",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "6889",
    "uic": "6889",
    "abbrevCFR": "UOI (Petawawa)",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (ONTARIO) DÉTACHMENT PETAWAWA",
    "addressHtml": "PO BOX 9999 STN MAIN PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAIN PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "6651",
    "uic": "6651",
    "abbrevCFR": "",
    "officialName": "450e Esc 450E ESCADRON TACTIQUE D'HÉLICOPTÈRES",
    "addressHtml": "PO BOX 9999 STN MAINBUILDING CC-128 PETAWAWA<br>ON K8H 2X3<br>CAN",
    "addressPlain": "PO BOX 9999 STN MAINBUILDING CC-128 PETAWAWA\\nON K8H 2X3\\nCAN"
  },
  {
    "id": "3096",
    "uic": "3096",
    "abbrevCFR": "ÉCON FC",
    "officialName": "GE ÉCONOMATS DES FORCES CANADIENNES DÉTACHEMENT(GIELENKIRCHEN) POSTFACH",
    "addressHtml": "1280 GEILENKIRCHEN<br>DEU",
    "addressPlain": "1280 GEILENKIRCHEN\\nDEU"
  },
  {
    "id": "0037",
    "uic": "0037",
    "abbrevCFR": "CRFC DET S",
    "officialName": "DÉTACHEMENT SYDNEY, CENTRE DE RECRUTEMENT DES FORCES CANADIENNES HALIFAX PRINCE",
    "addressHtml": "STREET PLAZA, 325 PRINCE STREET SYDNEY<br>NS B1P 5K6<br>CAN",
    "addressPlain": "STREET PLAZA, 325 PRINCE STREET SYDNEY\\nNS B1P 5K6\\nCAN"
  },
  {
    "id": "1339",
    "uic": "1339",
    "abbrevCFR": "NCSM QUEEN",
    "officialName": "NAVIRE CANADIEN DE SA MAJESTÉ QUEEN QUEEN BUILDING",
    "addressHtml": "100 NAVY WAY REGINA<br>SK S4P 4K6<br>CAN",
    "addressPlain": "100 NAVY WAY REGINA\\nSK S4P 4K6\\nCAN"
  },
  {
    "id": "3961",
    "uic": "3961",
    "abbrevCFR": "Dét Regina",
    "officialName": "DÉTACHEMENT RÉGINA 23E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES RM",
    "addressHtml": "110 1820 HAMILTON ST REGINA<br>SK S4P 4K7<br>CAN",
    "addressPlain": "110 1820 HAMILTON ST REGINA\\nSK S4P 4K7\\nCAN"
  },
  {
    "id": "3508",
    "uic": "3508",
    "abbrevCFR": "CI 4 Div C",
    "officialName": "CENTRE D'INSTRUCTION DE LA 4E DIVISION DU CANADA RR",
    "addressHtml": "1 GREY RD 112 - VALOUR ROAD MEAFORD<br>ON N4L 0A1<br>CAN",
    "addressPlain": "1 GREY RD 112 - VALOUR ROAD MEAFORD\\nON N4L 0A1\\nCAN"
  },
  {
    "id": "3580",
    "uic": "3580",
    "abbrevCFR": "Dét Meafor",
    "officialName": "DÉTACHEMENT MEAFORD 31E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES RR",
    "addressHtml": "1 GREY RD 112 - VALOUR ROAD MEAFORD<br>ON N4L 0A1<br>CAN",
    "addressPlain": "1 GREY RD 112 - VALOUR ROAD MEAFORD\\nON N4L 0A1\\nCAN"
  },
  {
    "id": "1177",
    "uic": "1177",
    "abbrevCFR": "LRP 2 Div CA",
    "officialName": "CADRE DE LA PREMIÈRE RÉSERVE DE LA 2e DIVISION DU CANADA",
    "addressHtml": "RUE 6560 HOCHELAGA MONTREAL<br>QC H1N 1X9<br>CAN",
    "addressPlain": "RUE 6560 HOCHELAGA MONTREAL\\nQC H1N 1X9\\nCAN"
  },
  {
    "id": "0130",
    "uic": "0130",
    "abbrevCFR": "BS 2",
    "officialName": "Div CA Det Montreal DÉTACHEMENT MONTRÉAL, BASE DE SOUTIEN DE LA 2E DIVISION DU CANADA, VALCARTIER",
    "addressHtml": "RUE 6560 HOCHELAGA MONTREAL<br>QC H1N 1X9<br>CAN",
    "addressPlain": "RUE 6560 HOCHELAGA MONTREAL\\nQC H1N 1X9\\nCAN"
  },
  {
    "id": "3981",
    "uic": "3981",
    "abbrevCFR": "QG 4",
    "officialName": "Gp Svc S QUARTIER GÉNÉRAL DU 4E GROUPE DES SERVICES DE SANTÉ",
    "addressHtml": "RUE 6560 HOCHELAGA MONTREAL<br>QC H1N 1X9<br>CAN",
    "addressPlain": "RUE 6560 HOCHELAGA MONTREAL\\nQC H1N 1X9\\nCAN"
  },
  {
    "id": "3172",
    "uic": "3172",
    "abbrevCFR": "4 Cie Rens",
    "officialName": "4E COMPAGNIE DU RENSEIGNEMENT",
    "addressHtml": "RUE 6560 HOCHELAGA MONTREAL<br>QC H1N 1X9<br>CAN",
    "addressPlain": "RUE 6560 HOCHELAGA MONTREAL\\nQC H1N 1X9\\nCAN"
  },
  {
    "id": "3801",
    "uic": "3801",
    "abbrevCFR": "41 C",
    "officialName": "Svc S FC Det Mtl DETACHEMENT LONGUE POINTE 41E CENTRE DES SERVICES DE SANTE DES FORCES CANADIENNES",
    "addressHtml": "RUE 6560 HOCHELAGA MONTREAL<br>QC H1N 1X9<br>CAN",
    "addressPlain": "RUE 6560 HOCHELAGA MONTREAL\\nQC H1N 1X9\\nCAN"
  },
  {
    "id": "6422",
    "uic": "6422",
    "abbrevCFR": "CMSEA CENTRE",
    "officialName": "DE LA MISE EN SERVICE DE L'ÉQUIPMENT DE L'ARMÉE",
    "addressHtml": "RUE 6560 HOCHELAGA MONTREAL<br>QC H1N 1X9<br>CAN",
    "addressPlain": "RUE 6560 HOCHELAGA MONTREAL\\nQC H1N 1X9\\nCAN"
  },
  {
    "id": "1558",
    "uic": "1558",
    "abbrevCFR": "ÉMIS EU",
    "officialName": "ÉTAT-MAJOR INTERARMÉES STRATÉGIQUE HORS CANADA - ÉTAT-UNIS RUSSELL OFFICES CANBERRA",
    "addressHtml": "ACT<br>AUS",
    "addressPlain": "ACT\\nAUS"
  },
  {
    "id": "0008",
    "uic": "0008",
    "abbrevCFR": "DET R CFRC",
    "officialName": "DÉTACHEMENT RÉGINA CENTRE DE RECRUTEMENT DES FORCES CANADIENNES CALGARY SUITE",
    "addressHtml": "140 1783 HAMILTON STREET REGINA<br>SK S4P 2B6<br>CAN",
    "addressPlain": "140 1783 HAMILTON STREET REGINA\\nSK S4P 2B6\\nCAN"
  },
  {
    "id": "6346",
    "uic": "6346",
    "abbrevCFR": "AP PRAIRIE",
    "officialName": "SOUS-MINISTRE ADJOINT (AFFAIRES PUBLIQUES) DES PRAIRIES ET DU NORD SUITE",
    "addressHtml": "574 220 4TH AVE SE CALGARY<br>AB T2G 4X3<br>CAN",
    "addressPlain": "574 220 4TH AVE SE CALGARY\\nAB T2G 4X3\\nCAN"
  },
  {
    "id": "5106",
    "uic": "5106",
    "abbrevCFR": "NS(NB)R THE",
    "officialName": "NORTH SHORE (NEW BRUNSWICK) REGIMENT THE COLONEL CCL GAMMON ARMOURY",
    "addressHtml": "1820 KING AVENUE BATHURST<br>NB E2A 4Z7<br>CAN",
    "addressPlain": "1820 KING AVENUE BATHURST\\nNB E2A 4Z7\\nCAN"
  },
  {
    "id": "6556",
    "uic": "6556",
    "abbrevCFR": "Dét Toront",
    "officialName": "CENTRE DE TRANSITION TORONTO",
    "addressHtml": "THE LCOL GEORGE TAYLOR DENISON ARMOURY 1 YUKON LANE RM C110 TORONTO<br>ON M3K 0A1<br>CAN",
    "addressPlain": "THE LCOL GEORGE TAYLOR DENISON ARMOURY 1 YUKON LANE RM C110 TORONTO\\nON M3K 0A1\\nCAN"
  },
  {
    "id": "3506",
    "uic": "3506",
    "abbrevCFR": "1 DAC",
    "officialName": "Det DÉT ÉLÉMENT DE COORDINATION DE LA COMPOSANTE AÉRIENNE CENTRAL, QUARTIER GÉNÉRAL DE LA 1ER DAC",
    "addressHtml": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO<br>ON M3K 0A1<br>CAN",
    "addressPlain": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO\\nON M3K 0A1\\nCAN"
  },
  {
    "id": "2056",
    "uic": "2056",
    "abbrevCFR": "Dét",
    "officialName": "T",
    "addressHtml": "1 UD 1ER UNITÉ DENTAIRE DÉTACHEMENT TORONTO THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO<br>ON M3K 0A1<br>CAN",
    "addressPlain": "1 UD 1ER UNITÉ DENTAIRE DÉTACHEMENT TORONTO THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO\\nON M3K 0A1\\nCAN"
  },
  {
    "id": "3171",
    "uic": "3171",
    "abbrevCFR": "2 INT COY",
    "officialName": "2E COMPAGNIE DU RENSEIGNEMENT",
    "addressHtml": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO<br>ON M3K 0A1<br>CAN",
    "addressPlain": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO\\nON M3K 0A1\\nCAN"
  },
  {
    "id": "6477",
    "uic": "6477",
    "abbrevCFR": "2 Regt PM",
    "officialName": "2E RÉGIMENT DE LA POLICE MILITAIRE",
    "addressHtml": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO<br>ON M3K 0A1<br>CAN",
    "addressPlain": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO\\nON M3K 0A1\\nCAN"
  },
  {
    "id": "3658",
    "uic": "3658",
    "abbrevCFR": "QG 32 GBC",
    "officialName": "QUARTIER GÉNÉRAL DU 32E GROUPE-BRIGADE DU CANADA",
    "addressHtml": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO<br>ON M3K 0A1<br>CAN",
    "addressPlain": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO\\nON M3K 0A1\\nCAN"
  },
  {
    "id": "5048",
    "uic": "5048",
    "abbrevCFR": "32 RGC",
    "officialName": "32E RÉGIMENT DU GÉNIE DE COMBAT",
    "addressHtml": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO<br>ON M3K 0A1<br>CAN",
    "addressPlain": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO\\nON M3K 0A1\\nCAN"
  },
  {
    "id": "3588",
    "uic": "3588",
    "abbrevCFR": "32 C Svc S",
    "officialName": "32E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES",
    "addressHtml": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO<br>ON M3K 0A1<br>CAN",
    "addressPlain": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO\\nON M3K 0A1\\nCAN"
  },
  {
    "id": "5237",
    "uic": "5237",
    "abbrevCFR": "32 Bon Svc",
    "officialName": "32E BATAILLON DES SERVICES",
    "addressHtml": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO<br>ON M3K 0A1<br>CAN",
    "addressPlain": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO\\nON M3K 0A1\\nCAN"
  },
  {
    "id": "3183",
    "uic": "3183",
    "abbrevCFR": "QG 4 Div C",
    "officialName": "QUARTIER GÉNÉRAL DE LA 4E DIVISION DU CANADA",
    "addressHtml": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO<br>ON M3K 0A1<br>CAN",
    "addressPlain": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO\\nON M3K 0A1\\nCAN"
  },
  {
    "id": "3980",
    "uic": "3980",
    "abbrevCFR": "4 QG SVC S",
    "officialName": "DÉTACHEMENT TORONTO QUARTIER GÉNÉRAL DU 4E GROUPE DES SERVICES DE SANTÉ",
    "addressHtml": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO<br>ON M3K 0A1<br>CAN",
    "addressPlain": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO\\nON M3K 0A1\\nCAN"
  },
  {
    "id": "1178",
    "uic": "1178",
    "abbrevCFR": "4CdnDivPRL LISTE",
    "officialName": "RÉSERVE PRIMAIRE - 4E DIVISION DU CANADA",
    "addressHtml": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO<br>ON M3K 0A1<br>CAN",
    "addressPlain": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO\\nON M3K 0A1\\nCAN"
  },
  {
    "id": "3682",
    "uic": "3682",
    "abbrevCFR": "AJAG CENTR",
    "officialName": "ASSISTANT JUGE-AVOCAT GÉNÉRAL CENTRE",
    "addressHtml": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO<br>ON M3K 0A1<br>CAN",
    "addressPlain": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO\\nON M3K 0A1\\nCAN"
  },
  {
    "id": "2778",
    "uic": "2778",
    "abbrevCFR": "CENTRALE SOUS-MINISTRE",
    "officialName": "ADJOINT (AFFAIRES PUBLIQUES) DE l'ONTARIO",
    "addressHtml": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO<br>ON M3K 0A1<br>CAN",
    "addressPlain": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO\\nON M3K 0A1\\nCAN"
  },
  {
    "id": "3536",
    "uic": "3536",
    "abbrevCFR": "Det TORONT",
    "officialName": "DÉTACHEMENT TORONTO, BASE DE SOUTIEN DE LA 4E DIVISION DU CANADA, PETAWAWA",
    "addressHtml": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO<br>ON M3K 0A1<br>CAN",
    "addressPlain": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO\\nON M3K 0A1\\nCAN"
  },
  {
    "id": "5001",
    "uic": "5001",
    "abbrevCFR": "GGHG THE",
    "officialName": "GOVERNOR GENERAL'S HORSE GUARDS",
    "addressHtml": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO<br>ON M3K 0A1<br>CAN",
    "addressPlain": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO\\nON M3K 0A1\\nCAN"
  },
  {
    "id": "6437",
    "uic": "6437",
    "abbrevCFR": "QG FOIC",
    "officialName": "QUARTIER GÉNÉRAL DE LA FORCE OPÉRATIONNELLE INTERARMÉES (CENTRE)",
    "addressHtml": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO<br>ON M3K 0A1<br>CAN",
    "addressPlain": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO\\nON M3K 0A1\\nCAN"
  },
  {
    "id": "0854",
    "uic": "0854",
    "abbrevCFR": "URSC(C) TO",
    "officialName": "DÉTACHEMENT TORONTO, UNITÉ RÉGIONALE DE SOUTIEN AUX CADETS (CENTRE)",
    "addressHtml": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO<br>ON M3K 0A1<br>CAN",
    "addressPlain": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO\\nON M3K 0A1\\nCAN"
  },
  {
    "id": "6843",
    "uic": "6843",
    "abbrevCFR": "UOI (Ontario)",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (ONTARIO)",
    "addressHtml": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO<br>ON M3K 0A1<br>CAN",
    "addressPlain": "THE LCOL GEORGE TAYLOR DENISON IIIARMOURY 1 YUKON LANE, TORONTO\\nON M3K 0A1\\nCAN"
  },
  {
    "id": "5069",
    "uic": "5069",
    "abbrevCFR": "33 Régt tr",
    "officialName": "33E RÉGIMENT DES TRANSMISSIONS THE MAJOR EJG HOLLAND VC ARMOURY",
    "addressHtml": "2100 WALKLEY RD OTTAWA<br>ON K1A 0K2<br>CAN",
    "addressPlain": "2100 WALKLEY RD OTTAWA\\nON K1A 0K2\\nCAN"
  },
  {
    "id": "6703",
    "uic": "6703",
    "abbrevCFR": "39 Bon Svc",
    "officialName": "39E BATAILLON DES SERVICES THE SHERMAN ARMOURY",
    "addressHtml": "5500 NO. 4 RD RICHMOND<br>BC V6X 3L5<br>CAN",
    "addressPlain": "5500 NO. 4 RD RICHMOND\\nBC V6X 3L5\\nCAN"
  },
  {
    "id": "1549",
    "uic": "1549",
    "abbrevCFR": "TRINIT-WHI DÉTACHEMENT",
    "officialName": "WHIDBEY ISLAND, TRINITY THEATER UNDERSEA SURVEILLANCE COMMAND PACIFIC",
    "addressHtml": "1280 WEST INTRUDER STREET OAK HARBOR<br>WA 982789400<br>USA",
    "addressPlain": "1280 WEST INTRUDER STREET OAK HARBOR\\nWA 982789400\\nUSA"
  },
  {
    "id": "4052",
    "uic": "4052",
    "abbrevCFR": "31 C SVC S",
    "officialName": "DÉTACHEMENT SUDBURY 31E CENTRE DES SERVICES DE SANTÉ DES FORCES CANADIENNES UNIT",
    "addressHtml": "15 BRADY SQUARE 233 BRADY ST E SUDBURY<br>ON P3B 4H5<br>CAN",
    "addressPlain": "15 BRADY SQUARE 233 BRADY ST E SUDBURY\\nON P3B 4H5\\nCAN"
  },
  {
    "id": "0029",
    "uic": "0029",
    "abbrevCFR": "CRFC DET",
    "officialName": "DÉTACHEMENT SUDBURY, CENTRE DE RECRUTEMENT DES FORCES CANADIENNES OTTAWA UNIT",
    "addressHtml": "17 BRADY SQUARE 233 BRADY STE SUDBURY<br>ON P3B 4H5<br>CAN",
    "addressPlain": "17 BRADY SQUARE 233 BRADY STE SUDBURY\\nON P3B 4H5\\nCAN"
  },
  {
    "id": "3802",
    "uic": "3802",
    "abbrevCFR": "OMB OMBUDSMAN",
    "officialName": "URBANDALE BUILDING, 12TH FLOOR 100METCALFE",
    "addressHtml": "ST OTTAWA<br>ON K1P 5M1<br>CAN",
    "addressPlain": "ST OTTAWA\\nON K1P 5M1\\nCAN"
  },
  {
    "id": "6376",
    "uic": "6376",
    "abbrevCFR": "RGN NO/SE",
    "officialName": "RÉGION NORVÈGE / SUÈDE VIA GIORGIO PELOSI",
    "addressHtml": "1 00143 ROMA-CECCHIGNOLA<br>ITA",
    "addressPlain": "1 00143 ROMA-CECCHIGNOLA\\nITA"
  },
  {
    "id": "5251",
    "uic": "5251",
    "abbrevCFR": "20 Bie Aut",
    "officialName": "20E BATTERIE AUTONOME DE CAMPAGNE, ARC VIMY RIDGE ARMORIES",
    "addressHtml": "337 STUBB ROSSRD LETHBRIDGE<br>AB T1K 7N3<br>CAN",
    "addressPlain": "337 STUBB ROSSRD LETHBRIDGE\\nAB T1K 7N3\\nCAN"
  },
  {
    "id": "8455",
    "uic": "8455",
    "abbrevCFR": "UOI (O) CA",
    "officialName": "UNITÉ DES OPÉRATIONS IMMOBILIÈRES (OUEST) DÉTACHEMENT CALGARY WATERS BUILDING",
    "addressHtml": "4225 CROWCHILD TRAIL SW CALGARY<br>AB T3E 1T8<br>CAN",
    "addressPlain": "4225 CROWCHILD TRAIL SW CALGARY\\nAB T3E 1T8\\nCAN"
  },
  {
    "id": "3666",
    "uic": "3666",
    "abbrevCFR": "QG 41 GBC",
    "officialName": "QUARTIER GÉNÉRAL DU 41E GROUPE-BRIGADE DU CANADA WATERS BUILDING 4225D CROWCHILD TRAIL SW CALGARY",
    "addressHtml": "AB T3E 7H2<br>CAN",
    "addressPlain": "AB T3E 7H2\\nCAN"
  }
];
