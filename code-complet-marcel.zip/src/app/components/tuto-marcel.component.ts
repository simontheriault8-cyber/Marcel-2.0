import { Component, EventEmitter, Output } from "@angular/core";
import { CommonModule } from "@angular/common";

@Component({
  selector: "app-tuto-marcel",
  imports: [CommonModule],
  template: `
    <div class="min-h-screen w-full bg-slate-100 flex flex-col justify-between text-slate-800">
      <!-- HEADER BAR -->
      <header class="bg-white border-b border-slate-200 px-6 py-3.5 flex items-center justify-between shadow-xs shrink-0 sticky top-0 z-20">
        <div class="flex items-center gap-3">
          <div class="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-indigo-800 text-white flex items-center justify-center font-black shadow-xs text-base">
            M
          </div>
          <div>
            <h1 class="text-base font-black text-slate-900 leading-none">
              Tutoriel MARCEL
            </h1>
            <p class="text-[11px] text-slate-500 mt-1">Vidéo de formation</p>
          </div>
        </div>
      </header>

      <!-- MAIN CONTENT (CENTERED CARD) -->
      <main class="flex-1 p-6 flex items-center justify-center">
        <div class="max-w-md w-full bg-white rounded-3xl border border-slate-200 p-8 shadow-sm text-center space-y-6">
          <div class="w-16 h-16 mx-auto rounded-2xl bg-red-50 text-red-600 flex items-center justify-center shadow-xs">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-9 w-9" fill="currentColor" viewBox="0 0 24 24">
              <path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"/>
            </svg>
          </div>

          <div class="space-y-1">
            <h2 class="text-lg font-black text-slate-900">
              Vidéo de formation MARCEL
            </h2>
            <p class="text-xs text-slate-500">
              Cliquez ci-dessous pour visionner le tutoriel sur YouTube :
            </p>
          </div>

          <a
            href="https://www.youtube.com/watch?v=F-9g3ImNPho"
            target="_blank"
            rel="noopener noreferrer"
            class="w-full inline-flex items-center justify-center gap-3 px-6 py-3.5 bg-red-600 hover:bg-red-700 text-white rounded-2xl text-sm font-bold shadow-md hover:shadow-lg transition-all active:scale-95 cursor-pointer"
          >
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"/>
            </svg>
            <span>Regarder la vidéo sur YouTube</span>
          </a>

          <!-- LE SEUL BOUTON DE RETOUR VERS LE CHOIX DE RÔLE -->
          <div class="pt-2">
            <button
              type="button"
              (click)="onBackToRoleChoice()"
              class="w-full inline-flex items-center justify-center gap-2 px-5 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-slate-900 rounded-2xl text-xs font-bold border border-slate-200 transition-all active:scale-95 cursor-pointer"
            >
              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
              <span>Retour au choix de rôle</span>
            </button>
          </div>
        </div>
      </main>

      <!-- FOOTER -->
      <footer class="py-4 text-center text-xs text-slate-400">
        MARCEL 2.0 — Outil d'aide au recrutement FAC
      </footer>
    </div>
  `,
})
export class TutoMarcelComponent {
  @Output() close = new EventEmitter<void>();

  onBackToRoleChoice() {
    this.close.emit();
  }
}
